import re, sys
aff_path, dic_path, out_path = sys.argv[1:4]
PFX, SFX = {}, {}
cur = None
lines = open(aff_path, encoding='utf-8').read().splitlines()
for ln in lines:
    p = ln.split()
    if not p or p[0] not in ('PFX', 'SFX'):
        continue
    if len(p) >= 4 and p[2] in ('Y', 'N') and p[3].isdigit():
        cur = (SFX if p[0] == 'SFX' else PFX).setdefault(p[1], {'cross': p[2] == 'Y', 'rules': []})
        continue
    if cur is None or len(p) < 4:
        continue
    strip = '' if p[2] == '0' else p[2]
    add = p[3].split('/')[0]
    cond = p[4] if len(p) > 4 else '.'
    if add == '0':
        add = ''
    # convert a Hunspell condition into a regex
    rx = re.sub(r'\[\^([^\]]+)\]', r'[^\1]', cond)
    rx = rx if rx != '.' else '.*'
    cur['rules'].append((strip, add, re.compile(rx + '$' if p[0] == 'SFX' else '^' + rx)))
    # record for prefix/suffix by kind
    cur['kind'] = p[0]

def rules_for(table, flags, kind):
    return [(f, table[f]) for f in flags if f in table and table[f]['kind'] == kind]

def apply_prefix(stem, rule):
    strip, add, rx = rule
    if strip and not stem.startswith(strip):
        return None
    if not rx.search(stem):
        return None
    return add + stem[len(strip):]

def apply_suffix(stem, rule):
    strip, add, rx = rule
    if strip and not stem.endswith(strip):
        return None
    if not rx.search(stem):
        return None
    return stem[:len(stem) - len(strip)] + add

forms = set()
count = 0
dic = open(dic_path, encoding='utf-8').read().splitlines()[1:]
for line in dic:
    if not line.strip():
        continue
    word, _, flagstr = line.partition('/')
    word = word.strip()
    flags = set(flagstr)
    if 'c' in flags or '!' in flags:          # compound-only, or NOSUGGEST (taboo) words
        continue
    if word != word.lower() or not re.fullmatch(r"[a-z’']+", word):
        continue                                # proper nouns, acronyms, numbers, symbols
    count += 1
    stem = word.replace('’', "'")
    bases = [(stem, False)]
    for f, pf in rules_for(PFX, flags, 'PFX'):
        for rule in pf['rules']:
            new = apply_prefix(stem, rule)
            if new is not None:
                bases.append((new, pf['cross']))
    for form, pcross in bases:
        forms.add(form)
        for f, sf in rules_for(SFX, flags, 'SFX'):
            if form != stem and not (pcross and sf['cross']):
                continue
            for rule in sf['rules']:
                new = apply_suffix(form, rule)
                if new is not None:
                    forms.add(new)
clean = sorted(w for w in forms if re.fullmatch(r"[a-z']{1,24}", w))
open(out_path, 'w', encoding='utf-8').write('\n'.join(clean) + '\n')
print('base entries used:', count, ' expanded forms:', len(clean))
