ENGLISH WORD LIST (ESDB)

The keyboard reads these files, in this order, for word suggestions, glide typing and auto-correction:

  scowl_35.txt   the most common words (ESDB size 35)
  scowl_50.txt   medium (ESDB size 50)
  scowl_60.txt   the standard spell-checking list (ESDB size 60)

If none of them is here, the keyboard falls back to words.txt in the assets folder.

To create the files (needs Python 3.7+ and SQLite 3.33+, on Linux, macOS or WSL):

    git clone https://github.com/en-wl/wordlist
    cd wordlist
    make
    ./scowl --db scowl.db word-list 35 A 1 --deaccent > scowl_35.txt
    ./scowl --db scowl.db word-list 50 A 1 --deaccent > scowl_50.txt
    ./scowl --db scowl.db word-list 60 A 1 --deaccent > scowl_60.txt

Copy the three files into this folder (app/src/main/assets/wordlist/) and rebuild the app.

The keyboard keeps only plain a-z words and apostrophes, up to 24 letters, and lower-cases them.
Licence: see COPYING-ESDB.txt (the notice that applies to an official English speller dictionary).
