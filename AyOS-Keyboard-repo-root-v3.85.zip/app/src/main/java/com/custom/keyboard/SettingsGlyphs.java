package com.custom.keyboard;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/**
 * Small vector pieces of the iOS-style Settings screen: the white symbols on the coloured icon tiles,
 * the row chevron, the back chevron and the check mark.
 *
 * Every tile symbol is a short list of drawing steps on a 30 x 30 grid, so it scales with the tile and
 * is drawn the same on every phone. The settings preview reads this same list.
 *
 *   L x1 y1 x2 y2          line (stroke)         O cx cy r       circle (stroke)
 *   D cx cy r              disc (fill)           E cx cy rx ry   ellipse (stroke)
 *   R x y w h r            rounded rect (stroke) Q x y w h r     rounded rect (fill)
 *   A cx cy r start sweep  arc (stroke)          W cx cy r start sweep   pie (fill)
 *   P x y x y ...          polygon (fill)
 * Angles are in degrees, clockwise from 3 o'clock, as in Canvas.drawArc.
 */
final class SettingsGlyphs {

    private SettingsGlyphs() {}

    static final float GRID = 30f;
    static final float STROKE = 2.0f;

    /** Settings card corner exponent: G2 continuous (smooth) curvature, like the keys' squircle. 2 would be a plain circle. */
    static final float G2 = 4f;

    /**
     * The G2 radius that gives the same corner as a circle of radius circleR: the G2 curve is drawn from this radius, so
     * its corner sits at the same place as a capsule end. At 45 degrees a circle is cut in by circleR (1 - 1/sqrt 2); a
     * G2 corner of radius R is cut in by R (1 - 0.5^(1/G2)). Equal cuts give R = circleR (1 - 1/sqrt 2) / (1 - 0.5^(1/G2)).
     */
    static float g2RadiusFor(float circleR) {
        return (float) (circleR * (1.0 - Math.sqrt(0.5)) / (1.0 - Math.pow(0.5, 1.0 / G2)));
    }

    /** Corner radius of the multi-row settings cards: the capsule radius (half a row) carried by the G2 curve. */
    static final float CARD_R = 26f;
    static final float CARD_G2_R = g2RadiusFor(CARD_R);

    /** Capsule exponent: 2 gives true round ends (a circle at each end). */
    static final float CAPSULE = 2f;

    /** Symbol of each settings page, indexed by the page id in MainActivity (0 = root, no tile). */
    static final String[] OPS = {
            "",
            // 1 Setup: check mark
            "L 8.5 15.5 13 20; L 13 20 21.5 10.5",
            // 2 Language: globe
            "O 15 15 7.5; E 15 15 3.3 7.5; L 7.5 15 22.5 15",
            // 3 Corrections & suggestions: A with a check mark
            "L 6 22 11.5 8; L 11.5 8 17 22; L 8.5 17.5 14.5 17.5; L 19.5 16 22.5 19.5; L 22.5 19.5 27 12.5",
            // 4 Emoji: smiley
            "O 15 15 8; D 12 13 1.1; D 18 13 1.1; A 15 15 4.6 25 130",
            // 5 Dictation: microphone
            "Q 12 7 6 11 3; A 15 14 6.5 0 180; L 15 20.5 15 23.5",
            // 6 Layout & Keys: four keys
            "Q 8 8 6 6 1.6; Q 16 8 6 6 1.6; Q 8 16 6 6 1.6; Q 16 16 6 6 1.6",
            // 7 Preferences: three sliders
            "L 6 9 24 9; D 11 9 2.4; L 6 15 24 15; D 19 15 2.4; L 6 21 24 21; D 13 21 2.4",
            // 8 Privacy: lock
            "Q 9.5 13.5 11 9 2.5; A 15 13.5 4.2 180 180",
            // 9 About: i
            "D 15 9.2 1.4; L 15 13.2 15 21",
            // 10 Visuals & Themes: half-filled circle
            "O 15 15 8; W 15 15 8 90 180",
            // 11 Glide typing: a wave
            "A 10 12 4 0 270; A 18 19 4 180 270; L 14 12 16 19",
            // 12 Clipboard: board with a clip
            "R 8 7.5 14 18.5 2.2; Q 11 5.2 8 3.6 1.3; L 11 13 19 13; L 11 17 19 17",
            // 13 Dictionary: open book
            "L 6 9 14 11.5; L 14 11.5 14 23; L 14 23 6 20.5; L 6 20.5 6 9; L 24 9 16 11.5; L 16 11.5 16 23; L 16 23 24 20.5; L 24 20.5 24 9",
            // 14 Share: three linked dots
            "D 21 8 2.6; D 9 15 2.6; D 21 22 2.6; L 19.2 9.5 10.8 13.5; L 10.8 16.5 19.2 20.5",
            // 15 Help: question mark in a circle
            "O 15 15 9; A 15 12.6 3.2 200 230; L 15 15.8 15 17.2; D 15 20.4 1.2"
    };

    /** Tile colours (ARGB) per page id, as iOS system colours: light mode, then dark mode. */
    static final int[] TILE_LIGHT = {0, 0xFF007AFF, 0xFF5856D6, 0xFFFF9500, 0xFFFFCC00, 0xFFFF3B30,
            0xFF8E8E93, 0xFFFF2D55, 0xFF007AFF, 0xFF8E8E93, 0xFF32ADE6, 0xFF34C759, 0xFF5AC8FA,
            0xFF30B0C7, 0xFF5856D6, 0xFF636366};
    static final int[] TILE_DARK = {0, 0xFF0A84FF, 0xFF5E5CE6, 0xFFFF9F0A, 0xFFFFD60A, 0xFFFF453A,
            0xFF8E8E93, 0xFFFF375F, 0xFF0A84FF, 0xFF8E8E93, 0xFF32ADE6, 0xFF30D158, 0xFF64D2FF,
            0xFF40C8E0, 0xFF5E5CE6, 0xFF636366};

    /** The tile's top colour is its base colour lightened by this much; the tile fades down to the base. */
    static final float TILE_LIGHTEN = 0.12f;

    static int lighten(int color, float f) {
        int r = (color >> 16) & 0xFF, g = (color >> 8) & 0xFF, b = color & 0xFF;
        r += Math.round((255 - r) * f);
        g += Math.round((255 - g) * f);
        b += Math.round((255 - b) * f);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /** The white symbol of one settings page. Give it a rounded coloured background to make the tile. */
    static final class GlyphView extends View {

        private final String[] steps;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final Path path = new Path();

        GlyphView(Context context, int page) {
            super(context);
            steps = page > 0 && page < OPS.length ? OPS[page].split(";") : new String[0];
        }

        @Override
        protected void onDraw(Canvas c) {
            float s = Math.min(getWidth(), getHeight()) / GRID;
            paint.setColor(0xFFFFFFFF);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setStrokeWidth(STROKE * s);
            for (String step : steps) {
                String[] t = step.trim().split("\\s+");
                if (t.length < 2) continue;
                float[] v = new float[t.length - 1];
                for (int i = 1; i < t.length; i++) v[i - 1] = Float.parseFloat(t[i]) * s;
                switch (t[0].charAt(0)) {
                    case 'L':
                        paint.setStyle(Paint.Style.STROKE);
                        c.drawLine(v[0], v[1], v[2], v[3], paint);
                        break;
                    case 'O':
                        paint.setStyle(Paint.Style.STROKE);
                        c.drawCircle(v[0], v[1], v[2], paint);
                        break;
                    case 'D':
                        paint.setStyle(Paint.Style.FILL);
                        c.drawCircle(v[0], v[1], v[2], paint);
                        break;
                    case 'E':
                        paint.setStyle(Paint.Style.STROKE);
                        rect.set(v[0] - v[2], v[1] - v[3], v[0] + v[2], v[1] + v[3]);
                        c.drawOval(rect, paint);
                        break;
                    case 'R':
                    case 'Q': {
                        paint.setStyle(t[0].charAt(0) == 'R' ? Paint.Style.STROKE : Paint.Style.FILL);
                        Path rr = new Path();
                        KeyboardService.g2Rect(rr, v[0], v[1], v[0] + v[2], v[1] + v[3], v[4], G2);
                        c.drawPath(rr, paint);
                        break;
                    }
                    case 'A':
                    case 'W':
                        rect.set(v[0] - v[2], v[1] - v[2], v[0] + v[2], v[1] + v[2]);
                        boolean pie = t[0].charAt(0) == 'W';
                        paint.setStyle(pie ? Paint.Style.FILL : Paint.Style.STROKE);
                        c.drawArc(rect, v[3] / s, v[4] / s, pie, paint);
                        break;
                    case 'P':
                        paint.setStyle(Paint.Style.FILL);
                        path.reset();
                        path.moveTo(v[0], v[1]);
                        for (int i = 2; i + 1 < v.length; i += 2) path.lineTo(v[i], v[i + 1]);
                        path.close();
                        c.drawPath(path, paint);
                        break;
                    default:
                        break;
                }
            }
        }
    }

    /** A chevron or check mark, stroked in one colour. */
    static final class ShapeView extends View {

        static final int CHEVRON_RIGHT = 0, CHEVRON_LEFT = 1, CHECK = 2;

        private final int kind;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();

        ShapeView(Context context, int kind, int color) {
            super(context);
            this.kind = kind;
            paint.setColor(color);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            float d = getResources().getDisplayMetrics().density;
            paint.setStrokeWidth((kind == CHEVRON_RIGHT ? 2.0f : 2.4f) * d);
            float p = paint.getStrokeWidth() / 2f;
            path.reset();
            if (kind == CHEVRON_RIGHT) {
                path.moveTo(p, p);
                path.lineTo(w - p, h / 2f);
                path.lineTo(p, h - p);
            } else if (kind == CHEVRON_LEFT) {
                path.moveTo(w - p, p);
                path.lineTo(p, h / 2f);
                path.lineTo(w - p, h - p);
            } else {
                path.moveTo(p, h * 0.55f);
                path.lineTo(w * 0.36f, h - p);
                path.lineTo(w - p, p);
            }
            c.drawPath(path, paint);
        }
    }
}
