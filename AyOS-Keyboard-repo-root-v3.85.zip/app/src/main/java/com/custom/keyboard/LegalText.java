package com.custom.keyboard;

/**
 * The text of the Terms of Service and Privacy Policy shown in the app.
 * Fill in DEVELOPER, CONTACT and JURISDICTION before publishing, and have the text reviewed.
 * Each document is a list of alternating headings and paragraphs.
 */
final class LegalText {

    private LegalText() {}

    static final String DEVELOPER = "[Developer name]";
    static final String CONTACT = "[Contact email]";
    static final String JURISDICTION = "[jurisdiction]";
    static final String UPDATED = "23 November 2026";

    static final String[] PRIVACY = {
            "Summary",
            "TypeFlow works on your phone. The app has no internet permission, so it cannot send what you type, "
                    + "what you copy, or your settings to anyone. We do not collect analytics, usage statistics, advertising "
                    + "identifiers or audio recordings. There are no accounts and no sign-in.",

            "What is stored on your phone",
            "Settings. Your choices in the app (theme, layout, toggles) are saved in the app’s private storage on your phone.\n\n"
                    + "Learned words. If ‘Learn words on this phone’ is on, words you type repeatedly are remembered on your phone "
                    + "so suggestions improve. Delete learned words removes them.\n\n"
                    + "Clipboard history. If ‘Remember clipboard after restart’ is on (it is on by default), recently copied text "
                    + "is kept in a private database on your phone, so it is still there after a restart. Copies made in password "
                    + "fields, and copies the source app marks as sensitive, are never saved. Clear clipboard history deletes "
                    + "everything. Turning the setting off deletes the saved copies.\n\n"
                    + "Emoji and stickers. Recently used emoji are kept on your phone. Custom stickers you add are saved in the "
                    + "app’s private storage.",

            "What the app does not do",
            "It does not connect to the internet, read your contacts, location, photos or files, or record audio. "
                    + "Voice typing is handled by your phone’s own voice input service, which has its own privacy policy. "
                    + "TypeFlow does not record the microphone.",

            "Permissions",
            "The app requests one permission: vibration, used for key feedback.",

            "Clipboard access",
            "While the keyboard is on screen, it reads the clipboard only to offer recent copies. It does not read the "
                    + "clipboard in the background.",

            "Sensitive fields",
            "Suggestions and word learning are off in password, email and web-address fields. Clipboard items copied in "
                    + "password fields are never saved.",

            "Security",
            "Data stays in the app’s private storage, which other apps cannot read on a phone that has not been modified. "
                    + "TypeFlow does not add its own encryption on top of your phone’s protection.",

            "Your choices",
            "You can turn off word learning and clipboard memory, delete learned words and clipboard history, and remove all "
                    + "app data by uninstalling TypeFlow.",

            "Children",
            "TypeFlow collects no personal information from anyone, including children.",

            "Changes",
            "If this policy changes, the new version is shown in the app with its date.",

            "Contact",
            CONTACT,
    };

    static final String[] TERMS = {
            "Agreement",
            "By installing or using TypeFlow you agree to these terms. If you do not agree, uninstall the app.",

            "Licence",
            DEVELOPER + " grants you a personal, non-exclusive, non-transferable licence to use TypeFlow on Android "
                    + "devices you own or control. You may not copy, modify, reverse engineer or redistribute the app, except "
                    + "where the law allows or where an open source licence applies to a component.",

            "Your use",
            "You are responsible for the text you type and for checking it before you send it. Do not use the keyboard to "
                    + "break the law or to infringe the rights of others.",

            "Suggestions and corrections",
            "Word suggestions, glide typing, spelling corrections and emoji suggestions are automatic and can be wrong. Do not "
                    + "rely on them for passwords, legal, medical, financial or safety-critical text.",

            "Voice typing",
            "The mic key opens your phone’s own voice typing service. That service’s own terms and privacy policy apply to any "
                    + "speech it processes.",

            "Third-party components",
            "Some components are licensed separately. The Open source licenses page lists them, and their licences apply to "
                    + "those components.",

            "No warranty",
            "TypeFlow is provided ‘as is’, without warranty of any kind, express or implied, including fitness for a "
                    + "particular purpose and non-infringement, to the fullest extent the law allows.",

            "Limitation of liability",
            "To the fullest extent the law allows, " + DEVELOPER + " is not liable for indirect or consequential loss, or for "
                    + "loss of data, arising from the use of the app. Nothing in these terms limits liability that the law does "
                    + "not allow to be limited.",

            "Updates",
            "The app may be updated from time to time. Continued use after an update means you accept the updated terms.",

            "Governing law",
            "These terms are governed by the law of " + JURISDICTION + ".",

            "Contact",
            CONTACT,
    };
}
