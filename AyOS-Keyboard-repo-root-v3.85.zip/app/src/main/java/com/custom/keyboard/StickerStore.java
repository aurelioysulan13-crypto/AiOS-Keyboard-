package com.custom.keyboard;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Custom stickers: the image files live in the app's internal storage (files/stickers/), and their
 * records live in the custom_stickers table of KeyboardDb. A sticker is only ever read from that folder.
 */
final class StickerStore {

    static final String DIR_NAME = "stickers";
    private static final Random RANDOM = new Random();

    private StickerStore() {}

    /** The folder that holds every sticker file (created if missing). */
    static File dir(Context context) {
        File d = new File(context.getFilesDir(), DIR_NAME);
        if (!d.isDirectory()) {
            //noinspection ResultOfMethodCallIgnored
            d.mkdirs();
        }
        return d;
    }

    /**
     * Copies an image into internal storage and records it. Returns the new sticker id, or -1 if it failed
     * (a partly written file is removed then).
     */
    static long add(Context context, InputStream source) {
        KeyboardDb db = KeyboardDb.get(context);
        File target = new File(dir(context), newFileName());
        try (OutputStream out = new FileOutputStream(target)) {
            byte[] buf = new byte[16 * 1024];
            int n;
            while ((n = source.read(buf)) != -1) {
                out.write(buf, 0, n);
            }
        } catch (IOException e) {
            //noinspection ResultOfMethodCallIgnored
            target.delete();
            return -1;
        }
        long id = db.insertSticker(target.getAbsolutePath(), System.currentTimeMillis());
        if (id < 0) {
            //noinspection ResultOfMethodCallIgnored
            target.delete();
        }
        return id;
    }

    /** Every sticker whose file still exists, newest first. Rows whose file is gone are removed. */
    static List<KeyboardDb.StickerRow> list(Context context) {
        KeyboardDb db = KeyboardDb.get(context);
        List<KeyboardDb.StickerRow> out = new ArrayList<>();
        for (KeyboardDb.StickerRow row : db.querySticker()) {
            if (isInside(context, row.filePath) && new File(row.filePath).isFile()) {
                out.add(row);
            } else {
                db.deleteSticker(row.id);
            }
        }
        return out;
    }

    /** Decodes a sticker from its internal file, or null if the file is missing or not an image. */
    static Bitmap load(Context context, KeyboardDb.StickerRow row) {
        if (row == null || !isInside(context, row.filePath)) {
            return null;
        }
        return BitmapFactory.decodeFile(row.filePath);
    }

    /** Deletes a sticker: its record and its file. Returns true if the record was removed. */
    static boolean delete(Context context, long id) {
        KeyboardDb db = KeyboardDb.get(context);
        KeyboardDb.StickerRow row = db.getSticker(id);
        if (row == null) {
            return false;
        }
        if (isInside(context, row.filePath)) {
            //noinspection ResultOfMethodCallIgnored
            new File(row.filePath).delete();
        }
        return db.deleteSticker(id) > 0;
    }

    /** Replaces a sticker's image with a new one, keeping its id. Returns true on success. */
    static boolean replace(Context context, long id, InputStream source) {
        KeyboardDb db = KeyboardDb.get(context);
        KeyboardDb.StickerRow row = db.getSticker(id);
        if (row == null) {
            return false;
        }
        File target = new File(dir(context), newFileName());
        try (OutputStream out = new FileOutputStream(target)) {
            byte[] buf = new byte[16 * 1024];
            int n;
            while ((n = source.read(buf)) != -1) {
                out.write(buf, 0, n);
            }
        } catch (IOException e) {
            //noinspection ResultOfMethodCallIgnored
            target.delete();
            return false;
        }
        if (db.updateStickerPath(id, target.getAbsolutePath()) <= 0) {
            //noinspection ResultOfMethodCallIgnored
            target.delete();
            return false;
        }
        if (isInside(context, row.filePath)) {
            //noinspection ResultOfMethodCallIgnored
            new File(row.filePath).delete();
        }
        return true;
    }

    /** True only for a file directly inside the stickers folder (guards against paths from elsewhere). */
    static boolean isInside(Context context, String path) {
        if (path == null) {
            return false;
        }
        try {
            File f = new File(path).getCanonicalFile();
            File d = dir(context).getCanonicalFile();
            return f.getParentFile() != null && f.getParentFile().equals(d);
        } catch (IOException e) {
            return false;
        }
    }

    private static String newFileName() {
        return String.format(Locale.ROOT, "sticker_%d_%06d.png", System.currentTimeMillis(), RANDOM.nextInt(1000000));
    }
}
