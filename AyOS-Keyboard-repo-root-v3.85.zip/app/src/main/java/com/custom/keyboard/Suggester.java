package com.custom.keyboard;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Word suggestions, next-word prediction, auto-correct and on-device word learning. */
final class Suggester {

    private static final String[][] NEXT = {
            {"i", "am", "have", "will"},
            {"i'm", "not", "going", "sorry"},
            {"you", "are", "can", "have"},
            {"thank", "you"},
            {"thanks", "for", "so", "a"},
            {"how", "are", "to", "do"},
            {"what", "is", "are", "do"},
            {"where", "is", "are", "do"},
            {"are", "you", "we", "they"},
            {"is", "it", "this", "there"},
            {"do", "you", "not", "we"},
            {"don't", "know", "think", "want"},
            {"can", "you", "i", "we"},
            {"see", "you", "the", "if"},
            {"good", "morning", "night", "luck"},
            {"have", "a", "to", "you"},
            {"want", "to", "a", "you"},
            {"going", "to", "on", "home"},
            {"in", "the", "a", "my"},
            {"of", "the", "a", "course"},
            {"to", "be", "the", "do"},
            {"it", "is", "was", "will"},
            {"let", "me", "us", "you"},
            {"please", "let", "send", "help"},
            {"happy", "birthday", "to", "new"},
            {"for", "the", "a", "you"},
            {"on", "the", "my", "a"},
            {"this", "is", "will", "one"},
            {"that", "is", "was", "you"},
            {"the", "same", "best", "first"}
    };

    private static final String[][] FIXES = {
            {"i", "I"}, {"im", "I'm"}, {"i'm", "I'm"}, {"ive", "I've"}, {"i've", "I've"},
            {"i'll", "I'll"}, {"i'd", "I'd"}, {"dont", "don't"}, {"cant", "can't"},
            {"wont", "won't"}, {"didnt", "didn't"}, {"doesnt", "doesn't"}, {"isnt", "isn't"},
            {"arent", "aren't"}, {"wasnt", "wasn't"}, {"werent", "weren't"},
            {"couldnt", "couldn't"}, {"wouldnt", "wouldn't"}, {"shouldnt", "shouldn't"},
            {"havent", "haven't"}, {"hasnt", "hasn't"}, {"youre", "you're"},
            {"theyre", "they're"}, {"thats", "that's"}, {"whats", "what's"},
            {"teh", "the"}, {"recieve", "receive"}, {"definately", "definitely"},
            {"seperate", "separate"}, {"occured", "occurred"}, {"becuase", "because"},
            {"alot", "a lot"}, {"thier", "their"}, {"wich", "which"}, {"freind", "friend"},
            {"adress", "address"}, {"tommorow", "tomorrow"}, {"untill", "until"},
            {"wierd", "weird"}, {"beleive", "believe"}
    };

    private final Context appContext;
    private final ArrayList<String> words = new ArrayList<>();
    private final HashSet<String> wordSet = new HashSet<>();
    private final HashSet<String> learned = new HashSet<>();
    private final HashMap<String, Integer> seen = new HashMap<>();
    private final HashMap<String, String[]> next = new HashMap<>();
    private final HashMap<String, String> fixes = new HashMap<>();
    private volatile boolean ready = false;

    Suggester(Context ctx) {
        appContext = ctx.getApplicationContext() != null ? ctx.getApplicationContext() : ctx;
        for (String[] n : NEXT) {
            next.put(n[0], Arrays.copyOfRange(n, 1, n.length));
        }
        for (String[] f : FIXES) {
            fixes.put(f[0], f[1]);
        }
        Set<String> saved = Prefs.get(appContext).getStringSet(Prefs.K_LEARNED, null);
        if (saved != null) {
            learned.addAll(saved);
        }
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                loadWords();
            }
        });
        t.setPriority(Thread.MIN_PRIORITY);
        t.start();
    }

    /**
     * The word lists, most common first: words.txt (frequency order), then ESDB size 35 (common, in the
     * same tier as words.txt), then the Australian Hunspell list, then ESDB sizes 50 and 60.
     * See assets/wordlist/README.txt.
     */
    private static final String[] WORD_FILES = {
            "wordlist/en_au.txt", "wordlist/scowl_50.txt", "wordlist/scowl_60.txt"};

    /** How many words at the top of the list form the common tier (the spell fix only uses these). */
    private int commonCount = 0;

    private void loadWords() {
        ArrayList<String> list = new ArrayList<>();
        HashSet<String> set = new HashSet<>();
        readWords("words.txt", list, set);            // the built-in list, most common words first
        readWords("wordlist/scowl_35.txt", list, set);
        commonCount = list.size();
        for (String name : WORD_FILES) {
            readWords(name, list, set);
        }
        words.addAll(list);
        wordSet.addAll(set);
        ready = true;
    }

    /** Adds the plain words of one list file; false if the file is not in the app. */
    private boolean readWords(String name, ArrayList<String> list, HashSet<String> set) {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(appContext.getAssets().open(name), "UTF-8"))) {
            String line;
            while ((line = r.readLine()) != null) {
                String w = line.trim().toLowerCase(Locale.ROOT);
                if (isWord(w) && set.add(w)) {
                    list.add(w);
                }
            }
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    /** Plain a-z words and apostrophes, 1 to 24 letters: no spaces, digits or symbols. */
    private static boolean isWord(String w) {
        if (w.isEmpty() || w.length() > 24) return false;
        for (int i = 0; i < w.length(); i++) {
            char c = w.charAt(i);
            if (!((c >= 'a' && c <= 'z') || c == '\'')) return false;
        }
        return true;
    }

    /** Typed word first, then up to (max - 1) completions. */
    List<String> suggest(String typed, int max) {
        ArrayList<String> out = new ArrayList<>();
        if (typed.isEmpty()) {
            return out;
        }
        out.add(typed);
        if (!ready) {
            return out;
        }
        String p = typed.toLowerCase(Locale.ROOT);
        for (String w : learned) {
            if (out.size() >= max) break;
            if (w.length() > p.length() && w.startsWith(p)) {
                addUnique(out, matchCase(w, typed));
            }
        }
        for (int i = 0; i < words.size() && out.size() < max; i++) {
            String w = words.get(i);
            if (w.length() > p.length() && w.startsWith(p)) {
                addUnique(out, matchCase(w, typed));
            }
        }
        return out;
    }

    private static final float GLIDE_MISS = 1f;     // a word letter the finger never crossed
    private static final float GLIDE_SKIP = 0.3f;   // a crossed letter the word does not use
    private static final float GLIDE_LIMIT = 1f;    // worst accepted match (per letter)

    /**
     * Glide typing: the dictionary words that best match the letters a finger crossed. sub[a][b] is the cost of
     * the finger on key b when the word wants a (0 = same key). Words must start and end on the right keys.
     */
    List<String> glide(String path, float[][] sub, int max) {
        ArrayList<String> out = new ArrayList<>();
        if (!ready || path.length() < 2 || max < 1) {
            return out;
        }
        String p = path.toLowerCase(Locale.ROOT);
        ArrayList<String> pool = new ArrayList<>(words);
        pool.addAll(learned);
        float[] scores = new float[pool.size()];
        for (int i = 0; i < pool.size(); i++) {
            String w = pool.get(i).toLowerCase(Locale.ROOT);
            scores[i] = w.isEmpty() ? 9f : glideCost(w, p, sub);
        }
        for (int k = 0; k < max; k++) {
            int best = -1;
            for (int i = 0; i < scores.length; i++) {
                if (scores[i] <= GLIDE_LIMIT && (best < 0 || scores[i] < scores[best])) {
                    best = i;
                }
            }
            if (best < 0) break;
            out.add(pool.get(best));
            scores[best] = 9f;
        }
        return out;
    }

    /** Edit distance between a word and the crossed letters, with key-distance substitution costs. */
    private static float glideCost(String w, String p, float[][] sub) {
        int n = w.length(), m = p.length();
        float[] prev = new float[m + 1];
        float[] cur = new float[m + 1];
        for (int j = 1; j <= m; j++) prev[j] = j * GLIDE_SKIP;
        for (int i = 1; i <= n; i++) {
            char a = w.charAt(i - 1);
            cur[0] = i * GLIDE_MISS;
            for (int j = 1; j <= m; j++) {
                char b = p.charAt(j - 1);
                float diag = prev[j - 1] + subCost(sub, a, b);
                cur[j] = Math.min(diag, Math.min(prev[j] + GLIDE_MISS, cur[j - 1] + GLIDE_SKIP));
            }
            float[] t = prev; prev = cur; cur = t;
        }
        float s = prev[m];
        if (w.charAt(0) != p.charAt(0)) s += 1.5f;
        if (w.charAt(n - 1) != p.charAt(m - 1)) s += 1.5f;
        return s / Math.max(n, m);
    }

    private static float subCost(float[][] sub, char a, char b) {
        if (a == b) return 0f;
        if (a < 'a' || a > 'z' || b < 'a' || b > 'z') return 1f;
        return sub[a - 'a'][b - 'a'];
    }

    /** Guesses for the next word, given the previous word (lowercase). */
    List<String> nextWords(String prev) {
        ArrayList<String> out = new ArrayList<>();
        String[] n = next.get(prev);
        if (n != null) {
            for (String s : n) {
                if (out.size() < 3) out.add(s);
            }
        }
        String[] defaults = {"I", "the", "to"};
        for (String d : defaults) {
            if (out.size() < 3 && !out.contains(d)) out.add(d);
        }
        return out;
    }

    /** Returns the corrected form of a word, or null if it needs no correction. */
    String correction(String w) {
        if (w.isEmpty()) return null;
        String c = fixes.get(w.toLowerCase(Locale.ROOT));
        if (c == null) return dictionaryFix(w);
        String result = c;
        if (w.length() > 1 && w.equals(w.toUpperCase(Locale.ROOT))) {
            result = c.toUpperCase(Locale.ROOT);
        } else if (Character.isUpperCase(w.charAt(0)) && !Character.isUpperCase(c.charAt(0))) {
            result = Character.toUpperCase(c.charAt(0)) + c.substring(1);
        }
        return result.equals(w) ? null : result;
    }

    /**
     * Spell check: a word that is not in the dictionary (and was not learned) is replaced by the most common
     * dictionary word one edit away (a letter added, missing, swapped or changed). Null if there is none.
     */
    private String dictionaryFix(String w) {
        if (!ready || w.length() < 3 || w.length() > 20) return null;
        if (!Prefs.on(Prefs.get(appContext), Prefs.K_SPELL)) return null;
        String lw = w.toLowerCase(Locale.ROOT);
        if (wordSet.contains(lw) || learned.contains(lw)) return null;
        String best = null;
        int bestRank = Integer.MAX_VALUE;
        for (String c : edits1(lw)) {
            if (!wordSet.contains(c)) continue;
            int rank = words.indexOf(c);            // the lists are most common first
            if (rank < 0 || rank >= commonCount) continue;   // only the common tier may be a fix
            if (best == null || rank < bestRank) {
                best = c;
                bestRank = rank;
            }
        }
        if (best == null) return null;
        if (Character.isUpperCase(w.charAt(0))) {
            best = Character.toUpperCase(best.charAt(0)) + best.substring(1);
        }
        return best;
    }

    /** Every word one insertion, deletion, transposition or substitution away from w (lowercase). */
    private static Set<String> edits1(String w) {
        HashSet<String> out = new HashSet<>();
        String alpha = "abcdefghijklmnopqrstuvwxyz'";
        int n = w.length();
        for (int i = 0; i <= n; i++) {
            for (int k = 0; k < alpha.length(); k++) {
                out.add(w.substring(0, i) + alpha.charAt(k) + w.substring(i));
            }
        }
        for (int i = 0; i < n; i++) {
            out.add(w.substring(0, i) + w.substring(i + 1));
            if (i < n - 1) {
                out.add(w.substring(0, i) + w.charAt(i + 1) + w.charAt(i) + w.substring(i + 2));
            }
            for (int k = 0; k < alpha.length(); k++) {
                out.add(w.substring(0, i) + alpha.charAt(k) + w.substring(i + 1));
            }
        }
        out.remove(w);
        return out;
    }

    /** Remembers a word once it has been typed twice and isn't in the dictionary. */
    void learn(String word) {
        if (!ready) return;
        String w = word.toLowerCase(Locale.ROOT);
        if (w.length() < 3 || w.length() > 24) return;
        if (wordSet.contains(w) || learned.contains(w) || fixes.containsKey(w)) return;
        Integer prev = seen.get(w);
        int c = (prev == null) ? 1 : prev + 1;
        if (c >= 2) {
            seen.remove(w);
            if (learned.size() >= 2000) {
                Iterator<String> it = learned.iterator();
                if (it.hasNext()) {
                    it.next();
                    it.remove();
                }
            }
            learned.add(w);
            persist();
        } else {
            seen.put(w, c);
        }
    }

    void clearLearned() {
        learned.clear();
        seen.clear();
    }

    private void persist() {
        SharedPreferences.Editor e = Prefs.get(appContext).edit();
        e.putStringSet(Prefs.K_LEARNED, new HashSet<>(learned));
        e.apply();
    }

    private static void addUnique(List<String> list, String s) {
        if (!list.contains(s)) list.add(s);
    }

    private static String matchCase(String w, String typed) {
        if (w.equals("i") || w.startsWith("i'")) {
            return "I" + w.substring(1);
        }
        if (typed.length() > 1 && typed.equals(typed.toUpperCase(Locale.ROOT))) {
            return w.toUpperCase(Locale.ROOT);
        }
        if (Character.isUpperCase(typed.charAt(0))) {
            return Character.toUpperCase(w.charAt(0)) + w.substring(1);
        }
        return w;
    }
}
