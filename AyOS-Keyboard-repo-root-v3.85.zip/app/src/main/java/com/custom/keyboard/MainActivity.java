package com.custom.keyboard;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.os.Build;
import android.text.TextUtils;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import java.util.ArrayList;
import java.util.List;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.VelocityTracker;
import android.view.animation.OvershootInterpolator;

/**
 * TypeFlow settings in the iOS 26 Settings look (dark or light, following the phone): a root list of
 * categories with icon tiles, and each category opens its own page with a round back button.
 */
public class MainActivity extends Activity {

    // page ids
    static final int P_ROOT = 0, P_SETUP = 1, P_LANGUAGE = 2, P_CORRECTIONS = 3, P_EMOJI = 4, P_DICTATION = 5,
            P_LAYOUT = 6, P_PREFERENCES = 7, P_PRIVACY = 8, P_ABOUT = 9, P_VISUALS = 10, P_GLIDE = 11, P_CLIPBOARD = 12,
            P_TERMS = 13, P_PRIVACY_POLICY = 14, P_LICENSES = 15;

    private SharedPreferences prefs;
    private float density;
    private boolean dark;

    // colours, set by computeColors() for each page build
    private int labelColor, secondaryColor, separatorColor, accent, destructiveColor, onColor, offColor;
    private int glassTop, glassBottom, glassRim, backdropTop, backdropBottom, tileColor, boardColor;
    private int pageColor, groupColor, chevronColor, trackColor, backButtonColor, backButtonRim;

    private final ArrayList<Integer> stack = new ArrayList<>();
    private FrameLayout content;
    private View topView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = Prefs.get(this);
        density = getResources().getDisplayMetrics().density;
        int night = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        dark = night == Configuration.UI_MODE_NIGHT_YES;
        computeColors();

        getWindow().setStatusBarColor(pageColor);
        getWindow().setNavigationBarColor(pageColor);
        int uiFlags = 0;
        if (Build.VERSION.SDK_INT >= 23 && !dark) uiFlags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= 26 && !dark) uiFlags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        getWindow().getDecorView().setSystemUiVisibility(uiFlags);
        content = new FrameLayout(this);
        setContentView(content);
        stack.clear();
        push(P_ROOT, false);
        int startPage = getIntent() == null ? P_ROOT : getIntent().getIntExtra("page", P_ROOT);   // v3.108: the corner pop-up opens a page
        if (startPage != P_ROOT) {
            push(startPage, false);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshTop();     // setup status may have changed in system settings
    }

    @Override
    public void onBackPressed() {
        if (stack.size() > 1) {
            pop();
        } else {
            super.onBackPressed();
        }
    }

    // ------------------------------------------------------------- navigation
    private void push(int id, boolean animate) {
        stack.add(id);
        View v = buildPageView(id);
        if (topView != null) {
            content.removeView(topView);
        }
        content.addView(v);
        topView = v;
        if (animate) {
            v.setTranslationX(screenWidth());
            v.animate().translationX(0).setDuration(260).start();
        }
    }

    private void pop() {
        stack.remove(stack.size() - 1);
        final View leaving = topView;
        View v = buildPageView(stack.get(stack.size() - 1));
        content.addView(v, 0);          // underneath the page that is leaving
        topView = v;
        if (leaving != null) {
            leaving.animate().translationX(screenWidth()).setDuration(260).withEndAction(new Runnable() {
                @Override
                public void run() {
                    content.removeView(leaving);
                }
            }).start();
        }
    }

    /** Rebuilds the page on screen (after a setting changed). */
    private void refreshTop() {
        if (stack.isEmpty() || topView == null) {
            return;
        }
        int i = content.indexOfChild(topView);
        View v = buildPageView(stack.get(stack.size() - 1));
        content.removeView(topView);
        content.addView(v, i < 0 ? content.getChildCount() : i);
        topView = v;
    }

    private int screenWidth() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    private View buildPageView(int id) {
        computeColors();
        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{backdropTop, backdropBottom}));

        int statusH = statusBarHeight();
        if (id != P_ROOT) {
            outer.addView(navBar(pageTitle(id), statusH), new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, statusH + dp(60)));
        }

        ScrollView sc = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), id == P_ROOT ? statusH + dp(60) : dp(8), dp(16), dp(40));
        if (id == P_ROOT) {
            TextView big = text("TypeFlow", 34, labelColor, true);
            big.setLetterSpacing(-0.01f);
            big.setPadding(dp(4), 0, 0, dp(10));
            col.addView(big);
        }
        buildPage(id, col);
        capsulise(col);
        sc.addView(col, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        outer.addView(sc, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        Fonts.applyToTree(this, outer);
        return outer;
    }

    private String pageTitle(int id) {
        switch (id) {
            case P_SETUP: return "Setup";
            case P_LANGUAGE: return "Languages";
            case P_CORRECTIONS: return "Corrections & suggestions";
            case P_EMOJI: return "Emojis, stickers & GIFs";
            case P_DICTATION: return "Voice typing";
            case P_LAYOUT: return "Bottom row & size";
            case P_PREFERENCES: return "Preferences";
            case P_GLIDE: return "Glide typing";
            case P_CLIPBOARD: return "Clipboard";
            case P_PRIVACY: return "Privacy";
            case P_ABOUT: return "About";
            case P_VISUALS: return "Visuals & Themes";
            case P_TERMS: return "Terms of Service";
            case P_PRIVACY_POLICY: return "Privacy Policy";
            case P_LICENSES: return "Open source licenses";
            default: return "TypeFlow";
        }
    }

    /** iOS 26 navigation bar: a round back button on the left, the title centred, no divider. */
    private View navBar(String title, int statusH) {
        FrameLayout bar = new FrameLayout(this);
        bar.setBackgroundColor(pageColor);
        TextView t = text(title, 17, labelColor, true);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        tl.topMargin = statusH;
        tl.leftMargin = dp(72);
        tl.rightMargin = dp(72);
        bar.addView(t, tl);

        FrameLayout btn = new FrameLayout(this);
        btn.setBackground(glass(22, SettingsGlyphs.CAPSULE));   // circular back button
        btn.setClickable(true);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(dp(10), dp(17), Gravity.CENTER);
        cl.rightMargin = dp(1);
        btn.addView(new SettingsGlyphs.ShapeView(this, SettingsGlyphs.ShapeView.CHEVRON_LEFT, labelColor), cl);
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(dp(44), dp(44));
        bl.leftMargin = dp(16);
        bl.topMargin = statusH + dp(8);
        bar.addView(btn, bl);
        return bar;
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    private void buildPage(int id, LinearLayout col) {
        switch (id) {
            case P_SETUP: buildSetup(col); break;
            case P_LANGUAGE: buildLanguage(col); break;
            case P_CORRECTIONS: buildCorrections(col); break;
            case P_EMOJI: buildEmoji(col); break;
            case P_DICTATION: buildDictation(col); break;
            case P_LAYOUT: buildLayout(col); break;
            case P_PREFERENCES: buildPreferences(col); break;
            case P_GLIDE: buildGlide(col); break;
            case P_CLIPBOARD: buildClipboard(col); break;
            case P_PRIVACY: buildPrivacy(col); break;
            case P_ABOUT: buildAbout(col); break;
            case P_VISUALS: buildVisuals(col); break;
            case P_TERMS: buildLegal(col, LegalText.TERMS); break;
            case P_PRIVACY_POLICY: buildLegal(col, LegalText.PRIVACY); break;
            case P_LICENSES: buildLicenses(col); break;
            default: buildRoot(col); break;
        }
    }

    // ----------------------------------------------------------------- colours
    private void computeColors() {
        // iOS 26 Settings: black page with dark grey groups in dark mode; light grey page with white groups in light mode
        labelColor = dark ? 0xFFFFFFFF : 0xFF000000;
        secondaryColor = dark ? 0xFF8E8E93 : 0xFF6C6C70;
        separatorColor = dark ? 0xFF38383A : 0xFFC6C6C8;
        destructiveColor = dark ? 0xFFFF453A : 0xFFFF3B30;
        onColor = dark ? 0xFF30D158 : 0xFF34C759;                   // iOS switch green
        offColor = dark ? 0xFF5A595E : 0xFFE9E9EA;
        trackColor = dark ? 0xFF48484A : 0xFFE5E5EA;                // slider track
        accent = Prefs.ACCENTS[Prefs.accent(prefs)];
        pageColor = dark ? 0xFF000000 : 0xFFF2F2F7;
        groupColor = dark ? 0xFF1C1C1E : 0xFFFFFFFF;
        chevronColor = dark ? 0xFF48484A : 0xFFC4C4C7;
        backButtonColor = dark ? 0xFF1C1C1E : 0xFFFFFFFF;
        backButtonRim = dark ? 0x26FFFFFF : 0x14000000;
        backdropTop = pageColor;
        backdropBottom = pageColor;
        tileColor = dark ? 0xFF48484A : 0xFFFFFFFF;
        boardColor = dark ? 0xFF2C2C2E : 0xFFE5E5EA;
    }

    // ------------------------------------------------------------------ pages
    private void buildSetup(LinearLayout col) {
        final boolean enabled = isEnabled();
        final boolean selected = isSelected();
        header(col, "Enable");
        LinearLayout g = group(col);
        valueRow(g, "1. Enable TypeFlow", enabled ? "Enabled" : "Not enabled yet",
                enabled ? onColor : 0xFFE0903A);
        buttonRow(g, "Open keyboard settings", accent, new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
            }
        }, true);
        footer(col, "Turn on \"TypeFlow\" in the list of on-screen keyboards.");

        header(col, "Switch to it");
        g = group(col);
        String status = selected ? "Active" : enabled ? "Not selected yet" : "Finish step 1 first";
        valueRow(g, "2. Use TypeFlow", status, selected ? onColor : enabled ? 0xFFE0903A : secondaryColor);
        buttonRow(g, "Choose TypeFlow", accent, new Runnable() {
            @Override
            public void run() {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showInputMethodPicker();
            }
        }, enabled);
        footer(col, "Pick TypeFlow as the keyboard you type with.");

        header(col, "Try it out");
        g = group(col);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(10), dp(16), dp(10));
        EditText et = new EditText(this);
        et.setHint("Tap here and start typing\u2026");
        et.setHintTextColor(secondaryColor);
        et.setTextColor(labelColor);
        et.setBackground(null);
        et.setMinLines(3);
        et.setGravity(Gravity.TOP | Gravity.START);
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        box.addView(et);
        addRow(g, box);
    }

    // ------------------------------------------------------------ categories (Gboard settings order)
    private void buildRoot(LinearLayout col) {
        LinearLayout g = group(col);
        navRow(g, "Setup", setupSummary(), P_SETUP);

        g = group(col);
        navRow(g, "Languages", "English (US) (QWERTY)", P_LANGUAGE);
        navRow(g, "Preferences", null, P_PREFERENCES);
        navRow(g, "Theme", themeName(), P_VISUALS);

        g = group(col);
        navRow(g, "Corrections & suggestions", null, P_CORRECTIONS);
        navRow(g, "Glide typing", null, P_GLIDE);
        navRow(g, "Voice typing", null, P_DICTATION);
        navRow(g, "Emojis, stickers & GIFs", null, P_EMOJI);

        g = group(col);
        navRow(g, "Clipboard", null, P_CLIPBOARD);
        soonIconRow(g, "Dictionary", I_DICTIONARY);

        g = group(col);
        navRow(g, "Privacy", null, P_PRIVACY);
        soonIconRow(g, "Share TypeFlow", I_SHARE);
        navRow(g, "About", appVersion(), P_ABOUT);
        soonIconRow(g, "Help & feedback", I_HELP);
        footer(col, "Your own on-screen keyboard. The app has no internet permission, so nothing you type can leave your phone.");
    }

    private void buildLanguage(LinearLayout col) {
        header(col, "Keyboard languages & layouts");
        LinearLayout g = group(col);
        valueRow(g, "English (US)", "QWERTY", secondaryColor);
        soonRow(g, "Add keyboard");
        footer(col, "TypeFlow types in English (US) for now. More languages are coming soon.");
    }

    private void buildPreferences(LinearLayout col) {
        header(col, "Keys");
        LinearLayout g = group(col);
        toggleRow(g, "Number row", Prefs.K_NUMROW, false);
        toggleRow(g, "Number row for passwords", Prefs.K_NUMROW_PW, true);
        toggleRow(g, "Emoji key", Prefs.K_EMOJI_KEY, false);
        toggleRow(g, "Comma key", Prefs.K_COMMA, false);
        toggleRow(g, "Period key", Prefs.K_PERIOD, false);
        navRow(g, "Bottom row & size", null, P_LAYOUT);

        header(col, "Font");
        g = group(col);
        checkListRow(g, new String[]{"TypeFlow (SF Pro Display)", "System default"}, Prefs.fontChoice(prefs), Prefs.K_FONT);
        sliderRow(col, "Font size", Prefs.K_FONT_SCALE, Prefs.MIN_FONT_SCALE, Prefs.MAX_FONT_SCALE, Prefs.DEFAULT_FONT_SCALE, "%");

        header(col, "Layout");
        g = group(col);
        toggleRow(g, "Suggestion strip", Prefs.K_SUGGEST, true);

        header(col, "One-handed keyboard");
        segmentRow(col, new String[]{"Off", "Left", "Right"}, Prefs.oneHand(prefs), Prefs.K_ONEHAND);

        header(col, "Shortcuts");
        g = group(col);
        toggleRow(g, "Double-space period", Prefs.K_DBLSPACE, true);
        toggleRow(g, "Auto-space after punctuation", Prefs.K_AUTOSPACE, false);
        toggleRow(g, "Auto-switch after apostrophes", Prefs.K_APOS_SWITCH, true);
        toggleRow(g, "Touch & hold keys for symbols", Prefs.K_HOLD_SYMBOLS, true);
        toggleRow(g, "Flick keys to enter symbols", Prefs.K_FLICK, false);

        header(col, "Flick input sensitivity");
        segmentRow(col, new String[]{"Low", "Normal", "High"}, Prefs.flickSens(prefs), Prefs.K_FLICK_SENS);

        header(col, "Key tap");
        g = group(col);
        toggleRow(g, "Sound", Prefs.K_SOUND, false);
        toggleRow(g, "Keyboard vibration", Prefs.K_HAPTIC, true);
        toggleRow(g, "Key pop-up", Prefs.K_POPUP, true);
        sliderRow(col, "Volume", Prefs.K_VOLUME, Prefs.MIN_VOLUME, Prefs.MAX_VOLUME, Prefs.DEFAULT_VOLUME, "%");
        sliderRow(col, "Vibration strength on keypress", Prefs.K_VIB_MS, Prefs.MIN_VIB, Prefs.MAX_VIB, Prefs.DEFAULT_VIB, "ms");
        sliderRow(col, "Touch & hold duration", Prefs.K_HOLD_MS, Prefs.MIN_HOLD_MS, Prefs.MAX_HOLD_MS, Prefs.DEFAULT_HOLD_MS, "ms");
    }

    private void buildCorrections(LinearLayout col) {
        header(col, "Automatic corrections");
        LinearLayout g = group(col);
        toggleRow(g, "Auto-correction", Prefs.K_AUTOCORRECT, true);
        toggleRow(g, "Auto-capitalization", Prefs.K_AUTOCAP, true);

        header(col, "Spelling & grammar");
        g = group(col);
        soonRow(g, "Change default spell checker");
        toggleRow(g, "Spell check", Prefs.K_SPELL, true);
        soonRow(g, "Grammar check");

        header(col, "Suggestions");
        g = group(col);
        soonRow(g, "Don't suggest offensive words");
        toggleRow(g, "Word suggestions", Prefs.K_WORD_SUGGEST, true);
        toggleRow(g, "Next-word suggestions", Prefs.K_NEXT_WORD, true);
        soonRow(g, "Suggest contacts");
        soonRow(g, "Smart replies");
        footer(col, "Learned words are stored on this phone only. Clear them in Privacy.");
    }

    private void buildGlide(LinearLayout col) {
        header(col, "Glide");
        LinearLayout g = group(col);
        toggleRow(g, "Glide typing", Prefs.K_GLIDE, true);
        toggleRow(g, "Glide trail", Prefs.K_GLIDE_TRAIL, true);
        toggleRow(g, "Glide delete", Prefs.K_GLIDE_DELETE, true);
        toggleRow(g, "Glide cursor control", Prefs.K_GLIDE_CURSOR, true);
        footer(col, "Glide typing: slide across the letters to type a word. It picks from the built-in word list and "
                + "the words you have typed. Glide trail draws the path. Glide delete: slide left on the delete key to "
                + "remove the word before the cursor. Glide cursor control: slide along the space bar to move the cursor.");
    }

    private void buildDictation(LinearLayout col) {
        header(col, "Voice typing");
        LinearLayout g = group(col);
        valueRow(g, "Use voice typing", "On", secondaryColor);
        footer(col, "Tap the mic key to dictate with your phone's voice typing.");
    }

    /** The Apple Emoji row: the font is downloaded the first time, then it is chosen like the other rows. */
    private void appleRow(LinearLayout f, final EmojiFonts.Option o, String chosen) {
        final boolean ready = EmojiFonts.appleReady(this);
        final LinearLayout r = row(f);
        r.addView(text(o.label, 17, labelColor, false), fill());
        final TextView status = text(ready ? "" : "Download " + EmojiFonts.APPLE_EMOJI_SIZE_MB + " MB", 15, accent, false);
        r.addView(status);
        if (ready && o.path.equals(chosen)) {
            r.addView(new SettingsGlyphs.ShapeView(this, SettingsGlyphs.ShapeView.CHECK, accent),
                    new LinearLayout.LayoutParams(dp(18), dp(14)));
        }
        ripple(r);
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (EmojiFonts.appleReady(MainActivity.this)) {
                    prefs.edit().putString(Prefs.K_EMOJI_FONT, o.path).apply();
                    refreshTop();
                    return;
                }
                if (EmojiFonts.isDownloading()) {
                    return;
                }
                status.setText("Downloading 0%");
                EmojiFonts.downloadApple(MainActivity.this, new EmojiFonts.Progress() {
                    @Override
                    public void onProgress(final int pct) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                status.setText("Downloading " + pct + "%");
                            }
                        });
                    }

                    @Override
                    public void onDone(final boolean ok, final String message) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (ok) {
                                    prefs.edit().putString(Prefs.K_EMOJI_FONT, o.path).apply();
                                }
                                Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                                refreshTop();
                            }
                        });
                    }
                });
            }
        });
    }

    private void buildEmoji(LinearLayout col) {
        header(col, "Emoji font");
        LinearLayout f = group(col);
        final String chosen = EmojiFonts.stored(prefs);
        final List<EmojiFonts.Option> fontOptions = EmojiFonts.options();
        for (final EmojiFonts.Option o : fontOptions) {
            if (o.path.equals(EmojiFonts.APPLE)) {
                appleRow(f, o, chosen);   // v3.105: downloads the font the first time
                continue;
            }
            LinearLayout r = row(f);
            r.addView(text(o.label, 17, labelColor, false), fill());
            if (o.path.equals(chosen)) {
                r.addView(new SettingsGlyphs.ShapeView(this, SettingsGlyphs.ShapeView.CHECK, accent),
                        new LinearLayout.LayoutParams(dp(18), dp(14)));
            }
            ripple(r);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    prefs.edit().putString(Prefs.K_EMOJI_FONT, o.path).apply();
                    refreshTop();
                }
            });
        }
        soonRow(f, "iOS emoji (coming soon)");
        String fontNote = fontOptions.size() > 1
                ? "Found " + (fontOptions.size() - 1) + " emoji font" + (fontOptions.size() > 2 ? "s" : "")
                        + " on this phone. Emoji in the emoji panel and search use the font you choose. "
                : "Only the phone’s own emoji font was found, so there is nothing else to choose. The phone’s font list "
                        + "and its font folders were checked. ";
        footer(col, fontNote + "Emoji you send to other apps show in those apps’ own style.");

        header(col, "Layout");
        LinearLayout g = group(col);
        soonRow(g, "Emoji fast-access row");
        soonRow(g, "Emoji in symbols keyboard");
        sliderRow(col, "Emoji size", Prefs.K_EMOJI_SCALE, Prefs.MIN_EMOJI_SCALE, Prefs.MAX_EMOJI_SCALE, Prefs.DEFAULT_EMOJI_SCALE, "%");

        header(col, "Suggestions");
        g = group(col);
        toggleRow(g, "Text-to-emoji options", Prefs.K_TEXT_EMOJI, true);
        soonRow(g, "GIF category suggestions");

        header(col, "Suggestion strip");
        g = group(col);
        toggleRow(g, "Show emoji", Prefs.K_SUG_EMOJI, true);
        soonRow(g, "Show stickers");

        header(col, "Emoji Kitchen");
        g = group(col);
        soonRow(g, "Show stickers and explore options on emoji key tap");
    }

    private void buildLayout(LinearLayout col) {
        editTiles.clear();
        editSlot = null;
        header(col, "Size");
        sliderRow(col, "Keyboard height", Prefs.K_HEIGHT, Prefs.MIN_HEIGHT, Prefs.MAX_HEIGHT, Prefs.DEFAULT_HEIGHT, "dp");

        header(col, "Bottom row");
        LinearLayout g = group(col);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(8), dp(8), dp(8), dp(8));
        addKeyEditor(box);
        addRow(g, box);
        footer(col, "Tap a highlighted tile to change it. Tap + to add a button, or Delete to remove one. "
                + "Between 123 and space, and between space and return, each take one button; the return key is split in half "
                + "for the second. The corners swap if you pick the same button for both.");
    }

    private void buildClipboard(LinearLayout col) {
        header(col, "Clipboard");
        LinearLayout g = group(col);
        toggleRow(g, "Show recently copied text and images in suggestions bar", Prefs.K_CLIP, true);
        soonRow(g, "Show addresses, phone numbers, and other items pulled from recently copied text");
        soonRow(g, "Save recent screenshots in clipboard");

        header(col, "History");
        g = group(col);
        toggleRow(g, "Remember clipboard after restart", "clip_remember", true);
        buttonRow(g, "Clear clipboard history", destructiveColor, new Runnable() {
            @Override
            public void run() {
                prefs.edit().putLong(Prefs.K_CLIP_CLEAR_TOKEN, System.currentTimeMillis()).apply();
                Toast.makeText(MainActivity.this, "Clipboard cleared", Toast.LENGTH_SHORT).show();
            }
        }, true);
        footer(col, "Clipboard history is saved on this phone, so it is still there after a restart. Copies made in "
                + "password fields are never saved. Turning this off deletes the saved copies.");
    }

    private void buildPrivacy(LinearLayout col) {
        header(col, "Your data stays on this phone");
        LinearLayout g = group(col);
        valueRow(g, "Internet access", "None", secondaryColor);
        valueRow(g, "Voice typing", "Your phone’s own service", secondaryColor);
        valueRow(g, "Password fields", "Suggestions off", secondaryColor);
        footer(col, "TypeFlow has no internet permission, so nothing you type, copy or change can leave this phone. "
                + "It records no audio.");

        header(col, "Stored on this phone");
        g = group(col);
        toggleRow(g, "Learn words on this phone", Prefs.K_LEARN, true);
        valueRow(g, "Clipboard history", "Saved on this phone", secondaryColor);
        buttonRow(g, "Delete learned words", destructiveColor, new Runnable() {
            @Override
            public void run() {
                prefs.edit().remove(Prefs.K_LEARNED)
                        .putLong(Prefs.K_CLEAR_TOKEN, System.currentTimeMillis()).apply();
                Toast.makeText(MainActivity.this, "Learned words deleted", Toast.LENGTH_SHORT).show();
            }
        }, true);
        buttonRow(g, "Clear clipboard history", destructiveColor, new Runnable() {
            @Override
            public void run() {
                prefs.edit().putLong(Prefs.K_CLIP_CLEAR_TOKEN, System.currentTimeMillis()).apply();
                Toast.makeText(MainActivity.this, "Clipboard history cleared", Toast.LENGTH_SHORT).show();
            }
        }, true);
        footer(col, "Learned words and clipboard history are kept only on this phone. Uninstalling TypeFlow "
                + "removes everything it has stored.");

        header(col, "Usage statistics");
        g = group(col);
        soonRow(g, "Share usage statistics");
        footer(col, "TypeFlow does not collect or share usage statistics. This setting is not available.");

        header(col, "Documents");
        g = group(col);
        navRow(g, "Privacy Policy", null, P_PRIVACY_POLICY);
        navRow(g, "Terms of Service", null, P_TERMS);
    }

    private void buildAbout(LinearLayout col) {
        header(col, "TypeFlow");
        LinearLayout g = group(col);
        valueRow(g, "Version", appVersion(), secondaryColor);
        valueRow(g, "Developer", LegalText.DEVELOPER, secondaryColor);
        valueRow(g, "Contact", LegalText.CONTACT, secondaryColor);

        header(col, "Legal");
        g = group(col);
        navRow(g, "Terms of Service", null, P_TERMS);
        navRow(g, "Privacy Policy", null, P_PRIVACY_POLICY);
        navRow(g, "Open source licenses", null, P_LICENSES);
        footer(col, "Last updated " + LegalText.UPDATED + ".");

        header(col, "Tips");
        g = group(col);
        textRow(g, "\u2022 Tap \u21E7 once for one capital, twice for caps lock.\n"
                + "\u2022 Hold a top-row letter to type its number.\n"
                + "\u2022 Slide your finger along the space bar to move the cursor.\n"
                + "\u2022 Hold \u232B to keep deleting.\n"
                + "\u2022 Tap the globe to switch keyboards, hold it for the full list.\n"
                + "\u2022 Tap the mic to switch to your phone’s voice typing.\n"
                + "\u2022 Open this app any time to change the look.");
    }

    /** A legal document: alternating headings and paragraphs. */
    private void buildLegal(LinearLayout col, String[] doc) {
        for (int i = 0; i + 1 < doc.length; i += 2) {
            header(col, doc[i]);
            LinearLayout g = group(col);
            textRow(g, doc[i + 1]);
        }
        footer(col, "Last updated " + LegalText.UPDATED + ".");
    }

    /** The open source notices bundled with the app, read from the assets so they match the files shipped. */
    private void buildLicenses(LinearLayout col) {
        header(col, "Bundled data");
        LinearLayout g = group(col);
        textRow(g, "English Speller Database (ESDB) word lists, Kevin Atkinson, from github.com/en-wl/wordlist.\n\n"
                + readAsset("wordlist/COPYING-ESDB.txt"));

        header(col, "Spelling dictionary");
        g = group(col);
        textRow(g, "Hunspell en_AU dictionary, version 2026.02.25, from wordlist.aspell.net.\n\n"
                + readAsset("wordlist/COPYING-en_AU.txt"));

        header(col, "Emoji and fonts");
        g = group(col);
        textRow(g, "Emoji characters and their order are taken from the Unicode Standard. Unicode, Inc. Terms of Use apply.\n\n"
                + "SF Pro Display typeface \u00A9 Apple Inc. All rights reserved.");

        footer(col, "TypeFlow contains no third-party code libraries. The notices above cover the data and fonts "
                + "bundled with the app.");
    }

    /** Text of a file in the app's assets; a short note if it cannot be read. */
    private String readAsset(String name) {
        try (java.io.InputStream in = getAssets().open(name)) {
            java.util.Scanner sc = new java.util.Scanner(in, "UTF-8").useDelimiter("\\A");
            return sc.hasNext() ? sc.next() : "";
        } catch (java.io.IOException e) {
            return "The notice could not be read.";
        }
    }

    private void buildVisuals(LinearLayout col) {
        header(col, "Theme");
        segmentRow(col, new String[]{"System", "Light", "Dark"}, Prefs.theme(prefs), Prefs.K_THEME);
        footer(col, "System follows your phone's light or dark mode.");

        header(col, "Accent colour");
        accentSegmentRow(col);
        footer(col, "Used for the Return, Go and Search key and the buttons in this app.");

        header(col, "Glass");
        LinearLayout g = group(col);
        toggleRow(g, "Frosted glass", Prefs.K_BLUR, true);
        soonRow(g, "Liquid glass");
        sliderRow(col, "Blur strength", Prefs.K_BLUR_DP, Prefs.MIN_BLUR_DP, Prefs.MAX_BLUR_DP, Prefs.DEFAULT_BLUR_DP, "dp");
        sliderRow(col, "Opacity", Prefs.K_OPACITY, Prefs.MIN_OPACITY, Prefs.MAX_OPACITY, Prefs.DEFAULT_OPACITY, "%");
        footer(col, "The keyboard becomes see-through with a blur. Real blur needs Android 12+ with window blur enabled on "
                + "your phone; otherwise you get a soft see-through look.");

        header(col, "Shape");
        g = group(col);
        toggleRow(g, "Rounded keyboard corners", Prefs.K_ROUNDED, true);

        header(col, "Themes");
        g = group(col);
        soonRow(g, "Keyboard themes");
        soonRow(g, "Key style");
        soonRow(g, "Background image");
    }

    /** A root row that is not built yet: its icon tile, and its label greyed out. */
    private void soonIconRow(LinearLayout g, String label, int iconId) {
        LinearLayout r = row(g);
        View icon = iconTile(iconId);
        if (icon != null) {
            r.addView(icon);
            g.setTag(dp(INSET + TILE + TILE_GAP));    // separators start under the label
        }
        r.addView(text(label, 17, secondaryColor, false), fill());
        addNotYetNote(r, label);
    }

    /** The "Not available yet" note on the right of a row that is not built, and its tap message. */
    private void addNotYetNote(LinearLayout r, final String label) {
        TextView note = text("Not available yet", 13, secondaryColor, false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = dp(8);
        r.addView(note, lp);
        ripple(r);
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, label + " is not available yet.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /** A setting that is not implemented in this version: its label is greyed out, with a "Not available yet" note. */
    private void soonRow(LinearLayout g, String label) {
        LinearLayout r = row(g);
        r.addView(text(label, 17, secondaryColor, false), new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        addNotYetNote(r, label);
    }

    // ----------------------------------------------------------- status helpers
    private boolean isEnabled() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm == null) return false;
        for (InputMethodInfo info : imm.getEnabledInputMethodList()) {
            if (info.getPackageName().equals(getPackageName())) {
                return true;
            }
        }
        return false;
    }

    private boolean isSelected() {
        String id = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        return id != null && id.startsWith(getPackageName() + "/");
    }

    private String appVersion() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "?";
        }
    }

    private String setupSummary() {
        if (isSelected()) return "Active";
        if (isEnabled()) return "Not selected";
        return "Not enabled";
    }

    private String themeName() {
        switch (Prefs.theme(prefs)) {
            case 1: return "Light";
            case 2: return "Dark";
            default: return "System";
        }
    }

    // --------------------------------------------------------- iOS building blocks
    private static final int ROW_H = 52;       // row height, dp (iOS 26)
    private static final int GROUP_R = 26;     // grouped-list corner radius, dp (iOS 26)
    /** The one padding for every card and capsule: the gap from the edge to the content, on all sides, in dp. */
    static final int PAD = 12;
    /** Side inset of text, rows and separators inside every card (toggles and sliders keep PAD). */
    static final int SIDE = 16;
    private static final int INSET = SIDE;     // text and row inset inside a group, dp
    private static final int TILE = 30;        // icon tile size, dp
    private static final int TILE_GAP = 14;    // gap between the icon tile and the label, dp
    /** Slider handle size, dp; the gap to the capsule edge is (ROW_H - THUMB_H) / 2 = 12 on every side. */
    private static final int THUMB_W = 44, THUMB_H = 28;
    // icon tiles for the root rows that are not built yet (their label is greyed out; the tile keeps its colour)
    static final int I_DICTIONARY = 13, I_SHARE = 14, I_HELP = 15;

    private int dp(float v) {
        return Math.round(v * density);
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) {
            t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        }
        return t;
    }

    /**
     * Settings glass: the keyboard's own glass (same top-to-bottom gradient, hairline rim and continuous G2
     * corner as its keys). Used for the grouped panels, the icon tiles and the back button.
     */
    private Drawable glass(float radiusDp) {
        return glass(radiusDp, SettingsGlyphs.G2);
    }

    /** power = the superellipse exponent: G2_POWER for the continuous corners, 2 for a true circle. */
    private Drawable glass(float radiusDp, float power) {
        int top = dark ? 0x2EFFFFFF : 0x8CFFFFFF;
        int bottom = dark ? 0x1FFFFFFF : 0x61FFFFFF;
        int rim = dark ? 0x26FFFFFF : 0x99FFFFFF;
        return new KeyboardService.G2Drawable(top, bottom, rim, Math.max(1, Math.round(0.75f * density)), dp(radiusDp), power);
    }

    private Drawable pill(int color) {
        return pill(color, 10);
    }

    /** A solid rounded panel, tile or button with the keyboard's G2 continuous-curvature corners. */
    private Drawable pill(int color, float radiusDp) {
        return new KeyboardService.G2Drawable(color, color, 0, 0f, dp(radiusDp), SettingsGlyphs.G2);
    }

    private void ripple(View r) {
        TypedValue tv = new TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackground, tv, true);
        r.setBackgroundResource(tv.resourceId);
        r.setClickable(true);
    }

    /** Section title above a group: grey, medium weight, not capitalised (iOS 26). */
    private void header(LinearLayout col, String title) {
        TextView t = text(title, 15, secondaryColor, false);
        t.setTag("medium");
        t.setTypeface(Fonts.medium(this));
        t.setPadding(dp(16), dp(26), dp(16), dp(8));
        col.addView(t);
    }

    private void footer(LinearLayout col, String title) {
        TextView t = text(title, 13, secondaryColor, false);
        t.setLineSpacing(0, 1.1f);
        t.setPadding(dp(16), dp(8), dp(16), 0);
        col.addView(t);
    }

    /** An inset grouped list: one rounded panel. Rows are added with addRow(). */
    private LinearLayout group(LinearLayout col) {
        LinearLayout g = new LinearLayout(this);
        g.setOrientation(LinearLayout.VERTICAL);
        g.setBackground(glass(SettingsGlyphs.CARD_G2_R, SettingsGlyphs.G2));   // G2 corners, same corner as a capsule
        if (Build.VERSION.SDK_INT >= 21) {
            final float r = dp(SettingsGlyphs.CARD_G2_R);
            g.setClipToOutline(true);
            // the card's clip is the same G2 continuous-curvature shape as its painted glass
            g.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View v, android.graphics.Outline o) {
                    android.graphics.Path p = new android.graphics.Path();
                    boolean capsule = Boolean.TRUE.equals(v.getTag());   // single-row panels are capsules
                    float rad = capsule ? dp(999) : r;
                    KeyboardService.g2Rect(p, 0, 0, v.getWidth(), v.getHeight(), rad,
                            capsule ? SettingsGlyphs.CAPSULE : SettingsGlyphs.G2);
                    o.setPath(p);
                }
            });
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        int n = col.getChildCount();
        if (n > 0 && col.getChildAt(n - 1) instanceof LinearLayout) {
            lp.topMargin = dp(34);                  // two groups in a row, no header between
        }
        col.addView(g, lp);
        return g;
    }

    /**
     * A panel with one row (a switch, a link) is a full glass capsule, like the sliders. Multi-row panels keep their
     * rounded corners. A panel is only a capsule when its single child is a horizontal row, so tall boxes stay rounded.
     */
    private void capsulise(LinearLayout col) {
        for (int i = 0; i < col.getChildCount(); i++) {
            View v = col.getChildAt(i);
            if (!(v instanceof LinearLayout) || ((LinearLayout) v).getChildCount() != 1) continue;
            View only = ((LinearLayout) v).getChildAt(0);
            if (only instanceof LinearLayout && ((LinearLayout) only).getOrientation() == LinearLayout.HORIZONTAL) {
                v.setBackground(glass(999, SettingsGlyphs.CAPSULE));
                v.setTag(Boolean.TRUE);
            }
        }
    }

    /** Adds a row to a group, with a hairline separator above it (not above the first row). */
    private void addRow(LinearLayout g, View row) {
        if (g.getChildCount() > 0) {
            View sep = new View(this);
            sep.setBackgroundColor(separatorColor);
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    Math.max(1, Math.round(0.5f * density)));
            sp.leftMargin = g.getTag() instanceof Integer ? (Integer) g.getTag() : dp(INSET);
            sp.rightMargin = dp(INSET);
            g.addView(sep, sp);
        }
        g.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private LinearLayout row(LinearLayout g) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setMinimumHeight(dp(ROW_H));
        r.setPadding(dp(INSET), dp(8), dp(INSET), dp(8));
        addRow(g, r);
        return r;
    }

    private LinearLayout.LayoutParams fill() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    /** The coloured icon tile of a settings page (iOS style): colour and symbol per page. */
    private View iconTile(int page) {
        if (page <= 0 || page >= SettingsGlyphs.OPS.length) return null;
        int base = (dark ? SettingsGlyphs.TILE_DARK : SettingsGlyphs.TILE_LIGHT)[page];
        SettingsGlyphs.GlyphView v = new SettingsGlyphs.GlyphView(this, page);
        int lit = SettingsGlyphs.lighten(base, SettingsGlyphs.TILE_LIGHTEN);
        // coloured glass: the page colour seen through the glass, a soft sheen over the top, the keyboard's rim
        Drawable tint = new KeyboardService.G2Drawable((lit & 0x00FFFFFF) | 0xE6000000,
                (base & 0x00FFFFFF) | 0xD9000000, 0x59FFFFFF, Math.max(1, Math.round(0.75f * density)), dp(SettingsGlyphs.CARD_G2_R), SettingsGlyphs.G2);
        Drawable sheen = new KeyboardService.G2Drawable(0x66FFFFFF, 0x00FFFFFF, 0, 0f, dp(SettingsGlyphs.CARD_G2_R), SettingsGlyphs.G2);
        v.setBackground(new LayerDrawable(new Drawable[]{tint, sheen}));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(TILE), dp(TILE));
        lp.rightMargin = dp(TILE_GAP);
        v.setLayoutParams(lp);
        return v;
    }

    private void navRow(LinearLayout g, String label, String detail, final int pageId) {
        LinearLayout r = row(g);
        ripple(r);
        r.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                push(pageId, true);
            }
        });
        // icon tiles only on the first list, like the iOS Settings home screen
        if (!stack.isEmpty() && stack.get(stack.size() - 1) == P_ROOT) {
            View icon = iconTile(pageId);
            if (icon != null) {
                r.addView(icon);
                g.setTag(dp(INSET + TILE + TILE_GAP));    // separators start under the label
            }
        }
        r.addView(text(label, 17, labelColor, false), fill());
        if (detail != null) {
            TextView d = text(detail, 17, secondaryColor, false);
            d.setPadding(dp(8), 0, dp(10), 0);
            r.addView(d);
        } else {
            r.addView(new View(this), new LinearLayout.LayoutParams(dp(10), 1));
        }
        r.addView(new SettingsGlyphs.ShapeView(this, SettingsGlyphs.ShapeView.CHEVRON_RIGHT, chevronColor),
                new LinearLayout.LayoutParams(dp(8), dp(14)));
    }

    private void valueRow(LinearLayout g, String label, String value, int valueColor) {
        LinearLayout r = row(g);
        r.addView(text(label, 17, labelColor, false), fill());
        TextView v = text(value, 17, valueColor, false);
        v.setGravity(Gravity.END);
        v.setPadding(dp(12), 0, 0, 0);
        r.addView(v);
    }

    /** An action row: blue (or red) text on the left, like iOS. */
    private void buttonRow(LinearLayout g, String label, int color, final Runnable action, boolean enabled) {
        LinearLayout r = row(g);
        r.addView(text(label, 17, enabled ? color : secondaryColor, false), fill());
        if (enabled) {
            ripple(r);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    action.run();
                }
            });
        }
    }

    private void textRow(LinearLayout g, String body) {
        TextView t = text(body, 15, labelColor, false);
        t.setLineSpacing(0, 1.12f);
        t.setPadding(dp(INSET), dp(12), dp(INSET), dp(12));
        addRow(g, t);
    }

    private void toggleRow(LinearLayout g, String label, final String key, boolean def) {
        LinearLayout r = row(g);
        // the 28 dp switch sits 12 dp from the top and bottom of the 52 dp row; the right gap is 12 dp too
        r.setPadding(dp(INSET), dp(8), dp(PAD), dp(8));
        r.addView(text(label, 17, labelColor, false), fill());
        ToggleView t = new ToggleView(Prefs.on(prefs, key));
        t.setListener(new ToggleListener() {
            @Override
            public void changed(boolean on) {
                prefs.edit().putBoolean(key, on).apply();
            }
        });
        r.addView(t);
    }

    /** A list of choices, one per row, the chosen one with a blue check mark (iOS "Format: HDR / SDR"). Saves an int. */
    private void checkListRow(LinearLayout g, final String[] names, int selected, final String key) {
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            LinearLayout r = row(g);
            r.addView(text(names[i], 17, labelColor, false), fill());
            if (i == selected) {
                r.addView(new SettingsGlyphs.ShapeView(this, SettingsGlyphs.ShapeView.CHECK, accent),
                        new LinearLayout.LayoutParams(dp(18), dp(14)));
            }
            ripple(r);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    prefs.edit().putInt(key, idx).apply();
                    refreshTop();
                }
            });
        }
    }

    /** The accent colours, one per row with a colour dot; the chosen one has a check mark. */
    private void accentListRow(LinearLayout g) {
        String[] names = {"Blue", "Green", "Purple", "Orange", "Pink"};
        int current = Prefs.accent(prefs);
        for (int i = 0; i < Prefs.ACCENTS.length; i++) {
            final int idx = i;
            LinearLayout r = row(g);
            View dot = new View(this);
            GradientDrawable d = new GradientDrawable();
            d.setShape(GradientDrawable.OVAL);
            d.setColor(Prefs.ACCENTS[i]);
            dot.setBackground(d);
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(22), dp(22));
            dl.rightMargin = dp(14);
            r.addView(dot, dl);
            r.addView(text(i < names.length ? names[i] : "Colour " + (i + 1), 17, labelColor, false), fill());
            if (i == current) {
                r.addView(new SettingsGlyphs.ShapeView(this, SettingsGlyphs.ShapeView.CHECK, accent),
                        new LinearLayout.LayoutParams(dp(18), dp(14)));
            }
            ripple(r);
            r.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    prefs.edit().putInt(Prefs.K_ACCENT, idx).apply();
                    refreshTop();
                }
            });
        }
        g.setTag(dp(INSET + 22 + 14));      // separators start under the label
    }

    /** A glass capsule panel (the same glass and round ends as the slider panels). */
    private FrameLayout capsuleCard() {
        FrameLayout card = new FrameLayout(this);
        card.setBackground(glass(999, SettingsGlyphs.CAPSULE));
        if (Build.VERSION.SDK_INT >= 21) {
            card.setClipToOutline(true);
            card.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View v, android.graphics.Outline o) {
                    android.graphics.Path p = new android.graphics.Path();
                    KeyboardService.g2Rect(p, 0, 0, v.getWidth(), v.getHeight(), dp(999), SettingsGlyphs.CAPSULE);
                    o.setPath(p);
                }
            });
        }
        return card;
    }

    /** The highlight behind the chosen part of a capsule selector: the slider handle's glass, any size. */
    private Drawable glassSelector(float radiusDp) {
        // light mode: a white highlight cannot be seen on the light panel, so the glass is tinted with the chosen accent
        int tint = accent & 0xFFFFFF;
        int edge = dark ? 0xFFFFFF : tint;
        int[] alphas = dark ? new int[]{0x44, 0x2E, 0x1C, 0x0C} : new int[]{0x40, 0x28, 0x18, 0x0A};
        Drawable[] layers = new Drawable[alphas.length + 1];
        layers[0] = new KeyboardService.G2Drawable(dark ? 0x2EFFFFFF : (0x4D << 24) | tint, dark ? 0x1FFFFFFF : (0x38 << 24) | tint,
                dark ? 0x26FFFFFF : (0x73 << 24) | tint, Math.max(1, Math.round(0.75f * density)), dp(radiusDp), SettingsGlyphs.CAPSULE);
        for (int k = 0; k < alphas.length; k++) {
            layers[k + 1] = new KeyboardService.G2Drawable(0, 0, (alphas[k] << 24) | edge, dp(1.5f), dp(radiusDp),
                    SettingsGlyphs.CAPSULE);
        }
        LayerDrawable t = new LayerDrawable(layers);
        for (int k = 0; k < alphas.length; k++) {
            int inset = dp(1.5f * (k + 1));
            t.setLayerInset(k + 1, inset, inset, inset, inset);
        }
        return t;
    }

    /** One equal part of a capsule selector. The highlight belongs to the selector, not the cell. */
    private View segmentCell(View content) {
        FrameLayout cell = new FrameLayout(this);
        cell.addView(content, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        return cell;
    }

    /** Called when the highlight settles on a part. */
    private interface OnPick {
        void picked(int index);
    }

    /**
     * A capsule selector: one glass highlight that glides between the parts. While the finger is down it follows the
     * finger, stretching softly with its speed. On release it snaps to the nearest part with a small overshoot and
     * registers that part (OnPick). A tap moves it to that part.
     */
    private final class CapsuleSelector extends FrameLayout {
        private final int n;
        private final int pad;
        private final View highlight;
        private final OnPick onPick;
        private int index;
        private float x;                 // highlight offset from the first part, in px
        private float cellW;
        private VelocityTracker vt;
        private ValueAnimator anim;

        CapsuleSelector(android.content.Context c, View[] cells, int selected, OnPick onPick) {
            super(c);
            this.n = cells.length;
            this.index = selected;
            this.onPick = onPick;
            this.pad = dp(4);
            highlight = new View(c);
            highlight.setBackground(glassSelector(ROW_H / 2f - 4));
            addView(highlight);
            LinearLayout line = new LinearLayout(c);
            line.setOrientation(LinearLayout.HORIZONTAL);
            line.setPadding(pad, pad, pad, pad);
            for (View cell : cells) {
                line.addView(cell, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
            }
            addView(line, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent e) {
                    return onSelectorTouch(e);
                }
            });
        }

        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            super.onLayout(changed, l, t, r, b);
            cellW = (getWidth() - 2 * pad) / (float) n;
            int h = getHeight() - 2 * pad;
            highlight.layout(pad, pad, pad + Math.round(cellW), pad + h);
            highlight.setPivotX(cellW / 2f);
            highlight.setPivotY(h / 2f);
            if (anim == null && vt == null) {
                x = index * cellW;
            }
            highlight.setTranslationX(x);
        }

        private boolean onSelectorTouch(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: {
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                    if (anim != null) anim.cancel();
                    vt = VelocityTracker.obtain();
                    vt.addMovement(e);
                    moveTo(e.getX() - pad - cellW / 2f, 0f);
                    return true;
                }
                case MotionEvent.ACTION_MOVE: {
                    vt.addMovement(e);
                    vt.computeCurrentVelocity(1000);
                    moveTo(e.getX() - pad - cellW / 2f, vt.getXVelocity());
                    return true;
                }
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL: {
                    float vx = 0f;
                    if (vt != null) {
                        vt.addMovement(e);
                        vt.computeCurrentVelocity(1000);
                        vx = vt.getXVelocity();
                        vt.recycle();
                        vt = null;
                    }
                    int target = Math.max(0, Math.min(n - 1, Math.round(x / cellW)));
                    settleTo(target, vx);
                    return true;
                }
                default:
                    return true;
            }
        }

        /** The highlight follows the finger; the faster it moves, the more it stretches (soft, it squashes back). */
        private void moveTo(float target, float vx) {
            float maxX = (n - 1) * cellW;
            x = Math.max(0f, Math.min(maxX, target));
            float stretch = 0.16f * (1f - (float) Math.exp(-Math.abs(vx) / 700f));
            highlight.setTranslationX(x);
            highlight.setScaleX(1f + stretch);
            highlight.setScaleY(1f - stretch * 0.45f);
        }

        /** Glides to a part with a soft overshoot, stretches at the middle of the glide, then registers the part. */
        private void settleTo(final int target, float vx) {
            final float from = x;
            final float to = target * cellW;
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(340);
            anim.setInterpolator(new OvershootInterpolator(0.9f));
            anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator va) {
                    float t = (Float) va.getAnimatedValue();
                    x = from + (to - from) * t;
                    float stretch = 0.10f * (float) Math.sin(Math.PI * Math.min(1f, t));
                    highlight.setTranslationX(x);
                    highlight.setScaleX(1f + stretch);
                    highlight.setScaleY(1f - stretch * 0.45f);
                }
            });
            anim.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    highlight.setScaleX(1f);
                    highlight.setScaleY(1f);
                    x = to;
                    highlight.setTranslationX(x);
                    anim = null;
                    if (target != index) {
                        index = target;
                        onPick.picked(target);
                    }
                }
            });
            anim.start();
        }
    }

    private void addSegments(LinearLayout col, View[] cells, int selected, OnPick onPick) {
        FrameLayout card = capsuleCard();
        card.addView(new CapsuleSelector(this, cells, selected, onPick), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        col.addView(card, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ROW_H)));
    }

    /** A glass capsule split into equal parts, one choice each (Theme, One-handed keyboard, Flick sensitivity). Saves an int. */
    private void segmentRow(LinearLayout col, final String[] names, int selected, final String key) {
        View[] cells = new View[names.length];
        for (int i = 0; i < names.length; i++) {
            TextView label = text(names[i], 16, i == selected ? accent : labelColor, false);
            if (i == selected) label.setTypeface(Fonts.medium(this));
            cells[i] = segmentCell(label);
        }
        addSegments(col, cells, selected, new OnPick() {
            @Override
            public void picked(int idx) {
                prefs.edit().putInt(key, idx).apply();
                refreshTop();
            }
        });
    }

    /** The accent colours as round colour dots in one glass capsule, five equal parts. */
    private void accentSegmentRow(LinearLayout col) {
        int current = Prefs.accent(prefs);
        View[] cells = new View[Prefs.ACCENTS.length];
        for (int i = 0; i < cells.length; i++) {
            View dot = new View(this);
            GradientDrawable d = new GradientDrawable();
            d.setShape(GradientDrawable.OVAL);
            d.setColor(Prefs.ACCENTS[i]);
            dot.setBackground(d);
            View cell = segmentCell(dot);
            ((FrameLayout) cell).getChildAt(0).setLayoutParams(new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
            cells[i] = cell;
        }
        addSegments(col, cells, current, new OnPick() {
            @Override
            public void picked(int idx) {
                prefs.edit().putInt(Prefs.K_ACCENT, idx).apply();
                refreshTop();
            }
        });
    }

    /** Title and value on one line, an iOS slider (thin track, white round thumb) below. */
    /** A capsule (round ends) in one colour: the slider track and its fill. */
    private Drawable capsule(int color) {
        return new KeyboardService.G2Drawable(color, color, 0, 0f, dp(3), SettingsGlyphs.CAPSULE);
    }

    /**
     * The slider handle: a liquid glass lens. RefractLayer bends the track behind it (magnified in the middle, the
     * edges pull in the surroundings, red, green and blue bend by slightly different amounts). On top: a faint veil
     * and rim, a dark blurred shadow just inside the edge, a specular rim at the top-left and bottom-right, a soft gloss.
     */
    private Drawable glassThumb(SeekBar seek) {
        final int rad = dp(THUMB_H / 2f);
        // the scene behind the handle is the page glass; the track and its fill are drawn over this colour
        final int base = dark ? 0xFF262626 : 0xFFF8F8FA;
        final int[] alphas = {0x5C, 0x4A, 0x3A, 0x2C, 0x20, 0x16, 0x0E, 0x08};   // eight fine rings, so no visible steps
        Drawable[] layers = new Drawable[alphas.length + 4];
        layers[0] = new RefractLayer(seek, base);
        layers[1] = new KeyboardService.G2Drawable(dark ? 0x1AFFFFFF : 0x38FFFFFF, dark ? 0x10FFFFFF : 0x20FFFFFF,
                dark ? 0x26FFFFFF : 0x99FFFFFF, Math.max(1, Math.round(0.75f * density)), rad, SettingsGlyphs.CAPSULE);
        for (int k = 0; k < alphas.length; k++) {
            layers[k + 2] = new KeyboardService.G2Drawable(0, 0, alphas[k] << 24, dp(1.0f), rad, SettingsGlyphs.CAPSULE);
        }
        layers[alphas.length + 2] = new SpecularRim();
        layers[alphas.length + 3] = new KeyboardService.G2Drawable(dark ? 0x33FFFFFF : 0x55FFFFFF, 0x00FFFFFF, 0, 0f,
                rad, SettingsGlyphs.CAPSULE);
        LayerDrawable t = new LayerDrawable(layers);
        for (int i = 0; i < layers.length; i++) {
            t.setLayerSize(i, dp(THUMB_W), dp(THUMB_H));
            t.setLayerGravity(i, Gravity.CENTER);
        }
        for (int k = 0; k < alphas.length; k++) {
            int inset = dp(0.8f * (k + 1));
            t.setLayerInset(k + 2, inset, inset, inset, inset);
        }
        return t;
    }

    // BEGIN LENS (the preview renderer has a port of this block, keep the two the same)
    private static final float[] LENS_MAG = {0.66f, 0.72f, 0.78f};    // red, green, blue magnification (1 / this)
    private static final float[] LENS_DISP = {0.90f, 1.00f, 1.10f};   // red, green, blue edge pull
    private static final float LENS_PUSH = 0.95f;                     // edge pull, in handle half-heights
    private static final float LENS_BAND = 0.70f;                     // width of the edge band, in half-heights

    /** Bends the scene s (sw x sh, the handle plus a margin m on every side) into the capsule o (w x h). */
    private static void lensRefract(int[] s, int sw, int sh, int[] o, int w, int h, int m) {
        final float hw = w / 2f, hh = h / 2f, r = hh, a = hw - r;
        final float pushAmp = LENS_PUSH * r, band = LENS_BAND * r;
        for (int y = 0; y < h; y++) {
            float py = y + 0.5f - hh;
            for (int x = 0; x < w; x++) {
                float px = x + 0.5f - hw;
                float cx = Math.max(-a, Math.min(a, px));
                float dx = px - cx, dy = py;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);
                float t = r - dist;
                if (t <= 0f) {
                    o[y * w + x] = 0;
                    continue;
                }
                float nx = dist > 1e-4f ? dx / dist : 0f;
                float ny = dist > 1e-4f ? dy / dist : 0f;
                float e = Math.max(0f, Math.min(1f, 1f - t / band));
                float push = pushAmp * e * e;
                int rgb = 0;
                for (int ch = 0; ch < 3; ch++) {
                    float sx = px * LENS_MAG[ch] + nx * push * LENS_DISP[ch] + hw + m;
                    float sy = py * LENS_MAG[ch] + ny * push * LENS_DISP[ch] + hh + m;
                    int shift = 16 - 8 * ch;
                    rgb |= lensSample(s, sw, sh, sx, sy, shift) << shift;
                }
                int alpha = Math.round(255f * Math.min(1f, t));
                o[y * w + x] = (alpha << 24) | rgb;
            }
        }
    }

    /** One colour channel of s at (x, y), bilinear. shift is 16 for red, 8 for green, 0 for blue. */
    private static int lensSample(int[] s, int sw, int sh, float x, float y, int shift) {
        float u = x - 0.5f, v = y - 0.5f;
        int x0 = (int) Math.floor(u), y0 = (int) Math.floor(v);
        float fx = u - x0, fy = v - y0;
        int x1 = Math.max(0, Math.min(sw - 1, x0 + 1));
        int y1 = Math.max(0, Math.min(sh - 1, y0 + 1));
        x0 = Math.max(0, Math.min(sw - 1, x0));
        y0 = Math.max(0, Math.min(sh - 1, y0));
        float c00 = (s[y0 * sw + x0] >> shift) & 255, c10 = (s[y0 * sw + x1] >> shift) & 255;
        float c01 = (s[y1 * sw + x0] >> shift) & 255, c11 = (s[y1 * sw + x1] >> shift) & 255;
        float val = (c00 * (1f - fx) + c10 * fx) * (1f - fy) + (c01 * (1f - fx) + c11 * fx) * fy;
        return Math.round(val);
    }
    // END LENS

    /**
     * The handle's glass. It draws the slider's own track (and its accent fill) into a small bitmap, bends that
     * bitmap through the lens (lensRefract) and paints the result in the handle's capsule, so the colours underneath
     * really are bent, like liquid. It redraws whenever the slider does, so the bend follows the finger.
     */
    private final class RefractLayer extends Drawable {
        private final SeekBar seek;
        private final int base;
        private final Paint bmpPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
        private android.graphics.Bitmap srcBmp, outBmp;
        private Canvas srcCanvas;
        private int[] sp, op;

        RefractLayer(SeekBar seek, int base) {
            this.seek = seek;
            this.base = base;
        }

        @Override
        public void draw(Canvas c) {
            android.graphics.Rect b = getBounds();
            int w = b.width(), h = b.height();
            if (w < 4 || h < 4) return;
            int m = dp(14);
            int sw = w + 2 * m, sh = h + 2 * m;
            if (srcBmp == null || srcBmp.getWidth() != sw || srcBmp.getHeight() != sh) {
                srcBmp = android.graphics.Bitmap.createBitmap(sw, sh, android.graphics.Bitmap.Config.ARGB_8888);
                srcCanvas = new Canvas(srcBmp);
                sp = new int[sw * sh];
            }
            if (outBmp == null || outBmp.getWidth() != w || outBmp.getHeight() != h) {
                outBmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888);
                op = new int[w * h];
            }
            // the scene behind the handle: the glass colour, then the track and its fill where they are
            srcBmp.eraseColor(base);
            srcCanvas.save();
            srcCanvas.translate(seek.getThumbOffset() - (b.left - m), -(b.top - m));
            Drawable track = seek.getProgressDrawable();
            if (track != null) track.draw(srcCanvas);
            srcCanvas.restore();
            srcBmp.getPixels(sp, 0, sw, 0, 0, sw, sh);
            lensRefract(sp, sw, sh, op, w, h, m);
            outBmp.setPixels(op, 0, w, 0, 0, w, h);
            c.drawBitmap(outBmp, b.left, b.top, bmpPaint);
        }

        @Override
        public void setAlpha(int alpha) {
        }

        @Override
        public void setColorFilter(android.graphics.ColorFilter cf) {
        }

        @Override
        public int getOpacity() {
            return android.graphics.PixelFormat.TRANSLUCENT;
        }
    }

    /** A bright rim at the top-left and the bottom-right of the handle, fading out along the sides (the lens's glint). */
    private final class SpecularRim extends Drawable {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Path path = new android.graphics.Path();

        @Override
        public void draw(Canvas c) {
            android.graphics.Rect b = getBounds();
            float inset = dp(1.4f);
            path.reset();
            KeyboardService.g2Rect(path, b.left + inset, b.top + inset, b.right - inset, b.bottom - inset,
                    (b.height() - 2 * inset) / 2f, SettingsGlyphs.CAPSULE);
            int hi = dark ? 0xCCFFFFFF : 0xFFFFFFFF;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1.6f));
            p.setShader(new android.graphics.LinearGradient(b.left, b.top, b.right, b.bottom,
                    new int[]{hi, 0x00FFFFFF, 0x00FFFFFF, hi}, new float[]{0f, 0.32f, 0.68f, 1f},
                    android.graphics.Shader.TileMode.CLAMP));
            c.drawPath(path, p);
        }

        @Override
        public void setAlpha(int alpha) {
        }

        @Override
        public void setColorFilter(android.graphics.ColorFilter cf) {
        }

        @Override
        public int getOpacity() {
            return android.graphics.PixelFormat.TRANSLUCENT;
        }
    }

    private void sliderRow(LinearLayout col, final String title, final String key, final int min, final int max,
                           final int def, final String unit) {
        final int current = Math.max(min, Math.min(max, prefs.getInt(key, def)));
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setPadding(dp(16), dp(26), dp(16), dp(8));
        TextView name = text(title, 15, secondaryColor, false);
        name.setTypeface(Fonts.medium(this));
        top.addView(name, fill());
        final TextView value = text(current + " " + unit, 15, secondaryColor, false);
        top.addView(value);
        col.addView(top);

        // the standard glass capsule panel: the same width and row height as the other panels
        final FrameLayout card = new FrameLayout(this);
        card.setBackground(glass(999, SettingsGlyphs.CAPSULE));
        if (Build.VERSION.SDK_INT >= 21) {
            card.setClipToOutline(true);
            card.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override
                public void getOutline(View v, android.graphics.Outline o) {
                    android.graphics.Path p = new android.graphics.Path();
                    KeyboardService.g2Rect(p, 0, 0, v.getWidth(), v.getHeight(), dp(999), SettingsGlyphs.CAPSULE);
                    o.setPath(p);
                }
            });
        }

        SeekBar seek = new SeekBar(this);
        seek.setMax(max - min);
        seek.setProgress(current - min);
        // a plain slider: a thin track with the accent fill up to the handle, and the glass handle
        LayerDrawable layers = new LayerDrawable(new Drawable[]{capsule(trackColor),
                new ClipDrawable(capsule(accent), Gravity.START, ClipDrawable.HORIZONTAL)});
        layers.setId(0, android.R.id.background);
        layers.setId(1, android.R.id.progress);
        layers.setLayerHeight(0, dp(6));
        layers.setLayerHeight(1, dp(6));
        for (int i = 0; i < 2; i++) {
            layers.setLayerGravity(i, Gravity.CENTER_VERTICAL | Gravity.FILL_HORIZONTAL);
        }
        // the track runs from the centre of the handle at the minimum to the centre at the maximum
        int half = dp(THUMB_W / 2f);
        layers.setLayerInset(0, half, 0, half, 0);
        layers.setLayerInset(1, half, 0, half, 0);
        seek.setProgressDrawable(layers);
        seek.setThumb(glassThumb(seek));
        seek.setPadding(dp(PAD), 0, dp(PAD), 0);   // the handle's ends sit PAD from the capsule ends
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                int v = min + progress;
                value.setText(v + " " + unit);
                if (fromUser) {
                    prefs.edit().putInt(key, v).apply();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
            }
        });
        // centred vertically in the capsule, so the handle sits on the middle of the track
        card.addView(seek, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL));
        col.addView(card, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(ROW_H)));
    }

    /** iOS 26 switch, drawn: 64 x 28 dp track (green on, grey off) and a wide white capsule knob that slides. */
    interface ToggleListener {
        void changed(boolean on);
    }

    private final class ToggleView extends View {

        private boolean on;
        private float pos;                  // 0 = off, 1 = on, animated
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private ToggleListener listener;

        ToggleView(boolean initial) {
            super(MainActivity.this);
            on = initial;
            pos = initial ? 1f : 0f;
            setClickable(true);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);   // for the knob's soft shadow
        }

        void setListener(ToggleListener l) {
            listener = l;
        }

        @Override
        protected void onMeasure(int widthSpec, int heightSpec) {
            setMeasuredDimension(dp(64), dp(28));
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            paint.setStyle(Paint.Style.FILL);
            paint.clearShadowLayer();
            paint.setColor((Integer) new ArgbEvaluator().evaluate(pos, offColor, onColor));
            android.graphics.Path shape = new android.graphics.Path();
            KeyboardService.g2Rect(shape, 0, 0, w, h, h / 2f, SettingsGlyphs.CAPSULE);   // capsule track: round ends
            c.drawPath(shape, paint);
            float kw = dp(37), kh = dp(24);
            float pad = (h - kh) / 2f;
            float x = pad + pos * (w - 2 * pad - kw);
            paint.setColor(Color.WHITE);
            paint.setShadowLayer(dp(1.5f), 0, dp(1), 0x33000000);
            KeyboardService.g2Rect(shape, x, pad, x + kw, pad + kh, kh / 2f, SettingsGlyphs.CAPSULE);   // capsule knob
            c.drawPath(shape, paint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_UP) {
                on = !on;
                ValueAnimator a = ValueAnimator.ofFloat(pos, on ? 1f : 0f);
                a.setDuration(220);
                a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    @Override
                    public void onAnimationUpdate(ValueAnimator va) {
                        pos = (Float) va.getAnimatedValue();
                        invalidate();
                    }
                });
                a.start();
                if (listener != null) {
                    listener.changed(on);
                }
                performClick();
            }
            return true;
        }

        @Override
        public boolean performClick() {
            return super.performClick();
        }
    }

    // ----------------------------------------------------------- key editor
    /*
     * A clone of the keyboard's bottom rows. Letters and the fixed keys are shown but cannot be changed here.
     * The highlighted tiles can be changed: between 123 and space, between space and return (each holds one
     * button or none), and the two bottom corners (always one button each).
     */
    private static final String[] MID_LEFT = {"none", "emoji", "clip", "globe", "mic"};
    private static final String[] MID_RIGHT = {"none", "emoji", "clip", "globe", "mic"};
    private static final String[] CORNERS = {"emoji", "clip", "globe", "mic"};

    private final java.util.HashMap<String, KeyTileView> editTiles = new java.util.HashMap<>();
    private String editSlot;             // the preference of the tile whose choices are shown, or null
    private LinearLayout editPicker;     // the choices for editSlot

    private void addKeyEditor(LinearLayout parent) {
        LinearLayout board = new LinearLayout(this);
        board.setOrientation(LinearLayout.VERTICAL);
        board.setPadding(dp(6), dp(8), dp(6), dp(8));
        board.setBackground(new KeyboardService.G2Drawable(boardColor, boardColor, 0, 0f, dp(SettingsGlyphs.CARD_G2_R), SettingsGlyphs.G2));

        board.addView(keyRow(0f, new String[]{"q", "w", "e", "r", "t", "y", "u", "i", "o", "p"}));
        board.addView(keyRow(0.5f, new String[]{"a", "s", "d", "f", "g", "h", "j", "k", "l"}));
        board.addView(keyRow(0f, new String[]{"\u21E7", "z", "x", "c", "v", "b", "n", "m", "\u232B"}));

        // bottom row: 123 | slot | space | slot | return (the return key is split in half when a slot is used)
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.addView(fixedTile("123", 1.25f));
        bottom.addView(slotTile(Prefs.K_MID_KEY, MID_LEFT, 1.25f));
        bottom.addView(fixedTile("", 5f));
        bottom.addView(slotTile(Prefs.K_MID_RIGHT_KEY, MID_RIGHT, 1.25f));
        bottom.addView(fixedTile("\u21B5", 1.25f));
        board.addView(bottom);

        // the two corner buttons, under the keys
        LinearLayout corners = new LinearLayout(this);
        corners.setOrientation(LinearLayout.HORIZONTAL);
        corners.addView(slotTile(Prefs.K_CORNER_LEFT, CORNERS, 2.5f));
        corners.addView(blankTile(5f));
        corners.addView(slotTile(Prefs.K_CORNER_RIGHT, CORNERS, 2.5f));
        board.addView(corners);

        editPicker = new LinearLayout(this);
        editPicker.setOrientation(LinearLayout.VERTICAL);
        editPicker.setVisibility(View.GONE);
        editPicker.setPadding(0, dp(8), 0, 0);
        board.addView(editPicker);

        parent.addView(board, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        refreshEditor();
    }

    /** A row of letter tiles (static). */
    private LinearLayout keyRow(float indent, String[] labels) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        if (indent > 0f) {
            row.addView(blankTile(indent));
        }
        for (String l : labels) {
            boolean fn = l.equals("\u21E7") || l.equals("\u232B");
            row.addView(fixedTile(l, fn ? 1.5f : 1f));
        }
        if (indent > 0f) {
            row.addView(blankTile(indent));
        }
        return row;
    }

    /** A static tile (letters, 123, space, return). */
    private View fixedTile(String label, float weight) {
        KeyTileView t = tile(label, weight);
        t.set(label, iconForKey(label), false, false);
        return t;
    }

    /** An invisible spacer (the indent of a row, the gap between the corners). */
    private View blankTile(float weight) {
        KeyTileView t = tile("", weight);
        t.setBlank();
        return t;
    }

    private int iconForKey(String label) {
        switch (label) {
            case "\u21E7": return Icons.SHIFT;
            case "\u232B": return Icons.DELETE;
            case "\u21B5": return Icons.RETURN;
            default: return Icons.NONE;
        }
    }

    private int slotIcon(String value) {
        switch (value) {
            case "emoji": return Icons.EMOJI;
            case "mic": return Icons.MIC;
            case "globe": return Icons.GLOBE;
            default: return Icons.NONE;
        }
    }

    /** An editable tile: an accent outline; its label shows what it holds. Tap it to change it. */
    private View slotTile(final String prefKey, final String[] values, float weight) {
        KeyTileView t = tile("", weight);
        t.set("", Icons.NONE, true, false);
        editTiles.put(prefKey, t);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPicker(prefKey, values);
            }
        });
        return t;
    }

    private KeyTileView tile(String label, float weight) {
        KeyTileView t = new KeyTileView(this);
        t.set(label, Icons.NONE, false, false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), weight);
        lp.setMargins(dp(2), dp(3), dp(2), dp(3));
        t.setLayoutParams(lp);
        return t;
    }

    /**
     * A key of the bottom-row editor, drawn like the keyboard's own keys: the same G2 face and colours, the
     * keyboard's text font and icons. An editable slot has an accent outline; the chosen one is filled accent.
     */
    private final class KeyTileView extends View {
        private final Paint ink = new Paint(Paint.ANTI_ALIAS_FLAG);
        private String label = "";
        private int icon = Icons.NONE;
        private boolean blank, slot, selected;

        KeyTileView(Context c) {
            super(c);
        }

        void setBlank() {
            blank = true;
            invalidate();
        }

        void set(String text, int iconType, boolean isSlot, boolean isSelected) {
            label = text;
            icon = iconType;
            slot = isSlot;
            selected = isSelected;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            if (blank) {
                return;
            }
            float w = getWidth();
            float h = getHeight();
            if (w <= 0 || h <= 0) {
                return;
            }
            boolean dark = labelColor == 0xFFFFFFFF;
            int face = selected ? accent : (dark ? 0xFF434343 : 0xB3FFFFFF);   // the keyboard's key colours
            int rim = (slot && !selected) ? accent : 0;
            Drawable d = new KeyboardService.G2Drawable(face, face, rim, rim == 0 ? 0f : dp(2), dp(12), SettingsGlyphs.G2);
            d.setBounds(0, 0, (int) w, (int) h);
            d.draw(canvas);
            boolean white = selected || dark;
            ink.setColor(white ? Color.WHITE : Color.BLACK);
            if (icon != Icons.NONE) {
                ink.setStyle(Paint.Style.STROKE);
                Icons.draw(canvas, icon, w / 2f, h / 2f, Math.min(w, h) * 0.42f, ink);
            } else if (!label.isEmpty()) {
                ink.setStyle(Paint.Style.FILL);
                ink.setTypeface(Fonts.ui(getContext()));
                ink.setTextSize(dp(label.length() > 2 ? 15 : 19));
                ink.setTextAlign(Paint.Align.CENTER);
                Paint.FontMetrics fm = ink.getFontMetrics();
                canvas.drawText(label, w / 2f, h / 2f - (fm.ascent + fm.descent) / 2f, ink);
            }
        }
    }

    private String defaultFor(String prefKey) {
        if (prefKey.equals(Prefs.K_CORNER_RIGHT)) return "mic";
        if (prefKey.equals(Prefs.K_CORNER_LEFT)) return "emoji";
        return "none";
    }

    private String slotName(String value) {
        switch (value) {
            case "emoji": return "Emoji";
            case "clip": return "Clip";
            case "globe": return "Globe";
            case "mic": return "Mic";
            default: return "+";
        }
    }

    private String slotLongName(String value) {
        switch (value) {
            case "emoji": return "Emoji";
            case "clip": return "Clipboard";
            case "globe": return "Globe (language)";
            case "mic": return "Voice typing";
            default: return "nothing";
        }
    }

    /** Shows what each editable tile holds, and highlights the tile being edited. */
    private void refreshEditor() {
        for (String key : editTiles.keySet()) {
            KeyTileView t = editTiles.get(key);
            String value = prefs.getString(key, defaultFor(key));
            boolean selected = key.equals(editSlot);
            int icon = slotIcon(value);
            t.set(icon != Icons.NONE ? "" : slotName(value), icon, true, selected);
        }
    }

    /** Opens the choices for one editable tile: each button, and Delete for the middle tiles. */
    private void openPicker(final String prefKey, final String[] values) {
        if (prefKey.equals(editSlot)) {          // tapping the same tile again closes it
            closePicker();
            return;
        }
        editSlot = prefKey;
        editPicker.removeAllViews();
        String current = prefs.getString(prefKey, defaultFor(prefKey));
        String title = prefKey.equals(Prefs.K_MID_KEY) ? "Between 123 and space"
                : prefKey.equals(Prefs.K_MID_RIGHT_KEY) ? "Between space and return"
                : prefKey.equals(Prefs.K_CORNER_LEFT) ? "Bottom left corner" : "Bottom right corner";
        TextView t = text(title + ": " + slotLongName(current), 14, secondaryColor, false);
        t.setPadding(0, 0, 0, dp(6));
        editPicker.addView(t);

        LinearLayout row = null;
        for (int i = 0; i < values.length; i++) {
            if (row == null || row.getChildCount() >= 3) {   // three choices per line
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                editPicker.addView(row);
            }
            final String value = values[i];
            TextView b = text(slotLongName(value), 13, labelColor, false);
            b.setGravity(Gravity.CENTER);
            boolean on = value.equals(current);
            b.setBackground(pill(on ? accent : 0x1F767680));
            b.setTextColor(on ? Color.WHITE : labelColor);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    pickSlot(prefKey, value);
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1f);
            lp.setMargins(0, dp(4), dp(6), 0);
            row.addView(b, lp);
        }
        if (!prefKey.equals(Prefs.K_CORNER_LEFT) && !prefKey.equals(Prefs.K_CORNER_RIGHT)) {
            if (row == null || row.getChildCount() >= 3) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                editPicker.addView(row);
            }
            TextView del = text("Delete", 13, destructiveColor, false);
            del.setGravity(Gravity.CENTER);
            del.setBackground(pill(0x1F767680));
            del.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    pickSlot(prefKey, "none");
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1f);
            lp.setMargins(0, dp(4), dp(6), 0);
            row.addView(del, lp);
        }
        editPicker.setVisibility(View.VISIBLE);
        refreshEditor();
    }

    private void closePicker() {
        editSlot = null;
        if (editPicker != null) {
            editPicker.setVisibility(View.GONE);
            editPicker.removeAllViews();
        }
        refreshEditor();
    }

    /** Saves a choice. The two corners cannot hold the same button: the other corner takes the old one. */
    private void pickSlot(String prefKey, String value) {
        String old = prefs.getString(prefKey, defaultFor(prefKey));
        SharedPreferences.Editor ed = prefs.edit().putString(prefKey, value);
        if (prefKey.equals(Prefs.K_CORNER_LEFT) || prefKey.equals(Prefs.K_CORNER_RIGHT)) {
            String otherKey = prefKey.equals(Prefs.K_CORNER_LEFT) ? Prefs.K_CORNER_RIGHT : Prefs.K_CORNER_LEFT;
            if (value.equals(prefs.getString(otherKey, defaultFor(otherKey)))) {
                ed.putString(otherKey, old);
            }
        }
        ed.apply();
        closePicker();
    }
}
