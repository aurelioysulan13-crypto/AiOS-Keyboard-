package com.custom.keyboard;

import android.content.Context;
import android.graphics.Typeface;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The emoji fonts that are installed on this phone, for Settings > Emojis > Emoji font.
 *
 * The phone's own font files are scanned in the system font folders. A file is listed when its name contains
 * "emoji". Samsung's emoji font is labelled "Samsung emoji", Google's Noto Color Emoji "Android emoji". The first
 * choice, "Phone default", uses whatever emoji font Android itself picks (the same as before this setting existed).
 */
final class EmojiFonts {

    private EmojiFonts() {}

    /** The stored value for "Phone default": no font file, Android's own emoji fallback. */
    static final String DEFAULT = "";

    /**
     * Apple Color Emoji. It is not in the app: the user downloads it once (Settings > Emojis > Emoji font), and it
     * is stored in the app's own files. Until it is downloaded, the keyboard uses the phone's emoji font.
     * This marker is the stored value for the Apple choice; the file itself is appleFile().
     */
    static final String APPLE = "apple:download";

    /**
     * Direct https link to AppleColorEmoji.ttf (116 MB). Host the file yourself, for example as a GitHub Release
     * asset, then paste its link here. Until this is set, the Download button reports that the link is missing.
     */
    static final String APPLE_EMOJI_URL = "https://github.com/aurelioysulan13-crypto/AiOS-Keyboard-/releases/download/fonts-1/AppleColorEmoji-Linux.ttf";

    /** Approximate download size, shown in Settings. */
    static final int APPLE_EMOJI_SIZE_MB = 116;

    /** Callbacks of a download; they run on the download thread. */
    interface Progress {
        void onProgress(int percent);

        void onDone(boolean ok, String message);
    }

    private static volatile boolean downloading;

    static File appleFile(Context context) {
        return new File(new File(context.getFilesDir(), "emoji"), "AppleColorEmoji.ttf");
    }

    /** True when the downloaded Apple font is on the phone and is a font file. */
    static boolean appleReady(Context context) {
        File f = appleFile(context);
        return f.canRead() && f.length() > 1000000L && isFontFile(f);
    }

    static boolean isDownloading() {
        return downloading;
    }

    /** TrueType (or OpenType) files start with one of these four-byte tags. */
    private static boolean isFontFile(File f) {
        try (InputStream in = new FileInputStream(f)) {
            byte[] h = new byte[4];
            if (in.read(h) != 4) return false;
            String tag = new String(h, "ISO-8859-1");
            return (h[0] == 0 && h[1] == 1 && h[2] == 0 && h[3] == 0) || tag.equals("OTTO") || tag.equals("true");
        } catch (IOException e) {
            return false;
        }
    }

    /**
     * Downloads the Apple emoji font into the app's files. The file is written under a temporary name and only
     * renamed once it is complete and is a font, so a broken download never counts as downloaded.
     */
    static void downloadApple(final Context context, final Progress cb) {
        if (downloading) {
            return;
        }
        if (APPLE_EMOJI_URL.isEmpty()) {
            cb.onDone(false, "The Apple emoji download link is not set in this build yet.");
            return;
        }
        downloading = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                File dir = new File(context.getFilesDir(), "emoji");
                File tmp = new File(dir, "AppleColorEmoji.part");
                HttpURLConnection conn = null;
                try {
                    if (!dir.isDirectory() && !dir.mkdirs()) {
                        throw new IOException("cannot create folder");
                    }
                    conn = (HttpURLConnection) new URL(APPLE_EMOJI_URL).openConnection();
                    conn.setConnectTimeout(20000);
                    conn.setReadTimeout(30000);
                    conn.setInstanceFollowRedirects(true);
                    if (conn.getResponseCode() / 100 != 2) {
                        throw new IOException("server answered " + conn.getResponseCode());
                    }
                    long total = conn.getContentLengthLong();
                    long done = 0;
                    int lastPct = -1;
                    try (InputStream in = conn.getInputStream(); FileOutputStream out = new FileOutputStream(tmp)) {
                        byte[] buf = new byte[65536];
                        int n;
                        while ((n = in.read(buf)) > 0) {
                            out.write(buf, 0, n);
                            done += n;
                            if (total > 0) {
                                int pct = (int) (done * 100 / total);
                                if (pct != lastPct) {
                                    lastPct = pct;
                                    cb.onProgress(pct);
                                }
                            }
                        }
                    }
                    if (!isFontFile(tmp) || tmp.length() < 1000000L) {
                        throw new IOException("the file is not the emoji font");
                    }
                    File dest = appleFile(context);
                    if (dest.exists() && !dest.delete()) {
                        throw new IOException("cannot replace the old file");
                    }
                    if (!tmp.renameTo(dest)) {
                        throw new IOException("cannot save the file");
                    }
                    downloading = false;
                    cb.onDone(true, "Apple Emoji downloaded.");
                } catch (Exception e) {
                    tmp.delete();
                    downloading = false;
                    cb.onDone(false, "Download failed: " + e.getMessage());
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }
        }, "apple-emoji-download").start();
    }

    /**
     * Where Android keeps its fonts. Android 12 and later moved the system fonts, including Google's emoji font,
     * into the Mainline module /apex/com.android.fonts; Samsung and others keep theirs in /system/fonts.
     */
    private static final String[] FONT_DIRS = {
            "/system/fonts", "/apex/com.android.fonts/fonts", "/product/fonts", "/system_ext/fonts", "/vendor/fonts"};

    /** The phone's font lists, which name every font file the system uses (including emoji). */
    private static final String[] FONT_LISTS = {
            "/system/etc/fonts.xml", "/product/etc/fonts.xml", "/system_ext/etc/fonts.xml",
            "/product/etc/fonts_customization.xml", "/system/etc/fonts_customization.xml"};

    /** One row of the list: the label shown in Settings, and the font file path (or DEFAULT). */
    static final class Option {
        final String label;
        final String path;

        Option(String label, String path) {
            this.label = label;
            this.path = path;
        }
    }

    /** The emoji fonts found on the phone: from its font lists first, then from the font folders. */
    static List<File> findEmojiFiles() {
        LinkedHashMap<String, File> found = new LinkedHashMap<>();
        for (String list : FONT_LISTS) {
            String xml = readText(list);
            if (xml == null) continue;
            Matcher m = Pattern.compile("<file[^>]*>\\s*([^<\\s]+)\\s*</file>").matcher(xml);
            while (m.find()) {
                String name = m.group(1).trim();
                if (!isEmojiName(name)) continue;
                File f = resolve(name);
                if (f != null) found.put(f.getName().toLowerCase(Locale.ROOT), f);
            }
        }
        for (String dir : FONT_DIRS) {
            File[] listed = new File(dir).listFiles();
            if (listed == null) continue;
            for (File f : listed) {
                if (isEmojiName(f.getName()) && f.canRead()) {
                    found.put(f.getName().toLowerCase(Locale.ROOT), f);
                }
            }
        }
        return new ArrayList<>(found.values());
    }

    private static boolean isEmojiName(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        return (n.endsWith(".ttf") || n.endsWith(".otf")) && n.contains("emoji");
    }

    /** The file a font list names, looked up in the font folders. */
    private static File resolve(String name) {
        if (name.contains("/")) {
            File direct = new File(name);
            return direct.canRead() ? direct : null;
        }
        for (String dir : FONT_DIRS) {
            File f = new File(dir, name);
            if (f.canRead()) return f;
        }
        return null;
    }

    private static String readText(String path) {
        try (FileInputStream in = new FileInputStream(path)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (IOException | RuntimeException e) {
            return null;
        }
    }

    /** The stored choice; Apple Emoji until the user picks something (an absent key is the default). */
    static String stored(android.content.SharedPreferences prefs) {
        return prefs.getString(Prefs.K_EMOJI_FONT, APPLE);
    }

    /** "Apple Emoji" first, then "Phone default", then each emoji font file found on the phone, Samsung before Android. */
    static List<Option> options() {
        ArrayList<Option> out = new ArrayList<>();
        out.add(new Option("Apple Emoji", APPLE));
        out.add(new Option("Phone default", DEFAULT));
        ArrayList<Option> samsung = new ArrayList<>();
        ArrayList<Option> android = new ArrayList<>();
        ArrayList<Option> other = new ArrayList<>();
        for (File f : findEmojiFiles()) {
            String n = f.getName().toLowerCase(Locale.ROOT);
            if (n.contains("samsung")) {
                samsung.add(new Option("Samsung emoji", f.getAbsolutePath()));
            } else if (n.contains("noto")) {
                android.add(new Option("Android emoji", f.getAbsolutePath()));
            } else {
                other.add(new Option("Emoji font (" + f.getName() + ")", f.getAbsolutePath()));
            }
        }
        out.addAll(samsung);
        out.addAll(android);
        out.addAll(other);
        return out;
    }

    /** The font path stored in Settings, if that file still exists; otherwise DEFAULT. */
    static String chosen(Context context) {
        String path = stored(Prefs.get(context));
        if (APPLE.equals(path)) {
            return appleReady(context) ? appleFile(context).getAbsolutePath() : DEFAULT;   // not downloaded: phone's font
        }
        if (path == null || path.isEmpty() || !new File(path).canRead()) {
            return DEFAULT;
        }
        return path;
    }

    /** The typeface for a font file, or null if it cannot be loaded (the caller uses the system default). */
    static Typeface load(Context context, String path) {
        if (path == null || path.isEmpty()) {
            return null;
        }
        try {
            return Typeface.createFromFile(path);
        } catch (RuntimeException error) {
            return null;
        }
    }
}
