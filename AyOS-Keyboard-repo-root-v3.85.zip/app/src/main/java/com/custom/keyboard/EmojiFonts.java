package com.custom.keyboard;

import android.graphics.Typeface;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The emoji fonts that are installed on this phone, for Settings > Emojis > Emoji font.
 *
 * The phone's own font files are scanned in the system font folders. A file is listed when its name contains
 * "emoji". Samsung's emoji font is labelled "Samsung emoji", Google's Noto Color Emoji "Android emoji". The first
 * choice, "Phone default", uses whatever emoji font Android itself picks (the same as before this setting existed).
 */
final class EmojiFonts {

    private EmojiFonts() {}

    /** The stored value for "Phone default": no font file, Android's own emoji fallback. */
    static final String DEFAULT = "";

    /**
     * Where Android keeps its fonts. Android 12 and later moved the system fonts, including Google's emoji font,
     * into the Mainline module /apex/com.android.fonts; Samsung and others keep theirs in /system/fonts.
     */
    private static final String[] FONT_DIRS = {
            "/system/fonts", "/apex/com.android.fonts/fonts", "/product/fonts", "/system_ext/fonts", "/vendor/fonts"};

    /** The phone's font lists, which name every font file the system uses (including emoji). */
    private static final String[] FONT_LISTS = {
            "/system/etc/fonts.xml", "/product/etc/fonts.xml", "/system_ext/etc/fonts.xml",
            "/product/etc/fonts_customization.xml", "/system/etc/fonts_customization.xml"};

    /** One row of the list: the label shown in Settings, and the font file path (or DEFAULT). */
    static final class Option {
        final String label;
        final String path;

        Option(String label, String path) {
            this.label = label;
            this.path = path;
        }
    }

    /** The emoji fonts found on the phone: from its font lists first, then from the font folders. */
    static List<File> findEmojiFiles() {
        LinkedHashMap<String, File> found = new LinkedHashMap<>();
        for (String list : FONT_LISTS) {
            String xml = readText(list);
            if (xml == null) continue;
            Matcher m = Pattern.compile("<file[^>]*>\\s*([^<\\s]+)\\s*</file>").matcher(xml);
            while (m.find()) {
                String name = m.group(1).trim();
                if (!isEmojiName(name)) continue;
                File f = resolve(name);
                if (f != null) found.put(f.getName().toLowerCase(Locale.ROOT), f);
            }
        }
        for (String dir : FONT_DIRS) {
            File[] listed = new File(dir).listFiles();
            if (listed == null) continue;
            for (File f : listed) {
                if (isEmojiName(f.getName()) && f.canRead()) {
                    found.put(f.getName().toLowerCase(Locale.ROOT), f);
                }
            }
        }
        return new ArrayList<>(found.values());
    }

    private static boolean isEmojiName(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        return (n.endsWith(".ttf") || n.endsWith(".otf")) && n.contains("emoji");
    }

    /** The file a font list names, looked up in the font folders. */
    private static File resolve(String name) {
        if (name.contains("/")) {
            File direct = new File(name);
            return direct.canRead() ? direct : null;
        }
        for (String dir : FONT_DIRS) {
            File f = new File(dir, name);
            if (f.canRead()) return f;
        }
        return null;
    }

    private static String readText(String path) {
        try (FileInputStream in = new FileInputStream(path)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (IOException | RuntimeException e) {
            return null;
        }
    }

    /** "Phone default" first, then each emoji font file found on the phone, Samsung before Android. */
    static List<Option> options() {
        ArrayList<Option> out = new ArrayList<>();
        out.add(new Option("Phone default", DEFAULT));
        ArrayList<Option> samsung = new ArrayList<>();
        ArrayList<Option> android = new ArrayList<>();
        ArrayList<Option> other = new ArrayList<>();
        for (File f : findEmojiFiles()) {
            String n = f.getName().toLowerCase(Locale.ROOT);
            if (n.contains("samsung")) {
                samsung.add(new Option("Samsung emoji", f.getAbsolutePath()));
            } else if (n.contains("noto")) {
                android.add(new Option("Android emoji", f.getAbsolutePath()));
            } else {
                other.add(new Option("Emoji font (" + f.getName() + ")", f.getAbsolutePath()));
            }
        }
        out.addAll(samsung);
        out.addAll(android);
        out.addAll(other);
        return out;
    }

    /** The font path stored in Settings, if that file still exists; otherwise DEFAULT. */
    static String chosen(android.content.Context context) {
        String path = Prefs.get(context).getString(Prefs.K_EMOJI_FONT, DEFAULT);
        if (path == null || path.isEmpty() || !new File(path).canRead()) {
            return DEFAULT;
        }
        return path;
    }

    /** The typeface for a font file, or null if it cannot be loaded (the caller uses the system default). */
    static Typeface load(String path) {
        if (path == null || path.isEmpty()) {
            return null;
        }
        try {
            return Typeface.createFromFile(path);
        } catch (RuntimeException error) {
            return null;
        }
    }
}
