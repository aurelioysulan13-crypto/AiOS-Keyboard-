
package com.custom.keyboard;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Shared settings used by the keyboard and the settings screen.
 */
final class Prefs {

    private Prefs() {}

    static final String FILE = "keyboard_prefs";

    // Appearance
    static final String K_THEME = "theme";       // 0 = system, 1 = light, 2 = dark
    static final String K_ACCENT = "accent";     // Index into ACCENTS
    static final String K_HEIGHT = "key_height_dp";
    static final String K_BLUR_DP = "blur_dp";        // window blur radius (Settings > Appearance slider)
    static final String K_OPACITY = "panel_opacity";  // keyboard panel opacity, percent (Settings slider)
    static final String K_MID_RIGHT_KEY = "mid_right_key"; // button between the space bar and return
    static final String K_BLUR = "frosted_glass";
    static final String K_ROUNDED = "rounded_corners";

    // Keyboard interaction
    static final String K_HAPTIC = "haptic";
    static final String K_SOUND = "sound";
    static final String K_VOLUME = "sound_volume";      // key sound volume, percent (Settings > Key tap > Volume)
    static final String K_POPUP = "key_popup";           // the key pop-up shown above a pressed key
    static final String K_HOLD_SYMBOLS = "hold_symbols"; // touch & hold a key to type its symbol / number
    static final String K_HOLD_MS = "hold_ms";           // touch & hold duration, milliseconds
    static final String K_VIB_MS = "vibration_ms";       // vibration length on a key press, milliseconds
    static final String K_AUTOSPACE = "auto_space";      // add a space after . , ! ? ; : typed straight after a word
    static final String K_APOS_SWITCH = "apostrophe_switch"; // back to the letters after an apostrophe typed on the symbols keyboard
    static final String K_FLICK = "flick_symbols";       // pull a key downward to type its hinted symbol / number
    static final String K_FLICK_SENS = "flick_sens";     // 0 = low, 1 = normal, 2 = high

    // Keys / appearance / layout (Settings > Preferences)
    static final String K_NUMROW = "number_row";          // digit row above the letters
    static final String K_NUMROW_PW = "number_row_pw";    // the same, but only in password fields
    static final String K_EMOJI_KEY = "emoji_key";        // dedicated emoji key between 123 and the space bar
    static final String K_COMMA = "comma_key";            // comma key left of the space bar
    static final String K_PERIOD = "period_key";          // period key right of the space bar
    static final String K_FONT = "font_choice";           // 0 = AiOS (SF Pro Display), 1 = system default
    static final String K_FONT_SCALE = "font_scale";      // key label size, percent
    static final String K_EMOJI_SCALE = "emoji_scale";    // emoji size in the emoji panel, percent
    static final String K_ONEHAND = "one_handed";         // 0 = off, 1 = left, 2 = right

    // Text assistance
    static final String K_SUGGEST = "suggestions";
    static final String K_WORD_SUGGEST = "word_suggestions";   // words that complete / correct what is being typed
    static final String K_NEXT_WORD = "next_word_suggestions"; // words that follow the previous word
    static final String K_AUTOCORRECT = "autocorrect";
    static final String K_SPELL = "spell_check";          // Settings > Corrections: fix words that are not in the dictionary
    static final String K_AUTOCAP = "autocap";
    static final String K_DBLSPACE = "dblspace";
    static final String K_LEARN = "learn";
    static final String K_LEARNED = "learned_words";
    static final String K_CLEAR_TOKEN = "clear_learned_token";

    // Emoji
    static final String K_EMOJI_RECENT = "emoji_recent";
    static final String K_GLIDE = "glide_typing";          // Settings > Glide typing: slide across the letters to type a word
    static final String K_GLIDE_TRAIL = "glide_trail";     // draw the path while gliding
    static final String K_GLIDE_DELETE = "glide_delete";   // slide left on the delete key to remove the word before the cursor
    static final String K_GLIDE_CURSOR = "glide_cursor";   // slide along the space bar to move the cursor
    static final String K_EMOJI_FONT = "emoji_font";       // path of the chosen emoji font file, "" = phone default
    static final String K_TEXT_EMOJI = "text_to_emoji";        // Settings > Emojis > Text-to-emoji options: emoji for typed words
    static final String K_SUG_EMOJI = "show_emoji_suggestions"; // Settings > Emojis > Show emoji: recent emoji in the suggestion strip

    // Clipboard
    static final String K_CLIP = "clipboard_enabled";
    static final String K_CLIP_REMEMBER = "clip_remember";   // keep clipboard history after a restart (off by default)
    static final String K_CLIP_CLEAR_TOKEN = "clip_clear_token";
    // Keys (Settings > Keys). Corners: emoji | clip | globe | mic. Middle key (between 123 and space): none | emoji | clip | globe.
    static final String K_CORNER_LEFT = "corner_left";
    static final String K_CORNER_RIGHT = "corner_right";
    static final String K_MID_KEY = "middle_key";

    static final int[] ACCENTS = {
            0xFF3478F7, // Blue
            0xFF2FB36D, // Green
            0xFF9B6BFF, // Purple
            0xFFFF8A3D, // Orange
            0xFFE9507A  // Pink
    };

    // Row pitch (key + gap). 52 dp = a 42 dp key + 10 dp gap, the iOS 27 portrait keyboard.
    static final int MIN_HEIGHT = 44;
    static final int MAX_HEIGHT = 68;
    static final int DEFAULT_HEIGHT = 52;
    static final int MIN_BLUR_DP = 0;
    static final int MAX_BLUR_DP = 24;
    static final int DEFAULT_BLUR_DP = 4;
    static final int MIN_VIB = 5;
    static final int MAX_VIB = 60;
    static final int DEFAULT_VIB = 20;
    static final int MIN_FONT_SCALE = 70;
    static final int MAX_FONT_SCALE = 130;
    static final int DEFAULT_FONT_SCALE = 100;
    static final int MIN_EMOJI_SCALE = 70;
    static final int MAX_EMOJI_SCALE = 130;
    static final int DEFAULT_EMOJI_SCALE = 100;
    static final int MIN_VOLUME = 10;
    static final int MAX_VOLUME = 100;
    static final int DEFAULT_VOLUME = 100;
    static final int MIN_HOLD_MS = 200;
    static final int MAX_HOLD_MS = 800;
    static final int DEFAULT_HOLD_MS = 450;
    static final int MIN_OPACITY = 30;
    static final int MAX_OPACITY = 100;
    static final int DEFAULT_OPACITY = 100;

    static SharedPreferences get(Context context) {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    /**
     * All on/off settings default to ON, except key sounds.
     */
    static boolean on(SharedPreferences preferences, String key) {
        if (preferences == null || key == null) {
            return false;
        }

        // Off unless the user turns them on: key sounds.
        // Frosted glass is on by default; where the phone cannot blur, the panel falls back to a translucent wash.
        boolean def = !(K_SOUND.equals(key) || K_NUMROW.equals(key) || K_EMOJI_KEY.equals(key)
                || K_COMMA.equals(key) || K_PERIOD.equals(key) || K_AUTOSPACE.equals(key) || K_FLICK.equals(key));
        return preferences.getBoolean(key, def);
    }

    static int theme(SharedPreferences preferences) {
        if (preferences == null) return 0;

        int value = preferences.getInt(K_THEME, 0);
        return (value < 0 || value > 2) ? 0 : value;
    }

    static int accent(SharedPreferences preferences) {
        if (preferences == null) return 0;

        int value = preferences.getInt(K_ACCENT, 0);
        return (value < 0 || value >= ACCENTS.length) ? 0 : value;
    }

    /** A stored choice, if it is one of the allowed values; otherwise the default. */
    static String choice(SharedPreferences preferences, String key, String def, String... allowed) {
        if (preferences == null) return def;
        String value = preferences.getString(key, def);
        for (String a : allowed) {
            if (a.equals(value)) return value;
        }
        return def;
    }

    static int height(SharedPreferences preferences) {
        if (preferences == null) return DEFAULT_HEIGHT;

        int value = preferences.getInt(K_HEIGHT, DEFAULT_HEIGHT);
        return Math.max(MIN_HEIGHT, Math.min(MAX_HEIGHT, value));
    }

    static int blurDp(SharedPreferences preferences) {
        if (preferences == null) return DEFAULT_BLUR_DP;
        int value = preferences.getInt(K_BLUR_DP, DEFAULT_BLUR_DP);
        return Math.max(MIN_BLUR_DP, Math.min(MAX_BLUR_DP, value));
    }

    private static int clamped(SharedPreferences preferences, String key, int def, int min, int max) {
        if (preferences == null) return def;
        return Math.max(min, Math.min(max, preferences.getInt(key, def)));
    }

    static int vibMs(SharedPreferences p) { return clamped(p, K_VIB_MS, DEFAULT_VIB, MIN_VIB, MAX_VIB); }
    static int fontScale(SharedPreferences p) { return clamped(p, K_FONT_SCALE, DEFAULT_FONT_SCALE, MIN_FONT_SCALE, MAX_FONT_SCALE); }
    static int emojiScale(SharedPreferences p) { return clamped(p, K_EMOJI_SCALE, DEFAULT_EMOJI_SCALE, MIN_EMOJI_SCALE, MAX_EMOJI_SCALE); }
    static int fontChoice(SharedPreferences p) { return clamped(p, K_FONT, 0, 0, 1); }
    static int oneHand(SharedPreferences p) { return clamped(p, K_ONEHAND, 0, 0, 2); }
    static int flickSens(SharedPreferences p) { return clamped(p, K_FLICK_SENS, 1, 0, 2); }

    static int volume(SharedPreferences preferences) {
        if (preferences == null) return DEFAULT_VOLUME;
        int value = preferences.getInt(K_VOLUME, DEFAULT_VOLUME);
        return Math.max(MIN_VOLUME, Math.min(MAX_VOLUME, value));
    }

    static int holdMs(SharedPreferences preferences) {
        if (preferences == null) return DEFAULT_HOLD_MS;
        int value = preferences.getInt(K_HOLD_MS, DEFAULT_HOLD_MS);
        return Math.max(MIN_HOLD_MS, Math.min(MAX_HOLD_MS, value));
    }

    static int opacity(SharedPreferences preferences) {
        if (preferences == null) return DEFAULT_OPACITY;
        int value = preferences.getInt(K_OPACITY, DEFAULT_OPACITY);
        return Math.max(MIN_OPACITY, Math.min(MAX_OPACITY, value));
    }
}
