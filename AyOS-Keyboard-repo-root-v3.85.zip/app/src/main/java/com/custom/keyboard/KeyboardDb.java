package com.custom.keyboard;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Local SQLite database of the keyboard (Android's built-in SQLite, no extra libraries).
 *
 * Tables:
 *   clipboard_items (id INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT, is_pinned INTEGER, timestamp INTEGER)
 *   custom_stickers (id INTEGER PRIMARY KEY AUTOINCREMENT, file_path TEXT, timestamp INTEGER)
 *
 * The file lives in the app's private data directory, so it survives app restarts and phone reboots.
 * Pinned clipboard items are never removed automatically: the only automatic removal is of unpinned items
 * (see enforceClipLimit), and a pinned item only goes when the user deletes it or clears the history.
 */
final class KeyboardDb extends SQLiteOpenHelper {

    static final String DB_NAME = "keyboard.db";
    static final int DB_VERSION = 1;

    static final String T_CLIP = "clipboard_items";
    static final String T_STICKER = "custom_stickers";

    private static KeyboardDb instance;

    /** One clipboard history row. */
    static final class ClipRow {
        final long id;
        final String content;
        final boolean pinned;
        final long timestamp;

        ClipRow(long id, String content, boolean pinned, long timestamp) {
            this.id = id;
            this.content = content;
            this.pinned = pinned;
            this.timestamp = timestamp;
        }
    }

    /** One custom sticker row. file_path points into the app's internal storage (see StickerStore). */
    static final class StickerRow {
        final long id;
        final String filePath;
        final long timestamp;

        StickerRow(long id, String filePath, long timestamp) {
            this.id = id;
            this.filePath = filePath;
            this.timestamp = timestamp;
        }
    }

    static synchronized KeyboardDb get(Context context) {
        if (instance == null) {
            instance = new KeyboardDb(context.getApplicationContext());
        }
        return instance;
    }

    private KeyboardDb(Context appContext) {
        super(appContext, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + T_CLIP + " ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "content TEXT NOT NULL, "
                + "is_pinned INTEGER NOT NULL DEFAULT 0, "
                + "timestamp INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX idx_clip_time ON " + T_CLIP + " (timestamp, id)");
        db.execSQL("CREATE TABLE " + T_STICKER + " ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "file_path TEXT NOT NULL, "
                + "timestamp INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // version 1 is the first schema; future versions add their steps here
    }

    // ------------------------------------------------------------ clipboard: create

    /** Inserts a clipboard item. Returns its id, or -1 if it could not be written. */
    long insertClip(String content, boolean pinned, long timestamp) {
        ContentValues v = new ContentValues();
        v.put("content", content);
        v.put("is_pinned", pinned ? 1 : 0);
        v.put("timestamp", timestamp);
        return getWritableDatabase().insert(T_CLIP, null, v);
    }

    // ------------------------------------------------------------ clipboard: read

    /** Every clipboard item, newest first. */
    List<ClipRow> queryClips() {
        List<ClipRow> out = new ArrayList<>();
        Cursor c = getReadableDatabase().query(T_CLIP, null, null, null, null, null,
                "timestamp DESC, id DESC");
        try {
            while (c.moveToNext()) {
                out.add(readClip(c));
            }
        } finally {
            c.close();
        }
        return out;
    }

    /** One clipboard item by id, or null. */
    ClipRow getClip(long id) {
        Cursor c = getReadableDatabase().query(T_CLIP, null, "id = ?",
                new String[]{String.valueOf(id)}, null, null, null);
        try {
            return c.moveToFirst() ? readClip(c) : null;
        } finally {
            c.close();
        }
    }

    /** The item with exactly this text, or null (used to move a repeated copy to the top). */
    ClipRow findClipByContent(String content) {
        Cursor c = getReadableDatabase().query(T_CLIP, null, "content = ?",
                new String[]{content}, null, null, "timestamp DESC, id DESC", "1");
        try {
            return c.moveToFirst() ? readClip(c) : null;
        } finally {
            c.close();
        }
    }

    int clipCount() {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM " + T_CLIP, null);
        try {
            return c.moveToFirst() ? c.getInt(0) : 0;
        } finally {
            c.close();
        }
    }

    // ------------------------------------------------------------ clipboard: update

    /** Pins or unpins an item. Returns the number of rows changed. */
    int updateClipPinned(long id, boolean pinned) {
        ContentValues v = new ContentValues();
        v.put("is_pinned", pinned ? 1 : 0);
        return getWritableDatabase().update(T_CLIP, v, "id = ?", new String[]{String.valueOf(id)});
    }

    /** Changes the text of an item and moves it to the given time. Returns the number of rows changed. */
    int updateClipContent(long id, String content, long timestamp) {
        ContentValues v = new ContentValues();
        v.put("content", content);
        v.put("timestamp", timestamp);
        return getWritableDatabase().update(T_CLIP, v, "id = ?", new String[]{String.valueOf(id)});
    }

    // ------------------------------------------------------------ clipboard: delete

    /** Deletes one item, pinned or not, because the user asked for it. */
    int deleteClip(long id) {
        return getWritableDatabase().delete(T_CLIP, "id = ?", new String[]{String.valueOf(id)});
    }

    /** Deletes every unpinned item. Pinned items stay. */
    int deleteUnpinnedClips() {
        return getWritableDatabase().delete(T_CLIP, "is_pinned = 0", null);
    }

    /** Deletes the whole clipboard history, pinned items included (the user's "clear history"). */
    int deleteAllClips() {
        return getWritableDatabase().delete(T_CLIP, null, null);
    }

    /**
     * Keeps the history at most {@code max} items. Only unpinned items are removed automatically, oldest first.
     * If every item is pinned and the history is still over the limit, the newest item is dropped instead
     * (the one that was just added). Returns false if that happened, i.e. the newest item was not kept.
     */
    boolean enforceClipLimit(int max) {
        boolean newestKept = true;
        SQLiteDatabase db = getWritableDatabase();
        while (clipCount() > max) {
            Cursor c = db.query(T_CLIP, new String[]{"id"}, "is_pinned = 0", null, null, null,
                    "timestamp ASC, id ASC", "1");
            long oldestUnpinned = -1;
            try {
                if (c.moveToFirst()) {
                    oldestUnpinned = c.getLong(0);
                }
            } finally {
                c.close();
            }
            if (oldestUnpinned >= 0) {
                deleteClip(oldestUnpinned);
            } else {
                Cursor n = db.query(T_CLIP, new String[]{"id"}, null, null, null, null,
                        "timestamp DESC, id DESC", "1");
                try {
                    if (n.moveToFirst()) {
                        deleteClip(n.getLong(0));
                    }
                } finally {
                    n.close();
                }
                newestKept = false;
            }
        }
        return newestKept;
    }

    private static ClipRow readClip(Cursor c) {
        return new ClipRow(c.getLong(c.getColumnIndexOrThrow("id")),
                c.getString(c.getColumnIndexOrThrow("content")),
                c.getInt(c.getColumnIndexOrThrow("is_pinned")) != 0,
                c.getLong(c.getColumnIndexOrThrow("timestamp")));
    }

    // ------------------------------------------------------------ stickers: create

    /** Records a sticker file that is already in internal storage. Returns its id, or -1. */
    long insertSticker(String filePath, long timestamp) {
        ContentValues v = new ContentValues();
        v.put("file_path", filePath);
        v.put("timestamp", timestamp);
        return getWritableDatabase().insert(T_STICKER, null, v);
    }

    // ------------------------------------------------------------ stickers: read

    /** Every sticker row, newest first. */
    List<StickerRow> querySticker() {
        List<StickerRow> out = new ArrayList<>();
        Cursor c = getReadableDatabase().query(T_STICKER, null, null, null, null, null,
                "timestamp DESC, id DESC");
        try {
            while (c.moveToNext()) {
                out.add(readSticker(c));
            }
        } finally {
            c.close();
        }
        return out;
    }

    /** One sticker row by id, or null. */
    StickerRow getSticker(long id) {
        Cursor c = getReadableDatabase().query(T_STICKER, null, "id = ?",
                new String[]{String.valueOf(id)}, null, null, null);
        try {
            return c.moveToFirst() ? readSticker(c) : null;
        } finally {
            c.close();
        }
    }

    // ------------------------------------------------------------ stickers: update

    /** Points a sticker at another file. Returns the number of rows changed. */
    int updateStickerPath(long id, String filePath) {
        ContentValues v = new ContentValues();
        v.put("file_path", filePath);
        return getWritableDatabase().update(T_STICKER, v, "id = ?", new String[]{String.valueOf(id)});
    }

    // ------------------------------------------------------------ stickers: delete

    /** Deletes a sticker row (the file is removed by StickerStore). Returns the number of rows removed. */
    int deleteSticker(long id) {
        return getWritableDatabase().delete(T_STICKER, "id = ?", new String[]{String.valueOf(id)});
    }

    private static StickerRow readSticker(Cursor c) {
        return new StickerRow(c.getLong(c.getColumnIndexOrThrow("id")),
                c.getString(c.getColumnIndexOrThrow("file_path")),
                c.getLong(c.getColumnIndexOrThrow("timestamp")));
    }
}
