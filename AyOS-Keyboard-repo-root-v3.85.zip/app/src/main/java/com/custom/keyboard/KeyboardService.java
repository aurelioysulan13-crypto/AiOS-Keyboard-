package com.custom.keyboard;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.StateListDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.text.InputType;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;
import android.view.inputmethod.InputMethodSubtype;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The on-screen keyboard, styled after the iOS keyboard: frosted translucent panel,
 * uniform glass keys, thin-line icons, pop-up key callouts and a QuickType-style bar.
 * Built entirely in code (no deprecated KeyboardView).
 *
 * v2.2: all keys sit on one exact grid (identical gap in both directions, rows laid out by
 * KeyRow), letters switch between lower/upper case as you type, emoji key moved to the old globe
 * spot, iOS-style key sounds, bundled fonts (SF-style UI font + Google Noto emoji).
 *
 * v2.4: bottom row under the keys is [emoji][clipboard] on the left and mic on the right. Clipboard is a list panel that replaces the key area; history is kept in memory
 * (max 20, newest first, no duplicates, nothing from password fields).
 *
 * v3.7: the key pop-up label is centred like the key labels (x-height / cap height), so a pressed letter and a
 * held number sit at the same height. The clipboard and emoji panels now run from the very top of the keyboard
 * to the very bottom: their progressive blur lives under the header / footer bars instead of inside the list
 * area. Emoji panel: bigger ABC / backspace tiles and the same edge blur.
 */
public class KeyboardService extends InputMethodService {

    // ------------------------------------------------------------------ layers
    private static final int LAYER_LETTERS = 0;
    private static final int LAYER_SYMBOLS1 = 1;
    private static final int LAYER_SYMBOLS2 = 2;
    private static final int LAYER_EMOJI = 3;
    private static final int LAYER_CLIP = 4;
    private static final int LAYER_EMOJI_SEARCH = 5;   // letters keyboard, typing goes to the emoji search

    // ---------------------------------------------------------------- key types
    private static final int T_CHAR = 0;
    private static final int T_SHIFT = 1;
    private static final int T_DELETE = 2;
    private static final int T_ENTER = 3;
    private static final int T_SPACE = 4;
    private static final int T_TO_SYMBOLS1 = 5;
    private static final int T_TO_SYMBOLS2 = 6;
    private static final int T_TO_LETTERS = 7;
    private static final int T_TO_EMOJI = 8;
    private static final int T_GLOBE = 9;
    private static final int T_SPACER = 10;
    private static final int T_MIC = 11;
    private static final int T_TO_CLIP = 12;
    private static final int T_CLIP_CLOSE = 13;
    private static final int T_CLIP_CLEAR = 14;

    /** Icons drawn by this class itself (the shared Icons set has no back arrow). */
    private static final int GLYPH_BASE = 10000;
    private static final int G_BACK = GLYPH_BASE + 4;
    private static final int G_SEARCH = GLYPH_BASE + 5;
    private static final int G_EMOJI = GLYPH_BASE + 6;   // solid smiley, like the iOS emoji key
    private static final int G_MIC = GLYPH_BASE + 7;
    private static final int G_CLIP = GLYPH_BASE + 8;   // solid clipboard (no longer drawn: the outline one is used)
    private static final int G_CLIP_LINE = GLYPH_BASE + 34; // outline clipboard (iOS style), all modes
    /** Emoji, clipboard and mic all measure this many dp from top to bottom (the same visual size). */
    private static final float TRAY_ICON_DP = 26f;
    /** Emoji / clipboard / mic icon colour in light mode: a soft off-black (dark mode: pure white). */
    private static final int TRAY_ICON_LIGHT = 0xFF48484C;
    /** Key press feel: shrink to this scale, then bounce back (with a small overshoot) while a soft glow fades. */
    private static final float PRESS_SCALE = 0.92f;
    private static final int G_SHIFT = GLYPH_BASE + 20;      // outline arrow
    private static final int G_SHIFT_ON = GLYPH_BASE + 21;   // solid arrow
    private static final int G_CAPS = GLYPH_BASE + 22;       // solid arrow + bar
    private static final int G_DELETE = GLYPH_BASE + 23;
    private static final int G_RETURN = GLYPH_BASE + 24;
    private static final int G_GLOBE = GLYPH_BASE + 30;      // line globe (emoji panel, bottom left)
    private static final int G_MIC_LINE = GLYPH_BASE + 31;   // outline microphone (frosted glass on)
    private static final int G_EMOJI_LINE = GLYPH_BASE + 32; // outline smiley (frosted glass on)
    private static final int G_GLOBE_SOLID = GLYPH_BASE + 33; // solid globe (frosted glass off)

    // ---- iOS 27 emoji panel, measured on a 390 dp wide screen (scaled with the key height setting)
    private static final float EMOJI_SEARCH_AREA_DP = 57f;  // top of the panel down to the first emoji row
    private static final float EMOJI_PILL_TOP_DP = 6f;      // pill top: 6 dp + the 2 dp panel padding = 8 dp, the same as at the sides
    private static final float EMOJI_PILL_H_DP = 37f;
    private static final float EMOJI_PILL_MARGIN_DP = 5f;   // plus the 3 dp panel padding = 8 dp from the screen edge
    private static final float PILL_ICON_X_DP = 20f;        // magnifier centre, from the left edge of the pill
    private static final float PILL_ICON_DP = 18f;
    private static final float CLIP_HEADER_GAP_DP = 8f;     // v3.103: space between the clipboard header and the first tile (was 22)
    private static final float CLIP_CLEAR_W_DP = 88f;       // width of the Clear all capsule
    private static final float CLIP_MENU_W_DP = 176f;       // fixed width of the Pin / Delete capsule (halves are equal)
    // tints of the inner highlight: red over Delete, green over Pin, blue over Unpin
    private static final int CLIP_TINT_RED = 0xFFFF3B30, CLIP_TINT_GREEN = 0xFF34C759, CLIP_TINT_BLUE = 0xFF3478F7;
    private static final float PILL_TEXT_X_DP = 36f;
    private static final float PILL_CLOSE_DP = 20f;        // round close button while searching
    private static final float PILL_CLOSE_ZONE_DP = 38f;
    private static final float EMOJI_ROW_EXTRA_DP = 4f;     // emoji row height = key height + this ...
    private static final float EMOJI_ROW_MAX_DP = 60f;      // ... but never more than this
    private static final float EMOJI_GRID_INSET_L_DP = 4f;
    private static final float EMOJI_GRID_INSET_R_DP = 7f;
    private static final float EMOJI_SIZE_FACTOR = 0.56f;   // emoji text size / row height
    private static final float EMOJI_CAT_BAR_DP = 36f;      // ABC, category icons, delete
    private static final float EMOJI_BAR_OVERLAP_DP = 9f;   // the last emoji row slides this far under the bar blur
    private static final float EMOJI_FOOT_DP = 62f;         // globe / microphone row
    // category bar: ABC | icons | delete. The ABC and delete slots are their content plus the same side padding,
    // so both edges are equally far from the screen edge; the icon group is centred on the bar.
    private static final float EMOJI_BAR_TOTAL_DP = 387f;
    private static final float EMOJI_BAR_PAD_DP = 12f;      // side padding of ABC and delete
    private static final float DEL_ICON_W_DP = 19.6f;       // width of the delete glyph
    private static final int CAT_MID = 4;                   // the middle of the nine categories sits on the bar centre
    private static final float CAT_PITCH_DP = 31.75f;       // distance between two icon centres
    private static final float CAT_ICON_DP = 22f;
    private static final float CAT_SEL_DP = 30f;            // soft circle behind the selected category
    private static final float ICON_STROKE_DP = 1.9f;      // outline weight shared by the globe, smiley and microphone
    private static final float GLOBE_ICON_DP = 22f;          // globe key icon, smaller than before (was 26.5)
    private static final float CHAR_LABEL_DP = 24f;          // one size for every letter, capital and number (cap height about 16.9 dp)
    private static final float MIC_LINE_ICON_DP = 27f;
    /** The header / footer bars of the emoji and clipboard panels float above the scrolling list. */
    private static final float PANEL_BAR_Z_DP = 2f;
    private static final int EMOJI_OPEN_MS = 230;    // emoji panel rises from below
    private static final int EMOJI_CLOSE_MS = 170;   // ...and drops back below
    // Emoji and clipboard panels: both rise from the bottom edge of the keyboard and sink back to it.
    private static final int PANEL_OPEN_MS = 300;
    private static final int PANEL_CLOSE_MS = 260;
    private static final android.view.animation.Interpolator PANEL_OPEN_EASE =
            new android.view.animation.PathInterpolator(0.22f, 1f, 0.36f, 1f);   // quick start, long soft landing
    private static final android.view.animation.Interpolator PANEL_CLOSE_EASE =
            new android.view.animation.PathInterpolator(0.4f, 0f, 0.8f, 0.6f);  // gentle start, smooth sink
    /** Circular glass highlight behind a pressed emoji, clipboard or microphone icon. */
    private static final float PRESS_CIRCLE_DP = 40f;
    // v3.112: one size for every corner pop-up button, one padding, one icon square
    private static final float POPUP_BTN_W_DP = 48f;    // each button's slot is this wide and as tall as the circle
    private static final float POPUP_PAD_DP = 12f;      // the same padding at both ends of the capsule
    private static final float POPUP_ICON_DP = 19f;     // every icon is drawn in this square
    private static final float POPUP_PRESS_DP = 17f;    // radius of the press highlight
    /** v3.120: the tool capsule rests this far from the mic; its overshoot pushes the mic sideways. */
    private static final float MIC_REST_GAP_DP = 2f;
    /** v3.120: the most the mic is pushed sideways by the capsule. */
    private static final float MIC_PUSH_MAX_DP = 8f;
    /** v3.1.22: the tool capsule's clock (v3.116). The droplet is fully detached at DETACH_U; the neck pinches from PINCH_U. */
    private static final float DETACH_U = 0.20f;
    private static final float PINCH_U = 0.10f;
    private static final long CORNER_OPEN_MS = 560L;
    private static final float CLIP_BOTTOM_ZONE_SCALE = 0.6f; // v3.103: the clipboard footer blur is half as deep (was 1.2)
    private static final float CLIP_BOTTOM_BLUR_SCALE = 0.6f; // v3.103: and half as strong at the footer edge
    private static final float EDGE_ZONE_SCALE = 1.75f; // edge blur is this many times deeper than the header / footer bar, so it fades out gently

    private static final int CLIP_MAX = 20;
    private static final String K_CLIP_REMEMBER = "clip_remember";   // optional "remember across restarts"
    private static final String K_CLIP_SAVED = "clip_history_v2";

    private static final String WORD_BREAKS = ".,!?;:)";

    private static final int EMOJI_COLS = 7;    // emoji columns on screen
    private static final int EMOJI_ROWS = 4;

    /** Top corner radius of the keyboard panel. */
    private static final float PANEL_RADIUS_DP = 26f;
    /** iOS key spacing: 6 dp between neighbouring keys, 10 dp between rows. */
    private static final float KEY_GAP_H_DP = 6f;
    private static final float KEY_GAP_V_DP = 10f;
    /** Corner size of a key tile; the corner itself is a G2 superellipse (see g2Rect). */
    private static final float KEY_RADIUS_DP = 12f;
    // space bar as a trackpad: hold it still for TP_HOLD_MS, then drag to move the cursor
    private static final long TP_HOLD_MS = 380;
    private static final float TP_SLOP_DP = 10f;           // a larger move before that is a normal swipe
    private static final float TP_STEP_X_DP = 9f;          // finger travel per letter
    private static final float TP_STEP_Y_DP = 22f;         // finger travel per line
    /** Exponent of the superellipse corner (G2 Squircle kit default). */
    static final float G2_POWER = 4f;
    // Clipboard tiles: a slightly rounder corner than the keys (16 dp, not 12) and a lower G2 exponent,
    // which pulls the corner curve towards a true circle (2.0) and away from the squarer 4.0.
    private static final float CLIP_TILE_RADIUS_DP = 16f;
    private static final float CLIP_TILE_POWER = 2.6f;

    private static final class Colors {
        boolean dark;
        int key, keyPressed, keyShadow, keyStroke, text, divider, accent, calloutFill, calloutText, calloutShadow;
    }

    private static final class Key {
        final int type;
        final String label;
        final String text;
        final float weight;
        final String alt;
        final boolean letter;
        final int icon;
        /** Moves the icon sideways inside its cell, as a fraction of the cell width. */
        float iconShift = 0f;
        /** Scales this key's icon only (1 = normal). v3.98: the clipboard key between 123 and space is 0.85. */
        float iconScale = 1f;
        /** v3.108: the lower-left corner key; holding it opens the pop-up. */
        boolean cornerLeft;
        /** Extra space (dp) between this key's face and its cell edge, on the left / right. */
        float padL = 0f;
        float padR = 0f;
        /** Label size in dp; 0 = the default for the key type. */
        float textDp = 0f;

        Key(int type, String label, String text, float weight, String alt, boolean letter, int icon) {
            this.type = type;
            this.label = label;
            this.text = text;
            this.weight = weight;
            this.alt = alt;
            this.letter = letter;
            this.icon = icon;
        }
    }

    // ------------------------------------------------------------------- state
    private SharedPreferences prefs;
    private KeyboardDb db;               // the keyboard's SQLite database (clipboard history, stickers)
    private Suggester suggester;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final TextView[] suggestionViews = new TextView[3];
    private LinearLayout sugWords;     // the three word suggestions (letters / symbols layers)
    private FrameLayout sugAlt;        // takes over the suggestion bar: emoji categories, clipboard header
    private int sugHeightPx = 110;
    private final ArrayList<KeyView> letterViews = new ArrayList<>();

    // Glide typing (Settings > Glide typing)
    private boolean glideOn = false;                 // a finger is gliding across the letters right now
    private boolean glideTrailOn = false;
    private boolean glideDeleteFired = false;
    private final ArrayList<Character> glideKeys = new ArrayList<>();
    private float[][] glideSub = new float[26][26];  // typing cost between letter pairs, from the key positions
    private float glidePitch = 1f;                   // letter key width in px
    private GlideTrailView glideTrail;
    private final int[] emojiCatStartCol = new int[EmojiData.COUNT];
    private final int[] emojiCatCols = new int[EmojiData.COUNT];
    private final StringBuilder emojiQuery = new StringBuilder();
    private SearchPill emojiPill;
    private EmojiScroll emojiScroll;
    private EmojiGridView emojiGrid;
    private CatIconsView emojiCatIcons;
    private int emojiTravelPx;
    private LinearLayout emojiResultsRow;
    private HorizontalScrollView emojiResultsScroll;
    private int emojiSelectedTab = -1;
    private EdgeBlurLayout emojiHolder;   // the emoji list (animated together with the header and footer)
    private View emojiCatBar;             // ABC, category icons, delete
    private View emojiFoot;               // globe / microphone row
    private boolean emojiClosing;
    private ValueAnimator morphAnim;       // v3.99: the keyboard frame grows / shrinks between keyboard and emoji height
    private int kbBaseHeightPx;            // keyboard frame height, measured just before the emoji panel opens
    private boolean clipClosing;          // the clipboard panel is sinking back down
    private KeyView shiftView;
    private LinearLayout keysContainer;
    private FrameLayout keysHost;                 // holds keysContainer and the trackpad overlay
    private TrackpadOverlay trackpadOverlay;      // the blurred keyboard with the prompt, shown while the space bar is a trackpad
    private LinearLayout inputRoot;               // the keyboard itself (header, keys, footer)
    private EdgeBlurLayout footerBlur;            // v3.119: the footer's progressive blur, around inputRoot
    private FrameLayout inputOuter;               // frame around footerBlur; the trackpad sheet is added here
    private KeyRow accessoryRow;         // emoji + clipboard (left) and mic (right), under the keys
    private View footerSlot;             // v3.117: the keyboard column's empty space for the universal footer
    private View sugHost;                // the suggestion bar (its header takes over in the emoji / clipboard panels)
    private KeySounds sounds;

    // clipboard (history lives in memory; saved to prefs only when "remember across restarts" is on)
    private static final class ClipItem {
        final String text;
        boolean pinned;
        long dbId = -1;          // its row in clipboard_items (-1 when it is not stored)
        long timestamp;          // when it was copied (ms)

        ClipItem(String text, boolean pinned) {
            this.text = text;
            this.pinned = pinned;
        }
    }

    private final ArrayList<ClipItem> clipItems = new ArrayList<>();   // newest first
    private ClipboardManager clipboard;
    private ListView clipList;
    private TextView clipEmpty;
    private View clipClearKey;
    private ClipAdapter clipAdapter;
    private View clipMenuBar;                 // header glass capsule (Pin / Unpin | Delete) shown on long-press
    private ValueAnimator clipGlide;          // the highlight gliding to the pressed half, its tint shifting
    private final ArgbEvaluator argbEvaluator = new ArgbEvaluator();
    private View clipMenuCatcher;             // covers the list while the capsule is open
    private View clipMenuCard;                // the held tile (selected while the capsule is open)
    private Drawable clipMenuCardBg;          // the held tile's own background, put back when the capsule closes
    private int clipTileColor;                // the held tile's current tint: grey (default), then green / blue / red
    private TextView clipTitle;               // the "Clipboard" title, hidden while the capsule is open
    private FrameLayout clipHolderView;       // the clipboard list holder (the catcher is added here)
    private long clipMenuClosedAt = 0;
    private String lastSeenClip = null;
    private boolean inputActive = false;
    private Typeface uiFont = Typeface.DEFAULT;
    private Typeface uiMedium = Typeface.DEFAULT;
    private Colors colors = new Colors();
    private final Paint iconPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glyphPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path glyphPath = new Path();
    private float density = 2f;
    private int keyHeightPx = 150;
    private int accessoryHeightPx = 110;
    private int insetH = 8;
    private int insetV = 14;
    private boolean windowFormatSet = false;

    // key callout (pop-up) state
    private PopupWindow popup;
    private CalloutView calloutView;
    private KeyView calloutOwner;
    private boolean calibrated = false;
    private boolean calibrating = false;
    private int corrX = 0;
    private int corrY = 0;
    private int curPx = 0;
    private int curPy = 0;
    private float expectScreenX = 0f;
    private float expectScreenY = 0f;

    private int layer = LAYER_LETTERS;
    private boolean shifted = false;
    private boolean capsLock = false;
    private long lastShiftTap = 0;
    private long lastSpaceTime = 0;
    private long lastOwnEdit = 0;
    private boolean spaceAfterSuggestion = false;
    private boolean rebuildPending = false;

    private boolean isPasswordField = false;
    private boolean isEmailField = false;
    private boolean isUriField = false;
    private boolean numberMode = false;
    private boolean noSuggest = false;
    private boolean smart = false;
    private boolean rawKeyMode = false;
    private int imeAction = EditorInfo.IME_ACTION_NONE;

    private final SharedPreferences.OnSharedPreferenceChangeListener prefListener =
            new SharedPreferences.OnSharedPreferenceChangeListener() {
                @Override
                public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
                    if (Prefs.K_CLEAR_TOKEN.equals(key)) {
                        if (suggester != null) suggester.clearLearned();
                    } else if (Prefs.K_CLIP_CLEAR_TOKEN.equals(key)) {
                        clipItems.clear();
                        if (db != null) {
                            db.deleteAllClips();
                        }
                        refreshClipList();
                    } else if (K_CLIP_REMEMBER.equals(key)) {
                        clipSave(); // switched on: write what is in memory; switched off: wipe the saved copy
                    } else if (Prefs.K_THEME.equals(key) || Prefs.K_ACCENT.equals(key)
                            || Prefs.K_HEIGHT.equals(key) || Prefs.K_BLUR.equals(key)
                            || Prefs.K_ROUNDED.equals(key) || Prefs.K_CORNER_LEFT.equals(key)
                            || Prefs.K_CORNER_RIGHT.equals(key) || Prefs.K_MID_KEY.equals(key)
                            || Prefs.K_MID_RIGHT_KEY.equals(key)) {
                        rebuildPending = true;
                    } else if (Prefs.K_FONT.equals(key) || Prefs.K_FONT_SCALE.equals(key) || Prefs.K_EMOJI_SCALE.equals(key)
                            || Prefs.K_NUMROW.equals(key) || Prefs.K_NUMROW_PW.equals(key) || Prefs.K_EMOJI_KEY.equals(key)
                            || Prefs.K_COMMA.equals(key) || Prefs.K_PERIOD.equals(key) || Prefs.K_ONEHAND.equals(key)) {
                        if (Prefs.K_FONT.equals(key)) loadFonts();
                        rebuildPending = true;
                    } else if (Prefs.K_EMOJI_FONT.equals(key)) {
                        Fonts.resetEmoji();
                        rebuildPending = true;
                    } else if (Prefs.K_BLUR_DP.equals(key) || Prefs.K_OPACITY.equals(key)) {
                        applyWindowStyle();   // blur strength and opacity apply at once
                    }
                }
            };

    /** The keyboard font: AiOS (SF Pro Display) or the phone's own (Settings > Preferences > Font). */
    private void loadFonts() {
        if (Prefs.fontChoice(prefs) == 1) {
            uiFont = Typeface.create("sans-serif", Typeface.NORMAL);
            uiMedium = Typeface.create("sans-serif-medium", Typeface.NORMAL);
        } else {
            uiFont = Fonts.ui(this);
            uiMedium = Fonts.medium(this);
        }
    }

    // --------------------------------------------------------------- lifecycle
    @Override
    public void onCreate() {
        setTheme(R.style.KeyboardTheme); // fully transparent keyboard window (must come before super)
        super.onCreate();
        EmojiData.prepareAsync(this);
        prefs = Prefs.get(this);
        loadFonts();
        db = KeyboardDb.get(this);
        density = getResources().getDisplayMetrics().density;
        suggester = new Suggester(this);
        sounds = new KeySounds(this);
        clipLoad();
        clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) {
            clipboard.addPrimaryClipChangedListener(clipListener);
        }
        prefs.registerOnSharedPreferenceChangeListener(prefListener);
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
                if (wm != null) {
                    wm.addCrossWindowBlurEnabledListener(blurWatcher);
                }
            } catch (Throwable ignored) {
                // no blur listener: the window style is still applied on every keyboard start
            }
        }
    }

    @Override
    public void onDestroy() {
        dismissCalloutNow();
        dismissClipMenu();
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener);
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
                if (wm != null) {
                    wm.removeCrossWindowBlurEnabledListener(blurWatcher);
                }
            } catch (Throwable ignored) {
                // nothing to remove
            }
        }
        handler.removeCallbacksAndMessages(null);
        if (clipboard != null) {
            clipboard.removePrimaryClipChangedListener(clipListener);
        }
        if (sounds != null) {
            sounds.release();
            sounds = null;
        }
        super.onDestroy();
    }

    @Override
    public View onCreateInputView() {
        return buildKeyboard();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && layer == LAYER_CLIP) {
            leaveClipboard();
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_BACK && layer == LAYER_EMOJI_SEARCH) {
            exitEmojiSearch();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onEvaluateFullscreenMode() {
        return false; // never take over the whole screen in landscape
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        dismissCalloutNow();
        if (keysContainer != null) {
            setInputView(buildKeyboard());
        }
    }

    @Override
    public void onWindowHidden() {
        super.onWindowHidden();
        dismissCalloutNow();
        dismissClipMenu();
        inputActive = false;
        if (layer == LAYER_CLIP || layer == LAYER_EMOJI_SEARCH) {
            emojiQuery.setLength(0);
            layer = homeLayer();
        }
    }

    @Override
    public void onFinishInputView(boolean finishingInput) {
        inputActive = false;
        super.onFinishInputView(finishingInput);
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        classifyField(info);
        inputActive = true;
        if (layer == LAYER_CLIP || layer == LAYER_EMOJI_SEARCH) {
            emojiQuery.setLength(0);
            layer = homeLayer();
        }
        captureClip(true);
        if (rebuildPending || keysContainer == null) {
            rebuildPending = false;
            setInputView(buildKeyboard());
        } else {
            applyWindowStyle();
        }
        if (!restarting) {
            capsLock = false;
            shifted = false;
            layer = numberMode ? LAYER_SYMBOLS1 : LAYER_LETTERS;
        }
        spaceAfterSuggestion = false;
        renderKeys();
        updateAutoShift();
        updateSuggestions();
    }

    @Override
    public void onUpdateSelection(int oldSelStart, int oldSelEnd, int newSelStart,
                                  int newSelEnd, int candidatesStart, int candidatesEnd) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd,
                candidatesStart, candidatesEnd);
        if (SystemClock.uptimeMillis() - lastOwnEdit < 150) {
            return; // our own edit, already handled
        }
        updateSuggestions();
        if (newSelStart == newSelEnd && Math.abs(newSelStart - oldSelStart) > 1) {
            updateAutoShift();
        }
    }

    // ------------------------------------------------------- field classification
    private void classifyField(EditorInfo info) {
        isPasswordField = false;
        isEmailField = false;
        isUriField = false;
        numberMode = false;
        noSuggest = false;
        smart = false;
        rawKeyMode = false;
        imeAction = EditorInfo.IME_ACTION_NONE;
        if (info == null) {
            return;
        }
        int type = info.inputType;
        int cls = type & InputType.TYPE_MASK_CLASS;
        int var = type & InputType.TYPE_MASK_VARIATION;
        if (cls == InputType.TYPE_CLASS_TEXT) {
            if (var == InputType.TYPE_TEXT_VARIATION_PASSWORD
                    || var == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    || var == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD) {
                isPasswordField = true;
            }
            if (var == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                    || var == InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS) {
                isEmailField = true;
            }
            if (var == InputType.TYPE_TEXT_VARIATION_URI) {
                isUriField = true;
            }
            if ((type & InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0) {
                noSuggest = true;
            }
            smart = !isPasswordField && !isEmailField && !isUriField && !noSuggest;
        } else if (cls == InputType.TYPE_CLASS_NUMBER
                || cls == InputType.TYPE_CLASS_PHONE
                || cls == InputType.TYPE_CLASS_DATETIME) {
            numberMode = true;
        } else if (cls == InputType.TYPE_NULL) {
            rawKeyMode = true;
        }
        if ((info.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0) {
            imeAction = info.imeOptions & EditorInfo.IME_MASK_ACTION;
            if (imeAction == EditorInfo.IME_ACTION_UNSPECIFIED) {
                imeAction = EditorInfo.IME_ACTION_NONE;
            }
        }
    }

    // ------------------------------------------------------- colors and window
    private int dp(float v) {
        return Math.round(v * density);
    }

    private Colors loadColors() {
        Colors c = new Colors();
        int mode = Prefs.theme(prefs);
        boolean dark;
        if (mode == 0) {
            int night = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            dark = night == Configuration.UI_MODE_NIGHT_YES;
        } else {
            dark = mode == 2;
        }
        c.dark = dark;
        if (dark) {
            c.key = 0x29FFFFFF;          // iOS 27 key: white 16 % over the #1F1F1F panel = #434343
            c.keyPressed = 0x4DFFFFFF;
            c.keyShadow = 0;
            c.keyStroke = 0;             // flat tile, no rim
            c.text = 0xFFFFFFFF;
            c.divider = 0x12FFFFFF;      // hairline between the suggestions (white 7 %)
            c.calloutFill = 0xFF3C3E44;          // dark pop-up: a dark grey, not light
            c.calloutText = 0xFFFFFFFF;
            c.calloutShadow = 0x55000000;
        } else {
            c.key = 0xB3FFFFFF;          // glass keys: white at ~70 %, the blurred panel shows through
            c.keyPressed = 0xD6BEC3CC;
            c.keyShadow = 0;             // (the old opaque edge layer would show through the glass)
            c.keyStroke = 0;             // flat tile, no rim
            c.text = 0xFF000000;
            c.divider = 0x14000000;
            c.calloutFill = 0xFFFFFFFF;
            c.calloutText = 0xFF000000;
            c.calloutShadow = 0x40000000;
        }
        c.accent = Prefs.ACCENTS[Prefs.accent(prefs)];
        return c;
    }

    /** Re-applies the window style when the system turns window blur on or off (Android 12+). */
    private final java.util.function.Consumer<Boolean> blurWatcher = new java.util.function.Consumer<Boolean>() {
        @Override
        public void accept(Boolean enabled) {
            if (keysContainer != null) {
                applyWindowStyle();
            }
        }
    };

    private boolean blurSupported() {
        if (Build.VERSION.SDK_INT < 31) {
            return false;
        }
        try {
            WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            return wm != null && wm.isCrossWindowBlurEnabled();
        } catch (Throwable t) {
            return false;
        }
    }

    private int panelColor(boolean frosted, boolean blurOk) {
        if (!frosted) {
            return colors.dark ? 0xFF1F1F1F : 0xFFE3E4E6;           // solid (iOS 27 dark panel #1F1F1F)
        }
        if (blurOk) {
            // v3.96: the blur is requested, but on the test phone it does not show (the system toggle is on), so the
            // glass is 85 % opaque: the chat behind never shows through. Blur appears on top only if the system draws it.
            return colors.dark ? 0xD91F1F1F : 0xD9E8E9EB;
        }
        // v3.95: no window blur on this phone, so the panel is nearly solid (88 %) and the app behind does not show through
        return colors.dark ? 0xE01F1F1F : 0xE0E3E4E6;
    }

    /** Scales the panel's alpha by the Settings > Appearance opacity (100 % leaves the colour unchanged). */
    private int withOpacity(int color) {
        int a = ((color >>> 24) * Prefs.opacity(prefs)) / 100;
        return (color & 0x00FFFFFF) | (a << 24);
    }

    /** v3.94: a lighter tint of the glass colour, used at the top edge of the frosted panel (light on glass). */
    private int glassSheen(int color) {
        float f = colors.dark ? 0.10f : 0.45f;
        int a = color >>> 24;
        int r = (color >> 16) & 0xFF, gr = (color >> 8) & 0xFF, b = color & 0xFF;
        r = Math.round(r + (255 - r) * f);
        gr = Math.round(gr + (255 - gr) * f);
        b = Math.round(b + (255 - b) * f);
        return (a << 24) | (r << 16) | (gr << 8) | b;
    }

    private Drawable panelDrawable(int color, boolean glass) {
        float r = Prefs.on(prefs, Prefs.K_ROUNDED) ? dp(PANEL_RADIUS_DP) : 0f;
        GradientDrawable g = new GradientDrawable();
        if (glass) {
            g.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
            g.setColors(new int[]{glassSheen(color), color});
        } else {
            g.setColor(color);
        }
        g.setCornerRadii(new float[]{r, r, r, r, 0f, 0f, 0f, 0f});
        return g;
    }

    /** Makes the keyboard window itself the frosted glass panel. Returns false if it could not. */
    private boolean applyWindowStyle() {
        try {
            if (getWindow() == null) {
                return false;
            }
            Window w = getWindow().getWindow();
            if (w == null) {
                return false;
            }
            boolean frosted = Prefs.on(prefs, Prefs.K_BLUR);
            boolean blurOk = frosted && blurSupported();
            if (!windowFormatSet) {
                w.setFormat(PixelFormat.TRANSLUCENT);
                windowFormatSet = true;
            }
            w.setBackgroundDrawable(panelDrawable(withOpacity(panelColor(frosted, blurOk)), frosted));
            if (Build.VERSION.SDK_INT >= 31) {
                // blur strength from Settings > Appearance (default 4 dp: a soft softening, not a hard frost)
                w.setBackgroundBlurRadius(blurOk ? dp(Prefs.blurDp(prefs)) : 0);
            }
            w.setNavigationBarColor(Color.TRANSPARENT);
            if (Build.VERSION.SDK_INT >= 28) {
                w.setNavigationBarDividerColor(Color.TRANSPARENT);
            }
            if (Build.VERSION.SDK_INT >= 29) {
                w.setNavigationBarContrastEnforced(false);
            }
            if (Build.VERSION.SDK_INT >= 26) {
                View decor = w.getDecorView();
                int flags = decor.getSystemUiVisibility();
                if (colors.dark) {
                    flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                } else {
                    flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                }
                decor.setSystemUiVisibility(flags);
            }
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    // ------------------------------------------------------------ building views
    private View buildKeyboard() {
        density = getResources().getDisplayMetrics().density;
        colors = loadColors();
        boolean landscape = getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE;
        int hDp = Prefs.height(prefs);
        if (landscape) {
            hDp = Math.round(hDp * 0.72f);
        }
        keyHeightPx = dp(hDp);
        accessoryHeightPx = dp(landscape ? 30 : 64);   // iOS: emoji / mic centres sit 37 dp under the bottom key row
        // Every key is separated from its neighbours by 2 * inset: 6 dp sideways, 10 dp between rows.
        insetH = Math.max(1, Math.round(dp(KEY_GAP_H_DP) / 2f));
        insetV = Math.max(1, Math.round(dp(KEY_GAP_V_DP) / 2f));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        // The emoji and clipboard lists run under the header and footer bars, i.e. beyond the key area.
        root.setClipChildren(false);
        root.setPadding(dp(3), dp(2), dp(3), 0);
        root.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        if (!applyWindowStyle()) {
            // Could not style the window: fall back to painting the panel ourselves.
            root.setBackground(panelDrawable(panelColor(false, false), false));
        }

        sugHeightPx = dp(landscape ? 36 : 43);   // panel top to key top = 49.6 dp on iOS
        sugHost = buildSuggestionBar();
        root.addView(sugHost, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, sugHeightPx));

        keysContainer = new LinearLayout(this);
        keysContainer.setOrientation(LinearLayout.VERTICAL);
        keysContainer.setClipChildren(false);
        keysContainer.setMotionEventSplittingEnabled(true);
        // keysHost wraps the keys so the trackpad overlay can cover them (it adds nothing to the layout)
        keysHost = new FrameLayout(this);
        keysHost.setClipChildren(false);
        keysHost.setClipToPadding(false);
        keysHost.addView(keysContainer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        glideTrail = new GlideTrailView(this);
        keysHost.addView(glideTrail, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(keysHost, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        accessoryRow = new KeyRow(this, accessoryHeightPx);
        // v3.117: the footer is one universal bar on the top layer (added to the input frame below). The keyboard
        // column keeps an empty slot of the same height, so nothing else moves.
        footerSlot = new View(this);
        root.addView(footerSlot, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, accessoryHeightPx));

        renderKeys();
        // the input view is a frame: the keyboard, with the trackpad sheet (when shown) laid over all of it
        inputRoot = root;
        // v3.119: the whole keyboard column sits inside one bottom-only progressive blur layer. Only the footer zone
        // (the bottom accessoryHeightPx) is blurred: strong at the screen edge, fading to sharp at the top of the footer.
        // Panels that slide down under the footer melt into it. The footer itself has no fill of its own.
        footerBlur = new EdgeBlurLayout(this, 0f, accessoryHeightPx);
        footerBlur.footerOnly = true;
        footerBlur.setClipChildren(false);
        footerBlur.addView(root, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        inputOuter = new FrameLayout(this);
        inputOuter.setClipChildren(false);
        inputOuter.addView(footerBlur, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        // v3.117: the universal footer sits over the bottom of the keyboard column, on the top layer, and does not move
        inputOuter.addView(accessoryRow, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, accessoryHeightPx, Gravity.BOTTOM));
        accessoryRow.setTranslationZ(dp(PANEL_BAR_Z_DP));
        return inputOuter;
    }

    private View buildSuggestionBar() {
        FrameLayout host = new FrameLayout(this);
        host.setClipChildren(false);   // the emoji header slides in from below the keyboard
        host.setClipToPadding(false);
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        for (int i = 0; i < 3; i++) {
            TextView tv = new TextView(this);
            tv.setGravity(Gravity.CENTER);
            tv.setSingleLine(true);
            tv.setEllipsize(TextUtils.TruncateAt.END);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, dp(16.5f));   // iOS: 16.5 dp, regular
            tv.setTextColor(colors.text);
            tv.setTypeface(uiFont);
            tv.setPadding(dp(8), 0, dp(8), 0);
            tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String s = ((TextView) v).getText().toString();
                    if (!s.isEmpty()) {
                        feedback(v, T_CHAR);
                        pickSuggestion(s);
                    }
                }
            });
            suggestionViews[i] = tv;
            bar.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
            if (i < 2) {
                View d = new View(this);
                d.setBackgroundColor(colors.divider);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Math.max(1, dp(0.7f)), dp(21));   // 1 px hairline, 21 dp tall
                lp.gravity = Gravity.CENTER_VERTICAL;
                bar.addView(d, lp);
            }
        }
        sugWords = bar;
        host.addView(bar, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        sugAlt = new FrameLayout(this);
        sugAlt.setVisibility(View.GONE);
        host.addView(sugAlt, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return host;
    }

    /** The emoji panel and the clipboard panel use the suggestion bar for their own controls. */
    private void updateSuggestionBarMode() {
        if (sugAlt == null || sugWords == null) {
            return;
        }
        sugAlt.removeAllViews();
        boolean alt = layer == LAYER_EMOJI || layer == LAYER_CLIP || layer == LAYER_EMOJI_SEARCH;
        // In the emoji and clipboard panels the list scrolls under this bar, so the bar must draw on top.
        if (sugHost != null) {
            sugHost.setTranslationZ(layer == LAYER_EMOJI || layer == LAYER_CLIP ? dp(PANEL_BAR_Z_DP) : 0f);
        }
        sugAlt.setVisibility(alt ? View.VISIBLE : View.GONE);
        sugWords.setVisibility(alt ? View.INVISIBLE : View.VISIBLE);
        if (layer == LAYER_EMOJI_SEARCH) {
            buildEmojiSearchBar();
        }
    }

    // ------------------------------------------------------------------ layouts
    private static Key fn(int type, String label, float weight) {
        return new Key(type, label, null, weight, null, false, Icons.NONE);
    }

    private static Key ic(int type, int icon, float weight) {
        return new Key(type, "", null, weight, null, false, icon);
    }

    private static Key ch(String s, float weight) {
        return new Key(T_CHAR, s, s, weight, null, false, Icons.NONE);
    }

    private static Key space(float weight, String label) {
        return new Key(T_SPACE, label, " ", weight, null, false, Icons.NONE);
    }

    private static Key[] chars(String chars, String alts, boolean letters, float weight) {
        Key[] out = new Key[chars.length()];
        for (int i = 0; i < chars.length(); i++) {
            String s = String.valueOf(chars.charAt(i));
            String a = (alts == null) ? null : String.valueOf(alts.charAt(i));
            out[i] = new Key(T_CHAR, s, s, weight, a, letters, Icons.NONE);
        }
        return out;
    }

    private static Key[] row(Object... parts) {
        ArrayList<Key> list = new ArrayList<>();
        for (Object p : parts) {
            if (p instanceof Key) {
                list.add((Key) p);
            } else if (p instanceof Key[]) {
                for (Key k : (Key[]) p) {
                    list.add(k);
                }
            }
        }
        return list.toArray(new Key[0]);
    }

    private boolean primaryAction() {
        return imeAction == EditorInfo.IME_ACTION_GO || imeAction == EditorInfo.IME_ACTION_SEARCH
                || imeAction == EditorInfo.IME_ACTION_SEND || imeAction == EditorInfo.IME_ACTION_DONE;
    }

    private Key returnKey(float weight) {
        switch (imeAction) {
            case EditorInfo.IME_ACTION_GO:
                return new Key(T_ENTER, "Go", null, weight, null, false, Icons.NONE);
            case EditorInfo.IME_ACTION_SEARCH:
                return ic(T_ENTER, Icons.SEARCH, weight);
            case EditorInfo.IME_ACTION_SEND:
                return new Key(T_ENTER, "Send", null, weight, null, false, Icons.NONE);
            case EditorInfo.IME_ACTION_DONE:
                return new Key(T_ENTER, "Done", null, weight, null, false, Icons.NONE);
            case EditorInfo.IME_ACTION_NEXT:
                return new Key(T_ENTER, "Next", null, weight, null, false, Icons.NONE);
            default:
                return ic(T_ENTER, Icons.RETURN, weight);
        }
    }

    /** The key between 123 and the space bar, or null for none. */
    private Key middleKey(float weight) {
        String id = Prefs.choice(prefs, Prefs.K_MID_KEY, "none", "none", "emoji", "clip", "globe", "mic");
        if ("none".equals(id) && Prefs.on(prefs, Prefs.K_EMOJI_KEY)) id = "emoji";   // Preferences > Emoji key
        if (id.equals("none")) {
            return null;
        }
        Key k = accessoryKey(id, weight);
        if ("clip".equals(id)) {
            k.iconScale = 0.75f;   // v3.98: only this key's clipboard icon is smaller (not the corner or other keys)
        }
        return k;
    }

    /** The key between the space bar and return, or null for none (Settings > Keys). */
    private Key midRightKey(float weight) {
        String id = Prefs.choice(prefs, Prefs.K_MID_RIGHT_KEY, "none", "none", "emoji", "clip", "globe", "mic");
        return "none".equals(id) ? null : accessoryKey(id, weight);
    }

    /** The language key: the globe icon. A tap switches the keyboard / language (T_GLOBE). */
    private static Key languageKey(float weight) {
        return ic(T_GLOBE, G_GLOBE, weight);
    }

    /** The key for a choice (emoji, clip, globe or mic), with its icon. */
    private static Key accessoryKey(String id, float weight) {
        switch (id) {
            case "clip":
                return ic(T_TO_CLIP, G_CLIP, weight);
            case "globe":
                return languageKey(weight);   // globe icon: switches keyboard / language
            case "mic":
                return ic(T_MIC, G_MIC, weight);
            default:
                return ic(T_TO_EMOJI, G_EMOJI, weight);
        }
    }

    private Key[] bottomRow(boolean fromLetters) {
        int toggleType = fromLetters ? T_TO_SYMBOLS1 : T_TO_LETTERS;
        String toggleLabel = fromLetters ? "123" : "ABC";
        ArrayList<Key> k = new ArrayList<>();
        // No emoji key here: 123 | space | return. Emoji lives in the tool tab under the keys.
        if (isEmailField) {
            k.add(fn(toggleType, toggleLabel, 1.6f));
            k.add(space(4.2f, ""));
            k.add(ch("@", 1.0f));
            k.add(ch(".", 1.0f));
            k.add(returnKey(2.2f));
        } else if (isUriField) {
            k.add(fn(toggleType, toggleLabel, 1.5f));
            k.add(space(3.9f, ""));
            k.add(ch(".", 1.0f));
            k.add(ch("/", 1.0f));
            k.add(new Key(T_CHAR, ".com", ".com", 1.3f, null, false, Icons.NONE));
            k.add(returnKey(1.3f));
        } else {
            // 123 is 2.5 units wide (90 dp). When the middle button is on, that width is split in half: 123 and the
            // button each take 1.25 units, equal in size. The space bar and the return key keep their size.
            Key mid = middleKey(1.25f);                 // optional button (Settings > Keys)
            Key midR = midRightKey(1.25f);              // optional button between the space bar and return
            k.add(fn(toggleType, toggleLabel, mid != null ? 1.25f : 2.5f));
            if (mid != null) {
                k.add(mid);
            }
            // the space bar keeps its size; a button between space and return splits the return key in half
            boolean comma = fromLetters && Prefs.on(prefs, Prefs.K_COMMA);     // Preferences > Comma key
            boolean period = fromLetters && Prefs.on(prefs, Prefs.K_PERIOD);   // Preferences > Period key
            if (comma) {
                k.add(ch(",", 1.0f));
            }
            k.add(space(5.0f - (comma ? 1f : 0f) - (period ? 1f : 0f), ""));   // no language label on the space bar (iOS 27)
            if (period) {
                k.add(ch(".", 1.0f));
            }
            if (midR != null) {
                k.add(midR);
                k.add(returnKey(1.25f));
            } else {
                k.add(returnKey(2.5f));
            }
        }
        return k.toArray(new Key[0]);
    }

    /** iOS keeps shift / delete a little further from the letters: 13 dp instead of 6 dp. */
    private static final float SIDE_KEY_GAP_EXTRA_DP = 7.2f;

    private static Key facingRight(Key k) {   // key sits at the left end of its row
        k.padR = SIDE_KEY_GAP_EXTRA_DP;
        return k;
    }

    private static Key facingLeft(Key k) {    // key sits at the right end of its row
        k.padL = SIDE_KEY_GAP_EXTRA_DP;
        return k;
    }

    /** The digit row above the letters (Settings > Preferences > Number row / Number row for passwords). */
    private boolean numberRowOn() {
        if (numberMode) return false;   // number and phone fields already start with digits
        return Prefs.on(prefs, Prefs.K_NUMROW) || (isPasswordField && Prefs.on(prefs, Prefs.K_NUMROW_PW));
    }

    /** Rows of keys above the tool row: 4, or 5 with the number row. */
    private int keyRows() {
        return numberRowOn() ? 5 : 4;
    }

    private static Key[][] withRowOnTop(Key[][] rows, Key[] top) {
        Key[][] out = new Key[rows.length + 1][];
        out[0] = top;
        System.arraycopy(rows, 0, out, 1, rows.length);
        return out;
    }

    private Key[][] lettersLayout() {
        boolean nr = numberRowOn();
        Key[][] rows = new Key[][]{
                chars("qwertyuiop", nr ? null : "1234567890", true, 1f),
                row(fn(T_SPACER, "", 0.5f), chars("asdfghjkl", null, true, 1f), fn(T_SPACER, "", 0.5f)),
                row(facingRight(ic(T_SHIFT, Icons.SHIFT, 1.5f)), chars("zxcvbnm", null, true, 1f),
                        facingLeft(ic(T_DELETE, Icons.DELETE, 1.5f))),
                bottomRow(true)
        };
        return nr ? withRowOnTop(rows, chars("1234567890", null, false, 1f)) : rows;
    }

    private Key[][] symbols1Layout() {
        Key[][] rows = new Key[][]{
                chars("1234567890", null, false, 1f),
                chars("-/:;()$&@\"", null, false, 1f),
                row(facingRight(fn(T_TO_SYMBOLS2, "#+=", 1.5f)), chars(".,?!'", null, false, 1.4f),
                        facingLeft(ic(T_DELETE, Icons.DELETE, 1.5f))),
                bottomRow(false)
        };
        if (!numberRowOn()) return rows;
        // with the number row the symbols keyboard keeps the same height as the letters: one more row of symbols
        return new Key[][]{rows[0], rows[1], chars("[]{}#%^*+=", null, false, 1f), rows[2], rows[3]};
    }

    private Key[][] symbols2Layout() {
        Key[][] rows = new Key[][]{
                chars("[]{}#%^*+=", null, false, 1f),
                chars("_\\|~<>\u20AC\u00A3\u00A5\u2022", null, false, 1f),
                row(facingRight(fn(T_TO_SYMBOLS1, "123", 1.5f)), chars(".,?!'", null, false, 1.4f),
                        facingLeft(ic(T_DELETE, Icons.DELETE, 1.5f))),
                bottomRow(false)
        };
        return numberRowOn() ? withRowOnTop(rows, chars("1234567890", null, false, 1f)) : rows;
    }

    // ---------------------------------------------------------------- rendering
    private void renderKeys() {
        if (keysContainer == null) {
            return;
        }
        dismissCalloutNow();
        dismissClipMenu();
        applyOneHand();
        keysContainer.removeAllViews();
        letterViews.clear();
        shiftView = null;
        applySugHeight();
        updateSuggestionBarMode();
        if (layer == LAYER_EMOJI) {
            renderEmoji();
        } else if (layer == LAYER_CLIP) {
            renderClipboard();
        } else {
            Key[][] rows;
            switch (layer) {
                case LAYER_SYMBOLS1:
                    rows = symbols1Layout();
                    break;
                case LAYER_SYMBOLS2:
                    rows = symbols2Layout();
                    break;
                default:
                    rows = lettersLayout();
                    break;
            }
            for (Key[] r : rows) {
                addKeyRow(r);
            }
        }
        renderAccessory();
        updateShiftVisuals();
    }

    /** One-handed keyboard (Preferences): the letters and symbols keyboards use 80 % of the width, left or right. */
    private void applyOneHand() {
        if (inputRoot == null) {
            return;
        }
        int mode = Prefs.oneHand(prefs);
        boolean portrait = getResources().getConfiguration().orientation != Configuration.ORIENTATION_LANDSCAPE;
        boolean keysLayer = layer == LAYER_LETTERS || layer == LAYER_SYMBOLS1 || layer == LAYER_SYMBOLS2;
        int extra = (mode != 0 && portrait && keysLayer)
                ? Math.round(getResources().getDisplayMetrics().widthPixels * 0.2f) : 0;
        inputRoot.setPadding(dp(3) + (mode == 2 ? extra : 0), dp(2), dp(3) + (mode == 1 ? extra : 0), 0);
    }

    /** The emoji panel's top area (search pill) is taller than the suggestion bar. */
    private void applySugHeight() {
        if (sugHost == null) {
            return;
        }
        int want = (layer == LAYER_EMOJI || layer == LAYER_EMOJI_SEARCH) ? emojiTopPx() : sugHeightPx;
        ViewGroup.LayoutParams lp = sugHost.getLayoutParams();
        if (lp != null && lp.height != want) {
            lp.height = want;
            sugHost.setLayoutParams(lp);
        }
    }

    private void renderAccessory() {
        if (accessoryRow == null) {
            return;
        }
        accessoryRow.removeAllViews();
        // In the clipboard panel the list scrolls under this row (the footer), so it must draw on top.
        accessoryRow.setTranslationZ(dp(PANEL_BAR_Z_DP));   // v3.117: always on top, in every panel
        accessoryRow.setVisibility(View.VISIBLE);   // v3.100: the footer is the same bar in every layer
        // Under the keys: two corner buttons, left and right (Settings > Keys: emoji, clipboard, globe or mic).
        // Both icons keep their old places: left icon centre 10.51 units from the left edge, right icon centre
        // 10.77 units from the right edge (units are 1/10 of the width; iOS 27: 41 dp and 42 dp on a 390 dp screen).
        float slotW = 2.5f;
        Key left = accessoryKey(Prefs.choice(prefs, Prefs.K_CORNER_LEFT, "emoji", "emoji", "clip", "globe", "mic"), slotW);
        left.cornerLeft = true;
        left.iconShift = (1.051f - slotW / 2f) / slotW;
        accessoryRow.add(new KeyView(left, true), slotW);
        accessoryRow.add(new View(this), 10f - 2f * slotW);
        Key right = accessoryKey(Prefs.choice(prefs, Prefs.K_CORNER_RIGHT, "mic", "emoji", "clip", "globe", "mic"), slotW);
        right.iconShift = (slotW / 2f - 1.077f) / slotW;
        accessoryRow.add(new KeyView(right, true), slotW);
    }

    private int homeLayer() {
        return numberMode ? LAYER_SYMBOLS1 : LAYER_LETTERS;
    }

    /** The globe's strokes on the 24 grid (ring, meridian ellipse, centre line, equator, two parallels) with the given stroke paint; ring = false skips the outer ring. */
    private void globeLines(Canvas c, Paint stroke, boolean ring) {
        Path gp = glyphPath;
        gp.reset();
        if (ring) {
            c.drawCircle(12f, 12f, 10f, stroke);
        }
        c.drawOval(new RectF(8.2f, 2f, 15.8f, 22f), stroke);
        c.drawLine(12f, 2f, 12f, 22f, stroke);
        c.drawLine(2f, 12f, 22f, 12f, stroke);
        gp.moveTo(4.08f, 5.9f);
        gp.quadTo(12f, 8.1f, 19.92f, 5.9f);
        c.drawPath(gp, stroke);
        gp.reset();
        gp.moveTo(4.08f, 18.1f);
        gp.quadTo(12f, 15.9f, 19.92f, 18.1f);
        c.drawPath(gp, stroke);
    }

    /** Draws the line icons this class owns, on a 24 x 24 grid scaled to `size`. */
    private void drawGlyph(Canvas c, int g, float cx, float cy, float size, int color) {
        Paint p = glyphPaint;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setColor(color);
        float sc = size / 24f;
        float w = dp(g == G_BACK ? 2.2f : 1.7f) / sc;
        final float iconW = dp(ICON_STROKE_DP) / sc;   // grid units
        p.setStrokeWidth(w);
        c.save();
        c.translate(cx - size / 2f, cy - size / 2f);
        c.scale(sc, sc);
        Path path = glyphPath;
        path.reset();
        switch (g) {
            case G_BACK:
                path.moveTo(15.6f, 4.6f);
                path.lineTo(8.4f, 12f);
                path.lineTo(15.6f, 19.4f);
                c.drawPath(path, p);
                break;
            case G_EMOJI: {
                // SOLID smiley (frosted glass off): filled face; the eyes and the open mouth are cut out, the teeth are filled back in
                p.setStyle(Paint.Style.FILL);
                path.setFillType(Path.FillType.EVEN_ODD);
                path.addCircle(12f, 12f, 11f, Path.Direction.CW);
                path.addOval(new RectF(7.5f, 7.8f, 9.9f, 10.8f), Path.Direction.CW);
                path.addOval(new RectF(14.1f, 7.8f, 16.5f, 10.8f), Path.Direction.CW);
                path.moveTo(5.0f, 12.7f);
                path.lineTo(19.0f, 12.7f);
                path.cubicTo(18.5f, 17.8f, 15.5f, 19.3f, 12f, 19.3f);
                path.cubicTo(8.5f, 19.3f, 5.5f, 17.8f, 5.0f, 12.7f);
                path.close();
                path.addRoundRect(new RectF(6.2f, 13.5f, 17.8f, 15.6f), 0.8f, 0.8f, Path.Direction.CW);
                c.drawPath(path, p);
                path.setFillType(Path.FillType.WINDING);
                break;
            }
            case G_EMOJI_LINE: {
                // OUTLINE smiley, the reference icon: ring, dot eyes, open mouth with a curved smile line and a curved teeth band
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(iconW);
                c.drawCircle(12f, 12f, 10.1f, p);
                p.setStyle(Paint.Style.FILL);
                c.drawOval(new RectF(7.57f, 8.08f, 9.97f, 11.08f), p);
                c.drawOval(new RectF(14.03f, 8.08f, 16.43f, 11.08f), p);
                path.setFillType(Path.FillType.EVEN_ODD);
                path.moveTo(5.0f, 13.0f);
                path.quadTo(12f, 14.4f, 19.0f, 13.0f);          // curved top edge of the mouth (a smile)
                path.cubicTo(18.6f, 17.9f, 15.5f, 19.2f, 12f, 19.2f);
                path.cubicTo(8.5f, 19.2f, 5.4f, 17.9f, 5.0f, 13.0f);
                path.close();
                path.moveTo(6.4f, 14.0f);                         // teeth band, curved like the top edge
                path.quadTo(12f, 15.4f, 17.6f, 14.0f);
                path.lineTo(17.3f, 14.9f);
                path.quadTo(12f, 17.3f, 6.7f, 14.9f);
                path.close();
                c.drawPath(path, p);
                path.setFillType(Path.FillType.WINDING);
                break;
            }
            case G_MIC: {
                // SOLID microphone (frosted glass off): filled capsule + U holder, stem and foot (reference proportions)
                p.setStyle(Paint.Style.FILL);
                c.drawRoundRect(new RectF(8.54f, 1.45f, 15.46f, 15.29f), 3.46f, 3.46f, p);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(1.32f);   // grid units
                path.moveTo(5.74f, 9.72f);
                path.lineTo(5.74f, 11.31f);
                path.arcTo(new RectF(5.74f, 5.05f, 18.26f, 17.57f), 180f, -180f, false);
                path.lineTo(18.26f, 9.72f);
                c.drawPath(path, p);
                c.drawLine(12f, 17.57f, 12f, 21.89f, p);
                c.drawLine(7.47f, 21.89f, 16.53f, 21.89f, p);
                break;
            }
            case G_SHIFT:
            case G_SHIFT_ON: {
                // broad short head, stubby stem, rounded corners (iOS 27).
                // Shift off = outline arrow only, shift on = solid arrow (the key tile itself never changes colour).
                path.moveTo(12f, 3.6f);
                path.lineTo(2f, 13f);
                path.lineTo(7.3f, 13f);
                path.lineTo(7.3f, 20.4f);
                path.lineTo(16.7f, 20.4f);
                path.lineTo(16.7f, 13f);
                path.lineTo(22f, 13f);
                path.close();
                if (g == G_SHIFT_ON) {
                    p.setStyle(Paint.Style.FILL_AND_STROKE);
                    p.setStrokeWidth(dp(1.8f) / sc);
                } else {
                    p.setStyle(Paint.Style.STROKE);
                    p.setStrokeWidth(dp(1.7f) / sc);
                }
                c.drawPath(path, p);
                break;
            }
            case G_CAPS: {
                p.setStyle(Paint.Style.FILL_AND_STROKE);
                p.setStrokeWidth(dp(1.8f) / sc);
                path.moveTo(12f, 2.8f);
                path.lineTo(2f, 11.8f);
                path.lineTo(7.3f, 11.8f);
                path.lineTo(7.3f, 16.2f);
                path.lineTo(16.7f, 16.2f);
                path.lineTo(16.7f, 11.8f);
                path.lineTo(22f, 11.8f);
                path.close();
                c.drawPath(path, p);
                c.drawRoundRect(new RectF(7.3f, 18.9f, 16.7f, 21.3f), 1.2f, 1.2f, p);
                break;
            }
            case G_DELETE: {
                // tag with a pointed, rounded left end and a bold x
                p.setStrokeWidth(dp(1.5f) / sc);
                path.moveTo(7.6f, 3.5f);
                path.lineTo(20.3f, 3.5f);
                path.quadTo(22.7f, 3.5f, 22.7f, 5.9f);
                path.lineTo(22.7f, 18.1f);
                path.quadTo(22.7f, 20.5f, 20.3f, 20.5f);
                path.lineTo(7.6f, 20.5f);
                path.lineTo(1.7f, 12.9f);
                path.quadTo(1.1f, 12f, 1.7f, 11.1f);
                path.close();
                c.drawPath(path, p);
                p.setStrokeWidth(dp(1.7f) / sc);
                c.drawLine(11.9f, 8.9f, 18.1f, 15.1f, p);
                c.drawLine(18.1f, 8.9f, 11.9f, 15.1f, p);
                break;
            }
            case G_RETURN: {
                // arrow pointing left; the line turns up at the right and ends in a short top cap
                p.setStrokeWidth(dp(1.5f) / sc);
                path.moveTo(12.7f, 3.8f);
                path.lineTo(19.5f, 3.8f);
                path.quadTo(21.9f, 3.8f, 21.9f, 6.2f);
                path.lineTo(21.9f, 12.2f);
                path.quadTo(21.9f, 14.6f, 19.5f, 14.6f);
                path.lineTo(2.1f, 14.6f);
                path.moveTo(7.5f, 9f);
                path.lineTo(2.1f, 14.6f);
                path.lineTo(7.5f, 20.2f);
                c.drawPath(path, p);
                break;
            }
            case G_CLIP: {
                // solid board with a gap around the clip and three cut-out lines (y 1.4 .. 22.6 of the grid)
                p.setStyle(Paint.Style.FILL);
                path.setFillType(Path.FillType.EVEN_ODD);
                path.addRoundRect(new RectF(4f, 3.2f, 20f, 22.6f), 3.2f, 3.2f, Path.Direction.CW);
                path.addRoundRect(new RectF(7.2f, 1.9f, 16.8f, 7.6f), 2.2f, 2.2f, Path.Direction.CW);
                path.addRoundRect(new RectF(7.8f, 10.6f, 16.2f, 12.2f), 0.8f, 0.8f, Path.Direction.CW);
                path.addRoundRect(new RectF(7.8f, 14.2f, 16.2f, 15.8f), 0.8f, 0.8f, Path.Direction.CW);
                path.addRoundRect(new RectF(7.8f, 17.8f, 16.2f, 19.4f), 0.8f, 0.8f, Path.Direction.CW);
                c.drawPath(path, p);
                path.setFillType(Path.FillType.WINDING);
                c.drawRoundRect(new RectF(8.4f, 1.4f, 15.6f, 6.4f), 1.8f, 1.8f, p);
                break;
            }
            case G_CLIP_LINE: {
                // OUTLINE clipboard: rounded board, clip tab on top (the board's top edge is open under the tab),
                // and three text lines, so it reads as a clipboard
                p.setStrokeWidth(iconW);
                final float L = 3.5f, R = 20.5f, T = 4f, B = 22.5f, rb = 3.5f;   // board
                final float cl = 8f, cr = 16f, ct = 1.5f, rc = 2.2f;             // clip tab
                path.reset();
                path.moveTo(cl, T);
                path.lineTo(L + rb, T);
                path.arcTo(new RectF(L, T, L + 2f * rb, T + 2f * rb), 270f, -90f, false);
                path.lineTo(L, B - rb);
                path.arcTo(new RectF(L, B - 2f * rb, L + 2f * rb, B), 180f, -90f, false);
                path.lineTo(R - rb, B);
                path.arcTo(new RectF(R - 2f * rb, B - 2f * rb, R, B), 90f, -90f, false);
                path.lineTo(R, T + rb);
                path.arcTo(new RectF(R - 2f * rb, T, R, T + 2f * rb), 0f, -90f, false);
                path.lineTo(cr, T);
                path.moveTo(cl, T);
                path.lineTo(cl, ct + rc);
                path.arcTo(new RectF(cl, ct, cl + 2f * rc, ct + 2f * rc), 180f, 90f, false);
                path.lineTo(cr - rc, ct);
                path.arcTo(new RectF(cr - 2f * rc, ct, cr, ct + 2f * rc), 270f, 90f, false);
                path.lineTo(cr, T);
                c.drawPath(path, p);
                c.drawLine(7.5f, 10.5f, 16.5f, 10.5f, p);
                c.drawLine(7.5f, 14.5f, 16.5f, 14.5f, p);
                c.drawLine(7.5f, 18.5f, 13.5f, 18.5f, p);
                break;
            }
            case G_SEARCH:
                c.drawCircle(10.5f, 10.5f, 6.5f, p);
                c.drawLine(15.3f, 15.3f, 20f, 20f, p);
                break;
            case G_GLOBE: {
                // OUTLINE globe (frosted glass on), the reference icon: ring, meridian ellipse, centre line, equator, two curved parallels
                p.setStrokeWidth(iconW);
                globeLines(c, p, true);
                break;
            }
            case G_GLOBE_SOLID: {
                // SOLID globe (frosted glass off): filled disc with the globe lines cut out
                int layerId = c.saveLayer(-2f, -2f, 26f, 26f, null);
                p.setStyle(Paint.Style.FILL);
                c.drawCircle(12f, 12f, 10.68f, p);
                clearPaint.setXfermode(new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.CLEAR));
                clearPaint.setStyle(Paint.Style.STROKE);
                clearPaint.setStrokeCap(Paint.Cap.ROUND);
                clearPaint.setStrokeJoin(Paint.Join.ROUND);
                clearPaint.setStrokeWidth(1.2f);   // grid units
                globeLines(c, clearPaint, false);   // the ring is not cut: the disc edge is the ring
                c.restoreToCount(layerId);
                break;
            }
            case G_MIC_LINE: {
                // OUTLINE microphone, the reference icon: capsule outline, U holder, stem and foot
                p.setStrokeWidth(iconW);
                c.drawRoundRect(new RectF(9.2f, 2.11f, 14.8f, 14.63f), 2.8f, 2.8f, p);
                path.moveTo(5.74f, 9.72f);
                path.lineTo(5.74f, 11.31f);
                path.arcTo(new RectF(5.74f, 5.05f, 18.26f, 17.57f), 180f, -180f, false);
                path.lineTo(18.26f, 9.72f);
                c.drawPath(path, p);
                c.drawLine(12f, 17.57f, 12f, 21.89f, p);
                c.drawLine(7.47f, 21.89f, 16.53f, 21.89f, p);
                break;
            }
            default:
                break;
        }
        c.restore();
    }

    /** Category icons, traced from the iOS 27 reference screenshot (24 x 24 grid, 1 unit = 2 reference px, centred). Order: Recent, Smileys & People, Animals & Nature, Food & Drink, Activities, Travel & Places, Objects, Symbols, Flags. Field 1 is the normal icon and field 2 the selected one; each is one path filled even-odd (the stroke rings). */
    private static final String[][] CAT_ICONS = {
        {"", "M 12.76 21.05 L 13.87 20.80 L 15.93 20.22 L 16.44 19.98 L 17.66 19.17 L 18.18 18.66 L 18.68 18.27 L 18.91 17.98 L 19.27 17.42 L 19.73 16.88 L 20.00 16.42 L 20.41 15.48 L 20.84 14.75 L 21.05 13.98 L 21.18 13.05 L 21.21 11.48 L 21.18 10.62 L 21.04 9.75 L 20.85 9.12 L 19.93 7.23 L 19.30 6.45 L 18.73 5.62 L 18.38 5.25 L 17.39 4.56 L 16.89 4.12 L 16.62 3.94 L 15.55 3.39 L 15.18 3.24 L 12.37 2.91 L 11.54 2.90 L 10.12 3.05 L 8.93 3.24 L 8.43 3.40 L 7.24 3.99 L 6.93 4.20 L 6.41 4.67 L 5.60 5.17 L 5.05 5.79 L 3.97 7.25 L 3.60 8.05 L 3.38 8.80 L 3.02 9.80 L 2.87 10.48 L 2.79 11.25 L 2.79 12.18 L 2.96 13.80 L 3.67 15.99 L 3.99 16.62 L 4.63 17.42 L 5.07 18.12 L 6.37 19.27 L 7.12 19.77 L 8.04 20.22 L 9.29 20.55 L 10.49 20.95 L 10.99 21.05 L 11.49 21.09 L 12.18 21.10 L 12.76 21.05 Z M 12.49 19.49 L 11.18 19.48 L 10.18 19.33 L 9.54 19.17 L 9.12 18.98 L 7.28 17.87 L 6.42 17.05 L 5.44 15.87 L 5.24 15.55 L 4.45 13.18 L 4.30 12.30 L 4.30 11.48 L 4.37 10.93 L 5.01 8.80 L 5.24 8.29 L 5.87 7.38 L 6.81 6.41 L 8.18 5.25 L 8.49 5.12 L 9.20 4.92 L 10.37 4.46 L 11.04 4.29 L 11.54 4.23 L 12.31 4.23 L 13.12 4.36 L 13.87 4.56 L 14.75 4.92 L 15.62 5.15 L 15.93 5.35 L 16.43 5.86 L 17.07 6.37 L 17.48 6.79 L 18.37 7.79 L 18.62 8.18 L 18.95 9.05 L 19.39 10.48 L 19.50 10.98 L 19.55 11.48 L 19.57 12.18 L 19.52 12.75 L 19.27 13.75 L 18.85 15.05 L 18.48 15.87 L 17.73 16.77 L 17.05 17.41 L 16.52 17.98 L 15.53 18.55 L 14.82 19.05 L 14.49 19.16 L 13.68 19.33 L 12.49 19.49 Z M 10.91 13.05 L 11.62 12.96 L 12.12 12.70 L 12.44 12.30 L 12.65 11.68 L 12.68 6.99 L 12.61 6.67 L 12.48 6.42 L 12.24 6.21 L 11.99 6.12 L 11.74 6.15 L 11.49 6.29 L 11.32 6.56 L 11.21 6.87 L 11.19 7.17 L 11.25 10.37 L 11.17 10.75 L 10.93 11.12 L 10.62 11.38 L 10.18 11.54 L 8.87 11.53 L 7.62 11.62 L 7.43 11.71 L 7.25 11.87 L 7.10 12.25 L 7.10 12.48 L 7.20 12.75 L 7.42 12.93 L 7.68 13.02 L 9.18 13.08 L 10.91 13.05 Z", "M 12.76 21.05 L 13.87 20.80 L 15.93 20.22 L 16.44 19.98 L 17.66 19.17 L 18.18 18.66 L 18.68 18.27 L 18.91 17.98 L 19.27 17.42 L 19.73 16.88 L 20.00 16.42 L 20.41 15.48 L 20.84 14.75 L 21.05 13.98 L 21.18 13.05 L 21.21 11.48 L 21.18 10.62 L 21.04 9.75 L 20.85 9.12 L 19.93 7.23 L 19.30 6.45 L 18.73 5.62 L 18.38 5.25 L 17.39 4.56 L 16.89 4.12 L 16.62 3.94 L 15.55 3.39 L 15.18 3.24 L 12.37 2.91 L 11.54 2.90 L 10.12 3.05 L 8.93 3.24 L 8.43 3.40 L 7.24 3.99 L 6.93 4.20 L 6.41 4.67 L 5.60 5.17 L 5.05 5.79 L 3.97 7.25 L 3.60 8.05 L 3.38 8.80 L 3.02 9.80 L 2.87 10.48 L 2.79 11.25 L 2.79 12.18 L 2.96 13.80 L 3.67 15.99 L 3.99 16.62 L 4.63 17.42 L 5.07 18.12 L 6.37 19.27 L 7.12 19.77 L 8.04 20.22 L 9.29 20.55 L 10.49 20.95 L 10.99 21.05 L 11.49 21.09 L 12.18 21.10 L 12.76 21.05 Z M 12.49 19.49 L 11.18 19.48 L 10.18 19.33 L 9.54 19.17 L 9.12 18.98 L 7.28 17.87 L 6.42 17.05 L 5.44 15.87 L 5.24 15.55 L 4.45 13.18 L 4.30 12.30 L 4.30 11.48 L 4.37 10.93 L 5.01 8.80 L 5.24 8.29 L 5.87 7.38 L 6.81 6.41 L 8.18 5.25 L 8.49 5.12 L 9.20 4.92 L 10.37 4.46 L 11.04 4.29 L 11.54 4.23 L 12.31 4.23 L 13.12 4.36 L 13.87 4.56 L 14.75 4.92 L 15.62 5.15 L 15.93 5.35 L 16.43 5.86 L 17.07 6.37 L 17.48 6.79 L 18.37 7.79 L 18.62 8.18 L 18.95 9.05 L 19.39 10.48 L 19.50 10.98 L 19.55 11.48 L 19.57 12.18 L 19.52 12.75 L 19.27 13.75 L 18.85 15.05 L 18.48 15.87 L 17.73 16.77 L 17.05 17.41 L 16.52 17.98 L 15.53 18.55 L 14.82 19.05 L 14.49 19.16 L 13.68 19.33 L 12.49 19.49 Z M 10.91 13.05 L 11.62 12.96 L 12.12 12.70 L 12.44 12.30 L 12.65 11.68 L 12.68 6.99 L 12.61 6.67 L 12.48 6.42 L 12.24 6.21 L 11.99 6.12 L 11.74 6.15 L 11.49 6.29 L 11.32 6.56 L 11.21 6.87 L 11.19 7.17 L 11.25 10.37 L 11.17 10.75 L 10.93 11.12 L 10.62 11.38 L 10.18 11.54 L 8.87 11.53 L 7.62 11.62 L 7.43 11.71 L 7.25 11.87 L 7.10 12.25 L 7.10 12.48 L 7.20 12.75 L 7.42 12.93 L 7.68 13.02 L 9.18 13.08 L 10.91 13.05 Z", "", "", "", ""},
        {"", "M 12.44 21.07 L 13.33 20.96 L 14.27 20.59 L 15.71 20.29 L 16.16 20.12 L 16.82 19.79 L 17.50 19.32 L 18.70 18.18 L 19.57 17.18 L 19.82 16.84 L 20.05 16.38 L 20.50 15.06 L 20.89 14.22 L 21.05 13.76 L 21.20 12.26 L 21.12 10.76 L 21.04 10.12 L 20.89 9.62 L 20.39 8.57 L 20.12 7.62 L 19.89 7.13 L 19.27 6.30 L 18.43 5.38 L 17.96 4.95 L 16.89 4.13 L 15.64 3.46 L 14.83 3.21 L 12.52 2.94 L 11.90 2.94 L 10.46 3.04 L 8.83 3.35 L 8.27 3.53 L 7.77 3.75 L 7.19 4.12 L 6.58 4.67 L 5.50 5.43 L 5.18 5.75 L 4.71 6.57 L 4.18 7.18 L 3.98 7.49 L 3.33 8.89 L 2.99 9.94 L 2.90 10.44 L 2.81 11.69 L 2.91 13.49 L 3.09 14.31 L 4.02 16.41 L 4.62 17.18 L 5.13 18.00 L 6.40 19.14 L 7.52 19.95 L 8.02 20.18 L 9.02 20.41 L 10.63 20.93 L 11.71 21.07 L 12.44 21.07 Z M 13.13 19.50 L 12.33 19.57 L 11.27 19.52 L 10.63 19.45 L 9.96 19.32 L 9.45 19.12 L 8.68 18.62 L 7.83 18.23 L 7.46 18.00 L 6.08 16.62 L 5.21 15.28 L 4.92 14.44 L 4.56 12.69 L 4.51 12.06 L 4.56 11.31 L 4.74 10.26 L 4.99 9.12 L 5.27 8.40 L 5.96 7.40 L 6.21 7.12 L 7.46 5.91 L 8.02 5.46 L 8.63 5.16 L 9.53 4.88 L 10.40 4.46 L 10.77 4.36 L 12.46 4.29 L 13.21 4.36 L 13.58 4.46 L 14.33 4.83 L 15.46 5.17 L 16.14 5.50 L 17.02 6.33 L 17.64 6.88 L 18.32 7.76 L 18.80 8.56 L 19.07 9.12 L 19.41 10.31 L 19.55 10.94 L 19.66 11.99 L 19.64 12.56 L 19.48 13.44 L 19.21 14.40 L 18.89 15.19 L 18.37 15.93 L 17.77 16.93 L 16.82 17.82 L 16.21 18.21 L 15.13 18.75 L 14.27 19.25 L 13.83 19.39 L 13.13 19.50 Z M 9.68 10.88 L 9.92 10.69 L 10.13 10.30 L 10.24 9.94 L 10.21 9.56 L 10.08 9.21 L 9.84 8.94 L 9.58 8.80 L 9.27 8.79 L 8.96 8.94 L 8.60 9.31 L 8.46 9.69 L 8.46 10.06 L 8.62 10.44 L 8.96 10.79 L 9.33 10.94 L 9.68 10.88 Z M 14.83 10.81 L 15.21 10.65 L 15.51 10.38 L 15.68 10.06 L 15.70 9.69 L 15.57 9.36 L 15.30 9.06 L 14.96 8.88 L 14.58 8.85 L 14.27 8.96 L 14.04 9.19 L 13.88 9.56 L 13.86 9.94 L 13.98 10.31 L 14.21 10.64 L 14.46 10.79 L 14.83 10.81 Z M 12.28 18.18 L 12.96 18.12 L 13.58 17.95 L 14.02 17.77 L 14.71 17.36 L 15.41 17.07 L 15.71 16.86 L 16.59 16.00 L 16.84 15.68 L 17.23 14.81 L 17.64 14.27 L 17.77 14.01 L 17.82 13.69 L 17.82 13.31 L 17.77 13.06 L 17.64 12.88 L 17.27 12.68 L 16.77 12.64 L 16.32 12.80 L 15.77 13.19 L 15.40 13.28 L 14.63 13.21 L 13.63 13.29 L 8.90 13.27 L 8.58 13.21 L 7.08 12.65 L 6.71 12.65 L 6.45 12.81 L 6.32 12.99 L 6.21 13.31 L 6.19 13.56 L 6.24 13.81 L 6.40 14.11 L 6.93 14.76 L 7.26 15.75 L 7.52 16.12 L 8.84 17.12 L 10.40 17.93 L 11.02 18.11 L 12.28 18.18 Z M 13.21 15.06 L 11.77 15.11 L 10.07 14.99 L 9.40 14.88 L 9.11 14.76 L 9.00 14.62 L 9.02 14.56 L 9.13 14.49 L 9.40 14.46 L 12.13 14.38 L 14.90 14.46 L 15.13 14.49 L 15.25 14.56 L 15.17 14.69 L 14.68 14.88 L 13.21 15.06 Z", "M 12.44 21.07 L 13.33 20.96 L 14.27 20.59 L 15.71 20.29 L 16.16 20.12 L 16.82 19.79 L 17.50 19.32 L 18.70 18.18 L 19.57 17.18 L 19.82 16.84 L 20.05 16.38 L 20.50 15.06 L 20.89 14.22 L 21.05 13.76 L 21.20 12.26 L 21.12 10.76 L 21.04 10.12 L 20.89 9.62 L 20.39 8.57 L 20.12 7.62 L 19.89 7.13 L 19.27 6.30 L 18.43 5.38 L 17.96 4.95 L 16.89 4.13 L 15.64 3.46 L 14.83 3.21 L 12.52 2.94 L 11.90 2.94 L 10.46 3.04 L 8.83 3.35 L 8.27 3.53 L 7.77 3.75 L 7.19 4.12 L 6.58 4.67 L 5.50 5.43 L 5.18 5.75 L 4.71 6.57 L 4.18 7.18 L 3.98 7.49 L 3.33 8.89 L 2.99 9.94 L 2.90 10.44 L 2.81 11.69 L 2.91 13.49 L 3.09 14.31 L 4.02 16.41 L 4.62 17.18 L 5.13 18.00 L 6.40 19.14 L 7.52 19.95 L 8.02 20.18 L 9.02 20.41 L 10.63 20.93 L 11.71 21.07 L 12.44 21.07 Z M 13.13 19.50 L 12.33 19.57 L 11.27 19.52 L 10.63 19.45 L 9.96 19.32 L 9.45 19.12 L 8.68 18.62 L 7.83 18.23 L 7.46 18.00 L 6.08 16.62 L 5.21 15.28 L 4.92 14.44 L 4.56 12.69 L 4.51 12.06 L 4.56 11.31 L 4.74 10.26 L 4.99 9.12 L 5.27 8.40 L 5.96 7.40 L 6.21 7.12 L 7.46 5.91 L 8.02 5.46 L 8.63 5.16 L 9.53 4.88 L 10.40 4.46 L 10.77 4.36 L 12.46 4.29 L 13.21 4.36 L 13.58 4.46 L 14.33 4.83 L 15.46 5.17 L 16.14 5.50 L 17.02 6.33 L 17.64 6.88 L 18.32 7.76 L 18.80 8.56 L 19.07 9.12 L 19.41 10.31 L 19.55 10.94 L 19.66 11.99 L 19.64 12.56 L 19.48 13.44 L 19.21 14.40 L 18.89 15.19 L 18.37 15.93 L 17.77 16.93 L 16.82 17.82 L 16.21 18.21 L 15.13 18.75 L 14.27 19.25 L 13.83 19.39 L 13.13 19.50 Z M 9.68 10.88 L 9.92 10.69 L 10.13 10.30 L 10.24 9.94 L 10.21 9.56 L 10.08 9.21 L 9.84 8.94 L 9.58 8.80 L 9.27 8.79 L 8.96 8.94 L 8.60 9.31 L 8.46 9.69 L 8.46 10.06 L 8.62 10.44 L 8.96 10.79 L 9.33 10.94 L 9.68 10.88 Z M 14.83 10.81 L 15.21 10.65 L 15.51 10.38 L 15.68 10.06 L 15.70 9.69 L 15.57 9.36 L 15.30 9.06 L 14.96 8.88 L 14.58 8.85 L 14.27 8.96 L 14.04 9.19 L 13.88 9.56 L 13.86 9.94 L 13.98 10.31 L 14.21 10.64 L 14.46 10.79 L 14.83 10.81 Z M 12.28 18.18 L 12.96 18.12 L 13.58 17.95 L 14.02 17.77 L 14.71 17.36 L 15.41 17.07 L 15.71 16.86 L 16.59 16.00 L 16.84 15.68 L 17.23 14.81 L 17.64 14.27 L 17.77 14.01 L 17.82 13.69 L 17.82 13.31 L 17.77 13.06 L 17.64 12.88 L 17.27 12.68 L 16.77 12.64 L 16.32 12.80 L 15.77 13.19 L 15.40 13.28 L 14.63 13.21 L 13.63 13.29 L 8.90 13.27 L 8.58 13.21 L 7.08 12.65 L 6.71 12.65 L 6.45 12.81 L 6.32 12.99 L 6.21 13.31 L 6.19 13.56 L 6.24 13.81 L 6.40 14.11 L 6.93 14.76 L 7.26 15.75 L 7.52 16.12 L 8.84 17.12 L 10.40 17.93 L 11.02 18.11 L 12.28 18.18 Z M 13.21 15.06 L 11.77 15.11 L 10.07 14.99 L 9.40 14.88 L 9.11 14.76 L 9.00 14.62 L 9.02 14.56 L 9.13 14.49 L 9.40 14.46 L 12.13 14.38 L 14.90 14.46 L 15.13 14.49 L 15.25 14.56 L 15.17 14.69 L 14.68 14.88 L 13.21 15.06 Z", "", "", "", ""},
        {"", "M 12.33 22.21 L 12.81 22.10 L 13.12 21.91 L 14.06 20.88 L 14.67 20.09 L 15.13 19.71 L 15.63 19.52 L 16.81 19.45 L 17.81 19.13 L 19.31 18.23 L 19.89 17.77 L 20.63 16.94 L 20.88 16.51 L 21.09 15.78 L 21.27 14.54 L 21.40 14.21 L 21.72 13.90 L 22.75 13.31 L 22.99 13.09 L 23.16 12.84 L 23.31 12.46 L 23.41 12.04 L 23.45 10.90 L 23.23 9.65 L 22.97 8.77 L 22.77 8.34 L 22.31 7.65 L 21.91 6.84 L 20.68 5.15 L 18.81 3.39 L 17.75 2.78 L 16.06 2.24 L 14.75 2.12 L 13.06 1.77 L 11.19 1.75 L 10.25 1.85 L 8.87 2.16 L 7.94 2.25 L 7.50 2.34 L 5.87 2.92 L 5.13 3.35 L 4.63 3.73 L 3.00 5.46 L 1.64 7.34 L 0.96 8.96 L 0.78 9.54 L 0.56 10.65 L 0.55 11.59 L 0.63 12.34 L 0.81 12.84 L 1.13 13.19 L 2.00 13.80 L 2.31 14.17 L 2.57 14.71 L 2.74 15.65 L 2.84 15.96 L 3.85 17.66 L 4.06 17.89 L 4.81 18.35 L 6.37 19.20 L 7.13 19.41 L 8.49 19.59 L 9.06 19.78 L 9.25 19.91 L 9.42 20.09 L 9.75 20.80 L 9.94 21.09 L 10.83 21.91 L 11.13 22.08 L 11.50 22.20 L 11.87 22.24 L 12.33 22.21 Z M 8.81 17.66 L 7.87 17.66 L 7.44 17.56 L 7.06 17.42 L 5.90 16.77 L 5.54 16.46 L 5.13 16.02 L 4.93 15.71 L 4.75 15.27 L 4.58 14.40 L 4.61 13.54 L 4.73 12.90 L 4.87 12.42 L 5.13 11.84 L 5.43 11.34 L 5.88 10.71 L 6.51 10.04 L 6.74 9.65 L 6.91 8.96 L 6.99 7.46 L 7.09 6.90 L 7.25 6.52 L 7.81 5.59 L 8.15 5.15 L 9.39 4.21 L 9.87 3.95 L 10.31 3.81 L 11.31 3.64 L 12.13 3.60 L 13.31 3.73 L 13.81 3.86 L 14.44 4.17 L 15.31 4.78 L 15.77 5.21 L 16.09 5.65 L 16.56 6.52 L 16.81 7.21 L 16.86 7.90 L 16.75 8.58 L 16.56 8.77 L 16.31 8.76 L 16.06 8.63 L 15.67 8.27 L 15.44 8.14 L 15.00 8.04 L 14.50 8.01 L 14.13 8.06 L 13.81 8.17 L 13.31 8.49 L 12.99 8.77 L 12.75 9.15 L 12.19 10.46 L 12.08 10.90 L 12.02 11.40 L 12.01 12.09 L 12.08 12.71 L 12.62 14.21 L 12.63 14.50 L 12.43 14.65 L 11.69 14.75 L 11.31 14.85 L 11.06 14.98 L 10.89 15.15 L 10.77 15.40 L 10.72 15.71 L 10.86 16.46 L 10.86 16.71 L 10.78 16.96 L 10.56 17.20 L 10.25 17.39 L 9.87 17.55 L 8.81 17.66 Z M 8.73 14.40 L 9.31 14.13 L 9.63 13.77 L 9.74 13.54 L 9.79 13.21 L 9.76 12.46 L 9.58 11.77 L 9.32 11.40 L 8.81 11.16 L 8.25 11.12 L 8.00 11.19 L 7.81 11.31 L 7.47 11.77 L 7.26 12.40 L 7.22 13.15 L 7.30 13.46 L 7.46 13.77 L 7.87 14.29 L 8.25 14.44 L 8.73 14.40 Z M 15.69 17.66 L 14.94 17.66 L 14.13 17.55 L 13.63 17.44 L 13.31 17.23 L 13.06 16.91 L 12.98 16.53 L 13.03 16.21 L 13.28 15.46 L 13.44 15.30 L 13.63 15.27 L 15.25 15.55 L 15.75 15.55 L 16.38 15.38 L 17.31 14.92 L 17.70 14.56 L 18.02 13.90 L 18.18 13.40 L 18.33 12.15 L 18.45 11.90 L 18.56 11.88 L 18.70 12.04 L 19.06 12.80 L 19.23 13.21 L 19.29 13.54 L 19.30 14.59 L 19.16 15.15 L 18.93 15.78 L 18.74 16.09 L 18.45 16.44 L 18.11 16.71 L 17.72 16.96 L 16.63 17.53 L 16.31 17.60 L 15.69 17.66 Z M 12.31 21.09 L 11.94 21.09 L 11.56 21.02 L 11.30 20.91 L 11.13 20.70 L 10.97 20.27 L 10.92 19.77 L 10.99 19.46 L 11.19 19.24 L 11.50 19.13 L 11.94 19.17 L 12.44 19.34 L 12.72 19.59 L 12.86 20.09 L 12.83 20.59 L 12.63 20.95 L 12.31 21.09 Z", "M 12.33 22.21 L 12.81 22.10 L 13.12 21.91 L 14.06 20.88 L 14.67 20.09 L 15.13 19.71 L 15.63 19.52 L 16.81 19.45 L 17.81 19.13 L 19.31 18.23 L 19.89 17.77 L 20.63 16.94 L 20.88 16.51 L 21.09 15.78 L 21.27 14.54 L 21.40 14.21 L 21.72 13.90 L 22.75 13.31 L 22.99 13.09 L 23.16 12.84 L 23.31 12.46 L 23.41 12.04 L 23.45 10.90 L 23.23 9.65 L 22.97 8.77 L 22.77 8.34 L 22.31 7.65 L 21.91 6.84 L 20.68 5.15 L 18.81 3.39 L 17.75 2.78 L 16.06 2.24 L 14.75 2.12 L 13.06 1.77 L 11.19 1.75 L 10.25 1.85 L 8.87 2.16 L 7.94 2.25 L 7.50 2.34 L 5.87 2.92 L 5.13 3.35 L 4.63 3.73 L 3.00 5.46 L 1.64 7.34 L 0.96 8.96 L 0.78 9.54 L 0.56 10.65 L 0.55 11.59 L 0.63 12.34 L 0.81 12.84 L 1.13 13.19 L 2.00 13.80 L 2.31 14.17 L 2.57 14.71 L 2.74 15.65 L 2.84 15.96 L 3.85 17.66 L 4.06 17.89 L 4.81 18.35 L 6.37 19.20 L 7.13 19.41 L 8.49 19.59 L 9.06 19.78 L 9.25 19.91 L 9.42 20.09 L 9.75 20.80 L 9.94 21.09 L 10.83 21.91 L 11.13 22.08 L 11.50 22.20 L 11.87 22.24 L 12.33 22.21 Z M 8.81 17.66 L 7.87 17.66 L 7.44 17.56 L 7.06 17.42 L 5.90 16.77 L 5.54 16.46 L 5.13 16.02 L 4.93 15.71 L 4.75 15.27 L 4.58 14.40 L 4.61 13.54 L 4.73 12.90 L 4.87 12.42 L 5.13 11.84 L 5.43 11.34 L 5.88 10.71 L 6.51 10.04 L 6.74 9.65 L 6.91 8.96 L 6.99 7.46 L 7.09 6.90 L 7.25 6.52 L 7.81 5.59 L 8.15 5.15 L 9.39 4.21 L 9.87 3.95 L 10.31 3.81 L 11.31 3.64 L 12.13 3.60 L 13.31 3.73 L 13.81 3.86 L 14.44 4.17 L 15.31 4.78 L 15.77 5.21 L 16.09 5.65 L 16.56 6.52 L 16.81 7.21 L 16.86 7.90 L 16.75 8.58 L 16.56 8.77 L 16.31 8.76 L 16.06 8.63 L 15.67 8.27 L 15.44 8.14 L 15.00 8.04 L 14.50 8.01 L 14.13 8.06 L 13.81 8.17 L 13.31 8.49 L 12.99 8.77 L 12.75 9.15 L 12.19 10.46 L 12.08 10.90 L 12.02 11.40 L 12.01 12.09 L 12.08 12.71 L 12.62 14.21 L 12.63 14.50 L 12.43 14.65 L 11.69 14.75 L 11.31 14.85 L 11.06 14.98 L 10.89 15.15 L 10.77 15.40 L 10.72 15.71 L 10.86 16.46 L 10.86 16.71 L 10.78 16.96 L 10.56 17.20 L 10.25 17.39 L 9.87 17.55 L 8.81 17.66 Z M 8.73 14.40 L 9.31 14.13 L 9.63 13.77 L 9.74 13.54 L 9.79 13.21 L 9.76 12.46 L 9.58 11.77 L 9.32 11.40 L 8.81 11.16 L 8.25 11.12 L 8.00 11.19 L 7.81 11.31 L 7.47 11.77 L 7.26 12.40 L 7.22 13.15 L 7.30 13.46 L 7.46 13.77 L 7.87 14.29 L 8.25 14.44 L 8.73 14.40 Z M 15.69 17.66 L 14.94 17.66 L 14.13 17.55 L 13.63 17.44 L 13.31 17.23 L 13.06 16.91 L 12.98 16.53 L 13.03 16.21 L 13.28 15.46 L 13.44 15.30 L 13.63 15.27 L 15.25 15.55 L 15.75 15.55 L 16.38 15.38 L 17.31 14.92 L 17.70 14.56 L 18.02 13.90 L 18.18 13.40 L 18.33 12.15 L 18.45 11.90 L 18.56 11.88 L 18.70 12.04 L 19.06 12.80 L 19.23 13.21 L 19.29 13.54 L 19.30 14.59 L 19.16 15.15 L 18.93 15.78 L 18.74 16.09 L 18.45 16.44 L 18.11 16.71 L 17.72 16.96 L 16.63 17.53 L 16.31 17.60 L 15.69 17.66 Z M 12.31 21.09 L 11.94 21.09 L 11.56 21.02 L 11.30 20.91 L 11.13 20.70 L 10.97 20.27 L 10.92 19.77 L 10.99 19.46 L 11.19 19.24 L 11.50 19.13 L 11.94 19.17 L 12.44 19.34 L 12.72 19.59 L 12.86 20.09 L 12.83 20.59 L 12.63 20.95 L 12.31 21.09 Z", "", "", "", ""},
        {"", "M 15.74 22.11 L 16.34 21.93 L 17.38 21.38 L 17.98 20.93 L 18.91 20.04 L 19.64 19.04 L 20.19 17.86 L 20.62 17.11 L 21.38 14.65 L 21.58 13.73 L 21.66 11.79 L 21.59 10.98 L 21.45 10.38 L 20.96 9.23 L 20.69 8.70 L 19.74 7.42 L 19.45 7.13 L 18.26 6.39 L 17.62 6.13 L 17.19 6.04 L 16.56 5.98 L 15.25 6.05 L 15.00 5.98 L 14.78 5.79 L 14.66 5.54 L 14.72 5.23 L 14.93 4.85 L 15.49 4.17 L 15.92 2.85 L 15.96 2.61 L 15.92 2.35 L 15.76 2.11 L 15.56 1.93 L 15.31 1.84 L 15.06 1.85 L 14.45 2.03 L 14.06 2.20 L 13.06 2.95 L 12.18 3.87 L 11.88 4.07 L 11.50 4.17 L 11.25 4.16 L 11.00 4.02 L 10.46 3.17 L 10.06 2.76 L 9.50 2.42 L 9.18 2.40 L 9.00 2.53 L 8.88 2.75 L 8.83 3.04 L 8.88 3.35 L 9.12 3.80 L 9.95 4.48 L 10.30 4.92 L 10.38 5.17 L 10.38 5.48 L 10.31 5.73 L 10.18 5.95 L 9.95 6.12 L 9.62 6.18 L 9.31 6.17 L 8.45 6.00 L 7.95 5.97 L 6.56 6.03 L 6.25 6.09 L 5.94 6.22 L 4.68 6.95 L 4.36 7.23 L 3.70 7.98 L 3.31 8.79 L 2.75 9.72 L 2.57 10.17 L 2.46 10.67 L 2.33 12.12 L 2.41 13.79 L 2.77 15.42 L 3.22 16.48 L 3.48 17.54 L 3.62 17.95 L 3.81 18.27 L 4.26 18.79 L 4.62 19.57 L 4.81 19.86 L 5.64 20.79 L 5.92 21.04 L 7.62 21.97 L 8.06 22.11 L 8.50 22.11 L 9.31 21.95 L 9.95 21.68 L 10.62 21.46 L 11.31 21.34 L 11.95 21.29 L 12.81 21.38 L 13.56 21.54 L 15.12 22.12 L 15.38 22.16 L 15.74 22.11 Z M 15.62 20.36 L 15.25 20.38 L 13.50 20.04 L 11.81 19.86 L 10.56 20.00 L 8.50 20.36 L 8.12 20.36 L 7.50 20.20 L 6.87 19.95 L 5.92 19.04 L 5.14 17.79 L 4.79 16.98 L 3.94 14.04 L 3.78 12.62 L 3.81 11.62 L 4.03 10.48 L 4.71 9.04 L 4.94 8.72 L 5.23 8.42 L 5.75 8.07 L 6.50 7.70 L 6.94 7.52 L 7.37 7.44 L 7.81 7.44 L 8.25 7.51 L 9.56 7.92 L 10.18 8.06 L 11.95 8.20 L 12.68 8.16 L 13.88 8.01 L 14.65 7.85 L 15.50 7.54 L 16.56 7.46 L 17.19 7.59 L 18.26 8.14 L 18.56 8.39 L 19.31 9.18 L 19.56 9.54 L 19.73 9.98 L 19.91 10.92 L 19.95 11.67 L 19.95 12.92 L 19.84 14.17 L 19.70 15.23 L 19.52 15.93 L 18.63 17.98 L 18.51 18.18 L 18.05 18.68 L 17.56 19.52 L 17.26 19.77 L 16.62 20.12 L 16.19 20.27 L 15.62 20.36 Z", "M 15.74 22.11 L 16.34 21.93 L 17.38 21.38 L 17.98 20.93 L 18.91 20.04 L 19.64 19.04 L 20.19 17.86 L 20.62 17.11 L 21.38 14.65 L 21.58 13.73 L 21.66 11.79 L 21.59 10.98 L 21.45 10.38 L 20.96 9.23 L 20.69 8.70 L 19.74 7.42 L 19.45 7.13 L 18.26 6.39 L 17.62 6.13 L 17.19 6.04 L 16.56 5.98 L 15.25 6.05 L 15.00 5.98 L 14.78 5.79 L 14.66 5.54 L 14.72 5.23 L 14.93 4.85 L 15.49 4.17 L 15.92 2.85 L 15.96 2.61 L 15.92 2.35 L 15.76 2.11 L 15.56 1.93 L 15.31 1.84 L 15.06 1.85 L 14.45 2.03 L 14.06 2.20 L 13.06 2.95 L 12.18 3.87 L 11.88 4.07 L 11.50 4.17 L 11.25 4.16 L 11.00 4.02 L 10.46 3.17 L 10.06 2.76 L 9.50 2.42 L 9.18 2.40 L 9.00 2.53 L 8.88 2.75 L 8.83 3.04 L 8.88 3.35 L 9.12 3.80 L 9.95 4.48 L 10.30 4.92 L 10.38 5.17 L 10.38 5.48 L 10.31 5.73 L 10.18 5.95 L 9.95 6.12 L 9.62 6.18 L 9.31 6.17 L 8.45 6.00 L 7.95 5.97 L 6.56 6.03 L 6.25 6.09 L 5.94 6.22 L 4.68 6.95 L 4.36 7.23 L 3.70 7.98 L 3.31 8.79 L 2.75 9.72 L 2.57 10.17 L 2.46 10.67 L 2.33 12.12 L 2.41 13.79 L 2.77 15.42 L 3.22 16.48 L 3.48 17.54 L 3.62 17.95 L 3.81 18.27 L 4.26 18.79 L 4.62 19.57 L 4.81 19.86 L 5.64 20.79 L 5.92 21.04 L 7.62 21.97 L 8.06 22.11 L 8.50 22.11 L 9.31 21.95 L 9.95 21.68 L 10.62 21.46 L 11.31 21.34 L 11.95 21.29 L 12.81 21.38 L 13.56 21.54 L 15.12 22.12 L 15.38 22.16 L 15.74 22.11 Z M 15.62 20.36 L 15.25 20.38 L 13.50 20.04 L 11.81 19.86 L 10.56 20.00 L 8.50 20.36 L 8.12 20.36 L 7.50 20.20 L 6.87 19.95 L 5.92 19.04 L 5.14 17.79 L 4.79 16.98 L 3.94 14.04 L 3.78 12.62 L 3.81 11.62 L 4.03 10.48 L 4.71 9.04 L 4.94 8.72 L 5.23 8.42 L 5.75 8.07 L 6.50 7.70 L 6.94 7.52 L 7.37 7.44 L 7.81 7.44 L 8.25 7.51 L 9.56 7.92 L 10.18 8.06 L 11.95 8.20 L 12.68 8.16 L 13.88 8.01 L 14.65 7.85 L 15.50 7.54 L 16.56 7.46 L 17.19 7.59 L 18.26 8.14 L 18.56 8.39 L 19.31 9.18 L 19.56 9.54 L 19.73 9.98 L 19.91 10.92 L 19.95 11.67 L 19.95 12.92 L 19.84 14.17 L 19.70 15.23 L 19.52 15.93 L 18.63 17.98 L 18.51 18.18 L 18.05 18.68 L 17.56 19.52 L 17.26 19.77 L 16.62 20.12 L 16.19 20.27 L 15.62 20.36 Z", "", "", "", ""},
        {"", "M 12.72 21.06 L 13.60 20.90 L 14.81 20.49 L 15.84 20.23 L 16.34 20.01 L 17.21 19.47 L 17.68 19.12 L 18.82 18.06 L 19.61 17.12 L 20.75 14.99 L 20.91 14.60 L 21.02 14.12 L 21.11 13.37 L 21.18 11.68 L 21.11 10.37 L 21.00 9.62 L 20.73 8.75 L 20.27 8.09 L 19.91 7.16 L 19.59 6.69 L 18.46 5.40 L 17.41 4.65 L 16.84 4.11 L 16.16 3.71 L 15.56 3.43 L 14.96 3.24 L 12.96 2.96 L 11.96 2.93 L 10.83 3.01 L 9.08 3.25 L 8.03 3.66 L 7.52 3.91 L 5.96 5.00 L 5.08 5.93 L 4.46 6.78 L 3.83 7.54 L 3.03 9.87 L 2.90 10.52 L 2.81 11.75 L 3.00 13.99 L 3.38 14.87 L 3.71 15.97 L 3.96 16.44 L 5.18 18.06 L 5.98 18.75 L 6.71 19.45 L 8.10 20.17 L 10.40 20.86 L 10.99 20.99 L 11.60 21.07 L 12.72 21.06 Z M 14.90 18.62 L 12.60 18.31 L 12.15 18.17 L 11.96 18.06 L 11.78 17.84 L 11.46 17.05 L 11.33 16.88 L 11.21 17.00 L 10.78 17.77 L 10.60 17.96 L 10.33 18.11 L 9.96 18.25 L 9.53 18.34 L 8.60 18.43 L 8.28 18.40 L 7.90 18.23 L 7.41 17.90 L 6.38 16.99 L 6.02 16.50 L 5.75 15.87 L 5.62 15.37 L 5.56 14.87 L 5.66 13.62 L 5.62 13.37 L 5.52 13.20 L 5.16 12.84 L 4.91 12.50 L 4.66 11.93 L 4.55 11.49 L 4.54 11.06 L 4.70 10.12 L 4.91 9.31 L 5.27 8.62 L 5.91 7.81 L 6.16 7.55 L 6.52 7.37 L 7.46 7.25 L 7.71 7.12 L 7.80 6.93 L 8.05 5.99 L 8.35 5.56 L 9.10 5.03 L 10.21 4.55 L 10.71 4.43 L 11.78 4.28 L 12.28 4.35 L 12.77 4.56 L 13.46 4.99 L 13.80 5.31 L 13.97 5.62 L 14.13 6.31 L 14.28 6.49 L 14.53 6.51 L 15.21 6.35 L 15.77 6.41 L 16.20 6.56 L 16.91 6.94 L 17.66 7.24 L 17.96 7.43 L 18.18 7.62 L 18.39 7.93 L 19.14 9.37 L 19.20 9.68 L 19.18 10.06 L 19.02 10.49 L 18.79 10.93 L 18.16 11.87 L 17.84 12.25 L 17.52 12.51 L 17.02 12.75 L 16.89 12.87 L 16.91 13.06 L 17.18 13.62 L 17.32 14.18 L 17.41 15.25 L 17.62 16.31 L 17.61 16.68 L 17.54 16.93 L 16.77 17.83 L 16.46 18.09 L 15.71 18.45 L 14.90 18.62 Z M 11.29 15.43 L 11.46 15.31 L 11.81 14.68 L 12.03 14.43 L 12.65 14.02 L 13.33 13.45 L 14.04 12.99 L 14.63 12.43 L 14.75 12.25 L 14.78 12.06 L 14.71 11.81 L 14.28 11.17 L 14.12 10.81 L 13.94 9.87 L 13.49 8.68 L 13.31 7.68 L 13.21 7.55 L 13.03 7.52 L 12.40 7.69 L 11.40 7.87 L 9.33 8.06 L 8.89 7.99 L 8.40 7.64 L 8.24 7.62 L 8.14 7.75 L 8.04 8.93 L 7.67 10.43 L 7.42 11.06 L 7.23 11.68 L 6.84 12.43 L 6.83 12.68 L 7.02 12.87 L 8.35 13.43 L 9.10 14.08 L 9.88 14.56 L 10.60 15.13 L 11.10 15.40 L 11.29 15.43 Z", "M 12.72 21.06 L 13.60 20.90 L 14.81 20.49 L 15.84 20.23 L 16.34 20.01 L 17.21 19.47 L 17.68 19.12 L 18.82 18.06 L 19.61 17.12 L 20.75 14.99 L 20.91 14.60 L 21.02 14.12 L 21.11 13.37 L 21.18 11.68 L 21.11 10.37 L 21.00 9.62 L 20.73 8.75 L 20.27 8.09 L 19.91 7.16 L 19.59 6.69 L 18.46 5.40 L 17.41 4.65 L 16.84 4.11 L 16.16 3.71 L 15.56 3.43 L 14.96 3.24 L 12.96 2.96 L 11.96 2.93 L 10.83 3.01 L 9.08 3.25 L 8.03 3.66 L 7.52 3.91 L 5.96 5.00 L 5.08 5.93 L 4.46 6.78 L 3.83 7.54 L 3.03 9.87 L 2.90 10.52 L 2.81 11.75 L 3.00 13.99 L 3.38 14.87 L 3.71 15.97 L 3.96 16.44 L 5.18 18.06 L 5.98 18.75 L 6.71 19.45 L 8.10 20.17 L 10.40 20.86 L 10.99 20.99 L 11.60 21.07 L 12.72 21.06 Z M 14.90 18.62 L 12.60 18.31 L 12.15 18.17 L 11.96 18.06 L 11.78 17.84 L 11.46 17.05 L 11.33 16.88 L 11.21 17.00 L 10.78 17.77 L 10.60 17.96 L 10.33 18.11 L 9.96 18.25 L 9.53 18.34 L 8.60 18.43 L 8.28 18.40 L 7.90 18.23 L 7.41 17.90 L 6.38 16.99 L 6.02 16.50 L 5.75 15.87 L 5.62 15.37 L 5.56 14.87 L 5.66 13.62 L 5.62 13.37 L 5.52 13.20 L 5.16 12.84 L 4.91 12.50 L 4.66 11.93 L 4.55 11.49 L 4.54 11.06 L 4.70 10.12 L 4.91 9.31 L 5.27 8.62 L 5.91 7.81 L 6.16 7.55 L 6.52 7.37 L 7.46 7.25 L 7.71 7.12 L 7.80 6.93 L 8.05 5.99 L 8.35 5.56 L 9.10 5.03 L 10.21 4.55 L 10.71 4.43 L 11.78 4.28 L 12.28 4.35 L 12.77 4.56 L 13.46 4.99 L 13.80 5.31 L 13.97 5.62 L 14.13 6.31 L 14.28 6.49 L 14.53 6.51 L 15.21 6.35 L 15.77 6.41 L 16.20 6.56 L 16.91 6.94 L 17.66 7.24 L 17.96 7.43 L 18.18 7.62 L 18.39 7.93 L 19.14 9.37 L 19.20 9.68 L 19.18 10.06 L 19.02 10.49 L 18.79 10.93 L 18.16 11.87 L 17.84 12.25 L 17.52 12.51 L 17.02 12.75 L 16.89 12.87 L 16.91 13.06 L 17.18 13.62 L 17.32 14.18 L 17.41 15.25 L 17.62 16.31 L 17.61 16.68 L 17.54 16.93 L 16.77 17.83 L 16.46 18.09 L 15.71 18.45 L 14.90 18.62 Z M 11.29 15.43 L 11.46 15.31 L 11.81 14.68 L 12.03 14.43 L 12.65 14.02 L 13.33 13.45 L 14.04 12.99 L 14.63 12.43 L 14.75 12.25 L 14.78 12.06 L 14.71 11.81 L 14.28 11.17 L 14.12 10.81 L 13.94 9.87 L 13.49 8.68 L 13.31 7.68 L 13.21 7.55 L 13.03 7.52 L 12.40 7.69 L 11.40 7.87 L 9.33 8.06 L 8.89 7.99 L 8.40 7.64 L 8.24 7.62 L 8.14 7.75 L 8.04 8.93 L 7.67 10.43 L 7.42 11.06 L 7.23 11.68 L 6.84 12.43 L 6.83 12.68 L 7.02 12.87 L 8.35 13.43 L 9.10 14.08 L 9.88 14.56 L 10.60 15.13 L 11.10 15.40 L 11.29 15.43 Z", "", "", "", ""},
        {"", "M 19.41 20.99 L 20.12 20.76 L 20.88 20.18 L 21.20 20.02 L 21.76 19.90 L 23.12 19.82 L 23.48 19.68 L 24.13 19.30 L 24.42 18.99 L 24.59 18.61 L 24.66 18.05 L 24.70 16.87 L 24.62 16.31 L 24.24 15.30 L 24.10 14.74 L 24.06 14.11 L 24.10 12.68 L 24.06 11.99 L 23.84 10.93 L 23.59 10.11 L 22.73 8.37 L 21.94 7.11 L 21.51 6.25 L 21.06 5.67 L 20.62 4.93 L 20.05 4.30 L 19.98 4.11 L 19.92 3.61 L 19.85 3.43 L 19.74 3.30 L 19.56 3.23 L 18.76 3.20 L 17.44 3.04 L 16.12 2.95 L 14.00 2.97 L 12.93 3.09 L 12.06 3.27 L 11.20 3.52 L 10.81 3.70 L 9.10 4.99 L 8.78 5.30 L 8.20 6.14 L 7.62 6.80 L 7.25 7.62 L 6.62 8.23 L 6.12 9.10 L 5.84 9.43 L 5.43 9.71 L 4.43 10.09 L 3.93 10.40 L 2.71 10.99 L 2.00 11.54 L 1.25 12.26 L 0.75 12.87 L 0.52 13.24 L 0.26 14.05 L -0.01 15.11 L -0.50 16.02 L -0.63 16.37 L -0.71 17.18 L -0.65 18.37 L -0.52 18.87 L -0.29 19.18 L 0.17 19.49 L 0.87 19.81 L 2.06 19.92 L 2.75 20.08 L 3.08 20.24 L 3.81 20.74 L 4.31 20.93 L 5.25 21.05 L 5.93 20.96 L 6.50 20.73 L 7.50 20.07 L 7.81 19.96 L 8.25 19.89 L 9.25 19.84 L 15.06 19.84 L 15.81 19.89 L 16.38 20.03 L 16.67 20.18 L 17.52 20.74 L 18.01 20.94 L 18.70 21.04 L 19.41 20.99 Z M 9.93 18.56 L 9.56 18.58 L 9.25 18.54 L 8.93 18.42 L 8.70 18.26 L 8.26 17.74 L 7.83 16.93 L 7.62 16.37 L 7.37 16.03 L 7.00 15.72 L 6.31 15.32 L 5.93 15.14 L 5.56 15.05 L 4.93 15.03 L 4.25 15.21 L 3.87 15.40 L 2.76 16.11 L 2.59 16.30 L 2.47 16.55 L 2.28 17.43 L 2.14 17.80 L 2.00 18.03 L 1.81 18.17 L 1.62 18.22 L 1.43 18.19 L 1.06 17.98 L 0.80 17.61 L 0.73 17.37 L 0.74 17.18 L 1.56 15.07 L 1.76 14.68 L 2.14 14.24 L 2.87 13.78 L 3.14 13.55 L 3.34 13.24 L 3.64 12.49 L 3.85 12.18 L 4.37 11.81 L 6.19 10.95 L 6.53 10.74 L 7.26 9.99 L 7.75 9.17 L 8.00 8.94 L 8.12 8.91 L 8.25 8.99 L 8.46 9.93 L 8.64 10.37 L 8.93 10.61 L 9.31 10.72 L 10.00 10.76 L 12.20 10.71 L 17.44 10.74 L 18.01 10.67 L 18.38 10.50 L 18.59 10.30 L 18.76 10.05 L 18.88 9.74 L 18.95 9.37 L 18.91 8.74 L 18.62 7.24 L 18.45 6.68 L 18.26 6.30 L 18.02 6.05 L 17.28 5.43 L 17.14 5.24 L 17.09 5.05 L 17.16 4.93 L 17.31 4.82 L 17.76 4.74 L 18.31 4.80 L 18.73 4.99 L 19.05 5.24 L 19.31 5.53 L 19.88 6.44 L 20.49 7.18 L 20.91 8.05 L 21.48 8.87 L 21.88 9.87 L 22.23 10.55 L 22.26 10.87 L 21.99 11.87 L 21.95 12.43 L 22.06 12.80 L 22.51 13.43 L 22.69 14.05 L 22.77 15.55 L 23.24 17.05 L 23.23 17.37 L 23.09 17.68 L 22.88 17.92 L 22.62 18.10 L 22.38 18.16 L 22.12 18.09 L 21.88 17.80 L 21.41 16.55 L 21.26 16.30 L 21.08 16.11 L 19.88 15.29 L 19.20 15.07 L 18.62 15.03 L 18.26 15.10 L 17.88 15.25 L 17.20 15.60 L 16.81 15.88 L 16.51 16.24 L 16.12 17.02 L 15.62 17.80 L 15.25 18.19 L 14.88 18.41 L 14.56 18.50 L 14.20 18.54 L 11.12 18.50 L 9.93 18.56 Z M 11.06 5.93 L 10.81 5.98 L 10.75 5.98 L 10.74 5.93 L 10.93 5.30 L 11.00 5.18 L 11.18 5.05 L 11.76 4.93 L 12.56 4.84 L 12.88 4.90 L 13.06 5.05 L 13.03 5.24 L 12.70 5.45 L 11.06 5.93 Z M 8.81 8.38 L 8.62 8.39 L 8.58 8.30 L 8.59 8.18 L 9.04 7.37 L 9.62 6.87 L 9.88 6.37 L 10.00 6.23 L 10.31 6.08 L 10.67 6.05 L 10.53 6.43 L 10.29 6.80 L 9.60 7.49 L 9.06 8.22 L 8.81 8.38 Z M 11.06 16.61 L 11.54 16.49 L 11.62 16.43 L 11.29 16.30 L 10.75 16.22 L 10.38 16.25 L 10.12 16.37 L 10.16 16.49 L 10.43 16.60 L 11.06 16.61 Z M 13.98 16.61 L 14.15 16.49 L 14.16 16.37 L 14.07 16.24 L 13.88 16.19 L 12.50 16.29 L 12.00 16.43 L 12.10 16.49 L 12.43 16.56 L 13.75 16.64 L 13.98 16.61 Z M 19.12 19.49 L 18.62 19.50 L 18.20 19.33 L 17.74 18.93 L 17.60 18.68 L 17.53 18.43 L 17.53 17.80 L 17.70 17.30 L 18.06 16.96 L 18.62 16.74 L 19.06 16.77 L 19.56 17.04 L 19.95 17.37 L 20.16 17.80 L 20.16 18.30 L 19.99 18.74 L 19.56 19.27 L 19.38 19.40 L 19.12 19.49 Z M 5.50 19.50 L 4.93 19.50 L 4.50 19.32 L 4.00 18.90 L 3.74 18.37 L 3.71 17.87 L 3.89 17.43 L 4.25 17.05 L 4.75 16.81 L 5.31 16.74 L 5.81 16.87 L 6.22 17.18 L 6.43 17.61 L 6.48 18.24 L 6.36 18.80 L 6.21 19.05 L 6.00 19.27 L 5.75 19.42 L 5.50 19.50 Z", "M 19.41 20.99 L 20.12 20.76 L 20.88 20.18 L 21.20 20.02 L 21.76 19.90 L 23.12 19.82 L 23.48 19.68 L 24.13 19.30 L 24.42 18.99 L 24.59 18.61 L 24.66 18.05 L 24.70 16.87 L 24.62 16.31 L 24.24 15.30 L 24.10 14.74 L 24.06 14.11 L 24.10 12.68 L 24.06 11.99 L 23.84 10.93 L 23.59 10.11 L 22.73 8.37 L 21.94 7.11 L 21.51 6.25 L 21.06 5.67 L 20.62 4.93 L 20.05 4.30 L 19.98 4.11 L 19.92 3.61 L 19.85 3.43 L 19.74 3.30 L 19.56 3.23 L 18.76 3.20 L 17.44 3.04 L 16.12 2.95 L 14.00 2.97 L 12.93 3.09 L 12.06 3.27 L 11.20 3.52 L 10.81 3.70 L 9.10 4.99 L 8.78 5.30 L 8.20 6.14 L 7.62 6.80 L 7.25 7.62 L 6.62 8.23 L 6.12 9.10 L 5.84 9.43 L 5.43 9.71 L 4.43 10.09 L 3.93 10.40 L 2.71 10.99 L 2.00 11.54 L 1.25 12.26 L 0.75 12.87 L 0.52 13.24 L 0.26 14.05 L -0.01 15.11 L -0.50 16.02 L -0.63 16.37 L -0.71 17.18 L -0.65 18.37 L -0.52 18.87 L -0.29 19.18 L 0.17 19.49 L 0.87 19.81 L 2.06 19.92 L 2.75 20.08 L 3.08 20.24 L 3.81 20.74 L 4.31 20.93 L 5.25 21.05 L 5.93 20.96 L 6.50 20.73 L 7.50 20.07 L 7.81 19.96 L 8.25 19.89 L 9.25 19.84 L 15.06 19.84 L 15.81 19.89 L 16.38 20.03 L 16.67 20.18 L 17.52 20.74 L 18.01 20.94 L 18.70 21.04 L 19.41 20.99 Z M 9.93 18.56 L 9.56 18.58 L 9.25 18.54 L 8.93 18.42 L 8.70 18.26 L 8.26 17.74 L 7.83 16.93 L 7.62 16.37 L 7.37 16.03 L 7.00 15.72 L 6.31 15.32 L 5.93 15.14 L 5.56 15.05 L 4.93 15.03 L 4.25 15.21 L 3.87 15.40 L 2.76 16.11 L 2.59 16.30 L 2.47 16.55 L 2.28 17.43 L 2.14 17.80 L 2.00 18.03 L 1.81 18.17 L 1.62 18.22 L 1.43 18.19 L 1.06 17.98 L 0.80 17.61 L 0.73 17.37 L 0.74 17.18 L 1.56 15.07 L 1.76 14.68 L 2.14 14.24 L 2.87 13.78 L 3.14 13.55 L 3.34 13.24 L 3.64 12.49 L 3.85 12.18 L 4.37 11.81 L 6.19 10.95 L 6.53 10.74 L 7.26 9.99 L 7.75 9.17 L 8.00 8.94 L 8.12 8.91 L 8.25 8.99 L 8.46 9.93 L 8.64 10.37 L 8.93 10.61 L 9.31 10.72 L 10.00 10.76 L 12.20 10.71 L 17.44 10.74 L 18.01 10.67 L 18.38 10.50 L 18.59 10.30 L 18.76 10.05 L 18.88 9.74 L 18.95 9.37 L 18.91 8.74 L 18.62 7.24 L 18.45 6.68 L 18.26 6.30 L 18.02 6.05 L 17.28 5.43 L 17.14 5.24 L 17.09 5.05 L 17.16 4.93 L 17.31 4.82 L 17.76 4.74 L 18.31 4.80 L 18.73 4.99 L 19.05 5.24 L 19.31 5.53 L 19.88 6.44 L 20.49 7.18 L 20.91 8.05 L 21.48 8.87 L 21.88 9.87 L 22.23 10.55 L 22.26 10.87 L 21.99 11.87 L 21.95 12.43 L 22.06 12.80 L 22.51 13.43 L 22.69 14.05 L 22.77 15.55 L 23.24 17.05 L 23.23 17.37 L 23.09 17.68 L 22.88 17.92 L 22.62 18.10 L 22.38 18.16 L 22.12 18.09 L 21.88 17.80 L 21.41 16.55 L 21.26 16.30 L 21.08 16.11 L 19.88 15.29 L 19.20 15.07 L 18.62 15.03 L 18.26 15.10 L 17.88 15.25 L 17.20 15.60 L 16.81 15.88 L 16.51 16.24 L 16.12 17.02 L 15.62 17.80 L 15.25 18.19 L 14.88 18.41 L 14.56 18.50 L 14.20 18.54 L 11.12 18.50 L 9.93 18.56 Z M 11.06 5.93 L 10.81 5.98 L 10.75 5.98 L 10.74 5.93 L 10.93 5.30 L 11.00 5.18 L 11.18 5.05 L 11.76 4.93 L 12.56 4.84 L 12.88 4.90 L 13.06 5.05 L 13.03 5.24 L 12.70 5.45 L 11.06 5.93 Z M 8.81 8.38 L 8.62 8.39 L 8.58 8.30 L 8.59 8.18 L 9.04 7.37 L 9.62 6.87 L 9.88 6.37 L 10.00 6.23 L 10.31 6.08 L 10.67 6.05 L 10.53 6.43 L 10.29 6.80 L 9.60 7.49 L 9.06 8.22 L 8.81 8.38 Z M 11.06 16.61 L 11.54 16.49 L 11.62 16.43 L 11.29 16.30 L 10.75 16.22 L 10.38 16.25 L 10.12 16.37 L 10.16 16.49 L 10.43 16.60 L 11.06 16.61 Z M 13.98 16.61 L 14.15 16.49 L 14.16 16.37 L 14.07 16.24 L 13.88 16.19 L 12.50 16.29 L 12.00 16.43 L 12.10 16.49 L 12.43 16.56 L 13.75 16.64 L 13.98 16.61 Z M 19.12 19.49 L 18.62 19.50 L 18.20 19.33 L 17.74 18.93 L 17.60 18.68 L 17.53 18.43 L 17.53 17.80 L 17.70 17.30 L 18.06 16.96 L 18.62 16.74 L 19.06 16.77 L 19.56 17.04 L 19.95 17.37 L 20.16 17.80 L 20.16 18.30 L 19.99 18.74 L 19.56 19.27 L 19.38 19.40 L 19.12 19.49 Z M 5.50 19.50 L 4.93 19.50 L 4.50 19.32 L 4.00 18.90 L 3.74 18.37 L 3.71 17.87 L 3.89 17.43 L 4.25 17.05 L 4.75 16.81 L 5.31 16.74 L 5.81 16.87 L 6.22 17.18 L 6.43 17.61 L 6.48 18.24 L 6.36 18.80 L 6.21 19.05 L 6.00 19.27 L 5.75 19.42 L 5.50 19.50 Z", "", "", "", ""},
        {"", "M 12.70 18.64 L 13.21 18.53 L 13.96 18.58 L 14.27 18.50 L 14.90 17.93 L 15.46 17.12 L 15.71 16.33 L 15.91 14.39 L 16.05 13.76 L 16.75 12.14 L 17.71 9.45 L 17.86 8.64 L 17.91 7.14 L 17.84 5.70 L 17.71 5.02 L 17.32 4.20 L 16.62 3.33 L 15.79 2.76 L 15.07 2.20 L 14.71 2.01 L 14.21 1.86 L 13.52 1.73 L 12.77 1.62 L 12.21 1.61 L 10.33 1.77 L 9.52 1.96 L 9.17 2.14 L 7.96 2.95 L 7.21 3.63 L 6.80 4.14 L 6.53 4.83 L 6.18 6.26 L 6.09 7.45 L 6.24 8.58 L 6.76 10.64 L 6.91 11.02 L 7.30 11.64 L 7.50 12.14 L 7.88 13.83 L 8.30 15.14 L 8.61 16.70 L 9.09 17.83 L 9.27 18.09 L 9.46 18.25 L 9.77 18.42 L 10.02 18.51 L 10.58 18.60 L 11.40 18.55 L 12.21 18.70 L 12.70 18.64 Z M 13.13 16.40 L 11.71 16.37 L 10.71 16.27 L 10.27 16.14 L 9.99 15.89 L 9.79 15.39 L 9.65 14.45 L 9.42 13.33 L 8.85 11.45 L 8.62 10.83 L 7.99 9.58 L 7.74 8.52 L 7.58 7.39 L 7.59 6.76 L 7.74 5.64 L 8.01 4.95 L 8.21 4.68 L 8.83 4.06 L 9.46 3.57 L 10.02 3.31 L 10.96 3.11 L 11.83 3.03 L 13.27 3.09 L 13.95 3.26 L 14.77 3.66 L 15.27 3.98 L 15.55 4.26 L 15.91 4.95 L 16.46 5.70 L 16.59 6.02 L 16.68 6.39 L 16.75 7.33 L 16.62 8.20 L 16.46 8.58 L 16.00 9.39 L 15.57 10.89 L 14.96 12.43 L 14.27 15.52 L 14.15 15.76 L 13.96 15.96 L 13.46 16.29 L 13.13 16.40 Z M 12.43 22.39 L 12.90 22.34 L 13.33 22.22 L 13.71 22.04 L 13.92 21.83 L 14.00 21.64 L 14.04 21.39 L 13.96 20.76 L 14.00 20.52 L 14.11 20.33 L 14.57 19.89 L 14.69 19.64 L 14.67 19.39 L 14.54 19.20 L 14.33 19.04 L 14.08 18.95 L 13.27 19.03 L 12.27 18.90 L 11.40 18.99 L 10.46 18.95 L 9.96 19.06 L 9.63 19.24 L 9.48 19.45 L 9.44 19.70 L 9.55 19.95 L 10.00 20.33 L 10.13 20.52 L 10.16 20.70 L 10.05 21.39 L 10.11 21.64 L 10.21 21.83 L 10.52 22.06 L 11.13 22.29 L 11.77 22.39 L 12.43 22.39 Z", "M 12.70 18.64 L 13.21 18.53 L 13.96 18.58 L 14.27 18.50 L 14.90 17.93 L 15.46 17.12 L 15.71 16.33 L 15.91 14.39 L 16.05 13.76 L 16.75 12.14 L 17.71 9.45 L 17.86 8.64 L 17.91 7.14 L 17.84 5.70 L 17.71 5.02 L 17.32 4.20 L 16.62 3.33 L 15.79 2.76 L 15.07 2.20 L 14.71 2.01 L 14.21 1.86 L 13.52 1.73 L 12.77 1.62 L 12.21 1.61 L 10.33 1.77 L 9.52 1.96 L 9.17 2.14 L 7.96 2.95 L 7.21 3.63 L 6.80 4.14 L 6.53 4.83 L 6.18 6.26 L 6.09 7.45 L 6.24 8.58 L 6.76 10.64 L 6.91 11.02 L 7.30 11.64 L 7.50 12.14 L 7.88 13.83 L 8.30 15.14 L 8.61 16.70 L 9.09 17.83 L 9.27 18.09 L 9.46 18.25 L 9.77 18.42 L 10.02 18.51 L 10.58 18.60 L 11.40 18.55 L 12.21 18.70 L 12.70 18.64 Z M 13.13 16.40 L 11.71 16.37 L 10.71 16.27 L 10.27 16.14 L 9.99 15.89 L 9.79 15.39 L 9.65 14.45 L 9.42 13.33 L 8.85 11.45 L 8.62 10.83 L 7.99 9.58 L 7.74 8.52 L 7.58 7.39 L 7.59 6.76 L 7.74 5.64 L 8.01 4.95 L 8.21 4.68 L 8.83 4.06 L 9.46 3.57 L 10.02 3.31 L 10.96 3.11 L 11.83 3.03 L 13.27 3.09 L 13.95 3.26 L 14.77 3.66 L 15.27 3.98 L 15.55 4.26 L 15.91 4.95 L 16.46 5.70 L 16.59 6.02 L 16.68 6.39 L 16.75 7.33 L 16.62 8.20 L 16.46 8.58 L 16.00 9.39 L 15.57 10.89 L 14.96 12.43 L 14.27 15.52 L 14.15 15.76 L 13.96 15.96 L 13.46 16.29 L 13.13 16.40 Z M 12.43 22.39 L 12.90 22.34 L 13.33 22.22 L 13.71 22.04 L 13.92 21.83 L 14.00 21.64 L 14.04 21.39 L 13.96 20.76 L 14.00 20.52 L 14.11 20.33 L 14.57 19.89 L 14.69 19.64 L 14.67 19.39 L 14.54 19.20 L 14.33 19.04 L 14.08 18.95 L 13.27 19.03 L 12.27 18.90 L 11.40 18.99 L 10.46 18.95 L 9.96 19.06 L 9.63 19.24 L 9.48 19.45 L 9.44 19.70 L 9.55 19.95 L 10.00 20.33 L 10.13 20.52 L 10.16 20.70 L 10.05 21.39 L 10.11 21.64 L 10.21 21.83 L 10.52 22.06 L 11.13 22.29 L 11.77 22.39 L 12.43 22.39 Z", "", "", "", ""},
        {"", "M 12.00 20.95 L 12.41 20.73 L 13.66 19.80 L 13.96 19.52 L 14.48 18.88 L 15.16 18.27 L 15.72 17.55 L 16.31 17.02 L 17.21 16.02 L 17.66 15.38 L 18.23 14.79 L 18.73 14.05 L 19.25 13.51 L 19.48 13.21 L 20.41 11.38 L 20.98 8.94 L 21.02 8.26 L 20.99 7.57 L 20.56 5.70 L 20.30 5.18 L 19.23 3.94 L 18.85 3.66 L 18.23 3.33 L 17.60 3.12 L 15.66 3.07 L 15.10 3.13 L 14.35 3.28 L 13.91 3.45 L 13.04 3.99 L 12.72 4.22 L 12.22 4.72 L 12.04 4.83 L 11.85 4.87 L 11.60 4.76 L 11.04 4.17 L 10.29 3.63 L 9.79 3.35 L 9.29 3.17 L 8.66 3.07 L 7.54 3.05 L 6.72 3.11 L 5.72 3.28 L 5.10 3.64 L 4.43 4.20 L 4.25 4.44 L 3.94 5.07 L 3.54 5.53 L 3.39 5.82 L 3.07 6.94 L 2.97 7.94 L 3.05 9.38 L 3.34 10.51 L 3.90 11.63 L 4.41 13.14 L 4.70 13.63 L 5.79 14.93 L 7.65 17.02 L 8.48 17.88 L 9.27 18.57 L 10.11 19.63 L 11.50 20.82 L 11.72 20.95 L 12.00 20.95 Z M 11.91 18.77 L 11.79 18.77 L 11.60 18.68 L 10.64 17.88 L 10.16 17.27 L 8.57 15.57 L 6.66 13.38 L 5.71 11.94 L 5.25 11.13 L 4.73 10.07 L 4.51 9.44 L 4.43 8.76 L 4.42 7.63 L 4.49 7.13 L 4.63 6.70 L 5.36 5.57 L 5.66 5.27 L 6.54 4.85 L 7.48 4.58 L 7.91 4.57 L 8.66 4.71 L 9.88 5.26 L 10.29 5.60 L 11.48 7.04 L 11.66 7.20 L 11.85 7.27 L 12.10 7.23 L 12.35 7.07 L 12.86 6.44 L 13.91 5.36 L 14.22 5.18 L 15.60 4.62 L 15.98 4.53 L 16.41 4.55 L 17.85 5.02 L 18.16 5.21 L 18.43 5.51 L 19.12 6.51 L 19.37 7.07 L 19.45 7.63 L 19.48 8.63 L 19.37 9.38 L 19.16 9.96 L 18.60 11.04 L 18.07 12.32 L 16.27 14.63 L 15.60 15.29 L 15.04 16.07 L 14.43 16.57 L 13.70 17.32 L 13.22 17.90 L 12.10 18.68 L 11.91 18.77 Z", "M 12.00 20.95 L 12.41 20.73 L 13.66 19.80 L 13.96 19.52 L 14.48 18.88 L 15.16 18.27 L 15.72 17.55 L 16.31 17.02 L 17.21 16.02 L 17.66 15.38 L 18.23 14.79 L 18.73 14.05 L 19.25 13.51 L 19.48 13.21 L 20.41 11.38 L 20.98 8.94 L 21.02 8.26 L 20.99 7.57 L 20.56 5.70 L 20.30 5.18 L 19.23 3.94 L 18.85 3.66 L 18.23 3.33 L 17.60 3.12 L 15.66 3.07 L 15.10 3.13 L 14.35 3.28 L 13.91 3.45 L 13.04 3.99 L 12.72 4.22 L 12.22 4.72 L 12.04 4.83 L 11.85 4.87 L 11.60 4.76 L 11.04 4.17 L 10.29 3.63 L 9.79 3.35 L 9.29 3.17 L 8.66 3.07 L 7.54 3.05 L 6.72 3.11 L 5.72 3.28 L 5.10 3.64 L 4.43 4.20 L 4.25 4.44 L 3.94 5.07 L 3.54 5.53 L 3.39 5.82 L 3.07 6.94 L 2.97 7.94 L 3.05 9.38 L 3.34 10.51 L 3.90 11.63 L 4.41 13.14 L 4.70 13.63 L 5.79 14.93 L 7.65 17.02 L 8.48 17.88 L 9.27 18.57 L 10.11 19.63 L 11.50 20.82 L 11.72 20.95 L 12.00 20.95 Z M 11.91 18.77 L 11.79 18.77 L 11.60 18.68 L 10.64 17.88 L 10.16 17.27 L 8.57 15.57 L 6.66 13.38 L 5.71 11.94 L 5.25 11.13 L 4.73 10.07 L 4.51 9.44 L 4.43 8.76 L 4.42 7.63 L 4.49 7.13 L 4.63 6.70 L 5.36 5.57 L 5.66 5.27 L 6.54 4.85 L 7.48 4.58 L 7.91 4.57 L 8.66 4.71 L 9.88 5.26 L 10.29 5.60 L 11.48 7.04 L 11.66 7.20 L 11.85 7.27 L 12.10 7.23 L 12.35 7.07 L 12.86 6.44 L 13.91 5.36 L 14.22 5.18 L 15.60 4.62 L 15.98 4.53 L 16.41 4.55 L 17.85 5.02 L 18.16 5.21 L 18.43 5.51 L 19.12 6.51 L 19.37 7.07 L 19.45 7.63 L 19.48 8.63 L 19.37 9.38 L 19.16 9.96 L 18.60 11.04 L 18.07 12.32 L 16.27 14.63 L 15.60 15.29 L 15.04 16.07 L 14.43 16.57 L 13.70 17.32 L 13.22 17.90 L 12.10 18.68 L 11.91 18.77 Z", "", "", "", ""},
        {"", "M 4.69 20.57 L 4.94 20.42 L 5.17 20.19 L 5.32 19.94 L 5.39 19.69 L 5.42 17.57 L 5.38 16.44 L 5.45 16.07 L 5.64 15.69 L 5.88 15.39 L 6.19 15.15 L 6.57 14.98 L 7.07 14.86 L 7.63 14.82 L 9.13 14.95 L 10.50 15.21 L 12.00 15.60 L 14.38 16.38 L 15.00 16.48 L 15.94 16.54 L 17.38 16.53 L 18.24 16.38 L 18.81 16.13 L 19.75 15.42 L 20.00 15.01 L 20.10 14.44 L 20.14 12.88 L 20.13 6.94 L 20.02 5.57 L 19.88 5.14 L 19.69 4.88 L 19.31 4.64 L 18.81 4.56 L 18.31 4.61 L 16.81 4.93 L 15.75 4.92 L 14.63 4.73 L 14.00 4.52 L 13.25 4.37 L 10.50 3.63 L 9.38 3.49 L 7.88 3.41 L 6.00 3.47 L 5.50 3.54 L 5.03 3.75 L 4.38 4.25 L 4.17 4.51 L 4.00 4.82 L 3.91 5.19 L 3.87 5.63 L 3.86 19.51 L 3.93 20.01 L 4.11 20.38 L 4.38 20.59 L 4.69 20.57 Z M 16.81 14.94 L 15.63 14.91 L 12.07 14.37 L 11.50 14.23 L 10.44 13.78 L 9.75 13.63 L 8.25 13.48 L 6.57 13.52 L 6.12 13.44 L 5.77 13.25 L 5.61 13.07 L 5.49 12.82 L 5.41 12.19 L 5.42 8.51 L 5.37 6.25 L 5.45 5.88 L 5.69 5.53 L 6.19 5.08 L 6.81 4.78 L 7.38 4.68 L 8.38 4.69 L 10.00 5.12 L 12.53 5.57 L 14.57 6.27 L 16.07 6.44 L 17.50 6.33 L 17.94 6.44 L 18.27 6.63 L 18.44 6.82 L 18.53 7.01 L 18.62 7.57 L 18.58 13.82 L 18.49 14.07 L 18.36 14.25 L 17.94 14.60 L 17.38 14.86 L 16.81 14.94 Z", "M 4.69 20.57 L 4.94 20.42 L 5.17 20.19 L 5.32 19.94 L 5.39 19.69 L 5.42 17.57 L 5.38 16.44 L 5.45 16.07 L 5.64 15.69 L 5.88 15.39 L 6.19 15.15 L 6.57 14.98 L 7.07 14.86 L 7.63 14.82 L 9.13 14.95 L 10.50 15.21 L 12.00 15.60 L 14.38 16.38 L 15.00 16.48 L 15.94 16.54 L 17.38 16.53 L 18.24 16.38 L 18.81 16.13 L 19.75 15.42 L 20.00 15.01 L 20.10 14.44 L 20.14 12.88 L 20.13 6.94 L 20.02 5.57 L 19.88 5.14 L 19.69 4.88 L 19.31 4.64 L 18.81 4.56 L 18.31 4.61 L 16.81 4.93 L 15.75 4.92 L 14.63 4.73 L 14.00 4.52 L 13.25 4.37 L 10.50 3.63 L 9.38 3.49 L 7.88 3.41 L 6.00 3.47 L 5.50 3.54 L 5.03 3.75 L 4.38 4.25 L 4.17 4.51 L 4.00 4.82 L 3.91 5.19 L 3.87 5.63 L 3.86 19.51 L 3.93 20.01 L 4.11 20.38 L 4.38 20.59 L 4.69 20.57 Z M 16.81 14.94 L 15.63 14.91 L 12.07 14.37 L 11.50 14.23 L 10.44 13.78 L 9.75 13.63 L 8.25 13.48 L 6.57 13.52 L 6.12 13.44 L 5.77 13.25 L 5.61 13.07 L 5.49 12.82 L 5.41 12.19 L 5.42 8.51 L 5.37 6.25 L 5.45 5.88 L 5.69 5.53 L 6.19 5.08 L 6.81 4.78 L 7.38 4.68 L 8.38 4.69 L 10.00 5.12 L 12.53 5.57 L 14.57 6.27 L 16.07 6.44 L 17.50 6.33 L 17.94 6.44 L 18.27 6.63 L 18.44 6.82 L 18.53 7.01 L 18.62 7.57 L 18.58 13.82 L 18.49 14.07 L 18.36 14.25 L 17.94 14.60 L 17.38 14.86 L 16.81 14.94 Z", "", "", "", ""},
    };

    private final Paint clearPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Path[][][] catPathCache;

    /** Tiny SVG path reader (M L H V C Q Z, absolute) for the category icon table. */
    private static void svgPath(Path p, String d) {
        int i = 0;
        int n = d.length();
        float[] a = new float[6];
        char cmd = 'M';
        float cy = 0f;
        float cx = 0f;
        while (i < n) {
            char ch = d.charAt(i);
            if (ch == ' ' || ch == ',') {
                i++;
                continue;
            }
            if (Character.isLetter(ch)) {
                cmd = ch;
                i++;
                if (cmd == 'Z') {
                    p.close();
                }
                continue;
            }
            int need;
            switch (cmd) {
                case 'M':
                case 'L':
                    need = 2;
                    break;
                case 'H':
                case 'V':
                    need = 1;
                    break;
                case 'Q':
                    need = 4;
                    break;
                case 'C':
                    need = 6;
                    break;
                default:
                    need = 0;
                    break;
            }
            if (need == 0) {
                i++;
                continue;
            }
            for (int k = 0; k < need; k++) {
                while (i < n && (d.charAt(i) == ' ' || d.charAt(i) == ',')) {
                    i++;
                }
                int st = i;
                while (i < n && (Character.isDigit(d.charAt(i)) || d.charAt(i) == '.' || d.charAt(i) == '-')) {
                    i++;
                }
                a[k] = Float.parseFloat(d.substring(st, i));
            }
            switch (cmd) {
                case 'M':
                    p.moveTo(a[0], a[1]);
                    cx = a[0];
                    cy = a[1];
                    cmd = 'L';
                    break;
                case 'L':
                    p.lineTo(a[0], a[1]);
                    cx = a[0];
                    cy = a[1];
                    break;
                case 'H':
                    p.lineTo(a[0], cy);
                    cx = a[0];
                    break;
                case 'V':
                    p.lineTo(cx, a[0]);
                    cy = a[0];
                    break;
                case 'Q':
                    p.quadTo(a[0], a[1], a[2], a[3]);
                    cx = a[2];
                    cy = a[3];
                    break;
                default:
                    p.cubicTo(a[0], a[1], a[2], a[3], a[4], a[5]);
                    cx = a[4];
                    cy = a[5];
                    break;
            }
        }
    }

    private Path[][] catPaths(int cat) {
        if (catPathCache == null) {
            catPathCache = new Path[CAT_ICONS.length][][];
        }
        if (catPathCache[cat] == null) {
            Path[][] fields = new Path[7][];
            for (int f = 0; f < 7; f++) {
                String[] parts = CAT_ICONS[cat][f].split("\\|");
                ArrayList<Path> list = new ArrayList<>();
                for (String part : parts) {
                    if (!part.trim().isEmpty()) {
                        Path q = new Path();
                        svgPath(q, part.trim());
                        q.setFillType(Path.FillType.EVEN_ODD);   // traced icons: stroke rings are holes
                        list.add(q);
                    }
                }
                fields[f] = list.toArray(new Path[0]);
            }
            catPathCache[cat] = fields;
        }
        return catPathCache[cat];
    }

    /**
     * Category icon of the emoji bar. Not selected: a line icon. Selected: the filled version, whose details
     * (eyes, clock hands, ball seams ...) are cut out of the shape, like the SF Symbols the iOS bar uses.
     */
    private void drawCatIcon(Canvas c, int cat, boolean filled, float cx, float cy, float size, int color) {
        if (cat < 0 || cat >= CAT_ICONS.length) {
            return;
        }
        Path[][] f = catPaths(cat);
        Paint p = glyphPaint;
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setColor(color);
        p.setStrokeWidth(1.55f);
        clearPaint.setXfermode(new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.CLEAR));
        clearPaint.setStrokeCap(Paint.Cap.ROUND);
        clearPaint.setStrokeJoin(Paint.Join.ROUND);
        clearPaint.setStrokeWidth(1.2f);
        float sc = size / 24f;
        c.save();
        c.translate(cx - size / 2f, cy - size / 2f);
        c.scale(sc, sc);
        if (!filled) {
            p.setStyle(Paint.Style.STROKE);
            for (Path q : f[0]) c.drawPath(q, p);
            p.setStyle(Paint.Style.FILL);
            for (Path q : f[1]) c.drawPath(q, p);
        } else {
            int layerId = c.saveLayer(-2f, -2f, 26f, 26f, null);
            p.setStyle(Paint.Style.FILL);
            for (Path q : f[2]) c.drawPath(q, p);
            p.setStyle(Paint.Style.STROKE);
            for (Path q : f[3]) c.drawPath(q, p);
            clearPaint.setStyle(Paint.Style.FILL);
            for (Path q : f[4]) c.drawPath(q, clearPaint);
            clearPaint.setStyle(Paint.Style.STROKE);
            for (Path q : f[5]) c.drawPath(q, clearPaint);
            c.restoreToCount(layerId);
            p.setStyle(Paint.Style.FILL);
            for (Path q : f[6]) c.drawPath(q, p);
        }
        c.restore();
    }

    /**
     * One row of keys. Children are placed by exact pixel edges computed from their weights, so every
     * row spans exactly the same width, keys of equal weight are equal width (+/- 1 px) and the gap
     * between two neighbouring keys is always the same.
     */
    private final class KeyRow extends ViewGroup {
        private final ArrayList<Float> weights = new ArrayList<>();
        private final int rowHeight;

        KeyRow(Context c, int rowHeight) {
            super(c);
            this.rowHeight = rowHeight;
            setMotionEventSplittingEnabled(true);
            setClipChildren(false);
        }

        void add(View v, float weight) {
            weights.add(weight);
            addView(v);
        }

        @Override
        public void removeAllViews() {
            super.removeAllViews();
            weights.clear();
        }

        private float total() {
            float t = 0f;
            for (int i = 0; i < weights.size(); i++) {
                t += weights.get(i);
            }
            return t <= 0f ? 1f : t;
        }

        @Override
        protected void onMeasure(int widthSpec, int heightSpec) {
            int width = MeasureSpec.getSize(widthSpec);
            if (width <= 0) {
                width = getResources().getDisplayMetrics().widthPixels;
            }
            float total = total();
            float acc = 0f;
            int left = 0;
            int n = Math.min(getChildCount(), weights.size());
            for (int i = 0; i < n; i++) {
                acc += weights.get(i);
                int right = Math.round(width * acc / total);
                getChildAt(i).measure(
                        MeasureSpec.makeMeasureSpec(Math.max(0, right - left), MeasureSpec.EXACTLY),
                        MeasureSpec.makeMeasureSpec(rowHeight, MeasureSpec.EXACTLY));
                left = right;
            }
            setMeasuredDimension(width, rowHeight);
        }

        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int width = r - l;
            float total = total();
            float acc = 0f;
            int left = 0;
            int n = Math.min(getChildCount(), weights.size());
            for (int i = 0; i < n; i++) {
                acc += weights.get(i);
                int right = Math.round(width * acc / total);
                getChildAt(i).layout(left, 0, right, rowHeight);
                left = right;
            }
        }
    }

    private void addKeyRow(Key[] keys) {
        KeyRow rowView = new KeyRow(this, keyHeightPx);
        for (Key k : keys) {
            if (k.type == T_SPACER) {
                rowView.add(new View(this), k.weight);
                continue;
            }
            KeyView kv = new KeyView(k, false);
            rowView.add(kv, k.weight);
            if (k.type == T_SHIFT) {
                shiftView = kv;
            }
            if (k.letter) {
                letterViews.add(kv);
            }
        }
        keysContainer.addView(rowView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, keyHeightPx));
    }

    // ------------------------------------------------------------- emoji panel
    // Same layout as the iOS 27 emoji keyboard: a "Search Emoji" glass pill on top, a horizontally scrolling
    // grid (4 rows, 7 columns on screen, filled column by column, every category one after the other),
    // the category bar (ABC, nine category icons, delete) and the globe / microphone row at the bottom.
    // The panel is taller than the letters keyboard, exactly like on iOS.
    private final Runnable emojiRetry = new Runnable() {
        @Override
        public void run() {
            if (layer != LAYER_EMOJI) {
                return;
            }
            if (EmojiData.isReady()) {
                renderKeys();
            } else {
                handler.postDelayed(this, 250);
            }
        }
    };

    private List<String> loadRecentEmoji() {
        ArrayList<String> out = new ArrayList<>();
        String saved = prefs.getString(Prefs.K_EMOJI_RECENT, "");
        if (saved != null && !saved.isEmpty()) {
            for (String s : saved.split(",")) {
                if (!s.isEmpty()) {
                    out.add(s);
                }
            }
        }
        return out;
    }

    private void rememberEmoji(String e) {
        List<String> list = loadRecentEmoji();
        list.remove(e);
        list.add(0, e);
        while (list.size() > 32) {
            list.remove(list.size() - 1);
        }
        StringBuilder sb = new StringBuilder();
        for (String s : list) {
            if (sb.length() > 0) sb.append(',');
            sb.append(s);
        }
        prefs.edit().putString(Prefs.K_EMOJI_RECENT, sb.toString()).apply();
    }

    // ---- geometry: everything follows the key height setting (and shrinks in landscape)
    private float emojiScale() {
        return Math.max(0.7f, Math.min(1f, keyHeightPx / (float) dp(50)));
    }

    private int emojiRowPx() {
        return dp(Math.min(EMOJI_ROW_MAX_DP, keyHeightPx / density + EMOJI_ROW_EXTRA_DP));
    }

    private int emojiTopPx() {
        return Math.round(dp(EMOJI_SEARCH_AREA_DP) * emojiScale());
    }

    private int emojiCatBarPx() {
        return Math.round(dp(EMOJI_CAT_BAR_DP) * emojiScale());
    }

    private int emojiFootPx() {
        return 0;   // v3.100: no emoji-only footer; the shared footer row sits below the content panel
    }

    private int emojiPanelHeightPx() {
        return emojiTopPx() + emojiRowPx() * EMOJI_ROWS + emojiCatBarPx() + emojiFootPx();
    }

    // ---- data: one flat column-major table, categories back to back
    private String[] emojiCells = new String[0];
    private int emojiTotalCols;

    private void buildEmojiGrid() {
        ArrayList<String> flat = new ArrayList<>();
        int col = 0;
        for (int c = 0; c < EmojiData.COUNT; c++) {
            List<String> list = (c == 0) ? loadRecentEmoji() : EmojiData.get(c);
            emojiCatStartCol[c] = col;
            int cols;
            if (list.isEmpty()) {
                cols = c == 0 ? EMOJI_COLS : 0;   // "No Recent Emoji" takes one screen
                emojiCatCols[c] = cols;
                for (int i = 0; i < cols * EMOJI_ROWS; i++) {
                    flat.add(null);
                }
            } else {
                cols = (list.size() + EMOJI_ROWS - 1) / EMOJI_ROWS;
                emojiCatCols[c] = cols;
                for (int i = 0; i < cols * EMOJI_ROWS; i++) {
                    flat.add(i < list.size() ? list.get(i) : null);
                }
            }
            col += cols;
        }
        emojiTotalCols = col;
        emojiCells = flat.toArray(new String[0]);
    }

    private int emojiViewportPx() {
        int w = keysContainer != null ? keysContainer.getWidth() : 0;
        if (w <= 0) {
            w = getResources().getDisplayMetrics().widthPixels - 2 * dp(3);
        }
        return w;
    }

    private int emojiCellW() {
        return Math.max(1, (emojiViewportPx() - dp(EMOJI_GRID_INSET_L_DP) - dp(EMOJI_GRID_INSET_R_DP)) / EMOJI_COLS);
    }

    /** The scrolling emoji grid: only the columns on screen are drawn, one view for all of them. */
    private final class EmojiGridView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint hintPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bubble = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int cellW = emojiCellW();
        private final int rowH = emojiRowPx();
        private final int insetL = dp(EMOJI_GRID_INSET_L_DP);
        private final int contentW;
        private final int slop = android.view.ViewConfiguration.get(KeyboardService.this).getScaledTouchSlop();
        private int downIdx = -1;
        private float downX;
        private float downY;

        EmojiGridView(Context c) {
            super(c);
            Typeface noto = Fonts.emoji(c);
            if (noto != null) {
                paint.setTypeface(noto);
            }
            paint.setColor(Color.BLACK);   // opaque, so the colour emoji keep full strength
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(Math.round(Math.min(rowH, cellW) * EMOJI_SIZE_FACTOR * Prefs.emojiScale(prefs) / 100f));
            hintPaint.setTypeface(uiFont);
            hintPaint.setTextAlign(Paint.Align.CENTER);
            hintPaint.setTextSize(dp(15));
            hintPaint.setColor(colors.dark ? 0x99EBEBF5 : 0x993C3C43);
            bubble.setColor(colors.dark ? 0x33FFFFFF : 0x26000000);
            // room after the last category so that every category can be scrolled to its first column
            int lastStart = emojiCatStartCol[EmojiData.COUNT - 1];
            int natural = insetL + emojiTotalCols * cellW + dp(EMOJI_GRID_INSET_R_DP);
            contentW = Math.max(natural, lastStart * cellW + emojiViewportPx());
            setWillNotDraw(false);
        }

        @Override
        public boolean hasOverlappingRendering() {
            return false;
        }

        @Override
        protected void onMeasure(int wSpec, int hSpec) {
            setMeasuredDimension(contentW, rowH * EMOJI_ROWS);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            Rect clip = canvas.getClipBounds();
            int first = Math.max(0, (clip.left - insetL) / cellW);
            int last = Math.min(emojiTotalCols - 1, (clip.right - insetL) / cellW);
            Paint.FontMetrics fm = paint.getFontMetrics();
            float off = -(fm.ascent + fm.descent) / 2f;
            for (int col = first; col <= last; col++) {
                for (int r = 0; r < EMOJI_ROWS; r++) {
                    int idx = col * EMOJI_ROWS + r;
                    String e = idx < emojiCells.length ? emojiCells[idx] : null;
                    if (e == null || e.isEmpty()) {
                        continue;
                    }
                    float cx = insetL + cellW * (col + 0.5f);
                    float cy = rowH * (r + 0.5f);
                    if (idx == downIdx) {
                        canvas.drawCircle(cx, cy, Math.min(cellW, rowH) * 0.5f, bubble);
                    }
                    canvas.drawText(e, cx, cy + off, paint);
                }
            }
            if (emojiCatCols[0] > 0 && loadRecentEmoji().isEmpty()) {
                float x = insetL + cellW * (emojiCatStartCol[0] + emojiCatCols[0] / 2f);
                canvas.drawText("No Recent Emoji", x, rowH * EMOJI_ROWS / 2f, hintPaint);
            }
        }

        private int indexAt(float x, float y) {
            int col = (int) ((x - insetL) / cellW);
            int row = (int) (y / rowH);
            if (x < insetL || col < 0 || col >= emojiTotalCols || row < 0 || row >= EMOJI_ROWS) {
                return -1;
            }
            int idx = col * EMOJI_ROWS + row;
            return (idx < emojiCells.length && emojiCells[idx] != null) ? idx : -1;
        }

        @Override
        public boolean onTouchEvent(MotionEvent ev) {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downIdx = indexAt(ev.getX(), ev.getY());
                    downX = ev.getX();
                    downY = ev.getY();
                    invalidate();
                    return downIdx >= 0;
                case MotionEvent.ACTION_MOVE:
                    if (downIdx >= 0 && (Math.abs(ev.getX() - downX) > slop || Math.abs(ev.getY() - downY) > slop)) {
                        downIdx = -1;
                        invalidate();
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (downIdx >= 0 && emojiCells[downIdx] != null) {
                        String e = emojiCells[downIdx];
                        downIdx = -1;
                        invalidate();
                        feedback(this, T_CHAR);
                        commitPlain(e);
                        rememberEmoji(e);
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    downIdx = -1;
                    invalidate();
                    return true;
                default:
                    return true;
            }
        }
    }

    /** Horizontal scroller of the grid; tells the category bar which category is on screen. */
    private final class EmojiScroll extends HorizontalScrollView {
        // v3.86 snap: when the finger is up and the scroll has stopped (after a drag or a fling), the grid
        // moves to the nearest emoji column, so an emoji never stops half-way across the grid.
        private boolean fingerDown;
        private int lastSnapX = Integer.MIN_VALUE;
        private final Runnable snapCheck = new Runnable() {
            @Override
            public void run() {
                if (fingerDown) {
                    return;
                }
                int x = getScrollX();
                if (x != lastSnapX) {        // still moving: check again shortly
                    lastSnapX = x;
                    postDelayed(this, 60);
                    return;
                }
                snapToColumn();
            }
        };

        EmojiScroll(Context c) {
            super(c);
            setHorizontalScrollBarEnabled(false);
            setOverScrollMode(View.OVER_SCROLL_NEVER);
            setFillViewport(false);
        }

        @Override
        public boolean onInterceptTouchEvent(MotionEvent ev) {
            // sees every touch, also the ones the emoji cells consume, so the finger state is always right
            int a = ev.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                fingerDown = true;
                removeCallbacks(snapCheck);
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                fingerDown = false;
                scheduleSnap();
            }
            return super.onInterceptTouchEvent(ev);
        }

        @Override
        protected void onScrollChanged(int l, int t, int ol, int ot) {
            super.onScrollChanged(l, t, ol, ot);
            updateEmojiTab(l);
            if (!fingerDown) {
                scheduleSnap();
            }
        }

        private void scheduleSnap() {
            removeCallbacks(snapCheck);
            lastSnapX = getScrollX();
            postDelayed(snapCheck, 80);
        }

        /**
         * v3.104 category snap: the grid stops at the start of each emoji category, and inside a long category
         * at every screen-wide page counted from that category's start. So a sideways swipe lands on a category
         * or on one of its pages, never half-way between them.
         */
        private void snapToColumn() {
            int cw = emojiCellW();
            if (cw <= 0 || getChildCount() == 0) {
                return;
            }
            int maxX = Math.max(0, getChildAt(0).getWidth() - getWidth());
            int x = getScrollX();
            int pageCols = Math.max(1, Math.round(getWidth() / (float) cw));
            int best = -1;
            int bestD = Integer.MAX_VALUE;
            for (int c = 0; c < EmojiData.COUNT; c++) {
                if (emojiCatCols[c] <= 0) {
                    continue;
                }
                int end = emojiCatStartCol[c] + emojiCatCols[c];
                for (int col = emojiCatStartCol[c]; col < end; col += pageCols) {
                    int pos = col * cw;
                    int d = Math.abs(pos - x);
                    if (d < bestD) {
                        bestD = d;
                        best = pos;
                    }
                }
            }
            int target = best >= 0 ? best : Math.round(x / (float) cw) * cw;
            target = Math.max(0, Math.min(maxX, target));
            if (target != getScrollX()) {
                smoothScrollTo(target, 0);   // onScrollChanged fires again, lands here, and stops
            }
        }
    }

    // ------------------------------------------------ corner pop-up (v3.109): hold the lower-left corner key
    private FrameLayout cornerPopup;        // transparent touch layer: scrim + the four buttons, while the pop-up is shown
    private CornerGooView cornerGoo;        // the glass circle + capsule, drawn as one liquid shape
    private LinearLayout cornerButtons;     // the four buttons, on the capsule's final place
    private KeyView cornerAnchorKey;        // v3.114: the lower-left key that opened the pop-up (its built-in circle stays lit)
    private KeyView cornerRightKey;         // v3.114: the right-corner key (mic), which also stays lit and dips a little

    /**
     * v3.109: the key itself stays as it is. A glass circle (the size of the press circle) lights up behind the
     * corner key's icon, and a separate glass capsule of the same height flows out of the circle to the middle of
     * the footer, joined to it by a liquid neck until it pulls free (the Dynamic Island split, the other way round).
     * A tap anywhere closes it: the capsule flows back into the circle and the circle fades.
     */
    private void openCornerPopup(View anchor) {
        if (cornerPopup != null || inputOuter == null || anchor == null || anchor.getWidth() <= 0
                || !(anchor instanceof KeyView)) {
            return;
        }
        final int ow = inputOuter.getWidth();
        final int oh = inputOuter.getHeight();
        int[] a = new int[2];
        int[] o = new int[2];
        anchor.getLocationInWindow(a);
        inputOuter.getLocationInWindow(o);
        Key k = ((KeyView) anchor).key;
        float keyCx = a[0] - o[0] + anchor.getWidth() * (0.5f + k.iconShift) + dp(k.padL - k.padR) / 2f;
        float keyCy = a[1] - o[1] + anchor.getHeight() / 2f;
        float r = dp(PRESS_CIRCLE_DP) / 2f;                 // circle and capsule share this height
        float capW = dp(4 * POPUP_BTN_W_DP + 2 * POPUP_PAD_DP);
        float capL = (ow - capW) / 2f;                      // the middle of the footer
        capL = Math.max(capL, keyCx + r + dp(10));          // never touches the circle on a narrow screen
        float capR = Math.min(capL + capW, ow - dp(8));
        // the right-corner key (mic by default, or whatever is set there) lights up its circle too
        float rightCx = Float.NaN;
        View rightView = null;
        if (accessoryRow != null) {
            for (int i = accessoryRow.getChildCount() - 1; i >= 0; i--) {
                View c = accessoryRow.getChildAt(i);
                if (c instanceof KeyView && c != anchor && c.getWidth() > 0) {
                    int[] ra = new int[2];
                    c.getLocationInWindow(ra);
                    Key rk = ((KeyView) c).key;
                    rightCx = ra[0] - o[0] + c.getWidth() * (0.5f + rk.iconShift) + dp(rk.padL - rk.padR) / 2f;
                    rightView = c;
                    break;
                }
            }
        }
        if (!Float.isNaN(rightCx)) {
            // v3.120: the capsule's right end rests 2 dp from the mic, so the spring overshoot touches it and pushes it
            capR = rightCx - r - dp(MIC_REST_GAP_DP);
        }
        capL = capR - capW;
        if (capL < keyCx + r + dp(10)) {                    // narrow screens: keep clear of the lower-left circle
            capL = keyCx + r + dp(10);
            capR = capL + capW;
        }

        // the touch layer: a tap anywhere outside a button closes the pop-up
        final FrameLayout host = new FrameLayout(this);
        host.setClickable(true);
        host.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismissCornerPopup();
            }
        });

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER_VERTICAL);
        buttons.setPadding(dp(POPUP_PAD_DP), 0, dp(POPUP_PAD_DP), 0);
        buttons.setClickable(true);                         // a tap between the buttons does not close it

        PopupButton settings = new PopupButton(this, Icons.GEAR, new Runnable() {
            @Override
            public void run() {
                dismissCornerPopup();
                openSettingsPage(MainActivity.P_ROOT);
            }
        });
        PopupButton size = new PopupButton(this, Icons.RESIZE, new Runnable() {
            @Override
            public void run() {
                dismissCornerPopup();
                openSettingsPage(MainActivity.P_LAYOUT);
            }
        });
        PopupButton translate = new PopupButton(this, Icons.TRANSLATE, new Runnable() {
            @Override
            public void run() {
                dismissCornerPopup();
                Toast.makeText(KeyboardService.this, "Translator is not set up yet", Toast.LENGTH_SHORT).show();
            }
        });
        PopupButton theme = new PopupButton(this, Icons.THEME, new Runnable() {
            @Override
            public void run() {
                dismissCornerPopup();
                prefs.edit().putInt(Prefs.K_THEME, colors.dark ? 1 : 2).apply();   // light <-> dark
            }
        });
        PopupButton[] items = {settings, size, translate, theme};
        for (PopupButton b : items) {
            buttons.addView(b, new LinearLayout.LayoutParams(dp(POPUP_BTN_W_DP), ViewGroup.LayoutParams.MATCH_PARENT));
            b.setAlpha(0f);
        }
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(Math.round(capW), Math.round(r * 2f));
        blp.leftMargin = Math.round(capL);
        blp.topMargin = Math.round(keyCy - r);
        host.addView(buttons, blp);

        final CornerGooView goo = new CornerGooView(this, keyCx, keyCy, r, capL, capR, rightCx);
        // v3.114: the glass layer is exactly the keyboard's size. A taller layer made the keyboard window grow near
        // the bottom edge, which pushed the whole panel up when the lower-left key was held.
        FrameLayout.LayoutParams glp = new FrameLayout.LayoutParams(ow, oh, Gravity.TOP | Gravity.LEFT);
        goo.setBoundsTop(0);
        goo.setRightKey(rightView);
        // The window is the glass, so the root is see-through: the goo goes BEHIND the keyboard, and the corner
        // key's icon stays on top of its circle, untouched. If the root paints its own panel, the goo goes on top.
        if (inputRoot != null && inputRoot.getBackground() == null && footerBlur != null
                && inputOuter.indexOfChild(footerBlur) >= 0) {
            inputOuter.addView(goo, 0, glp);
        } else {
            inputOuter.addView(goo, glp);
        }
        inputOuter.addView(host, new FrameLayout.LayoutParams(ow, oh, Gravity.TOP | Gravity.LEFT));
        cornerPopup = host;
        cornerGoo = goo;
        cornerButtons = buttons;
        cornerAnchorKey = (KeyView) anchor;
        cornerRightKey = rightView instanceof KeyView ? (KeyView) rightView : null;
        cornerAnchorKey.setHoldLit(true);
        if (cornerRightKey != null) {
            cornerRightKey.setHoldLit(true);
        }

        goo.open(buttons);
        if (Prefs.on(prefs, Prefs.K_HAPTIC)) {
            anchor.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK);
        }
    }

    /** The capsule flows back into the circle: the same springs run backwards, then everything is removed. */
    private void dismissCornerPopup() {
        final FrameLayout host = cornerPopup;
        final CornerGooView goo = cornerGoo;
        if (host == null || goo == null) {
            return;
        }
        cornerPopup = null;
        cornerGoo = null;
        cornerButtons = null;
        if (cornerAnchorKey != null) {
            cornerAnchorKey.setHoldLit(false);
        }
        if (cornerRightKey != null) {
            cornerRightKey.setHoldLit(false);
        }
        cornerAnchorKey = null;
        cornerRightKey = null;
        host.setClickable(false);                  // already closing: touches go through to the keys
        host.setOnClickListener(null);
        goo.close(new Runnable() {
            @Override
            public void run() {
                goo.resetRightKey();
                if (host.getParent() instanceof ViewGroup) {
                    ((ViewGroup) host.getParent()).removeView(host);
                }
                if (goo.getParent() instanceof ViewGroup) {
                    ((ViewGroup) goo.getParent()).removeView(goo);
                }
            }
        });
    }

    /** One damped spring: x chases target. A zeta below 1 gives the small overshoot that makes the rebound. */
    private static final class GooSpring {
        float x;
        float v;
        float target;
        final float k;
        final float c;

        GooSpring(float k, float c) {
            this.k = k;
            this.c = c;
        }

        void snap(float to) {
            x = to;
            v = 0f;
            target = to;
        }

        void step(float dt) {
            float a = k * (target - x) - c * v;   // semi-implicit Euler: stable at the sub-steps used below
            v += a * dt;
            x += v * dt;
        }

        boolean settled() {
            return Math.abs(target - x) < 0.002f && Math.abs(v) < 0.02f;
        }
    }

    /**
     * The tool capsule (v3.1.22: the clock animation of v3.116, replacing the spring version). One clock u runs 0 -> 1 when
     * it opens and 1 -> 0 when it closes, through the same curves, so closing is the opening played backwards. The droplet
     * leaves the key's circle, the neck pinches from PINCH_U and is fully detached at DETACH_U, then the capsule widens and
     * overshoots into the right-corner key, which is knocked sideways and springs back. The four buttons fade in last.
     */
    private final class CornerGooView extends View {
        private final float cx;          // the lit key's circle centre, in the parent's coordinates
        private final float cyAbs;
        private final float r;           // the press circle's radius
        private final float capL;        // where the capsule ends up on the left
        private final float capR;        // and on the right
        private final float rightCx;     // the right-corner key's centre (NaN when there is none)
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path all = new Path();
        private final Path neck = new Path();
        private final RectF rect = new RectF();
        private LinearGradient shader;   // built once: the same gradient as every key
        private int topInParent;
        private float clock;             // 0..1: what the animation last set
        private int rimColor;
        private LinearLayout buttons;    // the four buttons, faded in with the clock
        private View rightKeyView;       // the mic key: knocked sideways by the capsule, then it springs back
        private float micX;              // its sideways offset (px) and speed (px/s), a spring
        private float micV;
        private long lastNs;
        private ValueAnimator anim;

        CornerGooView(Context c, float cx, float cy, float r, float capL, float capR, float rightCx) {
            super(c);
            this.cx = cx;
            this.cyAbs = cy;
            this.r = r;
            this.capL = capL;
            this.capR = capR;
            this.rightCx = rightCx;
            fill.setStyle(Paint.Style.FILL);
            rim.setStyle(Paint.Style.STROKE);
            rim.setStrokeWidth(Math.max(1f, dp(0.75f)));
            rimColor = colors.dark ? 0x26FFFFFF : 0x99FFFFFF;   // the keys' rim
            rim.setColor(rimColor);
            setClickable(false);
        }

        void setBoundsTop(int top) {
            topInParent = top;
        }

        void setRightKey(View v) {
            rightKeyView = v;
            micX = 0f;
            micV = 0f;
        }

        /** Puts the mic back where it belongs once the pop-up is gone. */
        void resetRightKey() {
            if (rightKeyView != null) {
                rightKeyView.setTranslationX(0f);
            }
        }

        /** Ease out, no overshoot: fast start, soft landing. */
        private float easeOut(float t) {
            t = Math.max(0f, Math.min(1f, t));
            float v = 1f - t;
            return 1f - v * v * v;
        }

        /** A back-ease: overshoots by an amount set by c1 and lands at 1. */
        private float easeOutBack(float t, float c1) {
            t = Math.max(0f, Math.min(1f, t));
            float c3 = c1 + 1f, v = t - 1f;
            return 1f + c3 * v * v * v + c1 * v * v;
        }

        private float easeOutCorner(float t) {
            float v = 1f - t;
            return 1f - v * v * v;
        }

        void open(LinearLayout btns) {
            buttons = btns;
            if (anim != null) {
                anim.cancel();
            }
            anim = ValueAnimator.ofFloat(0f, 1f);
            anim.setDuration(CORNER_OPEN_MS);
            anim.setFrameDelay(0);                 // draw on every display refresh
            anim.setInterpolator(new android.view.animation.LinearInterpolator());
            anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator va) {
                    setClock((Float) va.getAnimatedValue());
                }
            });
            anim.start();
        }

        /** Runs the same curves backwards from wherever the opening got to, then calls done. */
        void close(final Runnable done) {
            float from = clock;
            if (anim != null) {
                anim.cancel();
            }
            anim = ValueAnimator.ofFloat(from, 0f);
            anim.setDuration(Math.max(160, Math.round(340 * from)));
            anim.setFrameDelay(0);
            anim.setInterpolator(new android.view.animation.LinearInterpolator());
            anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator va) {
                    setClock((Float) va.getAnimatedValue());
                }
            });
            anim.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(android.animation.Animator a) {
                    if (done != null) {
                        done.run();
                    }
                }
            });
            anim.start();
        }

        private void setClock(float u) {
            clock = u;
            applyButtons(u);
            invalidate();
        }

        /** The buttons arrive once the capsule has pulled free, one after another. */
        private void applyButtons(float u) {
            if (buttons == null) {
                return;
            }
            float f = easeOutCorner(Math.max(0f, Math.min(1f, (u - 0.45f) / 0.55f)));
            for (int i = 0; i < buttons.getChildCount(); i++) {
                View b = buttons.getChildAt(i);
                if (b instanceof PopupButton && ((PopupButton) b).pressed()) {
                    continue;                // a button under the finger keeps its own press squeeze
                }
                float fi = Math.max(0f, Math.min(1f, f * 1.3f - i * 0.1f));
                float sc = 0.8f + 0.2f * fi;
                b.setAlpha(fi);
                b.setScaleX(sc);
                b.setScaleY(sc);
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float u = Math.max(0f, Math.min(1f, clock));
            float cy = cyAbs - topInParent;
            if (shader == null) {
                shader = new LinearGradient(0, cy - r, 0, cy + r,
                        colors.dark ? 0x2EFFFFFF : 0x8CFFFFFF, colors.dark ? 0x1FFFFFFF : 0x61FFFFFF, Shader.TileMode.CLAMP);
            }
            float pop = 0.8f + 0.2f * easeOutBack(Math.min(1f, u / 0.35f), 1.1f);
            float rr = r * pop;
            float lead = easeOut(Math.min(1f, u / DETACH_U));              // the droplet runs out and detaches by DETACH_U
            float grow = easeOutBack((u - DETACH_U) / (1f - DETACH_U), 2.8f); // then it widens, and overshoots into the right key
            float x0 = (cx - rr) + (capL - (cx - rr)) * lead;
            float w = 2f * rr + ((capR - capL) - 2f * rr) * grow;
            float x1 = x0 + w;
            float alpha = Math.min(1f, u / 0.12f);

            // the right-corner key: a spring that the capsule's edge knocks sideways, then it settles back
            float micOff = 0f;
            if (!Float.isNaN(rightCx)) {
                long now = System.nanoTime();
                float dt = lastNs == 0 ? 0.016f : Math.min(0.033f, (now - lastNs) / 1e9f);
                lastNs = now;
                float line = rightCx - rr - dp(3);          // where the capsule's edge meets the key's circle
                float hit = Math.max(0f, x1 - line);        // how far the edge has pushed into it
                float k = 260f, cdamp = 17f;                // stiff and slightly under-damped: one small rebound
                int steps = 3;
                float h = dt / steps;
                for (int i = 0; i < steps; i++) {
                    float a = -k * micX - cdamp * micV;
                    micV += a * h;
                    micX += micV * h;
                    if (micX < hit) {                       // the capsule cannot pass through the key
                        micX = hit;
                        if (micV < 0f) {
                            micV = 0f;
                        }
                    }
                }
                if (Math.abs(micX) > 0.02f || Math.abs(micV) > 1f) {
                    postInvalidateOnAnimation();            // keep settling after the clock has stopped
                } else {
                    micX = 0f;
                    micV = 0f;
                }
                micOff = micX;
                if (rightKeyView != null) {
                    rightKeyView.setTranslationX(micOff);
                }
            }

            // after the neck breaks the circle recoils a touch (surface tension)
            float gapNow = x0 - (cx + rr);
            float rc = rr;
            if (gapNow >= rr) {
                float pb = Math.max(0f, 1f - (gapNow - rr) / (rr * 0.9f));
                rc = rr * (1f + 0.07f * pb * pb);
            }
            all.rewind();
            all.addCircle(cx, cy, rc, Path.Direction.CW);
            if (!Float.isNaN(rightCx)) {
                all.addCircle(rightCx + micOff, cy, rr, Path.Direction.CW);
            }
            if (u > 0.001f) {
                rect.set(Math.max(x0, cx), cy - rr, x1, cy + rr);
                if (rect.right > rect.left) {
                    all.addRoundRect(rect, rr, rr, Path.Direction.CW);
                }
                // the liquid neck: full until PINCH_U, then it narrows to nothing by DETACH_U
                float gap = x0 - (cx + rr);
                float g = rr;
                if (gap < g && u < DETACH_U) {
                    float t = gap <= 0f ? 1f : (float) Math.pow(1f - gap / g, 1.35);
                    float pinch = u < PINCH_U ? 1f : Math.max(0f, 1f - (u - PINCH_U) / (DETACH_U - PINCH_U));
                    float h = rr * t * pinch;
                    if (h > dp(0.6f)) {
                        float dx = (float) Math.sqrt(Math.max(0f, rr * rr - h * h));
                        float ax = cx + dx;
                        float bx = x0 + rr - dx;
                        if (bx > ax) {
                            float mx = (ax + bx) / 2f;
                            float kc = 1f - 0.6f * (1f - t);
                            neck.rewind();
                            neck.moveTo(ax, cy - h);
                            neck.quadTo(mx, cy - 2f * h * kc + h, bx, cy - h);
                            neck.lineTo(bx, cy + h);
                            neck.quadTo(mx, cy + 2f * h * kc - h, ax, cy + h);
                            neck.close();
                            all.addPath(neck);
                        }
                    }
                }
            }

            // one fill for the whole glass sheet: no double alpha where shapes overlap
            fill.setShader(shader);
            fill.setAlpha(Math.round(255f * alpha));
            canvas.drawPath(all, fill);
            rim.setColor(scaleAlpha(rimColor, alpha));
            canvas.drawPath(all, rim);
        }

        @Override
        protected void onDetachedFromWindow() {
            if (anim != null) {
                anim.cancel();
            }
            super.onDetachedFromWindow();
        }
    }

    /** Opens the Settings app on a page (P_ROOT for the first page). */
    private void openSettingsPage(int page) {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        i.putExtra("page", page);
        startActivity(i);
    }

    /**
     * An icon-only button of the corner pop-up (v3.112). Every button has the same slot and the icon is drawn in the
     * same square, so the four icons line up as one row. It fires when the finger lifts inside it.
     */
    private final class PopupButton extends View {
        private final int icon;
        private final Runnable action;
        private final Paint ink = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint press = new Paint(Paint.ANTI_ALIAS_FLAG);
        private boolean down;

        boolean pressed() {
            return down;
        }

        /** v3.1.21: squeezes on touch-down and springs back on release, so the press is direct. */
        private void squeeze(boolean in) {
            animate().cancel();
            animate().scaleX(in ? 0.9f : 1f).scaleY(in ? 0.9f : 1f)
                    .setDuration(in ? 80 : 320)
                    .setInterpolator(in ? new DecelerateInterpolator()
                            : new android.view.animation.OvershootInterpolator(1.6f)).start();
        }

        PopupButton(Context c, int icon, Runnable action) {
            super(c);
            this.icon = icon;
            this.action = action;
            setClickable(true);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float cx = getWidth() / 2f;
            float cy = getHeight() / 2f;
            if (down) {
                press.setColor(colors.dark ? 0x33FFFFFF : 0x22000000);
                canvas.drawCircle(cx, cy, dp(POPUP_PRESS_DP), press);
            }
            ink.setColor(colors.text);
            Icons.draw(canvas, icon, cx, cy, dp(POPUP_ICON_DP), ink);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    down = true;
                    squeeze(true);
                    invalidate();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    boolean inside = e.getX() >= 0 && e.getX() <= getWidth() && e.getY() >= 0 && e.getY() <= getHeight();
                    if (down != inside) {
                        down = inside;
                        squeeze(inside);
                        invalidate();
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    boolean fire = down;
                    down = false;
                    squeeze(false);
                    invalidate();
                    if (fire) {
                        action.run();
                    }
                    return true;
                default:
                    down = false;
                    squeeze(false);
                    invalidate();
                    return true;
            }
        }
    }

    private void updateEmojiTab(int scrollX) {
        int cellW = emojiCellW();
        int col = (scrollX + cellW / 2) / Math.max(1, cellW);
        int sel = 0;
        for (int c = 0; c < EmojiData.COUNT; c++) {
            if (emojiCatCols[c] > 0 && emojiCatStartCol[c] <= col) {
                sel = c;
            }
        }
        if (sel == emojiSelectedTab) {
            return;
        }
        emojiSelectedTab = sel;
        if (emojiCatIcons != null) {
            emojiCatIcons.invalidate();
        }
    }

    private void scrollEmojiTo(int cat, boolean animate) {
        if (emojiScroll == null || emojiCatCols[cat] <= 0) {
            return;
        }
        int x = emojiCatStartCol[cat] * emojiCellW();
        if (animate) {
            emojiScroll.smoothScrollTo(x, 0);
        } else {
            emojiScroll.scrollTo(x, 0);
        }
        updateEmojiTab(x);
    }

    /** The nine category icons of the category bar; the one on screen is filled and sits in a soft circle. */
    private final class CatIconsView extends View {
        // the selected category sits in a glass disc: the same gradient and rim as the capsules (see capsule())
        private final android.graphics.drawable.GradientDrawable glassDisc;
        private float viewDp = 1f;     // width of this view in bar units (dp)
        private float shiftDp = 0f;    // moves the icon group so its centre sits on the bar centre

        void setGeometry(float viewDpIn, float shiftDpIn) {
            viewDp = viewDpIn;
            shiftDp = shiftDpIn;
            invalidate();
        }

        private float pxPerDp() {
            return getWidth() / viewDp;
        }

        CatIconsView(Context c) {
            super(c);
            int top = colors.dark ? 0x2EFFFFFF : 0x8CFFFFFF;
            int bottom = colors.dark ? 0x1FFFFFFF : 0x61FFFFFF;
            glassDisc = new android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, new int[]{top, bottom});
            glassDisc.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            glassDisc.setStroke(Math.max(1, dp(0.75f)), colors.dark ? 0x26FFFFFF : 0x99FFFFFF);
        }

        private float centerX(int i) {
            return getWidth() / 2f + pxPerDp() * (shiftDp + CAT_PITCH_DP * (i - CAT_MID));
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float cy = getHeight() / 2f;
            float d = Math.min(dp(CAT_SEL_DP), getHeight() - dp(2));
            for (int i = 0; i < EmojiData.COUNT; i++) {
                boolean sel = i == emojiSelectedTab;
                float cx = centerX(i);
                if (sel) {
                    // centred on the icon: translate to the disc's top-left corner, draw it at its own size
                    int ds = Math.round(d);
                    canvas.save();
                    canvas.translate(cx - ds / 2f, cy - ds / 2f);
                    glassDisc.setBounds(0, 0, ds, ds);
                    glassDisc.draw(canvas);
                    canvas.restore();
                }
                int col = sel ? colors.text : scaleAlpha(colors.text, 0.82f);
                drawCatIcon(canvas, i, sel, cx, cy, dp(CAT_ICON_DP), col);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent ev) {
            if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
                return true;
            }
            if (ev.getActionMasked() == MotionEvent.ACTION_UP) {
                int best = -1;
                float bestD = pxPerDp() * CAT_PITCH_DP * 0.55f;
                for (int i = 0; i < EmojiData.COUNT; i++) {
                    float dd = Math.abs(ev.getX() - centerX(i));
                    if (dd <= bestD) {
                        bestD = dd;
                        best = i;
                    }
                }
                if (best >= 0) {
                    feedback(this, T_CHAR);
                    scrollEmojiTo(best, true);
                }
                return true;
            }
            return true;
        }
    }

    /** The "Search Emoji" glass pill (also shown, with the typed text, while searching). */
    private final class SearchPill extends View {
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint closeBg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private String value = "";
        boolean closable;      // while searching: a round close button at the right end
        float lastX;

        SearchPill(Context c) {
            super(c);
            text.setTypeface(uiFont);
            text.setTextSize(dp(17));
            setBackground(capsule());
            setContentDescription("Search emoji");
        }

        void setValue(String v) {
            value = v == null ? "" : v;
            invalidate();
        }

        boolean hitClose() {
            return closable && lastX > getWidth() - dp(PILL_CLOSE_ZONE_DP);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            lastX = e.getX();
            return super.onTouchEvent(e);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            float cy = getHeight() / 2f;
            int gray = colors.dark ? 0x99EBEBF5 : 0x993C3C43;
            drawGlyph(canvas, G_SEARCH, dp(PILL_ICON_X_DP), cy, dp(PILL_ICON_DP), gray);
            boolean empty = value.isEmpty();
            text.setColor(empty ? gray : colors.text);
            Paint.FontMetrics fm = text.getFontMetrics();
            float x = dp(PILL_TEXT_X_DP);
            String s = empty ? "Search Emoji" : value;
            float room = getWidth() - x - dp(closable ? PILL_CLOSE_ZONE_DP : 14f);
            if (!empty && text.measureText(s) > room) {
                s = TextUtils.ellipsize(s, new TextPaint(text), room, TextUtils.TruncateAt.START).toString();
            }
            canvas.drawText(s, x, cy - (fm.ascent + fm.descent) / 2f, text);
            if (closable) {
                float r = dp(PILL_CLOSE_DP) / 2f;
                float cx = getWidth() - dp(PILL_CLOSE_ZONE_DP) / 2f;
                closeBg.setColor(colors.dark ? 0x40FFFFFF : 0x33000000);
                canvas.drawCircle(cx, cy, r, closeBg);
                float k = r * 0.38f;
                glyphPaint.setStyle(Paint.Style.STROKE);
                glyphPaint.setStrokeCap(Paint.Cap.ROUND);
                glyphPaint.setStrokeWidth(dp(1.6f));
                glyphPaint.setColor(colors.dark ? 0xFF1C1C1E : 0xFFFFFFFF);
                canvas.drawLine(cx - k, cy - k, cx + k, cy + k, glyphPaint);
                canvas.drawLine(cx - k, cy + k, cx + k, cy - k, glyphPaint);
            }
        }
    }

    /** Capsule with a soft glass gradient (search pill, clipboard header). */
    private Drawable capsule() {
        int top = colors.dark ? 0x2EFFFFFF : 0x8CFFFFFF;
        int bottom = colors.dark ? 0x1FFFFFFF : 0x61FFFFFF;
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, new int[]{top, bottom});
        g.setCornerRadius(dp(60));
        g.setStroke(Math.max(1, dp(0.75f)), colors.dark ? 0x26FFFFFF : 0x99FFFFFF);
        return g;
    }

    /** A plain line icon (one of this class's own glyphs) that can be tapped. */
    private final class GlyphView extends View {
        final int glyph;

        GlyphView(Context c, int glyph) {
            super(c);
            this.glyph = glyph;
        }

        @Override
        protected void onDraw(Canvas canvas) {
            drawGlyph(canvas, glyph, getWidth() / 2f, getHeight() / 2f, dp(22), colors.text);
        }
    }

    private void renderEmoji() {
        final float f = emojiScale();
        final int topPx = emojiTopPx();
        final int rowPx = emojiRowPx();
        final int catPx = emojiCatBarPx();
        final int footPx = emojiFootPx();
        emojiTravelPx = emojiPanelHeightPx();

        // top: the Search Emoji pill lives in the suggestion bar slot (which is as tall as the search area)
        SearchPill pill = new SearchPill(this);
        pill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                feedback(v, T_CHAR);
                emojiQuery.setLength(0);
                setLayer(LAYER_EMOJI_SEARCH);
            }
        });
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.round(dp(EMOJI_PILL_H_DP) * f));
        plp.leftMargin = dp(EMOJI_PILL_MARGIN_DP);
        plp.rightMargin = dp(EMOJI_PILL_MARGIN_DP);
        plp.topMargin = dp(EMOJI_PILL_TOP_DP);
        sugAlt.addView(pill, plp);

        if (!EmojiData.isReady()) {
            TextView loading = new TextView(this);
            loading.setText("Loading emoji\u2026");
            loading.setGravity(Gravity.CENTER);
            loading.setTypeface(uiFont);
            loading.setTextColor(colors.dark ? 0x99FFFFFF : 0x99000000);
            keysContainer.addView(loading, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, rowPx * EMOJI_ROWS));
            addEmojiBars(null, catPx, footPx);
            handler.removeCallbacks(emojiRetry);
            handler.postDelayed(emojiRetry, 250);
            return;
        }
        buildEmojiGrid();

        // The grid sits between the pill and the category bar; its last row slides a little under the bar,
        // where the progressive blur melts it away (the blur zone of the bar is a bit deeper than the bar).
        int overlap = Math.round(dp(EMOJI_BAR_OVERLAP_DP) * f);
        EdgeBlurLayout holder = new EdgeBlurLayout(this, topPx, catPx + overlap);
        holder.fixed = true;
        emojiHolder = holder;
        emojiScroll = new EmojiScroll(this);
        emojiGrid = new EmojiGridView(this);
        emojiScroll.addView(emojiGrid, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, rowPx * EMOJI_ROWS));
        FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, rowPx * EMOJI_ROWS);
        slp.topMargin = topPx;
        holder.addView(emojiScroll, slp);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, topPx + rowPx * EMOJI_ROWS + catPx);
        hlp.topMargin = -topPx;
        hlp.bottomMargin = -catPx;
        keysContainer.addView(holder, hlp);
        addEmojiBars(emojiScroll, catPx, footPx);

        // open on the recent emoji if there are any, otherwise on the smileys
        emojiSelectedTab = -1;
        final int startCat = loadRecentEmoji().isEmpty() ? 1 : 0;
        emojiScroll.post(new Runnable() {
            @Override
            public void run() {
                scrollEmojiTo(startCat, false);
            }
        });
        updateEmojiTab(0);
    }

    /** Width in bar units (dp) of a text, measured with the given font. */
    private float textDp(Typeface tf, float sizeDp, String text) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTypeface(tf);
        p.setTextSize(sizeDp * density);
        return p.measureText(text) / density;
    }

    /** Category bar (ABC, icons, delete) and the globe / microphone row under it. */
    private void addEmojiBars(View scroller, int catPx, int footPx) {
        KeyRow bar = new KeyRow(this, catPx);
        Key abc = fn(T_TO_LETTERS, "ABC", 1f);
        abc.textDp = 16.5f;
        float abcW = textDp(uiFont, 16.5f, "ABC") + 2f * EMOJI_BAR_PAD_DP;
        float delW = DEL_ICON_W_DP + 2f * EMOJI_BAR_PAD_DP;
        float viewW = EMOJI_BAR_TOTAL_DP - abcW - delW;
        bar.add(new KeyView(abc, true), abcW);
        emojiCatIcons = scroller == null ? null : new CatIconsView(this);
        if (emojiCatIcons != null) {
            emojiCatIcons.setGeometry(viewW, (delW - abcW) / 2f);
        }
        bar.add(emojiCatIcons != null ? emojiCatIcons : new View(this), viewW);
        bar.add(new KeyView(ic(T_DELETE, Icons.DELETE, 1f), true), delW);
        keysContainer.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, catPx));
        emojiCatBar = scroller != null ? bar : null;

        emojiFoot = null;   // v3.100: the footer is the shared accessory row, not part of the content panel
    }

    // ------------------------------------------------- emoji and clipboard panel open / close animation
    private View[] emojiPanelViews() {
        return new View[]{sugAlt, emojiHolder, emojiCatBar};
    }

    private View[] clipPanelViews() {
        return new View[]{sugAlt, clipHolderView};   // v3.117: the footer is universal, it does not move
    }

    /**
     * How far a panel must move to sit just below the keyboard. The panel's top is at the top of the keyboard,
     * so its own height (the keyboard's current height, measured before the new layer is laid out) is the distance.
     */
    private float panelTravelPx() {
        if (inputRoot != null && inputRoot.getHeight() > 0) {
            return inputRoot.getHeight();
        }
        return dp(2) + sugHeightPx + keyHeightPx * keyRows() + accessoryHeightPx;
    }

    /** Every piece of the panel starts at the bottom edge of the keyboard and rises together. */
    private void raisePanel(View[] views) {
        float from = panelTravelPx();
        for (View v : views) {
            if (v != null) {
                v.animate().cancel();
                v.setTranslationY(from);
            }
        }
        for (View v : views) {
            if (v != null) {
                v.animate().translationY(0f).setDuration(PANEL_OPEN_MS)
                        .setInterpolator(PANEL_OPEN_EASE).withLayer().start();
            }
        }
    }

    /** The panel sinks to the bottom edge of the keyboard, then `after` runs. */
    private void sinkPanel(final View[] views, final Runnable after) {
        float to = panelTravelPx();
        View first = null;
        for (View v : views) {
            if (v != null) {
                v.animate().cancel();
                if (first == null) {
                    first = v;
                }
            }
        }
        if (first == null || !first.isAttachedToWindow()) {
            for (View v : views) {
                if (v != null) {
                    v.setTranslationY(0f);
                }
            }
            after.run();
            return;
        }
        for (View v : views) {
            if (v == null) {
                continue;
            }
            android.view.ViewPropertyAnimator a = v.animate().translationY(to).setDuration(PANEL_CLOSE_MS)
                    .setInterpolator(PANEL_CLOSE_EASE).withLayer();
            if (v == first) {
                a.withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        // the header, footer and list are reused by the next panel: put them back at rest
                        for (View w : views) {
                            if (w != null) {
                                w.setTranslationY(0f);
                            }
                        }
                        after.run();
                    }
                });
            }
            a.start();
        }
    }

    /**
     * v3.100: only the content panel (between header and footer) changes height. The header is the top of the
     * keyboard window and the footer row stays directly below the content, so the footer does not change.
     */
    private void playEmojiOpen(int fromH) {
        if (emojiHolder == null || emojiCatBar == null || sugAlt == null || keysHost == null || fromH <= 0) {
            return;
        }
        kbBaseHeightPx = fromH;
        // v3.115: the same open as the clipboard panel. The keyboard keeps its height (no per-frame layout change,
        // which made the window resize on every frame and dropped the animation to a few frames per second); the
        // emoji header, grid and category bar rise from below on transforms only.
        restoreContentHeight();
        setContentHeight(fromH);
        // v3.116: no open animation for the emoji panel; it appears at rest at once (the clipboard keeps its own)
        for (View v : emojiPanelViews()) {
            if (v != null) {
                v.animate().cancel();
                v.setTranslationY(0f);
            }
        }
    }

    private static final int EMOJI_MORPH_OPEN_MS = 300;
    private static final int EMOJI_MORPH_CLOSE_MS = 260;

    /** Natural height of the content panel for the current layer, without a forced height. */
    private int measureContentHeight() {
        int w = keysHost.getWidth();
        if (w <= 0) {
            w = getResources().getDisplayMetrics().widthPixels;
        }
        keysHost.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        return keysHost.getMeasuredHeight();
    }

    private void setContentHeight(int h) {
        if (keysHost == null) {
            return;
        }
        ViewGroup.LayoutParams lp = keysHost.getLayoutParams();
        if (lp != null && lp.height != h) {
            lp.height = h;
            keysHost.setLayoutParams(lp);
        }
    }

    /** Stops a running morph and gives the content panel its normal wrapping height back. */
    private void restoreContentHeight() {
        if (morphAnim != null) {
            morphAnim.cancel();
            morphAnim = null;
        }
        if (keysHost == null) {
            return;
        }
        keysHost.setClipChildren(false);
        setContentHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    /** Animates the content panel height; its content is clipped to the panel meanwhile. */
    private void morphContent(final int from, final int to, int durMs,
                              android.view.animation.Interpolator ease, final Runnable end) {
        restoreContentHeight();
        if (keysHost == null || from <= 0 || to <= 0 || from == to) {
            if (end != null) {
                end.run();
            }
            return;
        }
        keysHost.setClipChildren(true);
        setContentHeight(from);
        ValueAnimator va = ValueAnimator.ofInt(from, to);
        va.setDuration(durMs);
        va.setInterpolator(ease);
        va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                if (morphAnim == a) {
                    setContentHeight((Integer) a.getAnimatedValue());
                }
            }
        });
        va.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator a) {
                if (morphAnim == a) {
                    morphAnim = null;
                    restoreContentHeight();
                    if (end != null) {
                        end.run();
                    }
                }
            }
        });
        morphAnim = va;
        va.start();
    }

    /** Clipboard header, list and footer rise from below the keyboard, as the emoji panel does. */
    private void playClipOpen() {
        if (clipHolderView == null || accessoryRow == null || sugAlt == null) {
            return;
        }
        raisePanel(clipPanelViews());
    }

    /** Sink below the keyboard, then run `after` (which switches to the letters). */
    private void closeEmojiThen(final Runnable after) {
        if (emojiClosing) {
            return;
        }
        if (emojiHolder == null || emojiCatBar == null || sugAlt == null) {
            after.run();
            return;
        }
        emojiClosing = true;
        // v3.116: no close animation for the emoji panel; the keyboard letters come back at once
        for (View v : emojiPanelViews()) {
            if (v != null) {
                v.animate().cancel();
                v.setTranslationY(0f);
            }
        }
        emojiClosing = false;
        after.run();
    }

    // ----------------------------------------------------------- emoji search
    /** A small keyword list for the most used emoji (the emoji data itself carries no names). */
    private static final String[] EMOJI_KEYWORDS = {
        "\uD83D\uDE00|grin smile happy face", "\uD83D\uDE03|smile happy joy", "\uD83D\uDE04|smile happy laugh",
        "\uD83D\uDE01|grin beam happy", "\uD83D\uDE06|laugh haha squint", "\uD83D\uDE05|sweat laugh nervous relief",
        "\uD83D\uDE02|joy laugh cry lol tears funny", "\uD83E\uDD23|rofl laugh lol funny rolling",
        "\uD83D\uDE0A|blush smile happy shy", "\uD83D\uDE07|angel halo innocent", "\uD83D\uDE42|smile slight",
        "\uD83D\uDE09|wink flirt", "\uD83D\uDE0D|love heart eyes crush", "\uD83E\uDD70|love hearts adore",
        "\uD83D\uDE18|kiss blow love", "\uD83D\uDE0B|yum tasty delicious tongue", "\uD83D\uDE1C|silly wink tongue crazy",
        "\uD83E\uDD14|think thinking hmm wonder", "\uD83D\uDE0E|cool sunglasses", "\uD83E\uDD29|star wow excited",
        "\uD83D\uDE0F|smirk", "\uD83D\uDE12|unamused bored annoyed", "\uD83D\uDE44|eyeroll roll eyes",
        "\uD83D\uDE2D|cry sob sad tears", "\uD83D\uDE22|cry sad tear", "\uD83D\uDE1E|sad disappointed",
        "\uD83D\uDE21|angry mad rage", "\uD83D\uDE20|angry mad", "\uD83E\uDD2C|swear curse angry",
        "\uD83D\uDE31|scream shocked scared omg", "\uD83D\uDE28|fear scared afraid", "\uD83D\uDE34|sleep sleeping tired zzz",
        "\uD83E\uDD71|yawn tired bored", "\uD83E\uDD12|sick fever ill", "\uD83E\uDD2E|vomit sick",
        "\uD83E\uDD75|hot heat sweat", "\uD83E\uDD76|cold freezing", "\uD83E\uDD73|party celebrate birthday",
        "\uD83E\uDD7A|please begging puppy eyes", "\uD83D\uDE4F|pray thanks please folded hands",
        "\uD83D\uDC4D|thumbs up like yes ok good", "\uD83D\uDC4E|thumbs down dislike no bad", "\uD83D\uDC4C|ok perfect",
        "\u270C\uFE0F|peace victory", "\uD83E\uDD1E|luck fingers crossed hope", "\uD83D\uDC4B|wave hello hi bye",
        "\uD83D\uDC4F|clap applause bravo", "\uD83D\uDE4C|raised hands hooray praise", "\uD83D\uDCAA|strong muscle flex gym",
        "\uD83E\uDD1D|handshake deal agree", "\u270B|stop hand high five", "\uD83D\uDC40|eyes look see watch",
        "\uD83E\uDDE0|brain smart mind", "\u2764\uFE0F|heart love red", "\uD83D\uDC94|broken heart sad",
        "\uD83D\uDC99|blue heart", "\uD83D\uDC9A|green heart", "\uD83D\uDC9B|yellow heart", "\uD83D\uDC9C|purple heart",
        "\uD83D\uDDA4|black heart", "\uD83D\uDC95|hearts love two", "\u2728|sparkles shine magic new",
        "\uD83D\uDD25|fire hot lit flame", "\uD83D\uDCAF|hundred perfect score", "\uD83C\uDF89|party tada celebrate congrats",
        "\uD83C\uDF82|birthday cake", "\uD83C\uDF81|gift present", "\uD83D\uDCA9|poop", "\uD83D\uDC80|skull dead",
        "\uD83D\uDC7B|ghost halloween", "\uD83E\uDD16|robot", "\uD83D\uDC36|dog puppy pet", "\uD83D\uDC31|cat kitten pet",
        "\uD83D\uDC2D|mouse", "\uD83D\uDC3B|bear", "\uD83D\uDC3C|panda", "\uD83E\uDD81|lion", "\uD83D\uDC37|pig",
        "\uD83D\uDC38|frog", "\uD83D\uDC35|monkey", "\uD83D\uDC14|chicken", "\uD83D\uDC27|penguin", "\uD83D\uDC22|turtle",
        "\uD83D\uDC0D|snake", "\uD83D\uDC1F|fish", "\uD83D\uDC2C|dolphin", "\uD83D\uDC33|whale", "\uD83E\uDD8B|butterfly",
        "\uD83D\uDC1D|bee", "\uD83C\uDF39|rose flower", "\uD83C\uDF3B|sunflower flower", "\uD83C\uDF34|palm tree beach",
        "\uD83C\uDF31|plant seedling grow", "\uD83C\uDF0A|wave ocean sea water", "\uD83C\uDF0D|earth world globe",
        "\u2600\uFE0F|sun sunny weather", "\uD83C\uDF19|moon night", "\u2B50|star", "\u2601\uFE0F|cloud weather",
        "\uD83C\uDF27\uFE0F|rain weather", "\u26A1|lightning bolt power energy", "\u2744\uFE0F|snow cold winter",
        "\uD83C\uDF08|rainbow", "\uD83C\uDF4E|apple fruit red", "\uD83C\uDF4C|banana fruit", "\uD83C\uDF4A|orange fruit",
        "\uD83C\uDF53|strawberry fruit", "\uD83C\uDF49|watermelon fruit", "\uD83C\uDF4D|pineapple fruit", "\uD83E\uDD51|avocado",
        "\uD83C\uDF54|burger hamburger food", "\uD83C\uDF55|pizza food", "\uD83C\uDF5F|fries food", "\uD83C\uDF2E|taco food",
        "\uD83C\uDF63|sushi food", "\uD83C\uDF5C|noodles ramen food", "\uD83C\uDF5A|rice food", "\uD83C\uDF70|cake dessert sweet",
        "\uD83C\uDF69|donut dessert", "\uD83C\uDF6B|chocolate candy", "\uD83C\uDF66|ice cream dessert", "\u2615|coffee tea drink hot",
        "\uD83C\uDF7A|beer drink", "\uD83C\uDF77|wine drink", "\uD83E\uDD64|drink soda cup", "\uD83D\uDCA7|water drop",
        "\u26BD|soccer football ball sport", "\uD83C\uDFC0|basketball sport", "\uD83C\uDFBE|tennis sport", "\uD83C\uDFC6|trophy win winner",
        "\uD83C\uDFAE|game gaming controller video", "\uD83C\uDFB5|music note song", "\uD83C\uDFA7|headphones music",
        "\uD83C\uDFA4|microphone sing karaoke", "\uD83C\uDFAC|movie film clapper", "\uD83D\uDE97|car auto drive",
        "\uD83D\uDE95|taxi cab", "\uD83D\uDE8C|bus", "\uD83D\uDE86|train", "\u2708\uFE0F|plane airplane flight travel",
        "\uD83D\uDE80|rocket space launch", "\uD83D\uDEB2|bike bicycle", "\uD83C\uDFE0|house home", "\uD83C\uDFD6\uFE0F|beach vacation",
        "\uD83D\uDCA1|bulb idea light", "\uD83D\uDCF1|phone mobile cellphone", "\uD83D\uDCBB|laptop computer", "\uD83D\uDCF7|camera photo",
        "\uD83D\uDCE7|email mail message", "\uD83D\uDCDD|note memo write", "\uD83D\uDCDA|books study read school",
        "\u270F\uFE0F|pencil write", "\uD83D\uDCB0|money cash bag", "\uD83D\uDCB5|money dollar cash", "\uD83D\uDD12|lock secure",
        "\uD83D\uDD11|key", "\u23F0|alarm clock time", "\u231B|hourglass time wait", "\uD83D\uDD14|bell notification",
        "\u2705|check done yes ok", "\u274C|cross no wrong x", "\u26A0\uFE0F|warning caution", "\u2753|question",
        "\u2757|exclamation important", "\uD83D\uDEA9|flag red", "\uD83C\uDFC1|finish flag race checkered",
        "\uD83C\uDDF5\uD83C\uDDED|philippines flag", "\uD83C\uDDFA\uD83C\uDDF8|usa america flag"
    };

    /** Matches the query against the keyword list and the category names. Empty query: recents. */
    private List<String> emojiSearchResults(String query) {
        ArrayList<String> out = new ArrayList<>();
        String q = query.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) {
            out.addAll(loadRecentEmoji());
            if (out.isEmpty() && EmojiData.isReady() && EmojiData.COUNT > 1) {
                List<String> first = EmojiData.get(1);
                for (int i = 0; i < first.size() && i < 24; i++) out.add(first.get(i));
            }
            return out;
        }
        String[] words = q.split("\\s+");
        // best matches first: a word that starts with the query word, then ones that merely contain it
        for (int pass = 0; pass < 2; pass++) {
            for (String entry : EMOJI_KEYWORDS) {
                int bar = entry.indexOf('|');
                String e = entry.substring(0, bar);
                String[] keys = entry.substring(bar + 1).split(" ");
                boolean all = true;
                for (String w : words) {
                    boolean hit = false;
                    for (String k : keys) {
                        if (pass == 0 ? k.startsWith(w) : k.contains(w)) {
                            hit = true;
                            break;
                        }
                    }
                    if (!hit) {
                        all = false;
                        break;
                    }
                }
                if (all && !out.contains(e)) {
                    out.add(e);
                }
            }
        }
        // typing a category name ("food", "animals", "flags") lists that whole category
        if (EmojiData.isReady()) {
            for (int c = 1; c < EmojiData.COUNT; c++) {
                String name = (c < EmojiData.NAMES.length && EmojiData.NAMES[c] != null)
                        ? EmojiData.NAMES[c].toLowerCase(Locale.ROOT) : "";
                if (q.length() >= 3 && name.contains(q)) {
                    List<String> l = EmojiData.get(c);
                    for (int i = 0; i < l.size() && out.size() < 60; i++) {
                        if (!out.contains(l.get(i))) out.add(l.get(i));
                    }
                }
            }
        }
        return out;
    }

    /** Height of the results row: the first emoji row of the grid stays exposed above the keyboard. */
    private int searchResultsPx() {
        // v3.119: the footer is not part of the emoji panel height any more (emojiFootPx() is 0), so it is no longer
        // taken off here. The results row is what is left of the emoji panel above the letters, so the search keeps
        // the same total height as the emoji grid and the universal footer sits at the same place in both.
        int extra = emojiPanelHeightPx() - emojiTopPx() - keyRows() * keyHeightPx;
        return Math.max(0, extra);
    }

    /** Height of one search result cell: a full emoji row when it fits, otherwise the results row height. */
    private int searchRowPx() {
        return Math.max(1, Math.min(emojiRowPx(), searchResultsPx()));
    }

    /**
     * Searching keeps the emoji panel: the pill stays on top (with a close button), the first emoji row shows
     * the results and the letters keyboard slides up over the rest of the grid.
     */
    private void buildEmojiSearchBar() {
        emojiPill = new SearchPill(this);
        emojiPill.closable = true;
        emojiPill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (emojiPill != null && emojiPill.hitClose()) {
                    feedback(v, T_CHAR);
                    exitEmojiSearch();
                }
            }
        });
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.round(dp(EMOJI_PILL_H_DP) * emojiScale()));
        plp.leftMargin = dp(EMOJI_PILL_MARGIN_DP);
        plp.rightMargin = dp(EMOJI_PILL_MARGIN_DP);
        plp.topMargin = dp(EMOJI_PILL_TOP_DP);
        sugAlt.addView(emojiPill, plp);

        emojiResultsScroll = new HorizontalScrollView(this);
        emojiResultsScroll.setHorizontalScrollBarEnabled(false);
        emojiResultsScroll.setOverScrollMode(View.OVER_SCROLL_NEVER);
        emojiResultsRow = new LinearLayout(this);
        emojiResultsRow.setOrientation(LinearLayout.HORIZONTAL);
        emojiResultsScroll.addView(emojiResultsRow, new HorizontalScrollView.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, searchRowPx()));
        keysContainer.addView(emojiResultsScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, searchResultsPx()));
        refreshEmojiSearch();
    }

    /** The keyboard rises over the emoji grid while the pill and the results row stay where they are. */
    private void playSearchOpen() {
        // v3.116: no open animation for the emoji search either: everything is at rest at once
        for (int i = 1; i < keysContainer.getChildCount(); i++) {
            View v = keysContainer.getChildAt(i);
            v.animate().cancel();
            v.setTranslationY(0f);
        }
        if (accessoryRow != null) {
            accessoryRow.animate().cancel();
            accessoryRow.setTranslationY(0f);
        }
    }

    private void refreshEmojiSearch() {
        if (layer != LAYER_EMOJI_SEARCH || emojiPill == null || emojiResultsRow == null) {
            return;
        }
        emojiPill.setValue(emojiQuery.toString());
        emojiResultsRow.removeAllViews();
        List<String> res = emojiSearchResults(emojiQuery.toString());
        Typeface noto = Fonts.emoji(this);
        int cellW = emojiCellW();
        int rowH = searchRowPx();
        emojiResultsRow.addView(new View(this), new LinearLayout.LayoutParams(dp(EMOJI_GRID_INSET_L_DP), rowH));
        if (res.isEmpty()) {
            TextView none = new TextView(this);
            none.setText(emojiQuery.length() == 0 ? "Type to find an emoji" : "No matches");
            none.setTypeface(uiFont);
            none.setTextSize(TypedValue.COMPLEX_UNIT_PX, dp(15));
            none.setTextColor(colors.dark ? 0x99EBEBF5 : 0x993C3C43);
            none.setGravity(Gravity.CENTER_VERTICAL);
            none.setPadding(dp(10), 0, dp(10), 0);
            emojiResultsRow.addView(none, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, rowH));
        }
        for (final String e : res) {
            TextView tv = new TextView(this);
            tv.setText(e);
            if (noto != null) {
                tv.setTypeface(noto);
            }
            tv.setIncludeFontPadding(false);
            tv.setGravity(Gravity.CENTER);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, Math.round(Math.min(rowH, cellW) * EMOJI_SIZE_FACTOR * Prefs.emojiScale(prefs) / 100f));
            tv.setTextColor(Color.BLACK);
            tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    feedback(v, T_CHAR);
                    pickSearchedEmoji(e);
                }
            });
            emojiResultsRow.addView(tv, new LinearLayout.LayoutParams(cellW, rowH));
        }
        emojiResultsScroll.scrollTo(0, 0);
    }

    private void searchAppend(String t) {
        if (t == null || t.isEmpty() || emojiQuery.length() > 40) {
            return;
        }
        emojiQuery.append(t.toLowerCase(Locale.ROOT));
        refreshEmojiSearch();
    }

    private void searchBackspace() {
        if (emojiQuery.length() > 0) {
            emojiQuery.setLength(emojiQuery.length() - 1);
            refreshEmojiSearch();
        }
    }

    private void exitEmojiSearch() {
        emojiQuery.setLength(0);
        setLayer(LAYER_EMOJI);
    }

    private void pickSearchedEmoji(String e) {
        emojiQuery.setLength(0);
        layer = homeLayer();
        commitPlain(e);
        rememberEmoji(e);
        setLayer(homeLayer());
    }

    /** Letter keys draw their label from the current shift / caps state, so just ask them to redraw. */
    private void updateShiftVisuals() {
        for (KeyView kv : letterViews) {
            kv.invalidate();
        }
        if (shiftView != null) {
            shiftView.invalidate();
        }
    }

    private static int darken(int c) {
        return Color.rgb((int) (Color.red(c) * 0.8f), (int) (Color.green(c) * 0.8f),
                (int) (Color.blue(c) * 0.8f));
    }

    // ------------------------------------------------------------------ G2 shapes
    /** Adds one superellipse corner: x = r*sgn(cos a)*|cos a|^(2/n), y likewise (G2 where it meets the edges). */
    private static void g2Corner(Path p, float cx, float cy, float r, double a0, double a1, float n) {
        final int seg = 20;
        double e = 2.0 / Math.max(2.01f, n);
        for (int i = 1; i <= seg; i++) {
            double a = a0 + (a1 - a0) * i / seg;
            double c = Math.cos(a);
            double sn = Math.sin(a);
            p.lineTo((float) (cx + r * Math.signum(c) * Math.pow(Math.abs(c), e)),
                    (float) (cy + r * Math.signum(sn) * Math.pow(Math.abs(sn), e)));
        }
    }

    /** A rectangle with G2 continuous-curvature corners. */
    static void g2Rect(Path p, float l, float t, float r, float b, float radius, float n) {
        p.reset();
        float rad = Math.max(0f, Math.min(radius, Math.min(r - l, b - t) / 2f));
        if (rad < 0.5f) {
            p.addRect(l, t, r, b, Path.Direction.CW);
            return;
        }
        p.moveTo(l + rad, t);
        p.lineTo(r - rad, t);
        g2Corner(p, r - rad, t + rad, rad, -Math.PI / 2, 0, n);
        p.lineTo(r, b - rad);
        g2Corner(p, r - rad, b - rad, rad, 0, Math.PI / 2, n);
        p.lineTo(l + rad, b);
        g2Corner(p, l + rad, b - rad, rad, Math.PI / 2, Math.PI, n);
        p.lineTo(l, t + rad);
        g2Corner(p, l + rad, t + rad, rad, Math.PI, Math.PI * 1.5, n);
        p.close();
    }

    /**
     * The key pop-up: a wide head with G2 corners that narrows through two smooth S-curves into the
     * key itself, which keeps its own G2 bottom corners (one continuous outline, like the iOS bubble).
     */
    private static void g2Callout(Path p, float kl, float kr, float kb,
                                  float hl, float hr, float ht, float yS, float yE,
                                  float rh, float rk) {
        // Fitted to the reference pop-up: round (circular) corners, and a shoulder that leaves the head's
        // vertical side with a vertical handle (a smooth, tangent-continuous turn, no sharp corner) and settles into
        // the neck with the same handle, 0.302 of its height.
        p.reset();
        float m = (yE - yS) * 0.302f;
        final float round = 2.01f;
        p.moveTo(hl + rh, ht);
        p.lineTo(hr - rh, ht);
        g2Corner(p, hr - rh, ht + rh, rh, -Math.PI / 2, 0, round);
        p.lineTo(hr, yS);
        p.cubicTo(hr, yS + m, kr, yE - m, kr, yE);
        p.lineTo(kr, kb - rk);
        g2Corner(p, kr - rk, kb - rk, rk, 0, Math.PI / 2, round);
        p.lineTo(kl + rk, kb);
        g2Corner(p, kl + rk, kb - rk, rk, Math.PI / 2, Math.PI, round);
        p.lineTo(kl, yE);
        p.cubicTo(kl, yE - m, hl, yS + m, hl, yS);
        p.lineTo(hl, ht + rh);
        g2Corner(p, hl + rh, ht + rh, rh, Math.PI, Math.PI * 1.5, round);
        p.close();
    }

    /** A tile filled (optionally top-to-bottom gradient) with a hairline rim, shaped with g2Rect. */
    static final class G2Drawable extends Drawable {
        private final Paint fillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final int top;
        private final int bottom;
        private final float radius;
        private final float rim;
        private final boolean hasRim;
        private final float power;

        G2Drawable(int top, int bottom, int rimColor, float rimPx, float radiusPx) {
            this(top, bottom, rimColor, rimPx, radiusPx, G2_POWER);
        }

        G2Drawable(int top, int bottom, int rimColor, float rimPx, float radiusPx, float power) {
            this.power = power;
            this.top = top;
            this.bottom = bottom;
            this.radius = radiusPx;
            this.hasRim = rimColor != 0 && rimPx > 0f;
            this.rim = rimPx;
            fillPaint.setStyle(Paint.Style.FILL);
            rimPaint.setStyle(Paint.Style.STROKE);
            rimPaint.setStrokeWidth(rimPx);
            rimPaint.setColor(rimColor);
        }

        @Override
        protected void onBoundsChange(Rect b) {
            float half = hasRim ? rim / 2f : 0f;
            g2Rect(path, b.left + half, b.top + half, b.right - half, b.bottom - half, radius, power);
            if (top == bottom) {
                fillPaint.setShader(null);
                fillPaint.setColor(top);
            } else {
                fillPaint.setShader(new LinearGradient(0, b.top, 0, b.bottom, top, bottom, Shader.TileMode.CLAMP));
            }
        }

        @Override
        public void draw(Canvas c) {
            c.drawPath(path, fillPaint);
            if (hasRim) {
                c.drawPath(path, rimPaint);
            }
        }

        @Override
        public void setAlpha(int alpha) {
            fillPaint.setAlpha(alpha);
            rimPaint.setAlpha(alpha);
        }

        @Override
        public void setColorFilter(android.graphics.ColorFilter cf) {
            fillPaint.setColorFilter(cf);
            rimPaint.setColorFilter(cf);
        }

        @Override
        public int getOpacity() {
            return PixelFormat.TRANSLUCENT;
        }
    }

    private static int scaleAlpha(int c, float f) {
        int a = Math.min(255, Math.max(0, Math.round(Color.alpha(c) * f)));
        return (a << 24) | (c & 0x00FFFFFF);
    }

    /** Solid G2 tile (the blue action key). */
    private Drawable roundRect(int color) {
        return new G2Drawable(color, color, 0, 0f, dp(KEY_RADIUS_DP));
    }

    /** Glass tile: the same gradient and rim as the Search Emoji capsule (see capsule()), so every key is glass. */
    private Drawable glassRect(int fill) {
        boolean pressed = fill == colors.keyPressed;
        int top;
        int bottom;
        if (pressed) {
            top = colors.dark ? 0x66FFFFFF : 0xE6C9CED8;
            bottom = colors.dark ? 0x52FFFFFF : 0xD6BEC3CC;
        } else {
            top = colors.dark ? 0x2EFFFFFF : 0x8CFFFFFF;       // same as capsule()
            bottom = colors.dark ? 0x1FFFFFFF : 0x61FFFFFF;
        }
        int rim = colors.dark ? 0x26FFFFFF : 0x99FFFFFF;        // same rim as capsule()
        return new G2Drawable(top, bottom, rim, Math.max(1, dp(0.75f)), dp(KEY_RADIUS_DP));
    }

    /**
     * Clipboard tile: the same glass as the keys, with the larger clipboard corner. A held or selected tile
     * takes a tint of the accent colour from the settings (blue by default) instead of grey.
     */
    private Drawable tileGlass(boolean pressed) {
        // v3.91: a held or selected tile uses the same neutral tint as the long-press menu (light grey in light
        // mode, white in dark mode), never the accent colour: no blue.
        int n = colors.dark ? 0xFFFFFF : 0x8E8E8E;
        int top = pressed ? (colors.dark ? 0x66FFFFFF : (n | 0x4D000000)) : (colors.dark ? 0x2EFFFFFF : 0x8CFFFFFF);
        int bottom = pressed ? (colors.dark ? 0x59FFFFFF : (n | 0x3D000000)) : (colors.dark ? 0x1FFFFFFF : 0x61FFFFFF);
        int rim = pressed ? 0x66FFFFFF : (colors.dark ? 0x26FFFFFF : 0x99FFFFFF);
        return new G2Drawable(top, bottom, rim, Math.max(1, dp(0.75f)), dp(CLIP_TILE_RADIUS_DP), CLIP_TILE_POWER);
    }

    /** The accent (blue action) key, also glass: lighter at the top, with a soft rim. */
    private Drawable accentGlassRect(int fill) {
        // Blue glass, the same transparent accent tint as a held clipboard tile (accent at 30 % / 24 %).
        int a = fill & 0x00FFFFFF;
        int top;
        int bottom;
        if (colors.dark) {
            // dark mode: grey glass, since blue reads navy on the dark panel; a pressed key is brighter
            boolean held = fill != colors.accent;
            top = held ? 0x66FFFFFF : 0x4DFFFFFF;
            bottom = held ? 0x59FFFFFF : 0x40FFFFFF;
        } else {
            top = a | 0x4D000000;     // light mode: accent at 30 % / 24 %
            bottom = a | 0x3D000000;
        }
        return new G2Drawable(top, bottom, 0x66FFFFFF, Math.max(1, dp(0.75f)), dp(KEY_RADIUS_DP));
    }

    /** `glass` = translucent tile with a hairline rim; false = solid fill (the blue action key). */
    private Drawable keyFace(int fill, boolean glass, int extraL, int extraR) {
        Drawable face = glass ? glassRect(fill) : accentGlassRect(fill);
        LayerDrawable one = new LayerDrawable(new Drawable[]{face});
        one.setLayerInset(0, insetH + extraL, insetV, insetH + extraR, insetV);
        return one;
    }

    private Drawable keyBackground(int normal, int pressed, boolean glass, int extraL, int extraR) {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, keyFace(pressed, glass, extraL, extraR));
        s.addState(new int[]{}, keyFace(normal, glass, extraL, extraR));
        return s;
    }

    // ------------------------------------------------------------- key callout
    private final class CalloutView extends View {
        private final Path path = new Path();
        private final Path shadowPath = new Path();
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint rimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint backdropPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint maskPaint = new Paint(Paint.ANTI_ALIAS_FLAG);      // opaque source for the shape mask
        private final Paint maskLayerPaint = new Paint();                      // DST_IN, composites the mask
        private Bitmap backdrop;                  // frosted snapshot of what is under the pop-up
        private float handleTop, handleFull;      // the solid handle fades in between these y values
        private String label = "";
        private final Rect textBounds = new Rect();
        private float textX = 0f;
        private float textY = 0f;

        CalloutView(Context c) {
            super(c);
            fill.setStyle(Paint.Style.FILL);
            rimPaint.setStyle(Paint.Style.STROKE);
            maskLayerPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setTypeface(uiMedium);
        }

        void set(String text, float kl, float kt, float kr, float kb,
                 float hl, float hr, float ht, float hb) {
            label = text;
            // all numbers measured from the reference pop-up (key = 90 x 112 px there)
            float kh = kb - kt;
            float rh = 0.191f * (hr - hl);     // head corners: round, radius 19.1 % of the head width
            float rk = 0.266f * (kr - kl);     // neck bottom corners: round, radius 26.6 % of the key width
            float yS = kt - 0.328f * kh;       // where the head's sides start to curve in (0.328 key heights above the key)
            float yE = kt + 0.10f * kh;        // where they meet the neck (0.10 key heights below the key top)
            handleTop = yS;
            handleFull = yE;
            g2Callout(path, kl, kr, kb, hl, hr, ht, yS, yE, rh, rk);
            float off = dp(1.5f);
            g2Callout(shadowPath, kl, kr, kb + off, hl, hr, ht + off, yS + off, yE + off, rh, rk);
            textPaint.setTextSize(dp(34));
            // Same rule as the key labels (KeyView.onDraw): centre the x-height of a lowercase letter, or
            // the cap height of everything else (digits, capitals, symbols), on the middle of the head.
            // So a letter pressed and a number held both sit at the same optical height; centring the
            // font's ascent..descent box instead left letters (small x-height, descenders) low.
            boolean lower = label.length() == 1 && Character.isLowerCase(label.charAt(0));
            textPaint.getTextBounds(lower ? "x" : "H", 0, 1, textBounds);
            textX = (hl + hr) / 2f;
            textY = (ht + hb) / 2f - (textBounds.top + textBounds.bottom) / 2f;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            // The shadow is drawn only outside the head: the glass body is translucent, so a shadow
            // underneath would show through it and grey it.
            canvas.save();
            if (Build.VERSION.SDK_INT >= 26) {
                canvas.clipOutPath(path);
            } else {
                canvas.clipPath(path, Region.Op.DIFFERENCE);
            }
            fill.setShader(null);
            fill.setColor(colors.calloutShadow);
            canvas.drawPath(shadowPath, fill);
            canvas.restore();
            // Frosted glass: the head shows a blurred snapshot of what is under it (never the letters
            // themselves). The handle is mostly solid, fading out towards the head, so it keeps a hint
            // of blur. Everything is drawn into a layer and masked by the shape, so the edge stays smooth.
            boolean d = colors.dark;
            RectF b = new RectF();
            path.computeBounds(b, true);
            // v3.88: the content layer covers the whole view. The mask below must cover the whole layer too:
            // a DST_IN draw only keeps pixels where it is drawn, so the blur used to show in the box around the head.
            int layer = canvas.saveLayer(0, 0, getWidth(), getHeight(), null);
            fill.setShader(null);
            if (backdrop != null) {
                canvas.drawBitmap(backdrop, null, new RectF(0, 0, getWidth(), getHeight()), backdropPaint);
                fill.setColor(d ? 0x40000000 : 0x59FFFFFF);      // frost tint over the blur (dark: black 25 %)
            } else {
                fill.setColor(colors.calloutFill);               // no snapshot: solid, never see-through
            }
            canvas.drawPath(path, fill);
            int solid = (colors.calloutFill & 0x00FFFFFF) | 0xD9000000;   // handle: 85 % solid
            int clear = colors.calloutFill & 0x00FFFFFF;
            fill.setShader(new LinearGradient(0, handleTop, 0, handleFull,
                    new int[]{clear, solid}, null, Shader.TileMode.CLAMP));
            canvas.drawPath(path, fill);
            fill.setShader(null);
            maskPaint.setColor(0xFF000000);
            int maskLayer = canvas.saveLayer(0, 0, getWidth(), getHeight(), maskLayerPaint);
            canvas.drawPath(path, maskPaint);          // shape alpha: 1 inside the head, 0 outside
            canvas.restoreToCount(maskLayer);          // composites DST_IN over the whole content layer
            canvas.restoreToCount(layer);
            // hairline rim, the same as the key tiles
            rimPaint.setStrokeWidth(Math.max(1, dp(0.75f)));
            rimPaint.setColor(d ? 0x26FFFFFF : 0x99FFFFFF);
            canvas.drawPath(path, rimPaint);
            textPaint.setColor(colors.calloutText);
            canvas.drawText(label, textX, textY, textPaint);
        }

        /** Sets (or clears, with null) the frosted snapshot of the keys under the head. */
        void setBackdrop(Bitmap b) {
            if (backdrop != null && backdrop != b) {
                backdrop.recycle();
            }
            backdrop = b;
            invalidate();
        }
    }

    private final Runnable calibrateRunnable = new Runnable() {
        @Override
        public void run() {
            calibrating = false;
            try {
                if (popup == null || !popup.isShowing() || calloutView == null) {
                    return;
                }
                int[] l = new int[2];
                calloutView.getLocationOnScreen(l);
                int dx = Math.round(expectScreenX) - l[0];
                int dy = Math.round(expectScreenY) - l[1];
                if (Math.abs(dx) > 1 || Math.abs(dy) > 1) {
                    corrX += dx;
                    corrY += dy;
                    curPx += dx;
                    curPy += dy;
                    popup.update(curPx, curPy, -1, -1);
                }
                calibrated = true;
                calloutView.setAlpha(1f);
            } catch (Throwable ignored) {
                calibrated = true;
                if (calloutView != null) calloutView.setAlpha(1f);
            }
        }
    };

    /** A small, blurred snapshot of the keyboard under the pop-up's window (screen rect x, y, w, h). */
    private Bitmap frostBackdrop(float x, float y, int w, int h) {
        try {
            View root = getWindow().getWindow().getDecorView();
            int[] wl = new int[2];
            root.getLocationOnScreen(wl);
            int sw = Math.max(1, w / 4), sh = Math.max(1, h / 4);      // quarter size: cheap to blur
            Bitmap small = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(small);
            c.scale(sw / (float) w, sh / (float) h);
            c.translate(-(x - wl[0]), -(y - wl[1]));
            root.draw(c);
            Bitmap blurred = boxBlur(small, 3, 3);
            small.recycle();
            return blurred;
        } catch (Throwable ignored) {
            return null;     // no snapshot: the pop-up falls back to a solid head
        }
    }

    /** Separable box blur, applied `passes` times (close to a gaussian). */
    private static Bitmap boxBlur(Bitmap src, int r, int passes) {
        int w = src.getWidth(), h = src.getHeight();
        int[] a = new int[w * h], b = new int[w * h];
        src.getPixels(a, 0, w, 0, 0, w, h);
        for (int p = 0; p < passes; p++) {
            blurRows(a, b, w, h, r);
            blurCols(b, a, w, h, r);
        }
        return Bitmap.createBitmap(a, w, h, Bitmap.Config.ARGB_8888);
    }

    private static void blurRows(int[] src, int[] dst, int w, int h, int r) {
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int sa = 0, sr = 0, sg = 0, sb = 0, n = 0;
                for (int k = -r; k <= r; k++) {
                    int c = src[y * w + Math.min(w - 1, Math.max(0, x + k))];
                    sa += c >>> 24; sr += (c >> 16) & 255; sg += (c >> 8) & 255; sb += c & 255; n++;
                }
                dst[y * w + x] = ((sa / n) << 24) | ((sr / n) << 16) | ((sg / n) << 8) | (sb / n);
            }
        }
    }

    private static void blurCols(int[] src, int[] dst, int w, int h, int r) {
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int sa = 0, sr = 0, sg = 0, sb = 0, n = 0;
                for (int k = -r; k <= r; k++) {
                    int c = src[Math.min(h - 1, Math.max(0, y + k)) * w + x];
                    sa += c >>> 24; sr += (c >> 16) & 255; sg += (c >> 8) & 255; sb += c & 255; n++;
                }
                dst[y * w + x] = ((sa / n) << 24) | ((sr / n) << 16) | ((sg / n) << 8) | (sb / n);
            }
        }
    }

    /**
     * Screen position of a view's layout frame. getLocationOnScreen() includes the view's transform, so a key
     * that is squeezed while pressed (PRESS_SCALE) would report a position a little lower and to the side. The
     * pop-up must use the same frame for a press and for a hold, so this reads the layout frame only.
     */
    private void layoutScreenLocation(View v, int[] out) {
        float x = 0f, y = 0f;
        View cur = v;
        while (cur.getParent() instanceof View) {
            x += cur.getLeft();
            y += cur.getTop();
            cur = (View) cur.getParent();
        }
        int[] root = new int[2];
        cur.getLocationOnScreen(root);
        out[0] = root[0] + Math.round(x);
        out[1] = root[1] + Math.round(y);
    }

    private void showCallout(KeyView kv, String label) {
        try {
            if (keysContainer == null || kv.getWidth() == 0) {
                return;
            }
            int[] loc = new int[2];
            layoutScreenLocation(kv, loc);
            float kl = loc[0] + insetH;
            float kr = loc[0] + kv.getWidth() - insetH;
            float kt = loc[1] + insetV;
            float kb = loc[1] + kv.getHeight() - insetV;
            float kw = kr - kl;
            float kh = kb - kt;
            float headW = kw * 1.583f;         // reference: head = 1.58 x neck width (iOS: 370 px head over 233 px neck)
            float cx = (kl + kr) / 2f;
            float screenW = getResources().getDisplayMetrics().widthPixels;
            float pad = dp(4);
            float headL = Math.max(pad, Math.min(cx - headW / 2f, screenW - pad - headW));
            float headR = headL + headW;
            float headB = kt + 0.06f * kh;     // the label is centred between headT and here (matches the reference letter position)
            float headT = kt - 1.464f * kh;    // reference: head top = 1.46 key heights above the key

            float side = dp(2);
            float ox = Math.min(headL, kl) - side;
            float oy = headT;
            float ex = Math.max(headR, kr) + side;
            int pw = Math.round(ex - ox);
            int ph = Math.round(kb - oy) + dp(3);

            if (calloutView == null) {
                calloutView = new CalloutView(this);
            }
            calloutView.set(label, kl - ox, kt - oy, kr - ox, kb - oy,
                    headL - ox, headR - ox, 0f, headB - oy);
            calloutView.setBackdrop(frostBackdrop(ox, oy, pw, ph));

            int[] wl = new int[2];
            Window w = getWindow().getWindow();
            w.getDecorView().getLocationOnScreen(wl);
            curPx = Math.round(ox) - wl[0] + corrX;
            curPy = Math.round(oy) - wl[1] + corrY;
            expectScreenX = ox;
            expectScreenY = oy;

            if (popup == null) {
                popup = new PopupWindow(calloutView, pw, ph);
                popup.setTouchable(false);
                popup.setFocusable(false);
                popup.setClippingEnabled(false);
                popup.setAnimationStyle(0);
                popup.setInputMethodMode(PopupWindow.INPUT_METHOD_NOT_NEEDED);
            }
            if (popup.isShowing()) {
                popup.update(curPx, curPy, pw, ph);
            } else {
                popup.setWidth(pw);
                popup.setHeight(ph);
                if (!calibrated) {
                    calloutView.setAlpha(0f);
                }
                popup.showAtLocation(keysContainer, Gravity.NO_GRAVITY, curPx, curPy);
            }
            calloutOwner = kv;
            if (!calibrated && !calibrating) {
                calibrating = true;
                handler.postDelayed(calibrateRunnable, 40);
            }
        } catch (Throwable ignored) {
            // A missing pop-up must never stop typing.
        }
    }

    private void dismissCallout(KeyView owner) {
        if (calloutOwner == owner) {
            dismissCalloutNow();
        }
    }

    private void dismissCalloutNow() {
        calloutOwner = null;
        if (calloutView != null) {
            calloutView.setBackdrop(null);
        }
        try {
            if (popup != null && popup.isShowing()) {
                popup.dismiss();
            }
        } catch (Throwable ignored) {
            // ignore
        }
    }

    // ---------------------------------------------------------------- clipboard
    private final ClipboardManager.OnPrimaryClipChangedListener clipListener =
            new ClipboardManager.OnPrimaryClipChangedListener() {
                @Override
                public void onPrimaryClipChanged() {
                    captureClip(false);
                }
            };

    private boolean clipRemember() {
        return prefs != null && prefs.getBoolean(K_CLIP_REMEMBER, true);   // on by default: history survives restarts
    }

    /**
     * Adds text as the newest item. Duplicates move to the top (keeping their pin). Max 20 items.
     * With "remember across restarts" on, the item is written to the SQLite database as well.
     */
    private boolean clipAdd(String text) {
        if (text == null || text.trim().isEmpty()) {
            return false;
        }
        if (clipRemember() && db != null) {
            return clipAddStored(text);
        }
        boolean pinned = false;
        for (int i = 0; i < clipItems.size(); i++) {
            if (clipItems.get(i).text.equals(text)) {
                pinned = clipItems.get(i).pinned;
                clipItems.remove(i);
                break;
            }
        }
        ClipItem fresh = new ClipItem(text, pinned);
        fresh.timestamp = System.currentTimeMillis();
        clipItems.add(0, fresh);
        while (clipItems.size() > CLIP_MAX) {
            int drop = -1;
            for (int i = clipItems.size() - 1; i >= 0; i--) {
                if (!clipItems.get(i).pinned) {
                    drop = i;
                    break;
                }
            }
            if (drop < 0) {
                clipItems.remove(0); // 20 pinned items already: there is no room for a new one
                return false;
            }
            clipItems.remove(drop);
        }
        return true;
    }

    /** Adds text to the SQLite history and rebuilds the list from it (the database is the source of truth). */
    private boolean clipAddStored(String text) {
        boolean pinned = false;
        KeyboardDb.ClipRow same = db.findClipByContent(text);
        if (same != null) {
            pinned = same.pinned;
            db.deleteClip(same.id);
        }
        db.insertClip(text, pinned, System.currentTimeMillis());
        boolean kept = db.enforceClipLimit(CLIP_MAX);   // removes only unpinned items, oldest first
        clipReloadFromDb();
        return kept;
    }

    private void clipTogglePin(ClipItem it) {
        it.pinned = !it.pinned;
        if (db != null && clipRemember() && it.dbId >= 0) {
            db.updateClipPinned(it.dbId, it.pinned);
        }
    }

    private void clipRemove(ClipItem it) {
        clipItems.remove(it);
        if (db != null && clipRemember() && it.dbId >= 0) {
            db.deleteClip(it.dbId);
        }
    }

    private void clipClearUnpinned() {
        for (int i = clipItems.size() - 1; i >= 0; i--) {
            if (!clipItems.get(i).pinned) {
                clipItems.remove(i);
            }
        }
        if (db != null && clipRemember()) {
            db.deleteUnpinnedClips();   // pinned rows stay
        }
        refreshClipList();
    }

    /**
     * Memory only by default. With "remember across restarts" on, every item is kept in the SQLite database,
     * so it survives app restarts and reboots. Switching the option on writes what is in memory; switching it off
     * deletes the stored history.
     */
    private void clipSave() {
        if (db == null) {
            return;
        }
        try {
            if (!clipRemember()) {
                db.deleteAllClips();
                return;
            }
            db.deleteAllClips();
            long now = System.currentTimeMillis();
            int n = clipItems.size();
            for (int i = 0; i < n; i++) {
                ClipItem it = clipItems.get(i);
                // newest first in the list, so the newest gets the largest timestamp
                long ts = it.timestamp > 0 ? it.timestamp : now - (n - i);
                it.dbId = db.insertClip(it.text, it.pinned, ts);
            }
            clipReloadFromDb();
        } catch (Throwable ignored) {
            // never crash typing because of history storage
        }
    }

    /**
     * Loads the stored history into memory. Also moves the history from the older preference copy (JSON)
     * into the database, once.
     */
    private void clipLoad() {
        clipItems.clear();
        if (!clipRemember() || db == null) {
            if (prefs != null && prefs.contains(K_CLIP_SAVED)) {
                prefs.edit().remove(K_CLIP_SAVED).apply();   // the old preference copy is never used when remember is off
            }
            return;
        }
        try {
            migrateClipPrefs();
            clipReloadFromDb();
        } catch (Throwable ignored) {
            clipItems.clear();
        }
    }

    /** Rebuilds the in-memory list from the database, newest first, at most CLIP_MAX items. */
    private void clipReloadFromDb() {
        clipItems.clear();
        for (KeyboardDb.ClipRow row : db.queryClips()) {
            if (clipItems.size() >= CLIP_MAX) {
                break;
            }
            ClipItem it = new ClipItem(row.content, row.pinned);
            it.dbId = row.id;
            it.timestamp = row.timestamp;
            clipItems.add(it);
        }
    }

    /** One-time move of the history kept in preferences (K_CLIP_SAVED, JSON) into the database. */
    private void migrateClipPrefs() {
        if (prefs == null || !prefs.contains(K_CLIP_SAVED)) {
            return;
        }
        try {
            String saved = prefs.getString(K_CLIP_SAVED, null);
            if (saved != null && db.clipCount() == 0) {
                JSONArray arr = new JSONArray(saved);
                long now = System.currentTimeMillis();
                int n = arr.length();
                for (int i = 0; i < n; i++) {
                    JSONObject o = arr.getJSONObject(i);
                    String t = o.optString("t", "");
                    if (!t.isEmpty()) {
                        // the list was newest first, so the first item gets the largest timestamp
                        db.insertClip(t, o.optBoolean("p", false), now - i);
                    }
                }
            }
        } catch (Throwable ignored) {
            // a damaged old copy is simply dropped
        }
        prefs.edit().remove(K_CLIP_SAVED).apply();
    }

    /**
     * Reads the phone's current clip into the history (text only). Only runs while the keyboard is
     * showing, never saves anything copied in a password field, and never saves clips that the
     * source marked as sensitive.
     */
    private void captureClip(boolean fromStart) {
        if (clipboard == null || !inputActive || !Prefs.on(prefs, Prefs.K_CLIP)) {
            return;
        }
        try {
            ClipData cd = clipboard.getPrimaryClip();
            if (cd == null || cd.getItemCount() == 0) {
                return;
            }
            CharSequence t = cd.getItemAt(0).getText();
            if (t == null) {
                return;
            }
            String s = t.toString();
            if (fromStart && s.equals(lastSeenClip)) {
                return; // same clip we already have: do not shuffle the list just because the keyboard opened
            }
            boolean sensitive = false;
            ClipDescription d = cd.getDescription();
            if (d != null && d.getExtras() != null
                    && d.getExtras().getBoolean("android.content.extra.IS_SENSITIVE", false)) {
                sensitive = true; // password managers mark what they copy as sensitive
            }
            lastSeenClip = s;
            if (isPasswordField || sensitive) {
                return; // remembered as "seen" so it is not picked up later in a normal field
            }
            if (clipAdd(s) && layer == LAYER_CLIP) {
                refreshClipList();
            }
        } catch (Throwable ignored) {
            // clipboard access can be refused by the system; never crash typing
        }
    }

    /** Pinned items first, then the rest newest first. */
    private List<ClipItem> clipDisplayList() {
        ArrayList<ClipItem> out = new ArrayList<>();
        for (ClipItem it : clipItems) {
            if (it.pinned) out.add(it);
        }
        for (ClipItem it : clipItems) {
            if (!it.pinned) out.add(it);
        }
        return out;
    }

    /** The clipboard panel: it takes the place of the key area, exactly like the emoji panel. */
    private void renderClipboard() {

        // Header (back, title, Clear all) lives in the suggestion bar, so the list gets the whole key area.
        // Only the two buttons sit in glass: a circle for back, a capsule for Clear all. The title is centred on the panel.
        int btnH = Math.round(dp(EMOJI_PILL_H_DP) * emojiScale());   // same height as the emoji search pill
        TextView title = new TextView(this);
        clipTitle = title;
        title.setText("Clipboard");
        title.setTypeface(uiMedium);
        title.setTextColor(colors.text);
        title.setTextSize(TypedValue.COMPLEX_UNIT_PX, dp(17));
        title.setGravity(Gravity.CENTER);
        sugAlt.addView(title, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        FrameLayout backWrap = new FrameLayout(this);
        backWrap.setBackground(capsule());
        backWrap.addView(new KeyView(ic(T_CLIP_CLOSE, G_BACK, 1f), true), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(btnH, btnH);
        bl.leftMargin = dp(EMOJI_PILL_MARGIN_DP);
        bl.topMargin = dp(EMOJI_PILL_TOP_DP);   // same top padding as the emoji search pill
        sugAlt.addView(backWrap, bl);
        FrameLayout clearWrap = new FrameLayout(this);
        clearWrap.setBackground(capsule());
        clearWrap.addView(new KeyView(fn(T_CLIP_CLEAR, "Clear all", 1f), true), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        clipClearKey = clearWrap;
        FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(dp(CLIP_CLEAR_W_DP), btnH);
        cl.gravity = Gravity.RIGHT;
        cl.rightMargin = dp(EMOJI_PILL_MARGIN_DP);
        cl.topMargin = dp(EMOJI_PILL_TOP_DP);   // same top padding as the emoji search pill
        sugAlt.addView(clearWrap, cl);

        // The list runs from the very top of the keyboard (under the header) to the very bottom of the window (under
        // the footer). Only the header blurs it here; the footer's own progressive blur covers the bottom (v3.119).
        EdgeBlurLayout holder = new EdgeBlurLayout(this, sugHeightPx, accessoryHeightPx);
        holder.alwaysTop = true;   // v3.103: the header always blurs what passes under it
        holder.noBottom = true;    // v3.118: no bottom blur in the clipboard panel; only the universal footer has one
        clipHolderView = holder;
        clipList = new ListView(this);
        holder.list = clipList;
        // v3.101: the first tile starts a gap below the header buttons (the list still scrolls under the header)
        int clipHeaderBottom = Math.max(sugHeightPx, Math.round(dp(EMOJI_PILL_TOP_DP)) + btnH);
        // v3.119: the last tile can scroll to just above the footer, so the footer's blur only covers empty space below it
        clipList.setPadding(0, clipHeaderBottom + dp(CLIP_HEADER_GAP_DP), 0, accessoryHeightPx);
        clipList.setClipToPadding(false);
        clipList.setDivider(null);
        clipList.setVerticalScrollBarEnabled(false);
        clipList.setOverScrollMode(View.OVER_SCROLL_NEVER);
        // The soft blur transition at the top and bottom edge is drawn by EdgeBlurLayout (see below).
        clipList.setVerticalFadingEdgeEnabled(false);
        clipList.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState != SCROLL_STATE_IDLE) {
                    dismissClipMenu();
                }
            }

            @Override
            public void onScroll(AbsListView view, int first, int visible, int total) {
            }
        });
        clipList.setSelector(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        clipAdapter = new ClipAdapter();
        clipList.setAdapter(clipAdapter);
        holder.addView(clipList, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        clipEmpty = new TextView(this);
        clipEmpty.setText("Nothing copied yet.\nText you copy will show up here.");
        clipEmpty.setGravity(Gravity.CENTER);
        clipEmpty.setTypeface(uiFont);
        clipEmpty.setTextSize(TypedValue.COMPLEX_UNIT_PX, dp(14));
        clipEmpty.setTextColor(colors.dark ? 0x99FFFFFF : 0x99000000);
        clipEmpty.setPadding(0, sugHeightPx, 0, 0);   // centred between header and footer
        holder.addView(clipEmpty, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        // The key area stays four rows tall, so the keyboard never changes size; the holder reaches up over
        // the header (negative top margin) and down over the footer row (negative bottom margin).
        // v3.119: the holder also reaches down under the footer (negative bottom margin), so panels slide under it.
        // Its layout footprint stays the key area, so the keyboard keeps its height.
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, sugHeightPx + keyHeightPx * keyRows() + accessoryHeightPx);
        hlp.topMargin = -sugHeightPx;
        hlp.bottomMargin = -accessoryHeightPx;
        keysContainer.addView(holder, hlp);
        refreshClipList();
    }

    /**
     * Holds a scrolling list (clipboard, emoji). Content that scrolls into the top or bottom edge zone does not
     * get cut off: it melts into a progressive blur (sharp at the inner side, strongest at the outer edge) and
     * fades out. The two zones are as deep as the header and footer bars that sit on top of them.
     * The effect only grows as rows really scroll past an edge, so a list at rest looks completely sharp.
     * Android 12+ uses real blur (RenderEffect); older versions use the fade alone.
     * The blur is built from many thin strips (STEPS, pixel-snapped) whose radius and opacity change by a tiny
     * amount from one strip to the next, which reads as one smooth gradient with no visible horizontal lines.
     */
    private final class EdgeBlurLayout extends FrameLayout {
        private static final int STEPS = 64;   // thin strips (about 3 px each) so the blur steps cannot be seen as lines
        ListView list;
        boolean fixed;                         // emoji panel: blur always on, thin zones, cheap renderer
        boolean alwaysTop;                     // v3.103: clipboard header: the top blur is always on, not only while scrolling
        boolean noBottom;                      // v3.118: the clipboard list has no bottom blur of its own (the universal footer blurs)
        boolean footerOnly;                    // v3.119: only the bottom zone (the footer) blurs, at a fixed strength; no list
        private Object fast;                   // FastEdge, Android 12+
        private final float zoneTop;           // depth of the top zone (= header height)
        private final float zoneBottom;        // depth of the bottom zone (= footer height)
        private final float maxBlur = dp(16);   // blur radius at the very edge
        private final Paint maskPaint = new Paint();
        private Object engine;   // BlurEngine, only created on Android 12+

        EdgeBlurLayout(Context c, float zoneTopPx, float zoneBottomPx) {
            super(c);
            zoneTop = Math.max(1f, zoneTopPx);
            zoneBottom = Math.max(1f, zoneBottomPx);
            maskPaint.setXfermode(new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.DST_IN));
        }

        private float clamp01(float v) {
            return Math.max(0f, Math.min(1f, v));
        }

        /** smoothstep: starts and ends with zero slope, so the effect eases in instead of switching on. */
        private float ease(float v) {
            return v * v * (3f - 2f * v);
        }

        private float topStrength() {
            ListView lv = list;
            if (lv == null || lv.getChildCount() == 0) return 0f;
            if (lv.getFirstVisiblePosition() > 0) return 1f;
            return ease(clamp01((lv.getPaddingTop() - lv.getChildAt(0).getTop()) / zoneTop));
        }

        private float bottomStrength() {
            ListView lv = list;
            if (lv == null || lv.getChildCount() == 0) return 0f;
            if (lv.getLastVisiblePosition() < lv.getCount() - 1) return 1f;
            View last = lv.getChildAt(lv.getChildCount() - 1);
            return ease(clamp01((last.getBottom() - (lv.getHeight() - lv.getPaddingBottom())) / zoneBottom));
        }

        void superDispatchDraw(Canvas c) {
            super.dispatchDraw(c);
        }

        /**
         * v3.119: the universal footer. Only the bottom zone (the footer height) blurs, always at full strength:
         * strong at the screen edge, fading to sharp at the top of the footer. Everything above it is drawn as is.
         * Android 12+ uses the cheap three-level blur; older versions fade the content out instead.
         */
        private void drawFooterZone(Canvas canvas) {
            int w = getWidth();
            int h = getHeight();
            float bz = Math.min(zoneBottom, h * 0.45f);
            if (w <= 0 || h <= 0 || bz <= 0.5f) {
                super.dispatchDraw(canvas);
                return;
            }
            if (Build.VERSION.SDK_INT >= 31 && canvas.isHardwareAccelerated()) {
                try {
                    if (fast == null) {
                        fast = new FastEdge(dp(5), dp(15));
                    }
                    ((FastEdge) fast).draw(this, canvas, w, h, 0f, bz);
                    return;
                } catch (Throwable t) {
                    fast = null;   // fall through to the plain fade
                }
            }
            int layer = canvas.saveLayer(0, 0, w, h, null);
            super.dispatchDraw(canvas);
            final int n = 8;
            int[] cols = new int[n + 1];
            float[] pos = new float[n + 1];
            for (int i = 0; i <= n; i++) {
                float t = i / (float) n;                 // 0 = top of the footer zone, 1 = screen edge
                cols[i] = Color.argb((int) (255 * (1f - ease(t))), 0, 0, 0);
                pos[i] = 1f - (bz / h) * (1f - t);
            }
            maskPaint.setShader(new LinearGradient(0, 0, 0, h, cols, pos, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, maskPaint);
            canvas.restoreToCount(layer);
        }

        @Override
        protected void dispatchDraw(Canvas canvas) {
            if (footerOnly) {
                drawFooterZone(canvas);
                return;
            }
            float sTop = (fixed || alwaysTop) ? 1f : topStrength();
            float sBot = noBottom ? 0f : (fixed ? 1f : bottomStrength() * CLIP_BOTTOM_BLUR_SCALE);
            int w = getWidth();
            int h = getHeight();
            if (sTop <= 0.001f && sBot <= 0.001f || w <= 0 || h <= 0) {
                super.dispatchDraw(canvas);
                return;
            }
            // the blur / fade zones reach past the header / footer bars into the list, so the content fades out softly
            // instead of being cut at the bar's edge (at rest the strength is 0, so nothing there is blurred)
            float zs = fixed ? 1f : EDGE_ZONE_SCALE;   // the emoji blur zones are exactly as deep as the bars
            float bzTop = Math.min(zoneTop * zs, h * 0.45f);
            float zsBot = fixed ? 1f : CLIP_BOTTOM_ZONE_SCALE;
            float bzBot = noBottom ? 0f : Math.min(zoneBottom * zsBot, h * 0.45f);
            if (fixed && Build.VERSION.SDK_INT >= 31 && canvas.isHardwareAccelerated()) {
                try {
                    if (fast == null) {
                        fast = new FastEdge(dp(5), dp(15));
                    }
                    ((FastEdge) fast).draw(this, canvas, w, h, bzTop, bzBot);
                    return;
                } catch (Throwable t) {
                    fast = null; // fall through to the plain fade
                }
            } else if (!fixed && Build.VERSION.SDK_INT >= 31 && canvas.isHardwareAccelerated()) {
                try {
                    if (engine == null) {
                        engine = new BlurEngine();
                    }
                    ((BlurEngine) engine).draw(this, canvas, w, h, sTop, sBot, bzTop, bzBot, maxBlur, STEPS);
                    return;
                } catch (Throwable t) {
                    engine = null; // fall through to the plain fade
                }
            }
            int layer = canvas.saveLayer(0, 0, w, h, null);
            super.dispatchDraw(canvas);
            float zfTop = bzTop / h;
            float zfBot = bzBot / h;
            final int n = 8;   // eased fade: several stops instead of one straight ramp
            int[] cols = new int[2 * (n + 1)];
            float[] pos = new float[2 * (n + 1)];
            for (int i = 0; i <= n; i++) {
                float t = i / (float) n;                          // 0 = outer edge, 1 = inner side
                cols[i] = Color.argb((int) (255 * (1f - sTop * ease(1f - t))), 0, 0, 0);
                pos[i] = zfTop * t;
                cols[n + 1 + i] = Color.argb((int) (255 * (1f - sBot * ease(t))), 0, 0, 0);
                pos[n + 1 + i] = 1f - zfBot * (1f - t);
            }
            maskPaint.setShader(new LinearGradient(0, 0, 0, h, cols, pos, Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, maskPaint);
            canvas.restoreToCount(layer);
        }
    }

    /**
     * Cheap progressive edge blur for the emoji list (Android 12+). The list is recorded once per frame; each edge
     * zone then cross-fades three versions of it: sharp, a light blur and a strong blur, each through a cached
     * gradient mask. That is 4 small blurs per frame instead of 128 re-recorded strips, which is what made
     * scrolling lag.
     */
    @android.annotation.TargetApi(31)
    private static final class FastEdge {
        private final android.graphics.RenderNode content = new android.graphics.RenderNode("emojiContent");
        private final android.graphics.RenderNode[] mid = new android.graphics.RenderNode[2];
        private final android.graphics.RenderNode[] far = new android.graphics.RenderNode[2];
        private final Paint[] pSharp = new Paint[2];
        private final Paint[] pMid = new Paint[2];
        private final Paint[] pFar = new Paint[2];
        private final float rFar;
        private int cw = -1;
        private int ch = -1;
        private float czt = -1;
        private float czb = -1;

        FastEdge(float rMid, float rFar) {
            this.rFar = rFar;
            for (int i = 0; i < 2; i++) {
                mid[i] = new android.graphics.RenderNode("emojiMid" + i);
                far[i] = new android.graphics.RenderNode("emojiFar" + i);
                mid[i].setRenderEffect(android.graphics.RenderEffect.createBlurEffect(rMid, rMid, Shader.TileMode.CLAMP));
                far[i].setRenderEffect(android.graphics.RenderEffect.createBlurEffect(rFar, rFar, Shader.TileMode.CLAMP));
                pSharp[i] = maskPaint();
                pMid[i] = maskPaint();
                pFar[i] = maskPaint();
            }
        }

        private static Paint maskPaint() {
            Paint p = new Paint();
            p.setXfermode(new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.DST_IN));
            return p;
        }

        private static float smooth(float t) {
            t = Math.max(0f, Math.min(1f, t));
            return t * t * (3f - 2f * t);
        }

        /** Opacity of a layer at `depth` (0 = inner edge of the zone, 1 = outer edge of the keyboard). */
        private static float alpha(int kind, float depth) {
            switch (kind) {
                case 0:  return 1f - smooth(depth / 0.7f);                                   // sharp
                case 1:  return depth < 0.5f ? smooth(depth / 0.5f) : 1f - smooth((depth - 0.5f) / 0.5f);   // light blur
                default: return 0.94f * smooth((depth - 0.2f) / 0.8f);                       // strong blur
            }
        }

        private static Shader grad(float y0, float y1, boolean topZone, int kind) {
            final int n = 16;
            int[] c = new int[n + 1];
            float[] pos = new float[n + 1];
            for (int i = 0; i <= n; i++) {
                float p = i / (float) n;
                float depth = topZone ? 1f - p : p;
                c[i] = Color.argb(Math.round(255f * alpha(kind, depth)), 0, 0, 0);
                pos[i] = p;
            }
            return new LinearGradient(0, y0, 0, y1, c, pos, Shader.TileMode.CLAMP);
        }

        private void ensureMasks(int w, int h, float zt, float zb) {
            if (w == cw && h == ch && zt == czt && zb == czb) {
                return;
            }
            cw = w;
            ch = h;
            czt = zt;
            czb = zb;
            if (zt > 0.5f) {   // v3.119: no top zone in the footer-only layer
                pSharp[0].setShader(grad(0, zt, true, 0));
                pMid[0].setShader(grad(0, zt, true, 1));
                pFar[0].setShader(grad(0, zt, true, 2));
            }
            pSharp[1].setShader(grad(h - zb, h, false, 0));
            pMid[1].setShader(grad(h - zb, h, false, 1));
            pFar[1].setShader(grad(h - zb, h, false, 2));
        }

        void draw(EdgeBlurLayout host, Canvas canvas, int w, int h, float zt, float zb) {
            content.setPosition(0, 0, w, h);
            Canvas rec = content.beginRecording(w, h);
            try {
                host.superDispatchDraw(rec);
            } finally {
                content.endRecording();
            }
            ensureMasks(w, h, zt, zb);
            // the clear window in the middle: the list, drawn as is
            canvas.save();
            canvas.clipRect(0, zt, w, h - zb);
            canvas.drawRenderNode(content);
            canvas.restore();
            if (zt > 0.5f) {
                zone(canvas, 0, w, h, 0f, zt);
            }
            zone(canvas, 1, w, h, h - zb, h);
        }

        private void zone(Canvas canvas, int i, int w, int h, float y0, float y1) {
            int pad = (int) Math.ceil(rFar * 2.5f);
            int ny0 = Math.max(0, (int) y0 - pad);
            int ny1 = Math.min(h, (int) Math.ceil(y1) + pad);
            record(mid[i], w, ny0, ny1);
            record(far[i], w, ny0, ny1);
            layer(canvas, content, pSharp[i], w, y0, y1);
            layer(canvas, mid[i], pMid[i], w, y0, y1);
            layer(canvas, far[i], pFar[i], w, y0, y1);
        }

        private void record(android.graphics.RenderNode node, int w, int ny0, int ny1) {
            node.setPosition(0, ny0, w, ny1);
            Canvas rc = node.beginRecording(w, ny1 - ny0);
            try {
                rc.translate(0, -ny0);
                rc.drawRenderNode(content);
            } finally {
                node.endRecording();
            }
        }

        private void layer(Canvas canvas, android.graphics.RenderNode node, Paint mask, int w, float y0, float y1) {
            int sc = canvas.saveLayer(0, y0, w, y1, null);
            canvas.drawRenderNode(node);
            canvas.drawRect(0, y0, w, y1, mask);
            canvas.restoreToCount(sc);
        }
    }

    /** Android 12+: records the list once, then redraws the edge zones as thin strips with growing blur. */
    @android.annotation.TargetApi(31)
    private static final class BlurEngine {
        private final android.graphics.RenderNode content = new android.graphics.RenderNode("clipContent");
        private final android.graphics.RenderNode[] strips = new android.graphics.RenderNode[2 * 64];   // top + bottom zone, up to 64 strips each

        void draw(EdgeBlurLayout host, Canvas canvas, int w, int h, float sTop, float sBot,
                  float zoneTop, float zoneBot, float maxBlur, int steps) {
            content.setPosition(0, 0, w, h);
            Canvas rec = content.beginRecording(w, h);
            try {
                host.superDispatchDraw(rec);
            } finally {
                content.endRecording();
            }
            // sharp part in the middle; an edge zone is only taken out where its strip is drawn below
            canvas.save();
            canvas.clipRect(0, sTop > 0.001f ? zoneTop : 0, w, sBot > 0.001f ? h - zoneBot : h);
            canvas.drawRenderNode(content);
            canvas.restore();
            steps = Math.min(steps, 64);
            float shTop = zoneTop / steps;
            float shBot = zoneBot / steps;
            int k = 0;
            for (int i = 0; i < steps; i++) {
                float inner = (i + 0.5f) / steps;               // 0 = outer edge, 1 = inner side
                // strip edges are snapped to whole pixels: two neighbouring strips that meet inside a pixel would
                // both be anti-aliased there and leave a faint line
                if (sTop > 0.001f) {
                    strip(canvas, k++, w, h, Math.round(i * shTop), Math.round((i + 1) * shTop), inner, sTop, maxBlur);
                }
                if (sBot > 0.001f) {
                    strip(canvas, k++, w, h, Math.round(h - (i + 1) * shBot), Math.round(h - i * shBot), inner, sBot, maxBlur);
                }
            }
        }

        private static float smooth(float t) {
            return t * t * (3f - 2f * t);
        }

        private static float smoother(float t) {
            return t * t * t * (t * (6f * t - 15f) + 10f);
        }

        private void strip(Canvas canvas, int k, int w, int h, float y0, float y1,
                           float inner, float strength, float maxBlur) {
            float depth = 1f - inner;                            // 1 at the outer edge, 0 at the inner side
            if (y1 <= y0) {
                return;
            }
            // eased curves (zero slope at the inner side): the blur grows slowly at first, so there is no visible
            // start line, and the content fades out gradually instead of being cut off at the edge
            float radius = maxBlur * smoother(depth) * strength;
            float alpha = 1f - strength * smooth(depth);
            int pad = (int) Math.ceil(radius * 2.5f);
            int ny0 = Math.max(0, (int) y0 - pad);
            int ny1 = Math.min(h, (int) Math.ceil(y1) + pad);
            android.graphics.RenderNode node = strips[k];
            if (node == null) {
                node = new android.graphics.RenderNode("clipStrip" + k);
                strips[k] = node;
            }
            node.setPosition(0, ny0, w, ny1);
            Canvas rc = node.beginRecording(w, ny1 - ny0);
            try {
                rc.translate(0, -ny0);
                rc.drawRenderNode(content);
            } finally {
                node.endRecording();
            }
            node.setRenderEffect(radius > 0.5f
                    ? android.graphics.RenderEffect.createBlurEffect(radius, radius, Shader.TileMode.CLAMP) : null);
            node.setAlpha(alpha);
            canvas.save();
            canvas.clipRect(0, y0, w, y1);
            canvas.drawRenderNode(node);
            canvas.restore();
        }
    }

    private void refreshClipList() {
        dismissClipMenu();
        if (clipAdapter == null || layer != LAYER_CLIP) {
            return;
        }
        List<ClipItem> l = clipDisplayList();
        clipAdapter.set(l);
        if (clipEmpty != null) {
            clipEmpty.setVisibility(l.isEmpty() ? View.VISIBLE : View.GONE);
        }
        if (clipClearKey != null) {
            clipClearKey.setAlpha(l.isEmpty() ? 0.35f : 1f);
        }
    }

    /** Back button, Back key, and after pasting: the panel sinks down, then the letters come back. */
    private void leaveClipboard() {
        dismissClipMenu();
        if (layer != LAYER_CLIP || clipClosing) {
            return;
        }
        clipClosing = true;
        sinkPanel(clipPanelViews(), new Runnable() {
            @Override
            public void run() {
                clipClosing = false;
                if (layer == LAYER_CLIP) {
                    setLayer(homeLayer());
                }
            }
        });
    }

    private void pasteClip(String text) {
        commitPlain(text);
        leaveClipboard();
    }


    /** Small pin / delete button on a history row. */
    private final class IconButton extends View {
        private final int icon;
        boolean active = false;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

        IconButton(int icon) {
            super(KeyboardService.this);
            this.icon = icon;
            setClickable(true);
            setSoundEffectsEnabled(false);
        }

        @Override
        public void setPressed(boolean pressed) {
            super.setPressed(pressed);
            setAlpha(pressed ? 0.4f : 1f);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            paint.setColor(active ? colors.accent : (colors.dark ? 0x99FFFFFF : 0x99000000));
            Icons.draw(canvas, icon, getWidth() / 2f, getHeight() / 2f, dp(17), paint);
        }
    }

    private final class ClipHolder {
        FrameLayout card;
        LinearLayout content;
        TextView text;
        IconButton pin;
        ClipItem item;
        boolean swallowTap;   // this touch only closed the long-press menu, so it must not paste
    }

    // -------------------------------------------------- long-press menu (Pin / Delete)
    /** Removes the header capsule and the list catcher, restores the title and the held tile. */
    private void dismissClipMenu() {
        try {
            if (clipGlide != null) {
                clipGlide.cancel();
                clipGlide = null;
            }
            boolean wasOpen = clipMenuBar != null && clipMenuBar.getParent() != null;
            detachView(clipMenuBar);
            detachView(clipMenuCatcher);
            clipMenuBar = null;
            clipMenuCatcher = null;
            if (clipTitle != null) {
                clipTitle.setVisibility(View.VISIBLE);
            }
            if (clipMenuCard != null) {
                clipMenuCard.setBackground(clipMenuCardBg);   // back to its normal tile
                clipMenuCardBg = null;
                clipMenuCard.setSelected(false);
                clipMenuCard = null;
            }
            if (wasOpen) {
                clipMenuClosedAt = SystemClock.uptimeMillis();
            }
        } catch (Throwable ignored) {
            // ignore
        }
    }

    private static void detachView(View v) {
        if (v != null && v.getParent() instanceof ViewGroup) {
            ((ViewGroup) v.getParent()).removeView(v);
        }
    }

    /** One half of the header capsule: a label centred in its half. */
    private TextView clipMenuHalf(String label, int color) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setTypeface(uiMedium);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, dp(16));
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setClickable(true);
        return t;
    }

    /**
     * Long-press on a clipboard tile: the header's title is replaced by a glass capsule split in two by a
     * line, Pin (or Unpin) on the left and Delete on the right. A touch on the list closes it.
     */
    private void showClipMenu(final View card, final ClipItem item) {
        dismissClipMenu();
        try {
            final int btnH = Math.round(dp(EMOJI_PILL_H_DP) * emojiScale());
            final int inset = dp(3);
            final int halfW = dp(CLIP_MENU_W_DP) / 2;
            // v3.89: one universal tint for the held tile and every press (Pin, Unpin, Delete): light grey in light
            // mode, white in dark mode. No green, blue or red.
            final int neutral = colors.dark ? 0xFFFFFFFF : 0xFF8E8E8E;   // grey / white, no hue

            // The outer capsule is the shell.
            FrameLayout shell = new FrameLayout(this);
            shell.setBackground(capsule());

            // The inner capsule is the highlight. It glides to whichever half is pressed.
            final View highlight = new View(this);
            final GradientDrawable hg = new GradientDrawable();   // its tint is set as it glides
            hg.setCornerRadius(dp(60));
            highlight.setBackground(hg);
            final int[] hlColor = {0};   // the highlight's current tint (0 = not shown yet)
            highlight.setAlpha(0f);   // shown on the first touch
            FrameLayout.LayoutParams hlp = new FrameLayout.LayoutParams(
                    halfW - 2 * inset, btnH - 2 * inset, Gravity.LEFT | Gravity.CENTER_VERTICAL);
            hlp.leftMargin = inset;
            shell.addView(highlight, hlp);

            // The two labels sit on top of the highlight, split by a line in the middle.
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            final TextView pinHalf = clipMenuHalf(item.pinned ? "Unpin" : "Pin", colors.text);
            final TextView delHalf = clipMenuHalf("Delete", CLIP_TINT_RED);   // v3.93: Delete label is red; only the highlight is neutral
            View div = new View(this);
            div.setBackgroundColor(colors.divider);
            // equal halves (weight 1 each), so the divider sits in the exact middle whatever the label
            row.addView(pinHalf, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                    Math.max(1, dp(0.75f)), ViewGroup.LayoutParams.MATCH_PARENT);
            dlp.topMargin = dp(10);
            dlp.bottomMargin = dp(10);
            row.addView(div, dlp);
            row.addView(delHalf, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
            shell.addView(row, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            pinHalf.setOnTouchListener(clipGlideOnTouch(highlight, hg, hlColor, delHalf, halfW, 0f, neutral));
            delHalf.setOnTouchListener(clipGlideOnTouch(highlight, hg, hlColor, delHalf, halfW, halfW, neutral));

            pinHalf.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(final View v) {
                    clipActionAfterGlide(new Runnable() {
                        @Override
                        public void run() {
                            feedback(v, T_SHIFT);
                            dismissClipMenu();
                            clipTogglePin(item);
                            refreshClipList();
                        }
                    });
                }
            });
            delHalf.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(final View v) {
                    clipActionAfterGlide(new Runnable() {
                        @Override
                        public void run() {
                            feedback(v, T_DELETE);
                            dismissClipMenu();
                            clipRemove(item);
                            refreshClipList();
                        }
                    });
                }
            });

            // Fixed size, centred in the header where the title was.
            FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(
                    dp(CLIP_MENU_W_DP), btnH, Gravity.CENTER_HORIZONTAL);
            bp.topMargin = dp(EMOJI_PILL_TOP_DP);
            sugAlt.addView(shell, bp);
            clipMenuBar = shell;
            if (clipTitle != null) {
                clipTitle.setVisibility(View.GONE);
            }

            // A touch on the list (outside the capsule) closes the capsule. The header and footer stay reachable.
            View catcher = new View(this);
            catcher.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent ev) {
                    if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
                        dismissClipMenu();
                    }
                    return true;
                }
            });
            FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            cp.topMargin = sugHeightPx;
            cp.bottomMargin = accessoryHeightPx;
            if (clipHolderView != null) {
                clipHolderView.addView(catcher, cp);
            }
            clipMenuCatcher = catcher;

            clipMenuCard = card;
            clipMenuCardBg = card.getBackground();
            clipTileColor = neutral;   // default: light grey (light mode), white (dark mode)
            applyTileTint(card, clipTileColor);
            card.setSelected(true);
        } catch (Throwable t) {
            dismissClipMenu();   // a missing capsule must never break the clipboard
        }
    }

    /** Touch-down over a half: the highlight glides to it and its tint shifts to that half's colour. */
    private View.OnTouchListener clipGlideOnTouch(final View highlight, final GradientDrawable hg,
                                                  final int[] cur, final TextView delLabel, final float halfW,
                                                  final float toX, final int toColor) {
        return new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent ev) {
                if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    highlight.setAlpha(1f);
                    if (cur[0] == 0) {
                        cur[0] = toColor;               // first showing: it appears on this half, no shift
                        applyHighlightTint(hg, toColor);
                    }
                    glideClipHighlight(highlight, hg, cur, delLabel, halfW, toX, toColor);
                }
                return false;                           // the tap still reaches the half's click listener
            }
        };
    }

    /** v3.93: the Delete label is red at all times. The highlight behind it stays neutral. */
    private void updateDeleteLabel(TextView delLabel, float x, float halfW) {
        delLabel.setTextColor(CLIP_TINT_RED);
    }

    /** Tints the held clipboard tile in the given colour (the same glass, coloured). */
    private void applyTileTint(View tile, int color) {
        if (tile == null) {
            return;
        }
        int rgb = color & 0x00FFFFFF;
        int top = colors.dark ? (rgb | 0x59000000) : (rgb | 0x4D000000);
        int bottom = colors.dark ? (rgb | 0x47000000) : (rgb | 0x3D000000);
        int rim = rgb | 0x66000000;
        tile.setBackground(new G2Drawable(top, bottom, rim, Math.max(1, dp(0.75f)),
                dp(CLIP_TILE_RADIUS_DP), CLIP_TILE_POWER));
    }

    /** Tints the highlight: a translucent fill and a rim in the given colour. */
    private void applyHighlightTint(GradientDrawable hg, int color) {
        int rgb = color & 0x00FFFFFF;
        hg.setColors(new int[]{rgb | 0x59000000, rgb | 0x47000000});
        hg.setStroke(Math.max(1, dp(0.75f)), rgb | 0x99000000);
    }

    /** Glides the highlight to x = toX while its tint shifts to toColor; the Delete label follows the highlight. */
    private void glideClipHighlight(final View highlight, final GradientDrawable hg, final int[] cur,
                                    final TextView delLabel, final float halfW,
                                    final float toX, final int toColor) {
        if (clipGlide != null) {
            clipGlide.cancel();
        }
        final float fromX = highlight.getTranslationX();
        final int fromColor = cur[0];
        final int tileFrom = clipTileColor;   // the tile's tint moves with the highlight's
        clipGlide = ValueAnimator.ofFloat(0f, 1f);
        clipGlide.setDuration(240);
        clipGlide.setInterpolator(new AccelerateDecelerateInterpolator());
        clipGlide.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator anim) {
                float p = (Float) anim.getAnimatedValue();
                highlight.setTranslationX(fromX + (toX - fromX) * p);
                updateDeleteLabel(delLabel, highlight.getTranslationX(), halfW);
                int c = (Integer) argbEvaluator.evaluate(p, fromColor, toColor);
                cur[0] = c;
                applyHighlightTint(hg, c);
                int tc = (Integer) argbEvaluator.evaluate(p, tileFrom, toColor);
                clipTileColor = tc;
                applyTileTint(clipMenuCard, tc);
            }
        });
        clipGlide.start();
    }

    /** Runs the action once the highlight has finished gliding to the tapped half (at once if it has already arrived). */
    private void clipActionAfterGlide(final Runnable action) {
        if (clipGlide != null && clipGlide.isRunning()) {
            clipGlide.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    action.run();
                }
            });
        } else {
            action.run();
        }
    }

    private final class ClipAdapter extends BaseAdapter {
        private List<ClipItem> data = new ArrayList<>();

        void set(List<ClipItem> d) {
            data = d;
            notifyDataSetChanged();
        }

        @Override
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int position) {
            return data.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        private LinearLayout buildRow() {
            final ClipHolder h = new ClipHolder();
            LinearLayout outer = new LinearLayout(KeyboardService.this);
            outer.setPadding(insetH, insetV, insetH, insetV);   // same gap as between keys
            outer.setLayoutParams(new AbsListView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            FrameLayout card = new FrameLayout(KeyboardService.this);
            card.setMinimumHeight(keyHeightPx - 2 * insetV);
            StateListDrawable bg = new StateListDrawable();
            bg.addState(new int[]{android.R.attr.state_pressed}, tileGlass(true));
            bg.addState(new int[]{android.R.attr.state_selected}, tileGlass(true));
            bg.addState(new int[]{}, tileGlass(false));
            card.setBackground(bg);
            card.setClickable(true);
            h.card = card;

            // two-line preview (+ pin mark)
            LinearLayout content = new LinearLayout(KeyboardService.this);
            content.setOrientation(LinearLayout.HORIZONTAL);
            content.setGravity(Gravity.CENTER_VERTICAL);
            TextView tv = new TextView(KeyboardService.this);
            tv.setTypeface(uiFont);
            tv.setTextColor(colors.text);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, dp(15));
            tv.setMaxLines(2);
            tv.setEllipsize(TextUtils.TruncateAt.END);
            tv.setPadding(dp(14), dp(9), dp(8), dp(9));
            h.text = tv;
            h.pin = new IconButton(Icons.PIN);
            h.pin.setClickable(false);
            content.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            content.addView(h.pin, new LinearLayout.LayoutParams(dp(30), dp(30)));
            ((LinearLayout.LayoutParams) h.pin.getLayoutParams()).rightMargin = dp(8);
            h.content = content;
            FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            clp.gravity = Gravity.CENTER_VERTICAL;
            card.addView(content, clp);

            outer.addView(card, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            // A touch that lands right after the menu was closed by touching outside it only closes the menu.
            card.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent ev) {
                    if (ev.getActionMasked() == MotionEvent.ACTION_DOWN) {
                        h.swallowTap = SystemClock.uptimeMillis() - clipMenuClosedAt < 150;
                    }
                    return false;
                }
            });
            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (h.swallowTap) {
                        h.swallowTap = false;
                        return;
                    }
                    feedback(v, T_CHAR);
                    if (h.item != null) {
                        pasteClip(h.item.text);          // tap: paste and go back to the letters
                    }
                }
            });
            card.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    if (h.item == null) {
                        return false;
                    }
                    feedback(v, T_SHIFT);
                    showClipMenu(v, h.item);             // long press: pop-up with Pin / Delete
                    return true;
                }
            });
            outer.setTag(h);
            return outer;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            LinearLayout row = (convertView instanceof LinearLayout) ? (LinearLayout) convertView : buildRow();
            ClipHolder h = (ClipHolder) row.getTag();
            ClipItem it = data.get(position);
            h.item = it;
            h.text.setText(it.text.trim());
            h.pin.setVisibility(it.pinned ? View.VISIBLE : View.GONE);
            h.pin.active = it.pinned;
            h.pin.invalidate();
            h.card.setSelected(false);
            return row;
        }
    }

    // ------------------------------------------------------------------ key view
    /**
     * A key. It paints its own label every time it is drawn, using the live shift / caps state, so
     * letters always show lowercase or uppercase exactly as they will be typed.
     */
    private final class KeyView extends View {
        final Key key;
        private final boolean plain;
        private final Paint labelPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Rect textBounds = new Rect();
        private boolean cancelled = false;
        private boolean longPressFired = false;
        private boolean swiped = false;
        private float lastStepX = 0f;
        private boolean trackpad = false;      // holding the space bar still turned it into a cursor trackpad
        private float downRawX = 0f, downRawY = 0f;
        private float lastRawX = 0f, lastRawY = 0f;
        private float tpAccX = 0f, tpAccY = 0f;
        private float glow = 0f;                 // 0..1, press glow
        private boolean fxDown = false;
        private ValueAnimator glowAnim;
        private final Path glowPath = new Path();
        private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private boolean holdLit = false;         // v3.114: the corner pop-up keeps this key's built-in press circle lit

        /** v3.114: lights (or fades out) the key's built-in circle while the corner pop-up is open. */
        void setHoldLit(boolean v) {
            if (holdLit == v) {
                return;
            }
            holdLit = v;
            if (glowAnim != null) {
                glowAnim.cancel();
            }
            if (v) {
                glow = 1f;
                invalidate();
                return;
            }
            glowAnim = ValueAnimator.ofFloat(glow, 0f);
            glowAnim.setDuration(420);
            glowAnim.setInterpolator(new DecelerateInterpolator());
            glowAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator a) {
                    glow = (Float) a.getAnimatedValue();
                    invalidate();
                }
            });
            glowAnim.start();
        }

        /** Tactile press: the key squeezes in quickly, then springs back with a little bounce; a glow follows. */
        private void pressFx(boolean down) {
            if (fxDown == down) {
                return;
            }
            fxDown = down;
            animate().cancel();
            if (down) {
                animate().scaleX(PRESS_SCALE).scaleY(PRESS_SCALE).setDuration(70)
                        .setInterpolator(new DecelerateInterpolator()).start();
            } else {
                animate().scaleX(1f).scaleY(1f).setDuration(380)
                        .setInterpolator(new OvershootInterpolator(3.2f)).start();
            }
            if (!down && holdLit) {
                return;       // v3.114: the pop-up keeps the press circle lit until it closes
            }
            if (glowAnim != null) {
                glowAnim.cancel();
            }
            glowAnim = ValueAnimator.ofFloat(glow, down ? 1f : 0f);
            glowAnim.setDuration(down ? 90 : 420);
            glowAnim.setInterpolator(new DecelerateInterpolator());
            glowAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator a) {
                    glow = (Float) a.getAnimatedValue();
                    invalidate();
                }
            });
            glowAnim.start();
        }

        /** Soft light inside the key plus a thin halo around it (kept within the key's own inset). */
        private void drawGlow(Canvas c) {
            int base = (key.type == T_ENTER && primaryAction()) ? Color.WHITE : colors.accent;
            float w = getWidth();
            float h = getHeight();
            glowPaint.setShader(null);
            if (plain) {
                float cxp = w * (0.5f + key.iconShift);
                float r = dp(26);
                glowPaint.setStyle(Paint.Style.FILL);
                glowPaint.setShader(new RadialGradient(cxp, h / 2f, r, scaleAlpha(base, 0.34f * glow),
                        scaleAlpha(base, 0f), Shader.TileMode.CLAMP));
                c.drawCircle(cxp, h / 2f, r, glowPaint);
                glowPaint.setShader(null);
                return;
            }
            float l = insetH + dp(key.padL);
            float t = insetV;
            float r2 = w - insetH - dp(key.padR);
            float b = h - insetV;
            g2Rect(glowPath, l, t, r2, b, dp(KEY_RADIUS_DP), G2_POWER);
            glowPaint.setStyle(Paint.Style.FILL);
            glowPaint.setShader(new RadialGradient((l + r2) / 2f, (t + b) / 2f, Math.max(r2 - l, b - t) * 0.7f,
                    scaleAlpha(base, 0.30f * glow), scaleAlpha(base, 0.05f * glow), Shader.TileMode.CLAMP));
            c.drawPath(glowPath, glowPaint);
            glowPaint.setShader(null);
            glowPaint.setStyle(Paint.Style.STROKE);
            for (int k = 1; k <= 4; k++) {
                glowPaint.setStrokeWidth(dp(1.4f * k));
                glowPaint.setColor(scaleAlpha(base, 0.22f * glow / k));
                c.drawPath(glowPath, glowPaint);
            }
        }

        private android.graphics.drawable.GradientDrawable pressDisc;   // built on first use

        /** Glass circle (same gradient and rim as the glass disc of the emoji bar), fading with the press glow. */
        private void drawPressCircle(Canvas c, float cx, float cy) {
            float d = Math.min(dp(PRESS_CIRCLE_DP), Math.min(getWidth(), getHeight()) - dp(2));
            if (d <= 0f || glow <= 0f) {
                return;
            }
            if (pressDisc == null) {
                pressDisc = new android.graphics.drawable.GradientDrawable(
                        android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                        colors.dark ? new int[]{0x59FFFFFF, 0x3DFFFFFF} : new int[]{0xB3FFFFFF, 0x80FFFFFF});
                pressDisc.setShape(android.graphics.drawable.GradientDrawable.OVAL);
                pressDisc.setStroke(Math.max(1, dp(0.75f)), colors.dark ? 0x40FFFFFF : 0xB3FFFFFF);
            }
            pressDisc.setAlpha(Math.round(255f * Math.min(1f, glow)));
            int half = Math.round(d / 2f);
            pressDisc.setBounds(Math.round(cx) - half, Math.round(cy) - half,
                    Math.round(cx) + half, Math.round(cy) + half);
            pressDisc.draw(c);
        }

        private final Runnable longPressRunnable = new Runnable() {
            @Override
            public void run() {
                if (key.cornerLeft) {
                    longPressFired = true;          // v3.108: the lower-left corner opens the pop-up
                    openCornerPopup(KeyView.this);
                } else if (key.alt != null && Prefs.on(prefs, Prefs.K_HOLD_SYMBOLS)) {
                    longPressFired = true;
                    showCallout(KeyView.this, key.alt);
                    typeChar(key.alt, false);
                } else if (key.type == T_TO_EMOJI) {
                    longPressFired = true;
                    showKeyboardPicker(); // hold the emoji key to switch keyboards
                }
            }
        };

        private final Runnable trackpadRunnable = new Runnable() {
            @Override
            public void run() {
                if (key.type == T_SPACE && !cancelled && !swiped) {
                    trackpad = true;
                    longPressFired = true;
                    tpAccX = 0f;
                    tpAccY = 0f;
                    enterTrackpad();
                }
            }
        };

        private final Runnable repeatRunnable = new Runnable() {
            @Override
            public void run() {
                handleDelete();
                playSound(KeySounds.DELETE);
                handler.postDelayed(this, 45);
            }
        };

        KeyView(Key k, boolean plainKey) {
            super(KeyboardService.this);
            key = k;
            plain = plainKey;
            setSoundEffectsEnabled(false);
            setContentDescription(describe(k));

            boolean blue = k.type == T_ENTER && primaryAction();
            labelPaint.setTypeface(uiFont);
            labelPaint.setColor(blue ? Color.WHITE : colors.text);
            if (k.type == T_CLIP_CLEAR) {
                labelPaint.setColor(colors.accent);
            }
            if (k.type == T_SPACE) {
                labelPaint.setTextAlign(Paint.Align.RIGHT);
                labelPaint.setTextSize(dp(10.5f));
                labelPaint.setColor(colors.dark ? 0x99FFFFFF : 0x99000000);
            } else {
                labelPaint.setTextAlign(Paint.Align.CENTER);
                float size;
                if (k.textDp > 0f) {
                    size = k.textDp;
                } else if (k.type == T_CHAR) {
                    size = k.label.length() == 1 ? CHAR_LABEL_DP : 16f;   // letters and numbers share one size
                } else if (k.type == T_TO_SYMBOLS1 || k.type == T_TO_SYMBOLS2 || k.type == T_TO_LETTERS
                        || k.type == T_ENTER) {
                    size = 18f;
                } else {
                    size = 17f;
                }
                labelPaint.setTextSize(dp(size) * Prefs.fontScale(prefs) / 100f);
            }

            if (plain) {
                setBackground(null);
            } else {
                int fill = colors.key;
                int pressed = colors.keyPressed;
                if (blue) {
                    fill = colors.accent;
                    pressed = darken(colors.accent);
                }
                setBackground(keyBackground(fill, pressed, !blue, dp(k.padL), dp(k.padR)));
            }
        }

        String displayLabel() {
            if (key.letter) {
                return (shifted || capsLock)
                        ? key.label.toUpperCase(Locale.ROOT)
                        : key.label.toLowerCase(Locale.ROOT);
            }
            return key.label;
        }

        private String describe(Key k) {
            switch (k.type) {
                case T_SHIFT: return "Shift";
                case T_DELETE: return "Delete";
                case T_ENTER: return "Enter";
                case T_SPACE: return "Space";
                case T_GLOBE: return "Switch keyboard";
                case T_MIC: return "Voice typing";
                case T_TO_EMOJI: return "Emoji. Hold to switch keyboard";
                case T_TO_SYMBOLS1: return "Numbers";
                case T_TO_SYMBOLS2: return "More symbols";
                case T_TO_LETTERS: return "Letters";
                case T_TO_CLIP: return "Clipboard";
                case T_CLIP_CLOSE: return "Back to keyboard";
                case T_CLIP_CLEAR: return "Clear all clipboard history";
                default: return k.label;
            }
        }

        /** Frosted glass on: outline icons. Frosted glass off (solid keyboard): solid icons. Globe, emoji and dictation only. */
        private int styleIcon(int g) {
            boolean outline = true;   // outline icons only, whatever the frosted glass setting
            switch (g) {
                case G_EMOJI:
                case G_EMOJI_LINE:
                    return outline ? G_EMOJI_LINE : G_EMOJI;
                case G_MIC:
                case G_MIC_LINE:
                    return outline ? G_MIC_LINE : G_MIC;
                case G_GLOBE:
                case G_GLOBE_SOLID:
                    return outline ? G_GLOBE : G_GLOBE_SOLID;
                case G_CLIP:
                case G_CLIP_LINE:
                    return G_CLIP_LINE;
                default:
                    return g;
            }
        }

        /** Shift, delete and return are drawn by drawGlyph (iOS shapes), not by the shared Icons set. */
        private int ownGlyph(int icon) {
            if (key.type == T_SHIFT) {
                return capsLock ? G_CAPS : (shifted ? G_SHIFT_ON : G_SHIFT);
            }
            if (key.type == T_DELETE) {
                return G_DELETE;
            }
            if (key.type == T_ENTER && icon != Icons.NONE) {
                return icon == Icons.SEARCH ? G_SEARCH : G_RETURN;
            }
            return icon;
        }

        private int currentIcon() {
            if (key.type == T_SHIFT) {
                return capsLock ? Icons.CAPS : (shifted ? Icons.SHIFT_ON : Icons.SHIFT);
            }
            return key.icon;
        }

        private boolean showsCallout() {
            return key.type == T_CHAR && key.label.length() == 1 && Prefs.on(prefs, Prefs.K_POPUP);
        }

        private String calloutLabel() {
            if (key.letter) {
                return (shifted || capsLock)
                        ? key.text.toUpperCase(Locale.ROOT)
                        : key.text.toLowerCase(Locale.ROOT);
            }
            return key.text;
        }

        private boolean outside(MotionEvent e) {
            float s = dp(28);
            return e.getX() < -s || e.getX() > getWidth() + s
                    || e.getY() < -s || e.getY() > getHeight() + s;
        }

        private void cancelPending() {
            handler.removeCallbacks(longPressRunnable);
            handler.removeCallbacks(repeatRunnable);
            handler.removeCallbacks(trackpadRunnable);
        }

        @Override
        protected void onDetachedFromWindow() {
            cancelPending();
            if (trackpad) {
                trackpad = false;
                exitTrackpad();
            }
            dismissCallout(this);
            if (glowAnim != null) {
                glowAnim.cancel();
            }
            animate().cancel();
            setScaleX(1f);
            setScaleY(1f);
            fxDown = false;
            glow = 0f;
            super.onDetachedFromWindow();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas); // key background
            // The shift key tile never changes colour: only the arrow does (solid when on, outline when off).
            // press glow removed: the squeeze / bounce animation stays, the colour effect does not
            float cx = getWidth() * (0.5f + key.iconShift) + dp(key.padL - key.padR) / 2f;
            float cy = getHeight() / 2f;
            int icon = ownGlyph(currentIcon());
            if (icon >= GLYPH_BASE) {
                // one optical size per icon kind, the same on every key that shows it; always centred
                float gs = 22f;
                // glyph box = wanted height * 24 / (height the drawing really uses inside the 24 grid)
                if (icon == G_EMOJI) gs = TRAY_ICON_DP * 24f / 22f;
                else if (icon == G_MIC) gs = 26.6f * 24f / 21.05f;   // iOS mic: 17.5 x 26.6 dp
                else if (icon == G_GLOBE) gs = GLOBE_ICON_DP * 24f / 20f;
                else if (icon == G_MIC_LINE) gs = MIC_LINE_ICON_DP * 24f / 21.1f;
                else if (icon == G_CLIP || icon == G_CLIP_LINE) gs = GLOBE_ICON_DP * 24f / 20f;   // same size as the globe
                else if (icon == G_SHIFT || icon == G_SHIFT_ON || icon == G_CAPS) gs = 21.4f;   // 19.6 x 16.8 dp
                else if (icon == G_DELETE) gs = 21.2f;                                          // 19.6 x 16.8 dp
                else if (icon == G_RETURN) gs = 21.2f;                                          // 18.9 x 16.1 dp
                else if (icon == G_SEARCH && key.type == T_ENTER) gs = 23f;
                gs *= key.iconScale;   // v3.98: per-key scale (only the middle clipboard key uses it)
                boolean whiteIcon = key.type == T_ENTER && primaryAction();
                int iconColor = colors.text;
                if (key.type == T_TO_EMOJI || key.type == T_MIC || key.type == T_GLOBE || key.type == T_TO_CLIP) {
                    iconColor = colors.dark ? Color.WHITE : Color.BLACK;   // pure black, no grey (same as the other icons)
                }
                if (plain && (key.type == T_TO_EMOJI || key.type == T_TO_CLIP || key.type == T_MIC)) {
                    drawPressCircle(canvas, cx, cy);
                }
                drawGlyph(canvas, styleIcon(icon), cx, cy, dp(gs), whiteIcon ? Color.WHITE : iconColor);
                return;
            }
            if (icon != Icons.NONE) {
                boolean blue = key.type == T_ENTER && primaryAction();
                iconPaint.setColor(blue ? Color.WHITE : colors.text);
                float size = dp(plain ? 24 : 22);
                Icons.draw(canvas, icon, cx, cy, size, iconPaint);
                return;
            }
            String label = displayLabel();
            if (label == null || label.isEmpty()) {
                return;
            }
            if (key.type == T_SPACE) {
                float baseline = getHeight() - insetV - dp(7);
                canvas.drawText(label, getWidth() - insetH - dp(10), baseline, labelPaint);
                return;
            }
            // Same baseline for every key in the same case: centre the x-height (lowercase) or the
            // cap height (everything else) on the middle of the key.
            boolean lower = key.letter && !(shifted || capsLock);   // lowercase letters are centred on the x-height
            labelPaint.getTextBounds(lower ? "x" : "H", 0, 1, textBounds);
            float baseline = cy - (textBounds.top + textBounds.bottom) / 2f;
            canvas.drawText(label, cx, baseline, labelPaint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    setPressed(true);
                    pressFx(true);
                    if (plain) setAlpha(0.75f);
                    cancelled = false;
                    longPressFired = false;
                    swiped = false;
                    glideDeleteFired = false;
                    lastStepX = e.getX();
                    trackpad = false;
                    downRawX = lastRawX = e.getRawX();
                    downRawY = lastRawY = e.getRawY();
                    if (key.type == T_SPACE && Prefs.on(prefs, Prefs.K_GLIDE_CURSOR)) {
                        handler.postDelayed(trackpadRunnable, TP_HOLD_MS);
                    }
                    feedback(this, key.type);
                    if (showsCallout()) {
                        showCallout(this, calloutLabel());
                    }
                    if (key.type == T_DELETE) {
                        handleDelete();
                        handler.postDelayed(repeatRunnable, 380);
                    } else if (key.alt != null || key.cornerLeft || key.type == T_GLOBE || key.type == T_TO_EMOJI) {
                        handler.postDelayed(longPressRunnable, Prefs.holdMs(prefs));
                    }
                    return true;

                case MotionEvent.ACTION_MOVE:
                    if (glideOn) {
                        glideTrack(e.getRawX(), e.getRawY());
                        return true;
                    }
                    if (key.letter && !cancelled && Prefs.on(prefs, Prefs.K_GLIDE) && layer == LAYER_LETTERS
                            && !(Prefs.on(prefs, Prefs.K_FLICK) && key.alt != null)
                            && (Math.abs(e.getRawX() - downRawX) > dp(12) || Math.abs(e.getRawY() - downRawY) > dp(12))) {
                        cancelPending();
                        setPressed(false);
                        pressFx(false);
                        if (plain) setAlpha(1f);
                        dismissCallout(this);
                        glideBegin(this, downRawX, downRawY);
                        glideTrack(e.getRawX(), e.getRawY());
                        return true;
                    }
                    if (key.type == T_DELETE && Prefs.on(prefs, Prefs.K_GLIDE_DELETE) && !glideDeleteFired
                            && layer != LAYER_EMOJI_SEARCH
                            && e.getRawX() - downRawX < -dp(36) && Math.abs(e.getRawY() - downRawY) < dp(28)) {
                        glideDeleteFired = true;
                        handler.removeCallbacks(repeatRunnable);
                        deleteWordBefore();
                        return true;
                    }
                    if (key.type == T_SPACE && Prefs.on(prefs, Prefs.K_GLIDE_CURSOR)) {
                        float rx = e.getRawX();
                        float ry = e.getRawY();
                        float dRawX = rx - lastRawX;
                        float dRawY = ry - lastRawY;
                        lastRawX = rx;
                        lastRawY = ry;
                        if (trackpad) {
                            // trackpad: the finger's travel moves the cursor, left/right by letter, up/down by line
                            tpAccX += dRawX;
                            tpAccY += dRawY;
                            float sx = dp(TP_STEP_X_DP);
                            float sy = dp(TP_STEP_Y_DP);
                            while (tpAccX >= sx) { moveCursor(1); tpAccX -= sx; }
                            while (tpAccX <= -sx) { moveCursor(-1); tpAccX += sx; }
                            while (tpAccY >= sy) { moveCursorVertical(1); tpAccY -= sy; }
                            while (tpAccY <= -sy) { moveCursorVertical(-1); tpAccY += sy; }
                            return true;
                        }
                        if (Math.abs(rx - downRawX) > dp(TP_SLOP_DP) || Math.abs(ry - downRawY) > dp(TP_SLOP_DP)) {
                            handler.removeCallbacks(trackpadRunnable);   // it was a swipe, not a hold
                        }
                        float step = dp(14);
                        float x = e.getX();
                        while (x - lastStepX >= step) {
                            moveCursor(1);
                            lastStepX += step;
                            swiped = true;
                        }
                        while (lastStepX - x >= step) {
                            moveCursor(-1);
                            lastStepX -= step;
                            swiped = true;
                        }
                    } else if (!cancelled && !longPressFired && key.alt != null && Prefs.on(prefs, Prefs.K_FLICK)
                            && e.getRawY() - downRawY > dp(new int[]{26, 18, 10}[Prefs.flickSens(prefs)])) {
                        // flick keys: pull the key downward to type its hinted symbol / number
                        longPressFired = true;
                        handler.removeCallbacks(longPressRunnable);
                        showCallout(this, key.alt);
                        typeChar(key.alt, false);
                    } else if (!cancelled && outside(e)) {
                        cancelled = true;
                        cancelPending();
                        setPressed(false);
                        pressFx(false);
                        if (plain) setAlpha(1f);
                        dismissCallout(this);
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                    if (glideOn) {
                        setPressed(false);
                        pressFx(false);
                        if (plain) setAlpha(1f);
                        cancelPending();
                        dismissCallout(this);
                        glideEnd();
                        return true;
                    }
                    setPressed(false);
                    pressFx(false);
                    if (plain) setAlpha(1f);
                    cancelPending();
                    dismissCallout(this);
                    if (trackpad) {
                        trackpad = false;
                        exitTrackpad();
                        afterEdit();
                    } else if (key.type == T_DELETE) {
                        afterEdit();
                    } else if (!cancelled && !longPressFired && !swiped) {
                        onKeyTapped(key);
                    } else if (swiped) {
                        afterEdit();
                    }
                    return true;

                case MotionEvent.ACTION_CANCEL:
                    if (glideOn) {
                        glideCancel();
                        setPressed(false);
                        pressFx(false);
                        cancelPending();
                        dismissCallout(this);
                        return true;
                    }
                    setPressed(false);
                    pressFx(false);
                    if (plain) setAlpha(1f);
                    cancelPending();
                    dismissCallout(this);
                    if (trackpad) {
                        trackpad = false;
                        exitTrackpad();
                    }
                    return true;

                default:
                    return true;
            }
        }
    }

    // ------------------------------------------------------------ key handling
    /** The path drawn while gliding: a fading line over the keys, in keysHost coordinates. */
    private final class GlideTrailView extends View {
        private final Path path = new Path();
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int[] loc = new int[2];
        private boolean started = false;

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            // v3.88: a visible MATCH_PARENT child of a wrapping frame is measured against the whole screen, which
            // pushed the keyboard up into the ceiling during a glide. The trail takes exactly the key area's size.
            int w = 0, h = 0;
            if (keysContainer != null) {
                w = keysContainer.getMeasuredWidth();
                h = keysContainer.getMeasuredHeight();
            }
            setMeasuredDimension(w, h);
        }

        GlideTrailView(Context c) {
            super(c);
            setVisibility(GONE);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
        }

        void addPoint(float rx, float ry) {
            keysHost.getLocationOnScreen(loc);
            float x = rx - loc[0];
            float y = ry - loc[1];
            animate().cancel();
            setAlpha(1f);
            if (!started) {
                path.moveTo(x, y);
                started = true;
                setVisibility(VISIBLE);
            } else {
                path.lineTo(x, y);
            }
            invalidate();
        }

        void finish() {
            if (!started) return;
            animate().alpha(0f).setDuration(260).withEndAction(new Runnable() {
                @Override
                public void run() {
                    setVisibility(GONE);
                    setAlpha(1f);
                    path.reset();
                    started = false;
                }
            }).start();
        }

        @Override
        protected void onDraw(Canvas c) {
            int accent = colors.accent;
            paint.setColor((accent & 0x00FFFFFF) | 0xB3000000);   // accent colour at 70 %
            paint.setStrokeWidth(dp(7));
            c.drawPath(path, paint);
        }
    }

    /** Typing cost between letter pairs, from the centres of the letter keys on screen. */
    private void prepareGlide() {
        float pitch = 0f;
        float[] cx = new float[26];
        float[] cy = new float[26];
        int[] loc = new int[2];
        for (KeyView kv : letterViews) {
            String t = kv.key.text;
            if (t == null || t.length() != 1) continue;
            char c = Character.toLowerCase(t.charAt(0));
            if (c < 'a' || c > 'z') continue;
            kv.getLocationOnScreen(loc);
            cx[c - 'a'] = loc[0] + kv.getWidth() / 2f;
            cy[c - 'a'] = loc[1] + kv.getHeight() / 2f;
            pitch = Math.max(pitch, kv.getWidth());
        }
        glidePitch = pitch > 0f ? pitch : dp(36);
        for (int a = 0; a < 26; a++) {
            for (int b = 0; b < 26; b++) {
                float d = (float) Math.hypot(cx[a] - cx[b], cy[a] - cy[b]);
                glideSub[a][b] = Math.min(1.2f, 0.2f + 0.5f * d / glidePitch);
            }
        }
    }

    private void glideBegin(KeyView from, float downX, float downY) {
        glideOn = true;
        glideTrailOn = Prefs.on(prefs, Prefs.K_GLIDE_TRAIL);
        glideKeys.clear();
        prepareGlide();
        if (glideTrailOn && glideTrail != null) {
            glideTrail.addPoint(downX, downY);
        }
        glideAdd(from.key);
    }

    /** Called for each move while gliding: records the letter key nearest the finger. */
    private void glideTrack(float rx, float ry) {
        if (glideTrailOn && glideTrail != null) {
            glideTrail.addPoint(rx, ry);
        }
        KeyView best = null;
        float bestD = Float.MAX_VALUE;
        int[] loc = new int[2];
        for (KeyView kv : letterViews) {
            kv.getLocationOnScreen(loc);
            float dx = rx - (loc[0] + kv.getWidth() / 2f);
            float dy = ry - (loc[1] + kv.getHeight() / 2f);
            float d = dx * dx + dy * dy;
            if (d < bestD) {
                bestD = d;
                best = kv;
            }
        }
        float limit = glidePitch * 0.7f;
        if (best != null && bestD <= limit * limit) {
            glideAdd(best.key);
        }
    }

    private void glideAdd(Key k) {
        if (k.text == null || k.text.length() != 1) return;
        char c = Character.toLowerCase(k.text.charAt(0));
        if (c < 'a' || c > 'z') return;
        if (glideKeys.isEmpty() || glideKeys.get(glideKeys.size() - 1) != c) {
            glideKeys.add(c);
        }
    }

    private void glideEnd() {
        glideOn = false;
        if (glideTrail != null) glideTrail.finish();
        StringBuilder sb = new StringBuilder();
        for (char c : glideKeys) sb.append(c);
        glideKeys.clear();
        if (sb.length() == 0) {
            afterEdit();
            return;
        }
        if (sb.length() == 1) {
            typeChar(sb.toString(), true);   // a glide over one key is just a tap
            return;
        }
        List<String> best = suggester.glide(sb.toString(), glideSub, 1);
        if (best.isEmpty()) {
            afterEdit();
            return;
        }
        commitGlide(best.get(0));
    }

    private void glideCancel() {
        glideOn = false;
        glideKeys.clear();
        if (glideTrail != null) glideTrail.finish();
    }

    private void commitGlide(String w) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) {
            return;
        }
        if (capsLock) {
            w = w.toUpperCase(Locale.ROOT);
        } else if (shifted) {
            w = Character.toUpperCase(w.charAt(0)) + w.substring(1);
        }
        CharSequence before = ic.getTextBeforeCursor(1, 0);
        if (before != null && before.length() == 1 && Character.isLetterOrDigit(before.charAt(0))) {
            ic.commitText(" ", 1);
        }
        ic.commitText(w + " ", 1);
        if (Prefs.on(prefs, Prefs.K_LEARN)) {
            suggester.learn(w.toLowerCase(Locale.ROOT));
        }
        spaceAfterSuggestion = true;
        lastSpaceTime = 0;
        if (shifted && !capsLock) {
            shifted = false;
            updateShiftVisuals();
        }
        afterEdit();
    }

    /** Glide delete: removes the word before the cursor (and the spaces after it). */
    private void deleteWordBefore() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        CharSequence before = ic.getTextBeforeCursor(64, 0);
        if (before == null) return;
        int i = before.length();
        while (i > 0 && Character.isWhitespace(before.charAt(i - 1))) i--;
        while (i > 0 && !Character.isWhitespace(before.charAt(i - 1))) i--;
        int n = before.length() - i;
        if (n > 0) {
            ic.deleteSurroundingText(n, 0);
        }
        spaceAfterSuggestion = false;
        lastOwnEdit = SystemClock.uptimeMillis();
    }

    private void feedback(View v, int keyType) {
        if (Prefs.on(prefs, Prefs.K_HAPTIC)) {
            vibrateKey(v);
        }
        int kind = KeySounds.KEY;
        if (keyType == T_DELETE) {
            kind = KeySounds.DELETE;
        } else if (keyType == T_SHIFT || keyType == T_TO_SYMBOLS1 || keyType == T_TO_SYMBOLS2
                || keyType == T_TO_LETTERS || keyType == T_TO_EMOJI || keyType == T_GLOBE
                || keyType == T_MIC || keyType == T_TO_CLIP || keyType == T_CLIP_CLOSE) {
            kind = KeySounds.MODIFIER;
        }
        playSound(kind);
    }

    /** A short buzz of the length set in Preferences > Vibration strength; the system tap if the phone cannot buzz. */
    private void vibrateKey(View v) {
        try {
            Vibrator vib = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vib != null && vib.hasVibrator()) {
                int ms = Prefs.vibMs(prefs);
                if (Build.VERSION.SDK_INT >= 26) {
                    vib.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vib.vibrate(ms);
                }
                return;
            }
        } catch (RuntimeException ignored) {
            // fall through to the system tap
        }
        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    private void playSound(int kind) {
        if (sounds != null && Prefs.on(prefs, Prefs.K_SOUND)) {
            sounds.play(kind, Prefs.volume(prefs));
        }
    }

    private void onKeyTapped(Key k) {
        switch (k.type) {
            case T_CHAR:
                typeChar(k.letter && (shifted || capsLock) ? k.text.toUpperCase(Locale.ROOT) : k.text,
                        k.letter);
                break;
            case T_SPACE:
                handleSpace();
                break;
            case T_ENTER:
                handleEnter();
                break;
            case T_SHIFT:
                handleShift();
                break;
            case T_TO_SYMBOLS1:
                setLayer(LAYER_SYMBOLS1);
                break;
            case T_TO_SYMBOLS2:
                setLayer(LAYER_SYMBOLS2);
                break;
            case T_TO_LETTERS:
                if (layer == LAYER_EMOJI) {
                    closeEmojiThen(new Runnable() {
                        @Override
                        public void run() {
                            setLayer(LAYER_LETTERS);
                        }
                    });
                } else {
                    setLayer(LAYER_LETTERS);
                }
                break;
            case T_TO_EMOJI:
                setLayer(LAYER_EMOJI);
                break;
            case T_GLOBE:
                switchKeyboard();
                break;
            case T_MIC:
                startVoiceInput();
                break;
            case T_TO_CLIP:
                setLayer(LAYER_CLIP);
                break;
            case T_CLIP_CLOSE:
                leaveClipboard();
                break;
            case T_CLIP_CLEAR:
                clipClearUnpinned();
                break;
            default:
                break;
        }
    }

    private void setLayer(int newLayer) {
        boolean opening = newLayer == LAYER_EMOJI && layer != LAYER_EMOJI && layer != LAYER_EMOJI_SEARCH;
        boolean openingClip = newLayer == LAYER_CLIP && layer != LAYER_CLIP;
        boolean toSearch = newLayer == LAYER_EMOJI_SEARCH && layer == LAYER_EMOJI;
        int fromH = (opening && keysHost != null) ? keysHost.getHeight() : 0;
        if (newLayer != LAYER_EMOJI && newLayer != LAYER_EMOJI_SEARCH) {
            restoreContentHeight();
        }
        layer = newLayer;
        emojiClosing = false;
        renderKeys();
        if (opening) {
            playEmojiOpen(fromH);
        }
        if (openingClip) {
            playClipOpen();
        }
        if (toSearch) {
            playSearchOpen();
        }
        updateAutoShift();
        updateSuggestions();
    }

    private void handleShift() {
        long now = SystemClock.uptimeMillis();
        if (capsLock) {
            capsLock = false;
            shifted = false;
        } else if (shifted && now - lastShiftTap < 350) {
            capsLock = true;
            shifted = false;
        } else {
            shifted = !shifted;
        }
        lastShiftTap = now;
        updateShiftVisuals();
        updateSuggestions();
    }

    private void commit(InputConnection ic, String s) {
        if (rawKeyMode && s.length() == 1) {
            sendKeyChar(s.charAt(0));
        } else {
            ic.commitText(s, 1);
        }
    }

    private void typeChar(String s, boolean isLetter) {
        if (layer == LAYER_EMOJI_SEARCH) {
            searchAppend(s);
            if (isLetter && shifted && !capsLock) {
                shifted = false;
                updateShiftVisuals();
            }
            return;
        }
        InputConnection ic = getCurrentInputConnection();
        if (ic == null || s == null || s.isEmpty()) {
            return;
        }
        char c = s.charAt(0);
        boolean punctuation = s.length() == 1 && WORD_BREAKS.indexOf(c) >= 0;
        if (spaceAfterSuggestion && punctuation) {
            CharSequence b = ic.getTextBeforeCursor(1, 0);
            if (b != null && b.length() == 1 && b.charAt(0) == ' ') {
                ic.deleteSurroundingText(1, 0);
            }
        }
        if (punctuation) {
            finishWord(ic);
        }
        spaceAfterSuggestion = false;
        commit(ic, s);
        if (isLetter && shifted && !capsLock) {
            shifted = false;
            updateShiftVisuals();
        }
        if (punctuation && smart && c != ')' && Prefs.on(prefs, Prefs.K_AUTOSPACE)) {
            // Preferences > Auto-space after punctuation: "word." becomes "word. "
            CharSequence before = ic.getTextBeforeCursor(2, 0);
            if (before != null && before.length() == 2
                    && (c == '.' ? Character.isLetter(before.charAt(0)) : Character.isLetterOrDigit(before.charAt(0)))) {
                ic.commitText(" ", 1);
                spaceAfterSuggestion = true;
            }
        }
        if ((layer == LAYER_SYMBOLS1 || layer == LAYER_SYMBOLS2) && !numberMode && (c == '\'' || c == '\u2019')
                && s.length() == 1 && Prefs.on(prefs, Prefs.K_APOS_SWITCH)) {
            layer = LAYER_LETTERS;   // Preferences > Auto-switch after apostrophes
            renderKeys();
        }
        afterEdit();
    }

    private void commitPlain(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) {
            return;
        }
        spaceAfterSuggestion = false;
        ic.commitText(s, 1);
        afterEdit();
    }

    private void handleDelete() {
        if (layer == LAYER_EMOJI_SEARCH) {
            searchBackspace();
            return;
        }
        spaceAfterSuggestion = false;
        lastOwnEdit = SystemClock.uptimeMillis();
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
    }

    private void handleSpace() {
        if (layer == LAYER_EMOJI_SEARCH) {
            searchAppend(" ");
            return;
        }
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) {
            return;
        }
        long now = SystemClock.uptimeMillis();
        if (Prefs.on(prefs, Prefs.K_DBLSPACE) && smart && now - lastSpaceTime < 450) {
            CharSequence before = ic.getTextBeforeCursor(2, 0);
            if (before != null && before.length() == 2 && before.charAt(1) == ' '
                    && Character.isLetterOrDigit(before.charAt(0))) {
                ic.deleteSurroundingText(1, 0);
                ic.commitText(". ", 1);
                lastSpaceTime = 0;
                spaceAfterSuggestion = false;
                afterEdit();
                return;
            }
        }
        finishWord(ic);
        commit(ic, " ");
        spaceAfterSuggestion = false;
        lastSpaceTime = now;
        if ((layer == LAYER_SYMBOLS1 || layer == LAYER_SYMBOLS2) && !numberMode) {
            layer = LAYER_LETTERS;
            renderKeys();
        }
        afterEdit();
    }

    private void handleEnter() {
        if (layer == LAYER_EMOJI_SEARCH) {
            List<String> res = emojiSearchResults(emojiQuery.toString());
            if (res.isEmpty() || emojiQuery.length() == 0) {
                exitEmojiSearch();
            } else {
                pickSearchedEmoji(res.get(0));   // Return inserts the best match
            }
            return;
        }
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) {
            return;
        }
        finishWord(ic);
        spaceAfterSuggestion = false;
        lastOwnEdit = SystemClock.uptimeMillis();
        EditorInfo ei = getCurrentInputEditorInfo();
        if (ei != null && ei.actionLabel != null
                && (ei.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0) {
            ic.performEditorAction(ei.actionId);
        } else if (imeAction != EditorInfo.IME_ACTION_NONE) {
            ic.performEditorAction(imeAction);
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
        }
        afterEdit();
    }

    private void moveCursorVertical(int dir) {
        lastOwnEdit = SystemClock.uptimeMillis();
        sendDownUpKeyEvents(dir > 0 ? KeyEvent.KEYCODE_DPAD_DOWN : KeyEvent.KEYCODE_DPAD_UP);
    }

    /** Space bar held: the keys turn into a blurred glass sheet. The sheet is opaque over every key and only fades in the thin band beside them. */
    private void enterTrackpad() {
        if (trackpadOverlay != null || keysHost == null || inputOuter == null || inputRoot == null) {
            return;
        }
        final int feather = dp(8);
        final int keyT = keysHost.getTop();
        final int keyB = keysHost.getBottom();
        final int top = Math.max(0, keyT - feather);
        final int bottom = Math.min(inputRoot.getHeight(), keyB + feather);
        final int w = inputRoot.getWidth();
        final int h = bottom - top;
        if (w <= 0 || h <= 0) {
            return;
        }
        Bitmap snap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas sc = new Canvas(snap);
        sc.translate(0, -top);
        inputRoot.draw(sc);
        // blur: shrink four times, each half the size of the one before
        Bitmap prev = snap;
        Bitmap[] chain = new Bitmap[4];
        for (int i = 0; i < 4; i++) {
            chain[i] = Bitmap.createScaledBitmap(prev, Math.max(1, prev.getWidth() / 2),
                    Math.max(1, prev.getHeight() / 2), true);
            prev = chain[i];
        }
        Bitmap blur = Bitmap.createScaledBitmap(chain[3], w, h, true);
        snap.recycle();
        for (Bitmap b : chain) {
            b.recycle();
        }
        TrackpadOverlay ov = new TrackpadOverlay(this, blur, keyT - top, keyB - top);
        ov.setAlpha(0f);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(w, h, Gravity.TOP | Gravity.LEFT);
        lp.topMargin = top;
        inputOuter.addView(ov, lp);
        ov.animate().alpha(1f).setDuration(140).start();
        trackpadOverlay = ov;
        if (Prefs.on(prefs, Prefs.K_HAPTIC)) {
            keysHost.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
        }
    }

    private void exitTrackpad() {
        final TrackpadOverlay ov = trackpadOverlay;
        trackpadOverlay = null;
        if (ov == null) {
            return;
        }
        ov.animate().alpha(0f).setDuration(120).withEndAction(new Runnable() {
            @Override
            public void run() {
                if (ov.getParent() instanceof ViewGroup) {
                    ((ViewGroup) ov.getParent()).removeView(ov);
                }
                ov.release();
            }
        }).start();
    }

    /**
     * The trackpad sheet: the blurred keyboard with a glass wash and the prompt. It is opaque over the keys
     * (keyT .. keyB, local to the sheet) and fades only in the thin band beside them. It takes every touch
     * while it is shown, so no key under it can register a letter.
     */
    private final class TrackpadOverlay extends View {
        private final Bitmap blur;
        private final int keyT;
        private final int keyB;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final TextPaint text = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        private final Rect dst = new Rect();
        private StaticLayout label;

        TrackpadOverlay(Context c, Bitmap blur, int keyT, int keyB) {
            super(c);
            this.blur = blur;
            this.keyT = keyT;
            this.keyB = keyB;
            setClickable(true);
            text.setTypeface(uiMedium);
            text.setTextSize(dp(17));
            text.setColor(colors.dark ? 0xFFAEAEB2 : 0xFF636366);   // a soft grey prompt
        }

        void release() {
            if (blur != null && !blur.isRecycled()) {
                blur.recycle();
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            return true;   // the sheet is a trackpad: touches on it never reach the keys underneath
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            String msg = "Move your fingers to control the cursor";
            int maxW = Math.max(1, w - 2 * dp(24));
            label = StaticLayout.Builder.obtain(msg, 0, msg.length(), text, maxW)
                    .setAlignment(Layout.Alignment.ALIGN_CENTER)
                    .setIncludePad(false)
                    .build();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            int w = getWidth();
            int h = getHeight();
            float hh = Math.max(1, h);
            int layer = canvas.saveLayer(0, 0, w, h, null);
            dst.set(0, 0, w, h);
            if (colors.dark) {
                canvas.drawBitmap(blur, null, dst, paint);   // v3.102: light mode draws no blurred keys at all
            }
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(colors.dark ? 0xDD202022 : 0xFFF7F7F5);   // light mode: solid off-white wash
            canvas.drawRect(0, 0, w, h, paint);
            // mask: fully opaque over the keys, faded to nothing over the thin band beside them
            paint.setShader(new LinearGradient(0, 0, 0, h,
                    new int[]{0x00000000, 0xFF000000, 0xFF000000, 0x00000000},
                    new float[]{0f, keyT / hh, keyB / hh, 1f}, Shader.TileMode.CLAMP));
            paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
            canvas.drawRect(0, 0, w, h, paint);
            paint.setXfermode(null);
            paint.setShader(null);
            canvas.restoreToCount(layer);
            if (label != null) {
                canvas.save();
                canvas.translate(dp(24), (keyT + keyB) / 2f - label.getHeight() / 2f);
                label.draw(canvas);
                canvas.restore();
            }
        }
    }

    private void moveCursor(int dir) {
        lastOwnEdit = SystemClock.uptimeMillis();
        sendDownUpKeyEvents(dir > 0 ? KeyEvent.KEYCODE_DPAD_RIGHT : KeyEvent.KEYCODE_DPAD_LEFT);
    }

    private void switchKeyboard() {
        boolean ok = false;
        try {
            ok = switchToNextInputMethod(false);
        } catch (Throwable ignored) {
            // fall through to the picker
        }
        if (!ok) {
            showKeyboardPicker();
        }
    }

    private void showKeyboardPicker() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.showInputMethodPicker();
        }
    }

    /** Hands over to the phone's own voice-typing keyboard (e.g. Google voice typing). */
    private void startVoiceInput() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) {
                for (InputMethodInfo info : imm.getEnabledInputMethodList()) {
                    if (info.getPackageName().equals(getPackageName())) {
                        continue;
                    }
                    List<InputMethodSubtype> subs = imm.getEnabledInputMethodSubtypeList(info, true);
                    for (InputMethodSubtype st : subs) {
                        if ("voice".equals(st.getMode())) {
                            if (Build.VERSION.SDK_INT >= 28) {
                                switchInputMethod(info.getId(), st);
                            } else {
                                switchInputMethod(info.getId());
                            }
                            return;
                        }
                    }
                }
            }
        } catch (Throwable ignored) {
            // fall through to the message below
        }
        Toast.makeText(this, "Voice typing isn't available on this phone", Toast.LENGTH_SHORT).show();
    }

    // -------------------------------------------------- words, shift, suggestions
    private static boolean isWordChar(char c) {
        return Character.isLetter(c) || c == '\'' || c == '\u2019';
    }

    private String currentWord(InputConnection ic) {
        CharSequence before = ic.getTextBeforeCursor(32, 0);
        if (before == null) {
            return "";
        }
        int end = before.length();
        int i = end;
        while (i > 0 && isWordChar(before.charAt(i - 1))) {
            i--;
        }
        while (i < end && (before.charAt(i) == '\'' || before.charAt(i) == '\u2019')) {
            i++;
        }
        return before.subSequence(i, end).toString();
    }

    private String previousWord(InputConnection ic) {
        CharSequence before = ic.getTextBeforeCursor(48, 0);
        if (before == null) {
            return "";
        }
        int i = before.length();
        int spaces = 0;
        while (i > 0 && before.charAt(i - 1) == ' ') {
            i--;
            spaces++;
        }
        if (spaces == 0) {
            return "";
        }
        int end = i;
        while (i > 0 && isWordChar(before.charAt(i - 1))) {
            i--;
        }
        return before.subSequence(i, end).toString().replace('\u2019', '\'').toLowerCase(Locale.ROOT);
    }

    private boolean cursorInsideWord(InputConnection ic) {
        CharSequence after = ic.getTextAfterCursor(1, 0);
        return after != null && after.length() > 0 && Character.isLetter(after.charAt(0));
    }

    /** Called when a word is finished (space / punctuation / enter). */
    private void finishWord(InputConnection ic) {
        if (!smart || cursorInsideWord(ic)) {
            return;
        }
        String w = currentWord(ic);
        if (w.isEmpty()) {
            return;
        }
        if (Prefs.on(prefs, Prefs.K_AUTOCORRECT)) {
            String fix = suggester.correction(w);
            if (fix != null) {
                ic.deleteSurroundingText(w.length(), 0);
                ic.commitText(fix, 1);
                w = fix;
            }
        }
        if (Prefs.on(prefs, Prefs.K_LEARN)) {
            suggester.learn(w);
        }
    }

    private void pickSuggestion(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) {
            return;
        }
        if (Prefs.on(prefs, Prefs.K_AUTOCORRECT)) {
            String fix = suggester.correction(s);
            if (fix != null) {
                s = fix;
            }
        }
        String w = currentWord(ic);
        if (!w.isEmpty()) {
            ic.deleteSurroundingText(w.length(), 0);
        }
        ic.commitText(s + " ", 1);
        if (Prefs.on(prefs, Prefs.K_LEARN)) {
            suggester.learn(s);
        }
        spaceAfterSuggestion = true;
        lastSpaceTime = 0;
        afterEdit();
    }

    private void afterEdit() {
        lastOwnEdit = SystemClock.uptimeMillis();
        updateAutoShift();
        updateSuggestions();
    }

    private void updateAutoShift() {
        if (capsLock || layer != LAYER_LETTERS || !smart || !Prefs.on(prefs, Prefs.K_AUTOCAP)) {
            return;
        }
        InputConnection ic = getCurrentInputConnection();
        EditorInfo ei = getCurrentInputEditorInfo();
        if (ic == null || ei == null) {
            return;
        }
        boolean want = ic.getCursorCapsMode(ei.inputType) != 0;
        if (want != shifted) {
            shifted = want;
            updateShiftVisuals();
        }
    }

    private void updateSuggestions() {
        if (suggestionViews[0] == null) {
            return;
        }
        List<String> list = null;
        InputConnection ic = getCurrentInputConnection();
        if (ic != null && layer == LAYER_LETTERS && smart
                && Prefs.on(prefs, Prefs.K_SUGGEST) && !cursorInsideWord(ic)) {
            String w = currentWord(ic);
            if (w.isEmpty()) {
                list = Prefs.on(prefs, Prefs.K_NEXT_WORD) ? suggester.nextWords(previousWord(ic)) : null;
                if (list == null) list = new ArrayList<>();
                if (shifted || capsLock) {
                    ArrayList<String> up = new ArrayList<>();
                    for (String s : list) {
                        up.add(Character.toUpperCase(s.charAt(0)) + s.substring(1));
                    }
                    list = up;
                }
            } else {
                list = Prefs.on(prefs, Prefs.K_WORD_SUGGEST) ? suggester.suggest(w, 3) : new ArrayList<String>();
                list = new ArrayList<>(list);
                // Text-to-emoji: a typed word that names an emoji adds that emoji to the strip
                if (Prefs.on(prefs, Prefs.K_TEXT_EMOJI) && w.length() >= 2 && list.size() < 3) {
                    List<String> hits = emojiSearchResults(w);
                    if (!hits.isEmpty() && !list.contains(hits.get(0))) {
                        list.add(hits.get(0));
                    }
                }
            }
        }
        // Show emoji: with nothing to suggest, the most recent emoji fill the strip
        boolean emojiFill = (list == null || list.isEmpty()) && ic != null && currentWord(ic).isEmpty();
        if (emojiFill && layer == LAYER_LETTERS && Prefs.on(prefs, Prefs.K_SUG_EMOJI)
                && Prefs.on(prefs, Prefs.K_SUGGEST)) {
            List<String> recent = emojiSearchResults("");
            if (!recent.isEmpty()) {
                list = new ArrayList<>(recent.subList(0, Math.min(3, recent.size())));
            }
        }
        boolean any = false;
        for (int i = 0; i < suggestionViews.length; i++) {
            String s = list != null && i < list.size() ? list.get(i) : "";
            suggestionViews[i].setText(s);
            any |= !s.isEmpty();
        }
        // iOS with nothing to suggest: a wide middle cell, the two dividers 30 dp from the screen edges.
        float[] wts = any ? new float[]{1f, 1f, 1f} : new float[]{0.55f, 6.9f, 0.55f};
        for (int i = 0; i < suggestionViews.length; i++) {
            ViewGroup.LayoutParams lp = suggestionViews[i].getLayoutParams();
            if (lp instanceof LinearLayout.LayoutParams && ((LinearLayout.LayoutParams) lp).weight != wts[i]) {
                ((LinearLayout.LayoutParams) lp).weight = wts[i];
                suggestionViews[i].setLayoutParams(lp);
            }
        }
    }
}
