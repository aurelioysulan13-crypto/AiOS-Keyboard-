# AiOS Keyboard v3.113 - corner pop-up: visible stretching neck

- The liquid neck between the emoji circle and the pop-up capsule now shows. Before, it was drawn only while the capsule's left end was between one and two radii from the circle, a band the release spring crossed in a few frames, so it was almost never seen. The neck now starts as soon as the left end leaves the circle and stays visible over 2.4 radii of travel.
- The neck thins smoothly as it is pulled (half thickness 0.7 r falling to nothing), and its waist pinches harder the longer it gets, so it reads as a liquid strand before it lets go.
- The left edge's release spring is slower (stiffness 120, damping 15, was 180 / 18.8), so the neck is seen before it detaches. The rebound is still a small overshoot.
- Preview renderer updated to the same springs and neck, with frames during the release and just before the neck breaks.
- Not built with Gradle and not run on a device. Tune the neck length (2.4) and the release spring in CornerGooView if the feel is off.

# AiOS Keyboard v3.112 - corner pop-up: liquid stick, release, rebound; uniform icons

- The lower-left corner pop-up (the glass circle and capsule) now moves on three damped springs instead of a fixed 620 ms clock with an easing curve. The view steps its own springs once per frame (postOnAnimation), so the motion stays even when a frame is late.
- Stick, release, rebound: the circle pops, and the capsule's right edge stretches out of it while the left edge stays stuck to the circle. The left edge then lets go, the neck between circle and capsule thins and breaks, and the left edge overshoots a little and settles, like a stretched drop snapping back.
- Closing runs the same springs in reverse: the left edge is pulled into the circle first, the right edge follows, and the circle fades last. The four buttons fade before the capsule collapses.
- Less jitter: the glass gradient is built once instead of every frame, the shape is built with one reused path (no per-frame allocations beyond the boolean union), the press paint is reused, and the boolean union is only used where the circle, capsule and neck meet.
- Icons: the four corner pop-up buttons (Settings, Keyboard size, Translator, Light / dark) share one slot (48 x 40 dp), the same 12 dp padding at both ends of the capsule, and one 19 dp icon square. Each icon fills the same 0.7 x 0.7 extent, so they read the same size. The gear, the resize arrow, the translator and the light / dark ring were redrawn to that extent.
- Not built with Gradle and not run on a device. The spring constants are a first tuning; they are the place to adjust feel (K_LEAD / C_LEAD, K_GROW / C_GROW in CornerGooView).

# AiOS Keyboard v3.111 - both corner keys light up

- While the corner pop-up is open, the right-corner key (the mic by default, or whatever key is set there in Settings > Keys) also shows its circular glass highlight, the same circle as the left key's. Both circles use the keys' glass and pop in together.
- The capsule is kept clear of the right circle on narrow screens.
- Preview renderer draws both circles.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.110 - pop-up has the keys' glass

- The corner pop-up's circle and capsule now use exactly the glass of every key: the same translucent gradient (light 55 % to 38 % white, dark 18 % to 12 % white), the same 0.75 dp rim, and no shadow, so the frosted window shows through them the way it does through the keys. Before, they were a more opaque frosted fill with a drop shadow.
- Preview renderer draws the same glass.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.109 - corner pop-up flows out of a circle

- Holding the lower-left corner key no longer puts a big capsule over the key. The key and its icon are not touched. A glass circle (the same size as the key's press circle) lights up behind the icon.
- A separate glass capsule of the same height flows out of that circle to the middle of the footer. While it leaves, the two are joined by a liquid neck that stretches, thins and lets go (the Dynamic Island split from the video, the other way round). Circle and capsule are drawn as one glass sheet with one rim and one soft shadow.
- The capsule's leading edge runs out first and its trailing edge follows, on a smooth spring. The four buttons (Settings, Keyboard size, Translator, Light / dark) fade and scale in once the capsule is free.
- A tap anywhere closes it. The capsule flows back into the circle, the buttons fade first, and the circle fades last.
- The glass is drawn behind the keyboard, so the corner key's icon stays on top of its circle.
- Preview renderer updated to draw the circle, the capsule and two frames of the opening.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.108 - corner pop-up

- Holding the lower-left corner key opens a glass capsule that grows out of the key (it starts at the key's size and scales out, like the Dynamic Island). It has four icon-only buttons: Settings, Keyboard size (opens Settings > Bottom row & size), Translator, and Light / dark. A tap outside the capsule closes it.
- The Translator button shows "Translator is not set up yet". No translation service is in the app.
- The long press on the corner key no longer switches keyboards; the lower-left corner is now the pop-up.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.107 - bottom row editor looks like the keyboard

- Settings > Bottom row & size: the editor's tiles are drawn like the keyboard's own keys (the same G2 face and colours, the keyboard's font, and its shift, delete and return icons). Spacers are invisible.
- Editable slots keep an accent outline; the chosen slot is filled accent.
- Preview: the editor shows the keyboard's own key drawing, with accent outlines on the two corner tiles.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.106 - settings preview shows the emoji font rows

- Preview only: the Settings preview now draws the Emoji font rows (Apple Emoji with "Download 116 MB", and Phone default). It had left this section empty, because the preview cannot run the loop that creates those rows.
- No app code changed in this version.

# AiOS Keyboard v3.105 - Apple Emoji downloads on demand

- The Apple emoji font is no longer in the APK (the APK is back to its normal size).
- Settings > Emojis > Emoji font: the Apple Emoji row shows "Download 116 MB". Tapping it downloads the font into the app's files and shows the percentage. When it is ready, the row is chosen like the others and it is the default emoji font.
- Until the font is downloaded, the keyboard uses the phone's own emoji font.
- A download must be set up before it works: EmojiFonts.APPLE_EMOJI_URL is empty in this build and has to be set to the file's direct link. Until then the row says the download is not set up yet.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.104 - emoji category snap

- Sideways scrolling in the emoji panel now snaps to emoji categories. After a swipe or fling the grid stops at the start of the nearest category, or at a screen-wide page inside a long category, counted from that category's start. Before, it snapped to single emoji columns.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.103 - Apple Emoji font, clipboard blur and spacing

- Apple Color Emoji (CBDT) is bundled as assets/fonts/AppleColorEmoji.ttf and is the default emoji font. Settings > Emojis > Emoji font lists "Apple Emoji" first. A phone that already chose a font keeps that choice. Phone default is still listed.
- The bundled font is stored uncompressed (aaptOptions noCompress 'ttf'). It adds about 116 MB to the APK.
- Clipboard header: the top blur is always on, so content that passes under the header is blurred even when the list is not scrolled.
- Clipboard footer: the blur zone is half as deep and half as strong.
- Clipboard: the gap between the header and the first tile is 8 dp (was 22 dp).
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.102 - wider clipboard header gap, plain off-white trackpad

- Clipboard: the gap between the header buttons and the first tile is now 22 dp (was 10 dp).
- Trackpad, light mode: the blurred keys are no longer drawn at all. The sheet is a solid off-white (#F7F7F5), so no key shows through. Dark mode keeps the blur.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.101 - clipboard header gap, off-white trackpad

- Clipboard: the first tile now starts a gap (10 dp) below the header buttons (Back, Clipboard, Clear all). The list still scrolls under the header.
- Trackpad (space bar held): the light-mode blur is now an opaque off-white (#F7F7F5), so the keys underneath no longer show through. Dark mode is unchanged.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.100 - fixed footer, content-only emoji and clipboard animation

- The footer (emoji/clipboard and mic corner keys) is now the same bar in every layer and is never animated. The emoji panel no longer has its own globe/mic row inside the content.
- Only the content panel between the header and the footer changes height when the emoji panel opens or closes (morph, 300 ms open, 260 ms close). The content is clipped to the panel while it changes.
- Replaces the v3.99 window-height morph, which moved the footer with the content.
- Not built with Gradle and not run on a device. The window resize during the morph may still look uneven on some phones.

# AiOS Keyboard v3.99 - emoji panel morphs from the keyboard (KeyboardService)

- Opening the emoji panel: the keyboard frame now grows (morphs) from keyboard height into the emoji panel's height over 300 ms, instead of the tall panel appearing while its content slid up from below.
- Closing the emoji panel: the frame shrinks back to keyboard height over 260 ms, and then the letters appear. Before, the tall panel dropped out of view while its content sank down.
- The clipboard panel and the emoji search are unchanged.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.98 - clipboard key between 123 and space: smaller icon (KeyboardService, previews)

- The clipboard icon on the key between 123 and the space bar is scaled to 0.75 (it was 0.85 in the first version). Only this key's icon; the corner clipboard key and every other key are unchanged.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.97 - shallower blur at the bottom of the clipboard list (KeyboardService, previews)

- The blur strip above the clipboard footer is shallower (1.2 times the footer height instead of 1.75), so it takes less space. The header blur is unchanged.
- Why the header has no blur at rest: the top fade only appears once the list has been scrolled, because there is nothing above the first item to fade. The footer fades as soon as more items sit below it.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.96 - frosted glass panel 85 % opaque (KeyboardService, previews)

- The frosted panel is now 85 % opaque in light and dark mode, so the chat behind it no longer shows through. Window blur is still requested; it appears only if the phone draws it behind the keyboard.
- On the test phone, Allow window-level blurs is on in Developer options, but the keyboard still shows no blur. That is a system or phone limit, not a setting the app can change.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.95 - panel is nearly solid when the phone has no window blur (KeyboardService, previews)

- On phones where window blur is off (the keyboard checks the system setting), the frosted panel had no blur and the app behind showed through as text. It is now 88 % opaque, so the text no longer shows through.
- If you want the blur, check the phone's setting: on Samsung phones, Settings > Accessibility > Visibility enhancements > turn off "Reduce transparency and blur" (the path may differ slightly by One UI version).
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.94 - frosted glass panel reads as glass (Prefs, KeyboardService, previews)

- Frosted glass: the default blur is 20 dp (was 4 dp, too faint to see), and the panel is more see-through in light and dark mode, so the blurred content behind it shows as frosted glass.
- A soft light sheen runs along the top edge of the frosted panel.
- Not done: a grain or particle texture. Tell me if you meant a grainy texture and I'll add it.
- Not built with Gradle and not run on a device. Whether the blur shows depends on the phone allowing window blur (it did not show on the test phone, so the phone's blur support is still to be confirmed).

# AiOS Keyboard v3.93 - Delete label is red again (KeyboardService, previews)

- The Delete label in the long-press menu is red again, in light and dark mode. The highlight behind it stays neutral grey (light mode) or white (dark mode); no blue, green or red highlight.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.92 - preview sheets show the neutral press effect (previews, scenes.js)

- The preview sheets still showed the old blue, green and red press effects from before v3.91. They now draw the same neutral grey (light mode) or white (dark mode) as the app, and the Delete label keeps its normal text colour.
- The app code is the same as v3.91 (the press effect was already neutral there).
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.91 - no colour when pressing a clipboard tile (KeyboardService)

- Holding a clipboard tile and its Pin / Unpin / Delete highlight: no colour at all. The highlight and held tile use a pure neutral grey in light mode and white in dark mode. Blue, green and red are gone from the press effect, and the Delete label stays its normal text colour.
- The blue Clear all button and the blue pin mark on pinned tiles are unchanged; they are not press effects.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.90 - no accent blue on clipboard tiles (KeyboardService)

- A clipboard tile that is held or selected (for example while you hold it to open Pin / Delete) no longer takes the accent colour. It uses the same neutral light grey in light mode and white in dark mode as the menu.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.89 - one neutral tint for held clipboard tiles (KeyboardService)

- Holding a clipboard tile: the tile and its Pin, Unpin and Delete highlight use one universal tint, light grey in light mode and white in dark mode. The green, blue and red tints are removed.
- The Delete label keeps the normal text colour instead of turning red.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.88 - pop-up blur masked to its shape, glide no longer lifts the keyboard, clipboard keeps its corner keys (KeyboardService)

- Key pop-up: the frosted blur is now masked by the pop-up's shape. Before, the blur showed in the rectangle around the head, because the mask only covered the drawn outline.
- Glide typing: the glide trail no longer takes the screen's height when it appears, so the keyboard stays where it is.
- Clipboard panel: the list and empty message end above the footer row, so the emoji and mic keys are no longer covered by the list. The list no longer blurs under the footer.
- Emoji panel: snap to column and the search results height (v3.87) unchanged.
- Not built with Gradle and not run on a device. The clipboard fix is a layout change made from reading the code; please check it on a phone.

# AiOS Keyboard v3.87 - emoji snap, emoji search keeps the panel height (KeyboardService)

- Emoji panel: the grid snaps to the nearest emoji column when a drag or fling stops, so an emoji never stops half-way across.
- Emoji search: the results row now takes only the room left above the letters, so the panel no longer grows when searching. With the number row on, the emoji in the results row are smaller.
- Not fixed (diagnosed, needs a device to confirm): key pop-up blur edge, emoji and mic keys vanishing after the clipboard panel opens, glide typing jumping the keyboard up.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.86 - trackpad sheet hides the keys (KeyboardService)

- Space bar trackpad: the glass wash over the blurred keys is stronger (light mode 85 % instead of 40 %, dark mode 85 % instead of 70 %), so the keys underneath no longer show through.
- Not fixed in this version (diagnosed, needs a device to confirm): key pop-up blur edge, emoji and mic keys after opening the clipboard, emoji card snapping, glide typing jumping the keyboard up, and the emoji search panel height change.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.85 - partial app: every unbuilt feature says "Not available yet" (MainActivity)

- Each setting or menu row that is not built yet is greyed out, shows "Not available yet" on the right, and shows a short message when tapped. Nothing else changes: all built features work as before.
- Checked before this release: all Java files parse without syntax errors, every reference to the app's own classes resolves, and the resource references (styles, strings, icons, XML) exist. The build itself has not been run (no Android SDK here).

# AiOS Keyboard v3.84 - emoji font list finds the phone's fonts (EmojiFonts, MainActivity)

- v3.83 only looked in /system/fonts, so on Android 12+ phones, where Google's emoji font lives in /apex/com.android.fonts/fonts, the list showed just "Phone default".
- The emoji font scan now reads the phone's font lists (/system/etc/fonts.xml and the product/vendor customisation lists) for emoji font files, then checks every font folder including /apex/com.android.fonts/fonts.
- The Emoji font footer says how many emoji fonts were found, or that only the phone's own font was found.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.83 - emoji font choice (EmojiFonts, Fonts, KeyboardService, MainActivity)

- Settings > Emojis > Emoji font lists the emoji fonts installed on the phone: "Phone default" (Android's own choice, as before), "Samsung emoji" if the phone has Samsung's emoji font, and "Android emoji" if the phone has Google's Noto Color Emoji. The keyboard scans the system font folders (/system/fonts, /system_ext, /product, /vendor) for files with "emoji" in the name.
- The chosen font is used for the emoji panel and emoji search results. Changing it applies at once.
- "iOS emoji (coming soon)" is shown greyed out.
- Limits: the suggestion strip still uses the system emoji fallback. Emoji sent to other apps show in those apps' own style. Font files that cannot be read are skipped and the phone default is used.
- Not built with Gradle and not run on a device. Samsung's font file name and readability need to be confirmed on a Samsung phone.

# AiOS Keyboard v3.82 - clipboard memory on by default; honest privacy page; Terms, Privacy Policy and open source licences (MainActivity, KeyboardService, LegalText)

- Clipboard: "Remember clipboard after restart" is now on by default. Before, history was only kept in RAM and was lost when the keyboard restarted; with it on, history is saved in the keyboard's private database on the phone. Copies made in password fields are never saved; Clear clipboard history deletes everything.
- Privacy page rewritten to match what the app does: no internet permission ("None"), voice typing handled by the phone, learned words and clipboard history kept on the phone, Share usage statistics shown as not available (not on by default: there is no server and nothing is sent). Audio donations and "Improve for everyone" removed (the app records no audio and sends nothing).
- About: version, developer and contact, links to Terms of Service, Privacy Policy and Open source licenses, last-updated date.
- Terms of Service and Privacy Policy pages (LegalText.java). Developer name, contact email and jurisdiction are placeholders ([Developer name], [Contact email], [jurisdiction]) and must be filled in and reviewed before publishing.
- Open source licences page: reads the ESDB and en_AU notices from the assets, and lists Unicode emoji and the SF Pro Display font (see reply).
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.81 - Australian English dictionary and spell check (Suggester, Prefs, MainActivity, assets)

- Hunspell en_AU dictionary (2026.02.25) expanded to a flat word list (assets/wordlist/en_au.txt, 89,166 forms; the affix rules are applied, proper nouns, acronyms, taboo (NOSUGGEST) and compound-only words are left out). The expansion script is assets/wordlist/expand_hunspell.py.
- Word lists now load in this order: words.txt (frequency order), ESDB size 35, en_au.txt, ESDB 50, ESDB 60. Common words come first in suggestions.
- Spell check (Settings > Corrections > Spell check, on by default): a word typed and finished with a space that is not in the dictionary is corrected to the common word one edit away (for example teh -> the, becuase -> because). Only common words are used as fixes, so rare words are left alone. Learned words are never changed.
- Grammar check and the system spell checker are still not done (the grammar rows stay greyed out).
- Licence notice for the Australian dictionary: assets/wordlist/COPYING-en_AU.txt.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.80 - English Speller Database word lists (Suggester, assets/wordlist, previews)

- Word suggestions, glide typing and auto-correction now read the English Speller Database (ESDB, github.com/en-wl/wordlist) lists in assets/wordlist: scowl_35.txt, then scowl_50.txt, then scowl_60.txt. Common words come first. If none of those files is in the app, the old words.txt is used.
- The list files are not in the app yet: they are generated from the repository with make (commands in assets/wordlist/README.txt) and copied into that folder.
- Words are kept if they are plain a-z (with apostrophes), 1 to 24 letters. Spaces, digits and symbols are dropped.
- The ESDB licence notice for an official speller dictionary is in assets/wordlist/COPYING-ESDB.txt.
- Not done: grammar checking (ESDB is a spelling database, not a grammar engine) and a system spell checker (needs a separate SpellCheckerService). The Spelling & grammar rows stay greyed out.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.79 - glide typing (KeyboardService, Suggester, Prefs, MainActivity, previews)

- Glide typing (on by default): slide a finger from a letter across the other letters. On release the keyboard picks the best matching word from the built-in list and the words you have learned, and types it with a trailing space. The match uses the letters crossed in order and the distance between keys, and the word must start and end on the right keys. Over one key it types that letter, as a tap.
- Glide trail (on by default): a fading accent-coloured path is drawn over the keys while gliding.
- Glide delete (on by default): slide left on the delete key to remove the word before the cursor.
- Glide cursor control (on by default): the slide along the space bar moves the cursor; switching it off turns that slide off.
- Limit: glide can only pick words in words.txt (about 580 words) and words learned on the phone. Longer or rarer words will not match until the word list is extended.
- Not built with Gradle and not run on a device. The previews do not draw the glide trail or the glide matching.

# AiOS Keyboard v3.78 - Settings > Emojis wired to the keyboard (Settings, KeyboardService, Prefs)

- Emojis > Emoji size is now on the Emojis page (it was under Preferences); same setting, same slider.
- Emojis > Text-to-emoji options (on by default): when the word being typed names an emoji, that emoji is offered in the suggestion strip (after up to two word suggestions). Uses the keyboard's own emoji keyword search.
- Emojis > Show emoji (on by default): with nothing typed and no next-word suggestion, the most recent emoji fill the suggestion strip. Tapping one inserts it.
- Still greyed out, not built: Emoji fast-access row, Emoji in symbols keyboard, GIF category suggestions, Show stickers, Emoji Kitchen, and all of the Glide typing and Clipboard screenshot/address rows. These need new keyboard features, not just settings.
- Not built with Gradle and not run on a device.

# AiOS Keyboard v3.77 - slider handle is a refracting liquid glass lens (MainActivity, previews)

- The handle really refracts. It draws the slider's own track into a small bitmap, bends it (lensRefract) and paints it in the handle: magnified in the middle, the edges pull in the surroundings, red, green and blue bend by slightly different amounts. It redraws with the slider, so it follows the finger.
- Dark blurred shadow just inside the edge (eight fine rings), a specular glint at the top-left and bottom-right, a soft gloss.
- Previews use a Python port of lensRefract (lens_ref.py); tested against the Java on a test scene, identical pixels.
- Keyboard unchanged from v3.76. Not built with Gradle and not run on a device.

# AiOS Keyboard v3.76 - slider handle: inner dark shadow and refraction (MainActivity, previews)

- The handle's inner edge has a stronger dark, blurred shadow, fading inwards.
- Light refracts through the handle: the accent fill and the track bend across it (a lens-like band), with a specular line along the top inner edge.
- Keyboard unchanged from v3.75. Not built with Gradle and not run on a device.

# AiOS Keyboard v3.75 - capsule selector glides, follows the finger, snaps and registers (MainActivity, previews)

- Capsule selectors (Theme, Accent colour, One-handed keyboard, Flick input sensitivity) share one glass highlight that glides between the parts.
- While the finger is down the highlight follows it; it stretches softly with speed and squashes back.
- On release it snaps to the nearest part with a small overshoot, then registers that choice. A tap moves it to that part.
- Keyboard unchanged from v3.74. Not built with Gradle and not run on a device.

# AiOS Keyboard v3.74 - tinted selector highlight, matching size sliders (MainActivity, Prefs, previews)

- Capsule selectors (Theme, Accent colour, One-handed keyboard, Flick input sensitivity): in light mode the highlight capsule is still glass (gradient, rim, soft edge) but tinted with the chosen accent colour (30 % / 22 % fill, 45 % rim), so it can be seen. Dark mode is unchanged.
- Font size now runs 70-130 %, the same range as Emoji size, so 100 % puts the handle in the same place on both sliders (it was 80-130 vs 70-130).
- Keyboard unchanged from v3.72. Not built with Gradle and not run on a device.

# AiOS Keyboard v3.73 - capsule selectors (MainActivity, previews)

- Theme (System | Light | Dark), Accent colour (five round colour dots), One-handed keyboard (Off | Left | Right) and Flick input sensitivity (Low | Normal | High) are no longer full cards: each is one glass capsule (same glass, rim and round ends as the slider panels) split into 3 / 5 / 3 / 3 equal parts.
- The chosen part carries the slider handle's glass as a highlight capsule; its label turns to the accent colour (the accent dot has no label, so only the highlight shows).
- Font stays a card list. Keyboard unchanged from v3.72. Not built with Gradle and not run on a device.

# AiOS Keyboard v3.72 - the rest of Settings > Preferences made functional (Prefs, KeyboardService, MainActivity, manifest)

Keys: Number row (off) - a digit row above the letters, also on both symbols keyboards (which get one more symbols row so the height stays equal); Number row for passwords (on) - the same, only in password fields; Emoji key (off) - an emoji key between 123 and the space bar (when the middle key in Bottom row & size is "none"); Comma key (off) and Period key (off) - keys left / right of the space bar on the letters keyboard.
Font: AiOS (SF Pro Display) or System default; Font size (80-130 %, key labels); Emoji size (70-130 %, emoji panel).
Layout: One-handed keyboard - Off / Left / Right (letters and symbols keyboards use 80 % of the width in portrait).
Shortcuts: Auto-space after punctuation (off) - "word." becomes "word. " in text fields; Auto-switch after apostrophes (on) - back to the letters after an apostrophe typed on the symbols keyboard; Flick keys to enter symbols (off) - pull a top-row key down to type its number; Flick input sensitivity - Low / Normal / High.
Key tap: Vibration strength on keypress (5-60 ms, default 20) - a buzz of that length (new VIBRATE permission; the system tap is used if the phone cannot buzz).
Applied at once: auto-space, apostrophe switch, flick, vibration. Applied the next time the keyboard opens: number row, emoji / comma / period keys, font, font size, emoji size, one-handed.
Still grey elsewhere (other pages): Languages, Corrections, Glide, Emoji pages, Privacy, Themes. Not built with Gradle and not run on a device (no Java compiler here; brace-balance checked by hand).

# AiOS Keyboard v3.71 - six Settings rows made functional (Prefs, KeySounds, KeyboardService, MainActivity)

Settings > Preferences > Key tap / Shortcuts and Settings > Corrections & suggestions:
- Key pop-up (switch, on): turns the letter pop-up above a pressed key on or off.
- Touch & hold keys for symbols (switch, on): turns the hold-a-top-row-letter-for-its-number action on or off.
- Touch & hold duration (slider, 200-800 ms, default 450): how long a key is held before the hold action fires.
- Volume (slider, 10-100 %, default 100): key sound volume (the Sound switch still turns sounds on).
- Word suggestions (switch, on): words completing / correcting the word being typed in the suggestion strip.
- Next-word suggestions (switch, on): words predicted after a finished word in the suggestion strip.
All six apply at once (no restart). Other grey rows are unchanged. Not built with Gradle and not run on a device (syntax-checked by hand).

# AiOS Keyboard v3.70 - wider side padding in every panel (MainActivity.java, previews)

- Text, rows, icons and separators inside every card and capsule are inset 16 dp from the sides (SIDE), up from 12 dp.
- Toggle switches keep their 12 dp right gap; slider panels keep their 12 dp ends. Top and bottom gaps are unchanged.
- Keyboard unchanged from v3.63.

# AiOS Keyboard v3.69 - circular back button (MainActivity.java, previews)

- The back button in the top left corner is a circle (circle curve), not a rounded square.
- Keyboard unchanged from v3.63.

# AiOS Keyboard v3.68 - G2 icon corners, one padding for every card, slider track ends at the handle centre (MainActivity.java, previews)

- Settings icon tiles use the same G2 corner value as the cards (SettingsGlyphs.CARD_G2_R), so each tile is a G2 squircle.
- One padding, MainActivity.PAD = 12 dp, for every card and capsule: row and text inset, switch right gap, slider ends and the switch/slider top and bottom gap (52 - 28) / 2.
- The slider track runs from the centre of the handle at the minimum to the centre at the maximum (track inset = half the handle width), so the fill stops at the handle centre.
- Keyboard unchanged from v3.63.

# AiOS Keyboard v3.67 - G2 corner radius matches the capsule (MainActivity.java, SettingsGlyphs.java, previews)

- The G2 curve stays. Its radius is now derived from the capsule corner: SettingsGlyphs.g2RadiusFor() gives the G2 radius with the same corner cut as a 26 dp circle (about 47.9 dp for G2 = 4). The multi-row cards and the key editor board use it.
- Single-row cards and sliders are unchanged capsules.
- Keyboard unchanged from v3.63.

# AiOS Keyboard v3.66 - G2 smooth corners on every settings card; beta badge and announcement removed (MainActivity.java, SettingsGlyphs.java, previews)

- Settings card corners use G2 continuous curvature (exponent 4, was 2 = plain circle). This covers the multi-row groups, the key editor board, the icon tiles and the back button. Single-row cards and sliders stay true capsules, so their ends match the capsule radius.
- The beta badge beside the root title and the beta announcement are removed.
- Keyboard unchanged from v3.63.

# AiOS Keyboard v3.65 - slider handle, toggle padding, rounder icons, icons on every root row, beta badge and announcement (MainActivity.java, SettingsGlyphs.java, previews)

- Slider handle: 44 x 28 dp (was 52 x 36). The handle sits 12 dp from the capsule edge on every side (seekbar padding 12 dp, the rest is (52 - 28) / 2).
- Toggle switches: the switch sits 12 dp from the top, bottom and right edge of its row. Its size and shape are unchanged.
- Icon tiles: corner radius 11 dp (was 9), same G2 curve.
- Root rows Dictionary, Share AiOS Keyboard and Help & feedback have icon tiles, so every root row has an icon.
- BETA badge beside the root title, and a temporary beta announcement at the top of the root page. Both are marked TEMPORARY in the code.
- Keyboard unchanged from v3.63.

# AiOS Keyboard v3.64 - Settings app follows the Gboard settings order (MainActivity.java, SettingsGlyphs.java, previews)

- Root page in the Gboard order: Languages, Preferences, Theme; Corrections & suggestions, Glide typing, Voice typing, Emojis, stickers & GIFs; Clipboard, Dictionary; Privacy, Share, About, Help & feedback. Setup stays at the top.
- Preferences is new: Keys, Appearance, Layout, Shortcuts and Key tap sections with the Gboard items. The bottom row editor and keyboard size are reached from Keys ("Bottom row & size").
- Corrections & suggestions, Glide typing, Clipboard are new pages with the Gboard items; Voice typing and Emojis, stickers & GIFs follow the Gboard sections; Privacy and About follow the Gboard items.
- Items the keyboard does not implement yet are greyed out (label only, no switch, no "Coming soon" tag).
- Implemented items keep working: Auto-correction, Auto-capitalization, Double-space period, Suggestion strip, Sound, Keyboard vibration, Personalize for you (learn new words), Clipboard history, Remember clipboard, Delete learned words, the keyboard height slider, the bottom row editor, frosted glass, blur, opacity, theme, accent colour, rounded corners.
- New icon tiles for Preferences, Corrections & suggestions, Glide typing and Clipboard. Glass, panels, sliders, switches and capsules are unchanged.
- Keyboard unchanged from v3.63.

# AiOS Keyboard v3.63 - handle padding 8 dp on every side; Liquid glass row (coming soon) (MainActivity.java, previews)

- The slider handle is 36 dp tall with 8 dp of space on every side. Its ends are concentric with the capsule's ends, so the gap is the same all the way round.
- Glass section: a Liquid glass row below Frosted glass, greyed out and marked Coming soon.
- Keyboard unchanged from v3.48.

# AiOS Keyboard v3.62 - one corner radius for every panel (the capsule's); even slider padding (MainActivity.java, previews)

- Every settings panel uses the capsule corner: radius 26 dp (half a row), circular like the capsule ends. Single-row panels and sliders are full capsules.
- The key-editor board uses the same radius.
- The slider handle has 10 dp of padding at each side, with 10 dp above and below, so it never touches the capsule edge.
- Keyboard unchanged from v3.48.

# AiOS Keyboard v3.61 - single-row panels and sliders are glass capsules; handle centred (MainActivity.java, previews)

- A settings panel with one row is a full capsule (round ends). Multi-row panels keep their rounded corners.
- Each slider is a standard glass capsule panel: the same width and row height (52 dp) as the other panels, with the handle centred on the track.
- Keyboard unchanged from v3.48.

# AiOS Keyboard v3.60 - plain working glass slider (MainActivity.java, previews)

- The iOS 27 slider design is dropped. Each slider is a glass capsule panel with a title and value above, a thin accent track, and a glass handle with dark fading edges.
- Corner icons and tick dots are removed.
- Keyboard unchanged from v3.48.

# AiOS Keyboard v3.59 - handle is the faded glass capsule; outer capsule is a normal glass panel; no tick dots (MainActivity.java, previews)

- The slider handle is a transparent glass capsule with dark edges that fade inward (four concentric hairline rims over the keyboard's glass).
- Each slider's outer capsule is a normal glass panel, the same as the other cards.
- The tick dots are removed.
- Keyboard unchanged from v3.48.

# AiOS Keyboard v3.58 - glass capsule with fading dark edges; liquid handle with outline shadow (MainActivity.java, previews)

- Each slider's outer capsule uses the keyboard's glass gradient and rim, with four concentric hairline rims that are dark at the edge and fade inward.
- The handle is a liquid glass drop: translucent body, outline shadow, bright top and a darker band at the bottom. The old drop shadow is removed.
- Keyboard unchanged from v3.48.

# AiOS Keyboard v3.57 - water-style slider capsule, corner icons, fainter ticks (MainActivity.java, previews)

- Each slider's outer capsule is water-like: a translucent body with a bright top, a soft shadow along the bottom edge and a hairline rim.
- Corner icons from the reference: two overlapping rounded squares, outlined on the left, filled on the right.
- Tick dots are smaller and fainter.
- Keyboard unchanged from v3.48.

# AiOS Keyboard v3.56 - each slider is its own capsule card; glass thumb has a shadow (MainActivity.java, previews)

- Sliders are no longer rows in a shared panel. Each one is its own glass capsule card (round ends), with its title and value above it. Keyboard height, Blur strength and Opacity are separate cards.
- The Liquid Glass thumb has a soft two-layer shadow under it, so it stays visible on a white card.
- Keyboard unchanged from v3.48.

# AiOS Keyboard v3.55 - iOS 27 Liquid Glass slider on every settings slider (MainActivity.java, previews)

- Every settings slider (sliderRow) is the Liquid Glass slider from the iOS 27 reference: capsule track (6 dp) with the accent fill, five tick dots under the track, and a translucent glass capsule thumb (52 x 32 dp) with a highlight and hairline rim.
- Fixes a compile error from v3.51 onward: the slider track called setSize on a generic Drawable. The track height now comes from the layer height.
- Keyboard unchanged from v3.48.

# AiOS Keyboard v3.54 - rounder settings corners; on-off switches are capsules (MainActivity.java, SettingsGlyphs.java, previews)

- Settings panels, tiles, buttons and symbols use a G2 exponent of 2.5 (SettingsGlyphs.G2), rounder than the keys' 4 and still G2. Change this one constant to tune.
- On-off switch tracks and knobs are capsules with round ends (SettingsGlyphs.CAPSULE = 2).
- Keyboard unchanged from v3.48.

# AiOS Keyboard v3.53 - all settings corners are G2 (MainActivity.java, SettingsGlyphs.java, previews)

- Toggle tracks and knobs are G2 capsules (g2Rect), not drawRoundRect.
- The key-editor tiles are G2 with an accent rim (G2Drawable), not GradientDrawable corners.
- Glyph rounded rectangles (keyboard and layout symbols) are G2 paths.
- Back button uses G2 corners (exponent 4), no longer a true circle.
- Round accent dots and the slider knob stay circular: they are circles, not corners.
- Previews draw the same G2 shapes; the old circular CSS corners are removed.
- Keyboard unchanged from v3.48.

# AiOS Keyboard v3.52 - settings previews show the G2 curvature (previews only; app code unchanged from v3.51)

- The settings previews kept the old circular CSS border-radius under the G2 clip, so the visible corners were still circular. The radius is now removed where the G2 shape is drawn.
- The app already draws G2 corners (v3.51); no app code changed in this version.
- Keyboard unchanged from v3.48.

# AiOS Keyboard v3.51 - G2 continuous curvature on every settings panel, tile, button and toggle (MainActivity.java, previews)

- Every rounded panel, tile, button, toggle track and slider in the settings app now uses the keyboard's G2 corners (pill() draws a G2 shape).
- Previews draw the same G2 shapes for every one of those elements.
- Keyboard unchanged from v3.48.

# AiOS Keyboard v3.50 - G2 continuous curvature on every settings panel (MainActivity.java, previews)

- Settings cards clip to the same G2 shape as their painted glass (Outline path from g2Rect), so ripples and separators follow the G2 corner, not a circle.
- Settings previews draw the cards, icon tiles and back button with the same G2 path (power 4) and a matching rim. Previously they used circular CSS corners.
- Keyboard unchanged from v3.48.

# AiOS Keyboard v3.49 - settings app uses the keyboard's glass (MainActivity.java, KeyboardService.java, previews)

- Grouped panels (cards) in the settings app are glass: the keyboard's top-to-bottom gradient, hairline rim and G2 continuous corners (26 dp).
- Icon tiles are tinted glass: the page colour through the glass, a soft sheen over the top, the same rim and a G2 corner (9 dp).
- Back button is a glass circle with the same gradient and rim. No drop shadow.
- KeyboardService.G2Drawable and g2Rect are now package-visible so the settings screen draws with the same code. The keyboard itself is unchanged.
- Previews: settings_preview.py and build_previews.py draw the same glass. Not built with Gradle and not run on a device (only checked by reading the code).

# AiOS Keyboard v3.48 - settings restyled to match iOS 26 Settings exactly (MainActivity.java, SettingsGlyphs.java, Fonts.java, previews)

- Dark and light mode (follows the phone): black / light-grey page, #1C1C1E / white grouped panels with large 26 dp corners (a one-row group is a full capsule), 52 dp rows, hairline separators inset on both sides (they start under the label on the icon list).
- Navigation bar: round glass back button with a chevron (no "Back" text), centred bold title, no divider. Home page keeps a large left-aligned title.
- Section titles are grey, medium weight, not capitalised (as in iOS 26). Footnotes 13 sp grey.
- Home list: coloured icon tiles (30 dp, 8 dp corners, soft top-to-bottom shade) with white drawn symbols, thin grey chevrons. Icons now show only on the home list; sub-pages are plain rows, as in iOS.
- Switch: iOS 26 style, 64 x 28 dp, wide white capsule knob, green on / grey off (dark #5A595E).
- Choices (Theme, Accent colour) are check-mark lists, like Screen Capture > Format. The segmented control and colour swatches are gone.
- Action rows (Open keyboard settings, Clear ...) are left-aligned blue or red text. Sliders: thin track, white round thumb, value on the right.
- New file SettingsGlyphs.java: tile symbols, chevrons and check mark drawn with Canvas. Fonts.java: text tagged "medium" keeps the medium weight.
- Status and navigation bar take the page colour. Version 3.48 (code 48).
- Previews: settings preview in light and dark (previews/AiOS_Settings_light.png, AiOS_Settings_dark.png); settings_preview.py takes light|dark and reads the tile symbols from SettingsGlyphs.java. Keyboard unchanged.
- Not left out on purpose: the floating Search pill at the bottom of the iOS home screen is not built (it would need a working search).
Not built with Gradle and not run on a device. Only a JDK parser was available: the Java parses without syntax errors, but it was not type-checked against the Android SDK.

# AiOS Keyboard v3.47 - settings in the iOS look, dark or light (MainActivity.java, previews)

- Settings follows the phone's dark or light mode. Dark: black page, dark grey grouped panels, iOS separators and grey chevrons. Light: grey page, white panels.
- The glass panels are replaced by solid grouped panels with 10 dp corners, as in iOS Settings. The keyboard's glass is unchanged.
- Each category row has a coloured icon tile (iOS style) matching the page it opens.
- Settings preview: light mode only, as before.
Not built with Gradle and not run on a device. No JDK here, so the Java has not been compiled; checked by reading only.

# AiOS Keyboard v3.46 - settings categories (all files)

- The settings root lists Setup and nine categories: Language, Typing, Emoji, Dictation, Layout & Keys, Sound & Vibration, Privacy, Visuals & Themes, About AiOS Keyboard.
- Working settings: word suggestions, auto-correct, auto-capitalize, double-space period, learn new words, key sounds, vibrate on keypress, clipboard history, remember clipboard after restart, clear clipboard history, clear learned words, keyboard height, theme, accent colour, frosted glass, blur strength, opacity, rounded keyboard corners, emoji key and microphone key positions (links to Layout & Keys), the bottom-row editor.
- Settings the keyboard does not do yet are shown greyed out as Coming soon (no switch, no action).
- About shows the version from build.gradle (3.46). versionName and versionCode are set to match.
- Renderer: one phone per page, read from MainActivity.java.
Not built with Gradle and not run on a device. No JDK here, so the Java has not been compiled; it was checked by reading only.

# AiOS Keyboard v3.45 - renamed to AiOS Keyboard; settings split into pages, iOS style (all files)

- The app is renamed AiOS Keyboard (app name, the setup texts and the README). The package name com.custom.keyboard is unchanged, so an update installs over the old app.
- Settings is now a root list of categories. Each opens its own page with a back button: Setup (enable, select, try it out), Appearance (theme, glass, blur strength, opacity, accent, keyboard height), Keys (the bottom-row editor), Language & Typing (language note, suggestions, corrections, learning, clear learned words), Feedback (vibrate, sound), Tips & Privacy.
- iOS look: grouped inset lists with the keyboard's glass, uppercase section headers, nav bar with back, iOS-style switch (green), segmented control for theme, accent swatches, sliders in the accent colour.
- The settings preview is one phone per page, read from MainActivity.java.
- Keyboard: unchanged apart from the version.
Not built with Gradle and not run on a device. The Java was not compiled: no JDK is installed here (only a runtime), so it was checked by reading only.

# AyOS Keyboard v3.44 - globe icon restored as the language key (KeyboardService.java, MainActivity.java, previews)

- The language key shows the globe icon again (the EN label is removed). A tap still switches keyboard / language. Used for the letters-row button and the emoji panel's bottom-left key.
- Settings > Keys: the tile reads Globe; the picker reads Globe (language).
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.43 - button between space and return splits the return key (KeyboardService.java, MainActivity.java, previews)

- A button between the space bar and return now splits the return key in half (1.25 units each), like the button between 123 and space splits 123. The space bar keeps its size (5.0 units) in all cases.
- Settings > Keys clone and renderer: same layout.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.42 - language key, right-side button, blur and opacity sliders, key editor (all files)

- Language key: the globe is replaced by a key that shows the language code (EN, from the phone's language). A tap switches keyboard / language, as before. It is used for the letters-row button and the emoji panel's bottom-left key.
- Button between space and return: new choice in Settings > Keys (none, emoji, clipboard, language, mic). The space bar gives up 1.25 units when it is used.
- Between 123 and space: now also accepts mic.
- Settings > Appearance: sliders for blur strength (0-24 dp, default 4) and opacity (30-100 %, default 100), and the keyboard height slider is labelled Keyboard height. Blur and opacity apply at once.
- Settings > Keys: a clone of the bottom rows. Tap a highlighted tile (between 123 and space, between space and return, bottom left, bottom right) to choose its button; tap Delete to empty a middle tile. The corners swap when the same button is picked for both. Letters and the fixed keys are shown, not editable.
- Renderer: language key and the new button mirrored; sliders and the key editor are read from MainActivity.java; footer updated.
Not built with Gradle and not run on a device (checked by hand only; javac parse check passed).

# AyOS Keyboard v3.41 - Settings app panels use the keyboard's glass (MainActivity.java, previews)

- Every panel (card) in the Settings app uses the keyboard's glass: a translucent gradient (light: white 55 % to 38 %; dark: white 18 % to 12 %) with a 0.75 dp hairline rim, same corner radius as before.
- The Settings background is a soft peach-to-blue backdrop (dark: deep plum to navy) so the glass shows. Buttons, segmented controls and the text box keep their solid fills.
- Keyboard previews: unchanged apart from the version and footer.
- New: Settings app preview (light mode only), settings_preview.py, read from MainActivity.java and Prefs.java. It shows the layout, the labels and the switch defaults; the slider and accent swatches are drawn at their defaults, and the status lines show the first-launch state.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.40 - one size for letters, capitals and numbers (KeyboardService.java, previews)

- Lowercase letters, capitals and numbers on the character keys share one font size, 24 dp (was 21 dp for capitals and numbers, 29.1 dp for lowercase). Symbols on the symbol pages use the same size.
- Lowercase letters keep their natural x-height, so they look a little shorter than the capitals at the same size.
- Renderer: same size; footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.39 - clipboard icon clearer, same size and colour as the other icons (KeyboardService.java, previews)

- The clipboard is drawn larger: a wider board, a larger clip tab and three text lines, so it reads as a clipboard.
- Same size as the globe (26.4 dp glyph box) and the same pure black (white in dark mode) as the globe, microphone and emoji icons. The grey clipboard colour is no longer used.
- Renderer: same drawing and colour; footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.38 - clipboard icon redrawn in the iOS style (KeyboardService.java, previews)

- The clipboard button is a rounded board with a clip tab on top, like the iOS clipboard symbol. The board's top edge is open under the tab, so the tab joins the board without a line through it.
- The three text lines are removed. Same stroke weight and size as the globe and microphone.
- Renderer: same outline drawing; footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.37 - outline clipboard icon, iOS style (KeyboardService.java, previews)

- The clipboard button uses an outline icon in every mode: rounded board, clip tab on top, three text lines, the same stroke weight as the globe and microphone. The solid clipboard is no longer drawn.
- Same icon size as before (26 dp, like the emoji and microphone).
- Renderer: same outline drawing; footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.36 - smaller globe icon, lowercase letters match the capitals (KeyboardService.java, previews)

- The globe key icon is 22 dp (was 26.5 dp). This is the same globe icon used in the emoji panel's bottom-left, so it is smaller there too.
- Lowercase letters are drawn at 29.1 dp, capitals stay at 21 dp. The lowercase x-height (about 14.8 dp) now matches the capitals' cap height (14.8 dp). Ascenders (b, d, f, h, k, l, t) rise above the capitals, as in the font.
- Renderer: the same sizes are read from the source; footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.35 - 123 and the middle button split equally (KeyboardService.java, previews)

- The original 123 key (2.5 units) is divided in half: 123 and the button between 123 and space each take 1.25 units, so they are equal in size.
- The space bar and return key are unchanged. With no button chosen, the layout is unchanged.
- Renderer: the same equal split; footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.34 - the middle button divides the 123 key (KeyboardService.java, previews)

- When a button is chosen between 123 and space, the 123 key keeps 1.5 of its old 2.5 units and the button takes 1.0. The space bar and return key keep their size, as in the reference.
- With no button chosen, the layout is unchanged.
- Renderer: the same split; footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.33 - customisable corner keys and a middle key (KeyboardService.java, Prefs.java, MainActivity.java, previews)

- Settings > Keys (new card): three choices.
  - Left corner: Emoji (default), Clipboard, Globe, Mic.
  - Right corner: Mic (default), Emoji, Clipboard, Globe.
  - Between 123 and space: None (default), Emoji, Clipboard, Globe. Only one of these can be chosen.
- The two corners are interchangeable: picking the button the other corner already has swaps the two.
- The corner buttons keep the same icon positions as before, so the default layout looks the same.
- The middle key is on the letters and numbers layouts (not the email and web-address layouts).
- The old "Show clipboard button under the keys" switch is removed; the Keys card replaces it.
- Renderer: footer and middle key follow the same rules; cards for each choice added; footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.32 - refraction removed from the panel edges (KeyboardService.java, previews)

- The liquid-glass edge (the bent light and bright rim along the top, sides, bottom and corners) is removed. The LiquidGlassDrawable class and its rim constant are gone.
- The frosted panel is the light blur (4 dp) over a translucent body, with a plain edge. Frosted glass on/off and the blur setting work as before.
- Renderer: the liquid-glass drawing is removed; footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.31 - lighter blur by default (KeyboardService.java, previews)

- The window blur radius is 4 dp (was 12 dp in v3.29 and v3.30, 28 dp before). The background is now softly blurred, not a hard frost. The glass body and liquid-glass edge are unchanged.
- Compatibility is unchanged: the window blur needs Android 12+ with window blur enabled on the phone; otherwise the translucent panel is used.
- Renderer: the window blur is read from the code (K.windowBlurDp); footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.30 - neutral refracting liquid-glass edge (KeyboardService.java, previews)

- The liquid-glass rim no longer uses the accent colour or the cool counter-fringe, which read as a blue outline. The edge is now neutral light, like the floating dock in the iOS 27 reference.
- Light bends in along every edge (top, sides, bottom, top corners): brightest at the glass and falling off quickly inwards.
- A crisp bright edge: strongest at the top, with a soft bounce light at the bottom. A specular band runs across the top.
- Frosted glass setting and blur radius are unchanged from v3.29.
- Renderer: drawLiquidGlass() mirrors the new drawable; footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.29 - lighter frosted glass with a liquid-glass edge (KeyboardService.java, previews)

- Frosted glass is lighter by default: the window blur radius is 12 dp (was 28 dp) and the glass body is more see-through (about 50 % light, 46 % dark over the blur, was about 72 % / 90 %).
- Liquid-glass edge: the frosted panel is a LiquidGlassDrawable. A rim about 11 dp deep is drawn along every edge (top, sides, bottom, and the top corners; the bottom corners stay square as before). It is brightest at the glass and fades inwards (concentric rings), with a vibrant accent fringe, a cool counter-fringe, and a bright specular line along the top.
- The rim is drawn whether or not the phone can blur, so the glass edge shows on every phone when frosted glass is on. It is not drawn with frosted glass off (solid panel).
- Limit: an input method cannot read the pixels under the keyboard, so the refraction is drawn, not calculated from the app's content.
- Renderer: drawLiquidGlass() mirrors the drawable; footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.28 - frosted glass on by default, one pop-up position for press and hold (KeyboardService.java, Prefs.java, previews)

- Frosted glass is on by default (Prefs.on: only key sounds and the clipboard button default to off). The settings switch shows on for a new install.
- Compatibility: the system window blur is used on Android 12+ when the phone has cross-window blur enabled. The window style is re-applied when that setting changes (WindowManager cross-window blur listener, removed in onDestroy), and on every keyboard start. Where blur is not available the panel is a translucent wash, not a solid panel. Pop-up snapshots use an in-app blur and work on every version.
- Press and hold pop-up: the pressed key is squeezed to PRESS_SCALE, and getLocationOnScreen() includes that scale, so the hold pop-up was placed a little lower and to the side. The pop-up now reads the key's layout frame (layoutScreenLocation), so press and hold share one position. The hold reuses the same pop-up window and changes only its label.
- Renderer: frosted glass on by default in every card, two solid-panel cards added; footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.27 - press circle on emoji / clipboard / mic, smoother emoji and clipboard panels (KeyboardService.java, previews)

- Pressing the emoji, clipboard or microphone key shows a circular glass highlight (40 dp, same gradient and rim as the glass disc of the emoji bar) behind the icon. It fades in on press and out on release. Other keys are unchanged.
- Emoji and clipboard panels both rise from the very bottom edge of the keyboard and sink back to it. The travel is the keyboard's own height, so the panel starts and ends fully out of view (before, the emoji panel travelled only its own height).
- The clipboard panel now animates when it opens and when it closes (before, it switched instantly). Both panels use one shared rise and sink (300 ms rise, 260 ms sink) with the animations drawn on a hardware layer for smoother motion.
- The letters keyboard is hidden while the emoji or clipboard panel is open and comes back when the panel closes.
- Renderer: press circle drawn on the emoji, clipboard and mic keys; footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.26 - trackpad sheet follows light / dark mode (KeyboardService.java, previews)

- The trackpad glass wash is light in light mode (white 40 %) and dark grey in dark mode (#202022 at 70 %), instead of a white wash in dark mode.
- Renderer updated to the same colour; footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.25 - local SQLite storage for clipboard history, pinned items and custom stickers

New files:
- KeyboardDb.java: SQLiteOpenHelper (Android's built-in SQLite, no Gradle change). File keyboard.db in the app's private data directory, version 1.
  - clipboard_items (id INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT, is_pinned INTEGER, timestamp INTEGER)
  - custom_stickers (id INTEGER PRIMARY KEY AUTOINCREMENT, file_path TEXT, timestamp INTEGER)
  - CRUD: insertClip / queryClips / getClip / findClipByContent / clipCount / updateClipPinned / updateClipContent / deleteClip / deleteUnpinnedClips / deleteAllClips / enforceClipLimit; insertSticker / querySticker / getSticker / updateStickerPath / deleteSticker.
  - enforceClipLimit removes only unpinned items (oldest first). If every item is pinned and the limit is reached, the newest unpinned copy is dropped instead.
- StickerStore.java: sticker image files in files/stickers/ (internal storage). add / list / load / delete / replace. A file is only read or deleted if it sits directly in that folder.

KeyboardService.java:
- Clipboard history uses the database when "Remember across restarts" is on (clipAddStored, clipTogglePin, clipRemove, clipClearUnpinned, clipReloadFromDb). The list in memory is rebuilt from the database after each change.
- Turning the option on writes the current history to the database; turning it off deletes the stored history (as before). The old JSON copy in preferences is moved into the database once and then removed.
- Memory-only behaviour (option off) is unchanged.

Not built with Gradle. KeyboardDb and StickerStore were type-checked with javac against stub Android classes; KeyboardService.java was reviewed by hand only.
No sticker picker UI was added: StickerStore provides the storage and loading API.

# AyOS Keyboard v3.24 - trackpad sheet fully covers the keys and blocks their input (KeyboardService.java, previews)

- The sheet is opaque over every key (no see-through top or bottom rows). Its fade is only in an 8 dp band beside the keys, which extends slightly into the gap between keys and the header / footer.
- The sheet consumes every touch while it is shown (TrackpadOverlay.onTouchEvent returns true), so a finger placed on a key during trackpad mode types nothing. The space key keeps the moves it started with.
- The sheet is added over the whole keyboard frame (inputOuter) at keys top minus 8 dp, sized to keys plus 8 dp each side; the snapshot is taken from the keyboard root.
- Renderer: trackpad scene uses the same mask and band; footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.23 - trackpad sheet covers only the keys, with a smooth fade (KeyboardService.java, previews)

- The overlay now covers only the keys area (keysHost), not the suggestion bar or the globe / microphone row, which stay unchanged.
- The blurred keys and the glass wash are drawn into a layer and faded out at the top and bottom edges (a 16 dp feather, DST_IN gradient mask), so there is no hard cut.
- The overlay no longer clips to the panel's corners (it is inside the keys area).
- Renderer: trackpad scene uses the same region, blur, feather and prompt; footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.22 - trackpad sheet blends into the header and footer (KeyboardService.java, previews)

- The input view is now a FrameLayout (inputOuter) around the keyboard (inputRoot), so the trackpad sheet covers the whole keyboard: suggestion bar, keys and globe / microphone row.
- The sheet is a snapshot of the whole keyboard blurred in four steps (half-size chain). Bands: header blur grows from the top edge toward the keys, the keys get the full blur, the footer blur fades back out toward the bottom edge.
- The glass wash fades to clear at the top and bottom edges, so there is no hard cut at the header or footer. The sheet keeps the panel's corner radius.
- The prompt is soft grey (light 0xFF636366, dark 0xFFAEAEB2) instead of the text colour.
- Renderer: the trackpad scene uses the same bands, wash and prompt colour; footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.21 - space bar as a cursor trackpad (KeyboardService.java, previews)

- Hold the space bar still for 380 ms: it becomes a trackpad while the finger stays down. Moving the finger left/right moves the cursor one letter per 9 dp; up/down moves it one line per 22 dp (DPAD up/down). Lifting the finger returns to the normal keyboard.
- A move of more than 10 dp before the hold completes cancels the hold, so the existing quick swipe on the space bar still works.
- While active, the keys are covered by a blurred copy of themselves (downscale/upscale blur, works on all supported Android versions) with the same top-to-bottom glass wash as the keys, a rim, and the prompt "Move your fingers to control the cursor". It fades in and out.
- The keys now sit in a keysHost FrameLayout so the overlay can cover them; the layout is otherwise unchanged.
- Renderer: trackpad scene added (blur via canvas filter); footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.20 - emoji category bar balanced (KeyboardService.java, previews)

- The ABC and delete slots are sized to their content plus the same side padding (EMOJI_BAR_PAD_DP = 12 dp on each side), so the ABC label and the delete glyph sit equally far from the edges. The ABC width is measured with the UI font.
- The category icon row is centred on the bar: CatIconsView takes the view width and a shift ((delete slot - ABC slot) / 2), and icon 5 of 9 sits on the bar centre. Pitch and icon size are unchanged.
- Renderer (scenes.js) uses the same geometry; footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.19 - emoji category highlight centred and glass (KeyboardService.java, previews)

- The selected category's circle is now a glass disc (CatIconsView.glassDisc): the same vertical gradient and 0.75 dp rim as capsule().
- The disc is drawn centred on the icon centre (translate to the disc's corner, then draw at its own size).
- The traced category icons were re-centred so each one's ink bounding box is centred on the icon centre (they sat about 0.2 to 0.7 units off).
- Renderer: glassCircle() in scenes.js matches the glass disc; footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.18 - emoji category icons traced from the iOS 27 reference (KeyboardService.java, previews)

- The nine category icons of the emoji bar are traced from the reference screenshot: clock, smiley, dog, apple, ball, car, light bulb, heart, flag (in that order, matching Recent ... Flags).
- Each icon is one path filled even-odd (the traced stroke rings), used for both the normal and the selected state. The reference only shows the dog selected, so the selected dog matches it exactly; other selected icons use the same traced shape on the grey circle.
- Renderer: category icons are filled even-odd in scenes.js; footer updated.
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.17 - held clipboard tile takes the colour of the capsule choice (KeyboardService.java, previews)

- The held (long-pressed) clipboard tile is no longer a fixed blue (light mode) or grey (dark mode).
- Default while the capsule is open: light grey in light mode, light (white) in dark mode.
- The tile tint follows the capsule highlight as it glides: green for Pin, blue for Unpin, red for Delete. The tile and the highlight animate together.
- Closing the capsule restores the tile's normal glass.
- Code: applyTileTint(), clipTileColor / clipMenuCardBg fields, the tint animated in glideClipHighlight(), restored in dismissClipMenu().
- previews/ re-rendered for v3.17 (renderer scenes.js updated; new default-grey scene added).
Not built with Gradle and not run on a device (checked by hand only).

# AyOS Keyboard v3.4 - shift key states, globe / emoji / dictation icons (KeyboardService.java, previews)

Shift key:
- The shift key tile no longer changes colour (no white / dark fill any more); only the arrow is coloured.
- Shift off = outline arrow only, shift on = solid arrow, caps lock = solid arrow with the bar. Arrow colour = the normal key text colour (light mode: dark arrow, dark mode: light arrow).
- Typing behaviour unchanged: shift on = the next letter is a capital, shift off = lowercase, caps lock = all capitals.

Icons (globe, emoji, dictation microphone), redrawn to the reference icon images (proportions measured on the images):
- Frosted glass ON (Settings) = outline icons: ring + meridian + parallels globe, ring face with dot eyes and an open mouth with a white teeth band, capsule outline + U holder + stem + foot microphone.
- Frosted glass OFF (solid keyboard, the default) = solid icons: globe = filled disc with the globe lines cut out, emoji = filled face with cut-out eyes / mouth, microphone = filled capsule (U holder, stem and foot stay lines).
- The choice is made when the icon is drawn (KeyView.styleIcon, reads Prefs.K_BLUR), so it follows the setting. It applies to the letters / numbers tool row, the emoji panel footer (globe + mic) and the clipboard panel footer (emoji + mic).
- New glyph ids: G_EMOJI_LINE, G_GLOBE_SOLID (G_GLOBE / G_MIC_LINE are now the outline globe / mic, G_EMOJI / G_MIC the solid ones).
Not built with Gradle and not run on a device (only checked by hand). previews/ re-rendered for v3.4 (renderer updated; the last four cards of each sheet show frosted glass ON).

# AyOS Keyboard v3.3 - keyboard panel matched to the iOS 27 reference (KeyboardService.java, Prefs.java, MainActivity.java)

Measured on the iOS reference screenshot (558 px = 390 dp wide, 1.431 px per dp) and applied:
- Panel: solid #1F1F1F, top corner radius 26 dp, 49.6 dp from the panel top to the first key row (padding 2 + suggestion bar 43 + 5 key gap).
- Keys: flat #434343 tiles (white 16 % over the panel), no rim, no gradient. 32.4 x 42 dp, 6 dp sideways / 10 dp between rows (row pitch 52 dp = new default height), 6 dp screen margin, G2 corner (extent 12 dp = about 10 px circular radius on the reference).
- Bottom row: 123 = 90 dp, space = 186 dp (no "EN" label), return = 90 dp. Shift / delete sit 14 dp from the letters, as before.
- Labels: always capitals, 21 dp (cap height 14.8 dp); 123 / ABC 18 dp; suggestions 16.5 dp with 1 px, 21 dp tall dividers (white 7 %). With nothing to suggest the dividers move to 30 dp from both screen edges (wide middle cell), like the reference.
- Icons: shift = solid arrow 19.6 x 16.8 dp (key turns white with a dark arrow while shift / caps lock is on), delete 19.6 x 16.8, return 18.9 x 16.1, emoji 25 x 26 (oval eyes, open mouth with teeth), mic 17.5 x 26.6 (capsule + narrower U holder + stem + foot).
- Emoji and mic: centres 41 dp from the left / 42 dp from the right edge and 37 dp under the bottom key row (the accessory row is 64 dp tall).
- The clipboard button under the keys is hidden by default. New setting "Show clipboard button under the keys" (Prefs.K_CLIP_BTN) brings it back, 44 dp after the emoji icon. Clipboard history is still collected.
- Frosted glass is now off by default (the iOS panel is solid); it can still be switched on.
Not built with Gradle and not run on a device (only syntax-checked by hand). previews/ re-rendered for v3.3 (renderer updated to match).

# AyOS Keyboard v3.2 (KeyboardService.java only)

Emoji panel:
1. Search pill: same padding at the top and at both sides (8 dp). The panel itself uses the same 30 dp top corner radius as the standard keyboard (it is the window background, identical on every layer).
2. Searching no longer opens a separate panel. The pill stays on top (with a round close button), the first emoji row shows the results, and the letters keyboard slides up over the rest of the grid. The window height stays the same as the emoji panel, so nothing jumps. Close button, back key or picking an emoji leaves the search.

Clipboard panel:
1. Header: only the buttons are in glass - a circle for back and a capsule for Clear all.
2. The "Clipboard" title is centred on the panel.

Tuning: PILL_*, CLIP_CLEAR_W_DP, EMOJI_PILL_* near the top of KeyboardService.java.
Not built with Gradle and not run on a device (only syntax-checked). Previews: previews/.

## Icons, letter case and press effect
- Letter keys and the key callout now show lowercase letters normally and uppercase when Shift / Caps Lock is on.
- Globe, smiley and microphone are always the outline icons from the reference, whether frosted glass is on or off (no solid versions).
- Smiley mouth and teeth band re-proportioned to match the reference.
- Press glow / halo removed from keys. The squeeze and bounce animation is unchanged.

## v3.6
- Clipboard header capsules (back, Clear all) use the same top padding, side padding and height as the Search Emoji capsule.
- Smiley mouth: curved smile line and curved teeth band, like the reference.
- Globe, smiley and microphone: pure black (white in dark mode) and one shared outline weight (1.9 dp).

## v3.7
- Key pop-up reshaped to the reference: head 1.61 x key width, head top 1.51 key heights above the key, sides curve in over 0.3 key heights and meet the key at its top, head corner radius 14 % of the head width. The label is centred in the head.
- Every key and button is now glass, using the same gradient and rim as the Search Emoji capsule (light and dark), with a brighter glass state when pressed. The blue action key is glass too. Clipboard cards use the same glass.

## v3.8
- Key pop-up redrawn from a pixel-by-pixel measurement of the reference: head 1.69 x key width, head top 1.50 key heights above the key, round head corners (19.7 % of the head width), shoulder from 0.26 key heights above to 0.10 below the key top (crisp turn off the head, soft settle into the neck), round neck-bottom corners (27.8 % of the key width), label centred like the reference.
