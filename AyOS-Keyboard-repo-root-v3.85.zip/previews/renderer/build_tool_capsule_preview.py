"""Builds the frame-by-frame tool capsule preview. It uses the same constants (extracted from KeyboardService.java)
and the same Canvas drawing (scenes.js) as the keyboard sheets, so the footer, the key sizes and the capsule scale
are the ones the code defines. Usage:
    python3 build_tool_capsule_preview.py ../../app/src/main/java/com/custom/keyboard/KeyboardService.java out.html
"""
import base64, json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from extract_from_java import extract, search

JAVA, OUT = sys.argv[1], sys.argv[2]
VERSION = os.environ.get('AYOS_VERSION', '3.1.26')
K = extract(JAVA)
K['search_hap'] = search(K['emojiKeywords'], 'hap')
js = open(os.path.join(HERE, 'scenes.js'), encoding='utf-8').read()
FONTS = os.path.join(os.path.dirname(os.path.abspath(JAVA)), '..', '..', '..', '..', 'assets', 'fonts')
faces = ''
for wt, fn in [(400, 'SFPRODISPLAYREGULAR.OTF'), (500, 'SFPRODISPLAYMEDIUM.OTF'), (700, 'SFPRODISPLAYBOLD.OTF')]:
    data = base64.b64encode(open(os.path.join(FONTS, fn), 'rb').read()).decode()
    faces += "@font-face{font-family:SFPD;font-weight:%d;src:url(data:font/otf;base64,%s) format('opentype')}\n" % (wt, data)

PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Tool capsule: frame by frame (v%(ver)s)</title>
<style>
%(faces)s
:root{color-scheme:light dark}
body{margin:0;padding:16px;font:14px/1.4 -apple-system,system-ui,"Segoe UI",Roboto,sans-serif;background:#e4e6eb;color:#1c1c1e}
.card{max-width:560px;margin:0 auto;background:#f7f7f9;border-radius:18px;padding:16px}
h1{font-size:17px;margin:0 0 4px}
.sub{color:#6c6c70;font-size:12.5px;margin-bottom:12px}
.stage{background:#dfe2e8;border-radius:14px;padding:10px}
canvas.main{display:block;width:100%%;height:auto;border-radius:12px}
.row{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;align-items:center}
button{font:inherit;border:0;border-radius:10px;padding:9px 14px;background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.12);cursor:pointer}
button.primary{background:#0a7aff;color:#fff}
button:disabled{opacity:.45;cursor:default}
input[type=range]{flex:1;min-width:160px}
.readout{font-variant-numeric:tabular-nums;font-size:13px;background:#fff;border-radius:10px;padding:8px 10px;margin-top:10px}
.phase{font-weight:600}
h2{font-size:14px;margin:18px 0 8px}
.strip{display:grid;grid-template-columns:repeat(2,1fr);gap:8px}
.cell{background:#fff;border-radius:10px;padding:6px;font-size:11.5px;font-variant-numeric:tabular-nums;cursor:pointer}
.cell canvas{width:100%%;height:auto;display:block;border-radius:6px}
.cell.now{outline:2px solid #0a7aff}
.note{color:#6c6c70;font-size:12px;margin-top:12px}
</style></head><body>
<div class="card">
  <h1>Tool capsule: open and close, frame by frame</h1>
  <div class="sub">TypeFlow v%(ver)s. These frames are drawn by the same code as the keyboard previews: the constants and the
  footer layout come from KeyboardService.java, and the springs are the same as CornerGooView. Scale: the 390 dp keyboard
  card, the same as the sheets.</div>
  <div class="stage"><canvas class="main" id="main"></canvas></div>
  <div class="row">
    <button class="primary" id="btnOpen">Open</button>
    <button id="btnClose">Close</button>
    <button id="btnPause" disabled>Pause</button>
    <button id="btnPrev" disabled>&#9664; frame</button>
    <button id="btnNext" disabled>frame &#9654;</button>
    <button id="btnDark">Dark</button>
  </div>
  <div class="row"><input type="range" id="seek" min="0" max="0" value="0" step="1" disabled></div>
  <div class="readout" id="readout">Press Open or Close. Frames run at 60 fps.</div>
  <h2>Open: frame strip (every 4th frame)</h2>
  <div class="strip" id="stripOpen"></div>
  <h2>Close: frame strip (every 4th frame)</h2>
  <div class="strip" id="stripClose"></div>
  <div class="note">Frames are rendered on demand and cached. Opening starts from the key's circle; closing starts from the open capsule.</div>
</div>
<script>const K = %(K)s;
%(js)s
</script>
<script>
// ---- the controller: every frame is rendered by renderCard (the keyboard's own drawing code)
const ACC_Y = APP_H + PAD_T + SUG_H + 4 * KEY_H;     // the footer's top, as renderCard computes accY
const X0 = PAD_X, WW = W - 2 * PAD_X;
const FR_N = 0;
let dark = false;
const cache = {};
const mainEl = document.getElementById('main');
const mctx = mainEl.getContext('2d');
const seek = document.getElementById('seek');
const readout = document.getElementById('readout');
const CROP_TOP = ACC_Y - dp(28), CROP_H = dp(64) + dp(56);

function frameCanvas(kind, i) {
  const key = kind + ':' + i + ':' + (dark ? 'd' : 'l');
  if (cache[key]) return cache[key];
  const fr = gooSimFrames(kind, X0, WW, ACC_Y)[i];
  window.GOO_FORCE = fr;
  const card = renderCard({ state: { layer: T.LAYER_LETTERS }, cornerPopup: Math.max(fr.u, 0.0001), dark: dark });
  window.GOO_FORCE = null;
  const out = mkCanvas(W, CROP_H);
  out.getContext('2d').drawImage(card, 0, CROP_TOP, W, CROP_H, 0, 0, W, CROP_H);
  cache[key] = out;
  return out;
}

function phaseName(u, kind, f) {
  if (kind === 'close') {
    if (f > GOO_CLOSE_FRAME_N - 2) return 'Closing: the highlights fade out; the capsule is already gone';
    if (u > 0.9) return 'Closing: the capsule is still in the middle';
    if (u > 0.45) return 'Closing: the capsule rebounds back from the mic';
    if (u > 0.149) return 'Closing: the capsule narrows toward the key';
    if (u > 0.054) return 'Closing: the halves pinch back together';
    return 'Closing: the mini capsule returns to the key circle';
  }
  if (f < 2) return 'Opening: the highlights of the emoji and mic keys pop in (frames 0 to 1, no capsule yet)';
  if (u <= 0.054) return 'Opening: the capsule appears as a mini capsule on the circle';
  if (u <= 0.148) return 'Opening: the neck tapers as the capsule leaves the circle';
  if (u <= 0.45) return 'Opening: detached; the right half glides and widens';
  if (u <= 0.72) return 'Opening: the centred capsule rebounds into the mic';
  return 'Opening: settled in the middle; the mic springs back';
}

let runKind = null, runN = 0, idx = 0, playing = false, rafId = 0;
function showFrame(i) {
  if (!runKind) return;
  idx = Math.max(0, Math.min(runN - 1, i));
  const img = frameCanvas(runKind, idx);
  mainEl.width = img.width; mainEl.height = img.height;
  mctx.drawImage(img, 0, 0);
  seek.value = idx;
  document.querySelectorAll('.cell.now').forEach(c => c.classList.remove('now'));
  const cell = document.querySelector('[data-run="' + runKind + '"][data-f="' + idx + '"]');
  if (cell) cell.classList.add('now');
  const fr = gooSimFrames(runKind, X0, WW, ACC_Y)[idx];
  readout.innerHTML = '<span class="phase">' + phaseName(fr.u, runKind, idx) + '</span><br>' +
    'Frame ' + idx + ' / ' + (runN - 1) + ' &middot; t = ' + Math.round(fr.t * 1000) + ' ms &middot; clock u = ' + fr.u.toFixed(3) +
    ' &middot; capsule ' + (fr.x0 / D).toFixed(1) + ' to ' + (fr.x1 / D).toFixed(1) + ' dp &middot; mic offset ' + (fr.micX / D).toFixed(2) + ' dp';
  document.getElementById('btnPrev').disabled = idx === 0;
  document.getElementById('btnNext').disabled = idx === runN - 1;
}
function stop() { playing = false; cancelAnimationFrame(rafId); document.getElementById('btnPause').textContent = 'Pause'; }
function play() {
  playing = true; document.getElementById('btnPause').textContent = 'Pause';
  const start = performance.now() - (idx / 60) * 1000;
  const tick = now => {
    if (!playing) return;
    const f = Math.floor((now - start) / (1000 / 60));
    if (f >= runN - 1) { showFrame(runN - 1); stop(); return; }
    showFrame(f); rafId = requestAnimationFrame(tick);
  };
  rafId = requestAnimationFrame(tick);
}
function setRun(kind) {
  runKind = kind; runN = gooSimFrames(kind, X0, WW, ACC_Y).length;
  seek.min = 0; seek.max = runN - 1; seek.disabled = false;
  document.getElementById('btnPause').disabled = false;
  stop(); showFrame(0);
}
function buildStrip(kind, elId) {
  const el = document.getElementById(elId);
  el.innerHTML = '';
  const n = gooSimFrames(kind, X0, WW, ACC_Y).length;
  for (let i = 0; i < n; i += 4) {
    const cell = document.createElement('div');
    cell.className = 'cell'; cell.dataset.run = kind; cell.dataset.f = i;
    const img = frameCanvas(kind, i);
    const c = document.createElement('canvas'); c.width = img.width; c.height = img.height;
    c.getContext('2d').drawImage(img, 0, 0);
    cell.appendChild(c);
    const fr = gooSimFrames(kind, X0, WW, ACC_Y)[i];
    const lab = document.createElement('div');
    lab.textContent = 'f' + i + ' \u00b7 ' + Math.round(fr.t * 1000) + ' ms \u00b7 u ' + fr.u.toFixed(2);
    cell.appendChild(lab);
    cell.onclick = () => { if (runKind !== kind) setRun(kind); stop(); showFrame(i); };
    el.appendChild(cell);
  }
}
function buildStrips() { buildStrip('open', 'stripOpen'); buildStrip('close', 'stripClose'); }

document.getElementById('btnOpen').onclick = () => { setRun('open'); play(); };
document.getElementById('btnClose').onclick = () => { setRun('close'); play(); };
document.getElementById('btnPause').onclick = () => { if (playing) stop(); else if (runKind) play(); };
document.getElementById('btnPrev').onclick = () => { stop(); showFrame(idx - 1); };
document.getElementById('btnNext').onclick = () => { stop(); showFrame(idx + 1); };
seek.oninput = () => { stop(); showFrame(parseInt(seek.value, 10)); };
document.getElementById('btnDark').onclick = () => {
  dark = !dark; document.getElementById('btnDark').textContent = dark ? 'Light' : 'Dark';
  buildStrips(); if (runKind) showFrame(idx);
};

(async () => {
  await document.fonts.load('400 20px SFPD'); await document.fonts.load('500 20px SFPD');
  buildStrips();
  setRun('open'); stop(); showFrame(0);
})();
</script></body></html>
"""
page = PAGE % dict(ver=json.dumps(VERSION)[1:-1], faces=faces, K=json.dumps(K, ensure_ascii=False), js=js)
open(OUT, 'w', encoding='utf-8').write(page)
print('wrote', OUT, len(page) // 1024, 'KB')
