Regenerates the two preview sheets from KeyboardService.java (needs Python 3 + playwright + chromium, Noto Color Emoji; the app font SF Pro Display is read from app/src/main/assets/fonts):

    AYOS_VERSION=3.2 python3 build_previews.py ../../app/src/main/java/com/custom/keyboard/KeyboardService.java ./sheet

Every constant, colour, the category icon paths, the default key height / accent (Prefs.java) and the emoji lists (EmojiData.java) are parsed from the app source;
scenes.js is a Canvas port of the drawing code. Stand-ins: Notes background, sample texts, recent emoji, Noto Color Emoji instead of the phone emoji font.

Settings app preview (light and dark):
    python3 settings_preview.py ../../app/src/main/java/com/custom/keyboard/MainActivity.java ../../app/src/main/java/com/custom/keyboard/Prefs.java ./settings_light.png light
    python3 settings_preview.py ../../app/src/main/java/com/custom/keyboard/MainActivity.java ../../app/src/main/java/com/custom/keyboard/Prefs.java ./settings_dark.png dark
Reads the labels and the row order from MainActivity.java, the icon-tile symbols and colours from SettingsGlyphs.java; uses the app font from app/src/main/assets/fonts.
