"""Pull every number the previews depend on straight out of KeyboardService.java."""
import os, re, json, sys

def java_unescape(s):
    # Java "\uD83D\uDE00" escapes (surrogate pairs) -> real characters
    s = re.sub(r'\\u([0-9A-Fa-f]{4})', lambda m: chr(int(m.group(1), 16)), s)
    return s.encode('utf-16', 'surrogatepass').decode('utf-16')

def extract(path):
    src = open(path, encoding='utf-8').read()
    K = {}
    for m in re.finditer(r'static final float (\w+)\s*=\s*([\d.]+)f;', src):
        K[m.group(1)] = float(m.group(2))
    for m in re.finditer(r'static final int (\w+)\s*=\s*(0x[0-9A-Fa-f]+|\d+);', src):
        K[m.group(1)] = int(m.group(2), 0)
    # colours: the two branches of loadColors()
    lc = src[src.index('private Colors loadColors()'):src.index('private boolean blurSupported()')]
    dark_blk = lc[lc.index('if (dark) {'):lc.index('} else {', lc.index('if (dark) {'))]
    light_blk = lc[lc.index('} else {', lc.index('if (dark) {')):lc.index('c.accent')]
    def colors(blk):
        return {m.group(1): int(m.group(2), 16) for m in re.finditer(r'c\.(\w+)\s*=\s*0x([0-9A-Fa-f]+);', blk)}
    K['colors'] = {'dark': colors(dark_blk), 'light': colors(light_blk)}
    # panel colours
    pc = src[src.index('private int panelColor('):src.index('private Drawable panelDrawable')]
    nums = re.findall(r'colors\.dark \? 0x([0-9A-Fa-f]+) : 0x([0-9A-Fa-f]+)', pc)
    K['panel'] = {'solid': nums[0], 'blur': nums[1], 'noblur': nums[2]}
    K['windowBlurDp'] = float(re.search(r'DEFAULT_BLUR_DP = (\d+);', open(__import__('os').path.join(__import__('os').path.dirname(__import__('os').path.abspath(path)), 'Prefs.java'), encoding='utf-8').read()).group(1))
    # EdgeBlurLayout numbers
    K['edge'] = {
        'steps': int(re.search(r'STEPS = (\d+);', src).group(1)),
        'maxBlurDp': float(re.search(r'maxBlur = dp\((\d+)\);', src).group(1)),
    }
    # press animation
    pf = src[src.index('private void pressFx'):src.index('/** Soft light inside the key')]
    K['press'] = {
        'downMs': int(re.search(r'scaleX\(PRESS_SCALE\)\.scaleY\(PRESS_SCALE\)\.setDuration\((\d+)\)', pf).group(1)),
        'upMs': int(re.search(r'scaleX\(1f\)\.scaleY\(1f\)\.setDuration\((\d+)\)', pf).group(1)),
        'overshoot': float(re.search(r'OvershootInterpolator\(([\d.]+)f\)', pf).group(1)),
        'glowDownMs': int(re.search(r'glowAnim\.setDuration\(down \? (\d+) : (\d+)\)', pf).group(1)),
        'glowUpMs': int(re.search(r'glowAnim\.setDuration\(down \? (\d+) : (\d+)\)', pf).group(2)),
    }
    # emoji keyword table -> run the code's own search algorithm
    kw = src[src.index('EMOJI_KEYWORDS = {'):src.index('/** Matches the query against the keyword list')]
    entries = [java_unescape(m.group(1)) for m in re.finditer(r'"((?:[^"\\]|\\.)*)"', kw)]
    K['emojiKeywords'] = entries
    # ---- category icon table (CAT_ICONS): 7 strings per icon
    ci = src[src.index('CAT_ICONS = {'):]
    ci = ci[:ci.index('\n    };')]
    lits = [m.group(1).replace('\\\\', '\\').replace('\\"', '"') for m in re.finditer(r'"((?:[^"\\]|\\.)*)"', ci)]
    K['catIcons'] = [lits[i:i + 7] for i in range(0, len(lits), 7)]
    # ---- app defaults that live in Prefs.java / EmojiData.java (same folder as the service)
    import os
    folder = os.path.dirname(os.path.abspath(path))
    pf = open(os.path.join(folder, 'Prefs.java'), encoding='utf-8').read()
    K['defaultHeight'] = int(re.search(r'DEFAULT_HEIGHT = (\d+);', pf).group(1))
    acc = re.search(r'ACCENTS = \{(.*?)\};', pf, re.S).group(1)
    K['accent'] = int(re.findall(r'0x([0-9A-Fa-f]{8})', acc)[0], 16)   # default accent = first entry
    ed = open(os.path.join(folder, 'EmojiData.java'), encoding='utf-8').read()
    names = re.search(r'NAMES = \{(.*?)\};', ed, re.S).group(1)
    K['emojiNames'] = re.findall(r'"([^"]*)"', names)
    lists = []
    for m in re.finditer(r'data\.add\(makeList\((.*?)\)\);', ed, re.S):
        text = ''.join(re.findall(r'"((?:[^"\\]|\\.)*)"', m.group(1)))
        seen = []
        for v in text.split():
            if v not in seen: seen.append(v)
        lists.append(seen)
    K['emojiLists'] = [[]] + lists          # index 0 = Recent (filled at run time)
    return K

def search(entries, query):
    """Same two-pass algorithm as emojiSearchResults() (category-name matching needs EmojiData: not in zip)."""
    out = []
    words = query.strip().lower().split()
    for pass_ in range(2):
        for entry in entries:
            e, keys = entry.split('|', 1)
            keys = keys.split(' ')
            ok = True
            for w in words:
                hit = any((k.startswith(w) if pass_ == 0 else (w in k)) for k in keys)
                if not hit:
                    ok = False; break
            if ok and e not in out:
                out.append(e)
    return out

if __name__ == '__main__':
    K = extract(sys.argv[1])
    K['search_hap'] = search(K['emojiKeywords'], 'hap')
    json.dump(K, open(sys.argv[2], 'w'), ensure_ascii=False, indent=1)
    show = {k: v for k, v in K.items() if k not in ('emojiKeywords', 'colors')}
    print(json.dumps(show, ensure_ascii=False, indent=1)[:2600])
    print('colors dark :', {k: hex(v) for k, v in K['colors']['dark'].items()})
    print('colors light:', {k: hex(v) for k, v in K['colors']['light'].items()})
