import json, sys, html, os
HERE = os.path.dirname(os.path.abspath(__file__))
VERSION = os.environ.get('AYOS_VERSION', '3.1.19')
from playwright.sync_api import sync_playwright
from extract_from_java import extract, search

EMOJI_TTF = '/mnt/user-data/uploads/AppleColorEmoji-Linux.ttf'   # the Apple emoji preview font when it is uploaded; else Noto Color Emoji
JAVA = sys.argv[1]; OUT = sys.argv[2]
K = extract(JAVA)
FONTS = os.path.join(os.path.dirname(os.path.abspath(JAVA)), '..', '..', '..', '..', 'assets', 'fonts'); K['search_hap'] = search(K['emojiKeywords'], 'hap')
js = open(os.path.join(HERE, 'scenes.js'), encoding='utf-8').read()

PAGE = """<!doctype html><html><head><meta charset="utf-8"><style>
%(faces)s
body{margin:0;background:%(bg)s;font-family:SFPD,Inter,sans-serif;color:%(fg)s}
#sheet{width:3400px;padding:84px 84px 70px;box-sizing:border-box;background:%(bg)s}
h1{font-size:64px;margin:0 0 14px;font-weight:700;letter-spacing:-1px}
.sub{font-size:23px;line-height:1.5;color:%(sub)s;max-width:3100px;margin-bottom:56px}
.grid{display:grid;grid-template-columns:repeat(4,780px);column-gap:40px;row-gap:54px}
.cap{font-size:25px;font-weight:600;margin-bottom:14px;min-height:34px;color:%(fg)s}
canvas{display:block;box-shadow:0 14px 40px %(sh)s;border-radius:56px}
.foot{font-size:22px;line-height:1.55;color:%(sub)s;margin-top:60px;max-width:3100px}
.foot b{color:%(fg)s}
</style></head><body><div id="sheet"><h1 id="t"></h1><div class="sub" id="s"></div><div class="grid" id="g"></div><div class="foot" id="f"></div></div>
<script>const K = %(K)s;
%(js)s
(async () => {
  await document.fonts.load('400 20px SFPD'); await document.fonts.load('500 20px SFPD'); await document.fonts.load('700 20px SFPD');
  await document.fonts.load('28px "AppleEmojiPreview"', '😀');
  const dark = %(dark)s, g = document.getElementById('g');
  document.getElementById('t').textContent = 'TypeFlow v' + %(ver)s + ', ' + (dark ? 'dark' : 'light') + ' mode';
  document.getElementById('s').textContent = 'Drawn from KeyboardService.java (v' + %(ver)s + '): 390 dp wide, ' + K.KEY_GAP_H_DP + ' dp key gaps, ' + K.KEY_GAP_V_DP + ' dp row gaps, G2 superellipse keys (radius ' + K.KEY_RADIUS_DP + ' dp, power ' + K.G2_POWER + '), 43 dp suggestion bar, 64 dp tool row (emoji + mic, clipboard button hidden by default), ' + K.PANEL_RADIUS_DP + ' dp panel corners, ' + K.windowBlurDp + ' dp background blur, flat keys (' + (dark ? 'white 16 %% = #434343 on the solid #1F1F1F panel' : 'white 70 %%') + '), spring key press, iOS 27 emoji panel (' + K.EMOJI_COLS + ' x ' + K.EMOJI_ROWS + ' grid, ' + K.EMOJI_CAT_BAR_DP + ' dp category bar, ' + 'universal footer blur, fixed, bottom only: 15 dp radius at the screen edge), clipboard list under the footer (' + K.edge.steps + ' strips).';
  for (const sc of sceneList(dark)) {
    const f = document.createElement('div'); const c = document.createElement('div'); c.className = 'cap'; c.textContent = sc.title;
    f.appendChild(c); f.appendChild(sc.make()); g.appendChild(f);
  }
  document.getElementById('f').innerHTML = %(foot)s;
  window.__done = true;
})();
</script></body></html>"""

FOOT = ("<b>What changed in this update (v3.1.22)</b>: the tool capsule animation is replaced by the clock animation of v3.116: the droplet detaches from the key circle, the neck pinches from clock 0.10 and is fully detached at 0.20, the capsule widens and overshoots into the right key, the mic springs back, and closing plays the opening backwards. The four buttons squeeze when pressed. Earlier in v3.1.21: "
 "<b>Not in your zip, so stand-ins:</b> the Notes background is made up, the sample suggestion words, clipboard texts and recent emoji are invented, the emoji are drawn with Apple Color Emoji (the app's default emoji font, bundled), "
 "the pop-up menu shadow is approximated, and the window blur (" + str(int(K['windowBlurDp'])) + " dp) is drawn as a gaussian with sigma = radius / 2. "
 "Taken from your files instead of guessed: the app font (SF Pro Display), the default key height (" + str(K['defaultHeight']) + " dp, Prefs.java), the default accent and the full emoji lists (EmojiData.java). "
 "Every constant, colour and the category icon paths are parsed out of KeyboardService.java when this sheet is built. The footer blur and the mic spring are drawn by a Canvas port (scenes.js), not by the Android renderer, so check them on a device.")

def render(dark, path):
    t = dict(bg='#0b0c10' if dark else '#e0e3ea', fg='#f2f3f5' if dark else '#14161a', sub='#a3a7b0' if dark else '#4a4f5a',
             sh='rgba(0,0,0,.55)' if dark else 'rgba(30,40,70,.18)')
    faces = '@font-face{font-family:AppleEmojiPreview;src:url("file://%s")}' % (EMOJI_TTF if os.path.exists(EMOJI_TTF) else '/usr/share/fonts/truetype/noto/NotoColorEmoji.ttf') + ''.join('@font-face{font-family:SFPD;font-weight:%d;src:url("file://%s")}' % (wt, os.path.abspath(os.path.join(FONTS, fn))) for wt, fn in ((400,'SFPRODISPLAYREGULAR.OTF'),(500,'SFPRODISPLAYMEDIUM.OTF'),(700,'SFPRODISPLAYBOLD.OTF')))
    page = PAGE % dict(t, K=json.dumps(K, ensure_ascii=False), js=js, dark='true' if dark else 'false', foot=json.dumps(FOOT), faces=faces, ver=json.dumps(VERSION))
    pagefile = os.path.join(HERE, 'page_%s.html' % ('dark' if dark else 'light'))
    open(pagefile, 'w', encoding='utf-8').write(page)
    with sync_playwright() as p:
        b = p.chromium.launch(args=['--force-color-profile=srgb'])
        pg = b.new_page(viewport={'width': 3400, 'height': 1200}, device_scale_factor=1)
        logs = []; pg.on('console', lambda m: logs.append(m.text)); pg.on('pageerror', lambda e: logs.append('PAGEERROR ' + str(e)))
        pg.goto('file://' + pagefile)
        try:
            pg.wait_for_function('window.__done === true', timeout=240000)
        except Exception as e:
            print('TIMEOUT', logs[:5]); raise
        import base64
        url = pg.evaluate('editorBoardUrl(%s)' % ('true' if dark else 'false'))
        open(os.path.join(HERE, 'editor_%s.png' % ('dark' if dark else 'light')), 'wb').write(base64.b64decode(url.split(',', 1)[1]))
        pg.locator('#sheet').screenshot(path=path)
        for l in logs[:5]: print('console:', l)
        b.close()
    print('wrote', path)

if __name__ == '__main__':
    render(True, OUT + '_dark.png'); render(False, OUT + '_light.png')
