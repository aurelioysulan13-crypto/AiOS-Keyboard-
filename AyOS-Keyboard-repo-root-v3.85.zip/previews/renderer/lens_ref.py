import numpy as np

# Port of MainActivity.lensRefract / lensSample (keep the two the same).
LENS_MAG = (0.66, 0.72, 0.78)
LENS_DISP = (0.90, 1.00, 1.10)
LENS_PUSH = 0.95
LENS_BAND = 0.70


def lens_refract(src, w, h, m):
    """src: uint8/float array (h+2m, w+2m, 3), the scene around the handle. Returns uint8 RGBA (h, w, 4)."""
    src = src.astype(np.float32)
    sh, sw = src.shape[:2]
    hw, hh = w / 2.0, h / 2.0
    r = hh
    a = hw - r
    push_amp, band = LENS_PUSH * r, LENS_BAND * r
    ys, xs = np.mgrid[0:h, 0:w].astype(np.float32)
    px = xs + 0.5 - hw
    py = ys + 0.5 - hh
    cx = np.clip(px, -a, a)
    dx, dy = px - cx, py
    dist = np.sqrt(dx * dx + dy * dy)
    t = r - dist
    safe = np.where(dist > 1e-4, dist, 1.0)
    nx = np.where(dist > 1e-4, dx / safe, 0.0)
    ny = np.where(dist > 1e-4, dy / safe, 0.0)
    e = np.clip(1.0 - t / band, 0.0, 1.0)
    push = push_amp * e * e
    out = np.zeros((h, w, 4), np.float32)
    for ch in range(3):
        sx = px * LENS_MAG[ch] + nx * push * LENS_DISP[ch] + hw + m
        sy = py * LENS_MAG[ch] + ny * push * LENS_DISP[ch] + hh + m
        u, v = sx - 0.5, sy - 0.5
        x0, y0 = np.floor(u).astype(int), np.floor(v).astype(int)
        fx, fy = u - x0, v - y0
        x1 = np.clip(x0 + 1, 0, sw - 1)
        y1 = np.clip(y0 + 1, 0, sh - 1)
        x0 = np.clip(x0, 0, sw - 1)
        y0 = np.clip(y0, 0, sh - 1)
        c = src[..., ch]
        val = (c[y0, x0] * (1 - fx) + c[y0, x1] * fx) * (1 - fy) + (c[y1, x0] * (1 - fx) + c[y1, x1] * fx) * fy
        out[..., ch] = np.floor(val + 0.5)
    alpha = np.floor(255.0 * np.minimum(1.0, t) + 0.5)
    out[..., 3] = np.where(t > 0, alpha, 0)
    out[t <= 0, :3] = 0
    return out.astype(np.uint8)
