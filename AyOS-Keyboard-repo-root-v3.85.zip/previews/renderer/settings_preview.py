import os
"""AiOS settings preview, light or dark: one phone per settings page, drawn from MainActivity.java, SettingsGlyphs.java and Prefs.java.

Reads each buildXxx(LinearLayout col) page in order: section headers, groups, nav rows, toggles, sliders,
check lists (theme, accent colour), buttons, text rows and the key editor. The icon-tile symbols and colours are read from
SettingsGlyphs.java (the same drawing steps the app runs). The page list (titles and which page each nav row opens) is read
from pageTitle() and buildPage(). Dynamic values (status lines, the enabled state of the buttons) use the first-launch state.
Usage: python3 settings_preview.py MainActivity.java Prefs.java out.png [light|dark]
"""
import base64, html as H, io, json, math, os, re, sys
import numpy as np
from playwright.sync_api import sync_playwright
from PIL import Image
from lens_ref import lens_refract   # port of MainActivity.lensRefract (checked against the Java: identical pixels)

MAIN, PREFS, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
MODE = sys.argv[4] if len(sys.argv) > 4 else 'light'
DARK = MODE == 'dark'
GLYPHS = open(os.path.join(os.path.dirname(os.path.abspath(MAIN)), 'SettingsGlyphs.java'), encoding='utf-8').read()
FONT_DIR = os.path.join(os.path.dirname(os.path.abspath(MAIN)), '..', '..', '..', '..', 'assets', 'fonts')
src = open(MAIN, encoding='utf-8').read()
prefs_src = open(PREFS, encoding='utf-8').read()

LIT = r'"(?:[^"\\]|\\.)*"'
def lit(s): return json.loads(s)
def join_lits(group): return ''.join(lit(m) for m in re.findall(LIT, group))

consts = dict((k, int(v)) for k, v in re.findall(r'static final int (\w+) = (-?\d+);', prefs_src))
ACCENTS = [int(h, 16) for h in re.findall(r'0xFF([0-9A-Fa-f]{6})', re.search(r'ACCENTS = \{(.*?)\};', prefs_src, re.S).group(1))]
ACC = '#%06X' % ACCENTS[0]
_GRADLE = os.path.join(os.path.dirname(os.path.abspath(MAIN)), '..', '..', '..', '..', '..', '..', 'build.gradle')   # app/build.gradle
APP_VERSION = re.search(r'versionName "([^"]+)"', open(_GRADLE, encoding='utf-8').read()).group(1)

ORANGE = '#E0903A'
GREEN = '#30D158' if DARK else '#34C759'
SEC = '#8E8E93' if DARK else '#6C6C70'

# ---- page list, from pageTitle() and buildPage()
PAGE_TITLE = {m.group(1): m.group(2) for m in re.finditer(r'case (P_\w+): return "([^"]*)";', src)}
PAGE_METHOD = {m.group(1): m.group(2) for m in re.finditer(r'case (P_\w+): (build\w+)\(col\);', src)}
PAGE_TITLE['P_ROOT'] = 'AiOS Keyboard'
ICON_ID = {m.group(1): int(m.group(2)) for m in re.finditer(r'(I_\w+) = (\d+)', src)}
PAGE_METHOD['P_ROOT'] = 'buildRoot'
ORDER = ['P_ROOT', 'P_SETUP', 'P_LANGUAGE', 'P_PREFERENCES', 'P_CORRECTIONS', 'P_GLIDE', 'P_EMOJI', 'P_DICTATION', 'P_LAYOUT', 'P_CLIPBOARD', 'P_PRIVACY', 'P_VISUALS', 'P_ABOUT']

def method_body(name):
    a = src.index('private void %s(LinearLayout col) {' % name)
    b = src.index('\n    }\n', a)
    return src[a:b]

TOKEN = re.compile(
    r'(?P<header>header\(col, (?P<hlit>' + LIT + r')\))'
    r'|(?P<footer>footer\(col, (?P<flit>(?:' + LIT + r'\s*\+?\s*)+)\))'
    r'|(?P<group>group\(col\))'
    r'|(?P<nav>navRow\(g, (?P<nlit>' + LIT + r'), (?P<ndet>[^,]+), (?P<npage>P_\w+)\))'
    r'|(?P<soon>soon(?:Icon)?Row\(g, (?P<solit>' + LIT + r')(?:, (?P<sicon>I_\w+))?\))'
    r'|(?P<value>valueRow\(g, (?P<vlit>' + LIT + r'),\s*(?P<vval>[^,]+),\s*)'
    r'|(?P<button>buttonRow\(g, (?P<blit>' + LIT + r'),[\s\S]*?\}, (?P<ben>\w+)\);)'
    r'|(?P<toggle>toggleRow\(g, (?P<tlit>' + LIT + r'), (?P<tkey>Prefs\.\w+|' + LIT + r'), (?P<tdef>true|false)\))'
    r'|(?P<slider>sliderRow\(col, (?P<sl>' + LIT + r'),\s*Prefs\.(?P<sk>\w+),\s*Prefs\.(?P<smin>\w+),\s*Prefs\.(?P<smax>\w+),\s*Prefs\.(?P<sdef>\w+),\s*(?P<su>' + LIT + r')\))'
    r'|(?P<check>checkListRow\(g, new String\[\]\{(?P<cnames>[^}]*)\})'
    r'|(?P<seg>segmentRow\(col, new String\[\]\{(?P<segn>[^}]*)\}, (?P<segsel>[^,]+), Prefs\.\w+\))'
    r'|(?P<accseg>accentSegmentRow\(col\))'
    r'|(?P<accentlist>accentListRow\(g\))'
    r'|(?P<editor>addKeyEditor\(box\))'
    r'|(?P<textrow>textRow\(g, (?P<xlit>(?:' + LIT + r'\s*\+?\s*)+)\))'
    r'|(?P<hint>et\.setHint\((?P<hilit>' + LIT + r')\))'
)

# first-launch values for the dynamic rows (what the app shows when it is installed)
DYNAMIC_VALUE = {
    'Version': ('3.48', SEC),
    '1. Enable AiOS Keyboard': ('Not enabled yet', ORANGE),
    '2. Use AiOS Keyboard': ('Finish step 1 first', SEC),
    'Keyboard language': ('English (US)', SEC),
}
DYNAMIC_ENABLED = {'Choose AiOS Keyboard': False}   # disabled until step 1 is done
DYNAMIC_DETAIL = {'Setup': 'Not enabled', 'About AiOS Keyboard': '3.48', 'Visuals & Themes': 'System'}

NAV_DETAIL = {'Setup': 'Not enabled', 'Appearance': 'System'}

# ---- icon tiles: drawing steps and colours read from SettingsGlyphs.java
OPS = [lit(m) for m in re.findall(LIT, re.search(r'OPS = \{(.*?)\n    \};', GLYPHS, re.S).group(1)) ]
def _colors(name):
    body = re.search(name + r' = \{(.*?)\};', GLYPHS, re.S).group(1)
    return [int(x, 16) for x in re.findall(r'(?:0x([0-9A-Fa-f]{8})|\b0\b)', body) if x] if False else \
           [int(m.group(1), 16) if m.group(1) else 0 for m in re.finditer(r'0x([0-9A-Fa-f]{8})|(?<![\w])0(?![\w])', body)]
TILE_LIGHT = _colors('TILE_LIGHT'); TILE_DARK = _colors('TILE_DARK')
LIGHTEN = float(re.search(r'TILE_LIGHTEN = ([0-9.]+)f', GLYPHS).group(1))
PAGE_ID = {m.group(1): int(m.group(2)) for m in re.finditer(r'(P_\w+) = (\d+)', src)}
def _lighten(c, f):
    r, g, b = (c >> 16) & 255, (c >> 8) & 255, c & 255
    r += round((255 - r) * f); g += round((255 - g) * f); b += round((255 - b) * f)
    return '#%02X%02X%02X' % (r, g, b)
def g2d_py(l, t, r, b, rad, n):
    """Python port of KeyboardService.g2Rect (the G2 superellipse corners), as an SVG path."""
    rad = max(0.0, min(rad, min(r - l, b - t) / 2))
    e = 2.0 / max(2.01, n)
    P = []
    def corner(cx, cy, a0, a1):
        for i in range(1, 21):
            a = a0 + (a1 - a0) * i / 20
            c, sn = math.cos(a), math.sin(a)
            P.append((cx + rad * math.copysign(1, c) * abs(c) ** e, cy + rad * math.copysign(1, sn) * abs(sn) ** e))
    P += [(l + rad, t), (r - rad, t)]; corner(r - rad, t + rad, -math.pi / 2, 0)
    P += [(r, b - rad)]; corner(r - rad, b - rad, 0, math.pi / 2)
    P += [(l + rad, b)]; corner(l + rad, b - rad, math.pi / 2, math.pi)
    P += [(l, t + rad)]; corner(l + rad, t + rad, math.pi, math.pi * 1.5)
    return 'M' + ' L '.join('%.2f %.2f' % p for p in P) + ' Z'

def glyph_svg(page):
    import math
    out = []
    for step in OPS[page].split(';'):
        t = step.split()
        if len(t) < 2: continue
        v = [float(x) for x in t[1:]]; k = t[0]
        st = 'fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"'
        fl = 'fill="#fff"'
        if k == 'L': out.append('<line x1="%g" y1="%g" x2="%g" y2="%g" %s/>' % (v[0], v[1], v[2], v[3], st))
        elif k == 'O': out.append('<circle cx="%g" cy="%g" r="%g" %s/>' % (v[0], v[1], v[2], st))
        elif k == 'D': out.append('<circle cx="%g" cy="%g" r="%g" %s/>' % (v[0], v[1], v[2], fl))
        elif k == 'E': out.append('<ellipse cx="%g" cy="%g" rx="%g" ry="%g" %s/>' % (v[0], v[1], v[2], v[3], st))
        elif k in 'RQ': out.append('<path d="%s" %s/>' % (g2d_py(v[0], v[1], v[0] + v[2], v[1] + v[3], v[4], 2.5), st if k == 'R' else fl))
        elif k in 'AW':
            cx, cy, r, a0, sw = v
            x1, y1 = cx + r * math.cos(math.radians(a0)), cy + r * math.sin(math.radians(a0))
            x2, y2 = cx + r * math.cos(math.radians(a0 + sw)), cy + r * math.sin(math.radians(a0 + sw))
            arc = 'A %g %g 0 %d %d %.3f %.3f' % (r, r, 1 if abs(sw) > 180 else 0, 1 if sw > 0 else 0, x2, y2)
            if k == 'A': out.append('<path d="M %.3f %.3f %s" %s/>' % (x1, y1, arc, st))
            else: out.append('<path d="M %g %g L %.3f %.3f %s Z" %s/>' % (cx, cy, x1, y1, arc, fl))
        elif k == 'P':
            pts = ' '.join('%g,%g' % (v[i], v[i + 1]) for i in range(0, len(v), 2))
            out.append('<polygon points="%s" fill="#fff" stroke="#fff" stroke-width="0" />' % pts)
    return '<svg width="30" height="30" viewBox="0 0 30 30">%s</svg>' % ''.join(out)

CHEV = '<svg class="chev" width="8" height="14" viewBox="0 0 8 14"><path d="M1 1 L7 7 L1 13" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
CHECK = '<svg class="chk" width="18" height="14" viewBox="0 0 18 14"><path d="M1.2 7.7 L6.5 12.8 L16.8 1.2" fill="none" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>'
BACK = '<svg width="10" height="17" viewBox="0 0 10 17"><path d="M8.8 1.2 L1.2 8.5 L8.8 15.8" fill="none" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>'

def nav_row(label, detail, page, root):
    detail = NAV_DETAIL.get(label, detail)
    icon = ''
    if root:
        pid = PAGE_ID.get(page)
        if pid:
            base = (TILE_DARK if DARK else TILE_LIGHT)[pid]
            icon = '<span class="ico" style="background:linear-gradient(180deg,rgba(255,255,255,.4),rgba(255,255,255,0)),linear-gradient(180deg,%s,rgba(%d,%d,%d,.85));box-shadow:inset 0 0 0 .75px rgba(255,255,255,.35)">%s</span>' % (_lighten(base, LIGHTEN), (base >> 16) & 255, (base >> 8) & 255, base & 255, glyph_svg(pid))
    return '<div class="row link%s">%s<span class="l">%s</span>%s%s</div>' % (' hasico' if icon else '', icon, H.escape(label), ('<span class="d">%s</span>' % H.escape(detail)) if detail else '<span class="gap"></span>', CHEV)

def slider_icon(filled):
    # the reference's corner icons: two overlapping rounded squares on a 24 x 20 grid
    back = g2d_py(1.5, 1.5, 13, 13, 3, 2.5); front = g2d_py(9, 6, 19.5, 17, 3, 2.5)
    if filled:
        body = '<path d="%s" fill="%s"/><path d="%s" fill="%s"/>' % (back, SEC, front, SEC)
    else:
        body = '<path d="%s" fill="none" stroke="%s" stroke-width="1.5"/><path d="%s" fill="none" stroke="%s" stroke-width="1.5"/>' % (back, SEC, front, SEC)
    return '<svg class="sico" width="%d" height="%d" viewBox="0 0 24 20">%s</svg>' % (24 if not filled else 26, 20 if not filled else 22, body)

def key_editor_html():
    # v3.107: the keyboard's own key drawing (rendered by build_previews.py), not a text approximation
    import base64
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'editor_%s.png' % ('dark' if DARK else 'light'))
    if os.path.exists(path):
        return '<img alt="" style="width:100%%;display:block;border-radius:24px" src="data:image/png;base64,%s">' % base64.b64encode(open(path, 'rb').read()).decode()
    def tile(label, w, kind='fixed'):
        return '<div class="tile %s" style="flex:%s">%s</div>' % (kind, w, H.escape(label))
    def row(parts, indent=False):
        inner = ('<div class="tile blank" style="flex:.5"></div>' if indent else '') + ''.join(parts) + ('<div class="tile blank" style="flex:.5"></div>' if indent else '')
        return '<div class="krow">%s</div>' % inner
    letters = lambda s: [tile(c, 1) for c in s]
    bottom = row([tile('123', 1.25), tile('+', 1.25, 'slot'), tile('', 5), tile('+', 1.25, 'slot'), tile('\u21B5', 1.25)])
    corners = '<div class="krow">%s<div class="tile blank" style="flex:5"></div>%s</div>' % (tile('Emoji', 2.5, 'slot'), tile('Mic', 2.5, 'slot'))
    rows = (row(letters('qwertyuiop')) + row(letters('asdfghjkl'), indent=True)
            + row([tile('\u21E7', 1.5)] + letters('zxcvbnm') + [tile('\u232B', 1.5)]) + bottom + corners)
    return '<div class="board">%s</div>' % rows

def build_page(method, root=False):
    """Returns the page's HTML (nav rows, groups, headers and footers) in source order."""
    body = method_body(method)
    out, group, sections = [], None, []
    def open_group():
        nonlocal group
        group = []
        sections.append(('group', group))
    def close_all():
        nonlocal group
        group = None
    for m in TOKEN.finditer(body):
        if m.group('header'):
            close_all(); sections.append(('header', lit(m.group('hlit'))))
        elif m.group('footer'):
            close_all(); sections.append(('footer', join_lits(m.group('flit'))))
        elif m.group('group'):
            open_group()
        elif m.group('nav'):
            det = m.group('ndet').strip()
            label = lit(m.group('nlit'))
            detail = lit(det) if det.startswith('"') else DYNAMIC_DETAIL.get(label)
            group.append(nav_row(label, detail, m.group('npage'), root))
        elif m.group('soon'):
            ico = ''
            if m.group('sicon') and root:
                pid = ICON_ID[m.group('sicon')]
                base = (TILE_DARK if DARK else TILE_LIGHT)[pid]
                ico = '<span class="ico" style="background:linear-gradient(180deg,rgba(255,255,255,.4),rgba(255,255,255,0)),linear-gradient(180deg,%s,rgba(%d,%d,%d,.85));box-shadow:inset 0 0 0 .75px rgba(255,255,255,.35)">%s</span>' % (_lighten(base, LIGHTEN), (base >> 16) & 255, (base >> 8) & 255, base & 255, glyph_svg(pid))
            group.append('<div class="row soon%s">%s<span class="l">%s</span></div>' % (' hasico' if ico else '', ico, H.escape(lit(m.group('solit')))))
        elif m.group('value'):
            label = lit(m.group('vlit')); val = m.group('vval').strip()
            if label in DYNAMIC_VALUE:
                text, color = DYNAMIC_VALUE[label]
            else:
                text, color = val.strip('"'), SEC
            if 'appVersion' in val:
                text, color = APP_VERSION, SEC
            group.append('<div class="row"><span class="l">%s</span><span class="v" style="color:%s">%s</span></div>' % (H.escape(label), color, H.escape(text)))
        elif m.group('button'):
            label = lit(m.group('blit')); en = m.group('ben')
            enabled = DYNAMIC_ENABLED.get(label, True) if en == 'enabled' else (en == 'true')
            cls = 'btnrow' + ('' if enabled else ' off') + (' red' if 'destructiveColor' in m.group(0) else '')
            group.append('<div class="%s">%s</div>' % (cls, H.escape(label)))
        elif m.group('toggle'):
            label = lit(m.group('tlit')); dflt = m.group('tdef') == 'true'
            on = dflt                               # the default written in the source (Prefs.on / the literal)
            group.append('<div class="row tgr"><span class="l">%s</span><i class="tog %s"></i></div>' % (H.escape(label), 'on' if on else 'off'))
        elif m.group('slider'):
            # each slider is its own capsule card: title and value above, the slider resting in its own capsule
            title = lit(m.group('sl')); unit = lit(m.group('su'))
            lo, hi = consts[m.group('smin')], consts[m.group('smax')]; val = consts[m.group('sdef')]
            pct = (val - lo) / float(hi - lo) * 100
            close_all()
            sections.append(('raw', '<div class="sheader"><span>%s</span><span class="v" style="color:%s">%d %s</span></div>'
                            '<div class="scard"><div class="srow"><div class="slider">'
                            '<div class="fill" style="width:%.2f%%"></div>'
                            '<div class="thumb" style="left:calc(%.4f * 100%% - 22px)"></div></div></div></div>'
                            % (H.escape(title), SEC, val, unit, pct, pct / 100.0)))
        elif m.group('check'):
            names = [lit(x) for x in re.findall(LIT, m.group('cnames'))]
            for i, n in enumerate(names):
                group.append('<div class="row"><span class="l">%s</span>%s</div>' % (H.escape(n), CHECK if i == 0 else ''))
        elif m.group('seg'):
            names = [lit(x) for x in re.findall(LIT, m.group('segn'))]
            sel = 1 if 'flickSens' in m.group('segsel') else 0      # the default of that setting
            close_all()
            cells = ''.join('<div class="cell%s">%s</div>' % (' sel' if i == sel else '', H.escape(n)) for i, n in enumerate(names))
            sections.append(('raw', '<div class="scard seg">%s</div>' % cells))
        elif m.group('accseg'):
            close_all()
            cells = ''.join('<div class="cell%s"><span class="adot" style="background:#%06X"></span></div>' % (' sel' if i == 0 else '', a)
                            for i, a in enumerate(ACCENTS))
            sections.append(('raw', '<div class="scard seg">%s</div>' % cells))
        elif m.group('accentlist'):
            nm = ['Blue', 'Green', 'Purple', 'Orange', 'Pink']
            for i, a in enumerate(ACCENTS):
                group.append('<div class="row hasico dot"><span class="dotc" style="background:#%06X"></span><span class="l">%s</span>%s</div>' % (a, nm[i], CHECK if i == 0 else ''))
        elif m.group('editor'):
            group.append('<div class="row pad">%s</div>' % key_editor_html())
        elif m.group('textrow'):
            group.append('<div class="row text">%s</div>' % H.escape(join_lits(m.group('xlit'))).replace('\n', '<br>'))
        elif m.group('hint'):   # the Try it out text box
            group.append('<div class="row text tall">%s</div>' % H.escape(lit(m.group('hilit'))))
    # v3.106: the Emoji font rows come from a loop over EmojiFonts.options(), which this renderer cannot run,
    # so the rows the app shows are written out here: the state with no downloaded font.
    if method == 'buildEmoji':
        font_rows = [
            '<div class="row"><span class="l">Apple Emoji</span><span class="v" style="color:%s">Download 116 MB</span></div>' % ACC,
            '<div class="row"><span class="l">Phone default</span></div>',
        ]
        for kind, val in sections:
            if kind == 'group':
                val[:0] = font_rows
                break
    parts = []
    for kind, val in sections:
        if kind == 'header':
            parts.append('<div class="hdr">%s</div>' % H.escape(val))
        elif kind == 'raw':
            parts.append(val)
        elif kind == 'footer':
            parts.append('<div class="ftr">%s</div>' % H.escape(val))
        else:
            cls = 'group cap' if len(val) == 1 and val[0].startswith('<div class="row') and not re.match(r'<div class="row (col|pad|text)', val[0]) else 'group'
            parts.append('<div class="%s">%s</div>' % (cls, ''.join(val)))
    return ''.join(parts)

def phone(pid):
    title = PAGE_TITLE[pid]
    method = PAGE_METHOD[pid]
    content = build_page(method, pid == 'P_ROOT')
    if pid == 'P_ROOT':
        head = '<div class="big">%s</div>' % H.escape(title)
    else:
        head = '<div class="nav"><span class="back">%s</span><span class="ttl">%s</span></div>' % (BACK, H.escape(title))
    return '<div class="phone">%s<div class="body">%s</div></div>' % (head, content)

css = """
@font-face{font-family:SFPD;font-weight:400;src:url("file://%(f400)s")}
@font-face{font-family:SFPD;font-weight:500;src:url("file://%(f500)s")}
@font-face{font-family:SFPD;font-weight:700;src:url("file://%(f700)s")}
:root{--vtop:%(vtop)s;--vbot:%(vbot)s;--vrim:%(vrim)s;--gloss:%(gloss)s;--spec:%(spec)s;--tvig:%(tvig)s;--wtop:%(wtop)s;--wbot:%(wbot)s;--gtop:%(gtop)s;--gbot:%(gbot)s;--grim:%(grim)s;--thumbtop:%(thumbtop)s;--thumbbot:%(thumbbot)s;--thumbrim:%(thumbrim)s;--seltop:%(seltop)s;--selbot:%(selbot)s;--selrim:%(selrim)s;--page:%(page)s;--group:%(group)s;--label:%(label)s;--sec:%(sec)s;--sep:%(sep)s;--chev:%(chev)s;--off:%(off)s;--track:%(track)s;--backbg:%(backbg)s;--backrim:%(backrim)s;--board:%(board)s;--tile:%(tile)s;--acc:%(acc)s;--on:%(on)s;--red:%(red)s}
html,body{margin:0;background:transparent;font-family:SFPD,sans-serif;color:var(--label)}
.phone{width:390px;min-height:844px;box-sizing:border-box;display:flex;flex-direction:column;overflow:visible;background:var(--page)}
.nav{height:104px;box-sizing:border-box;position:relative;background:var(--page)}
.nav .back{position:absolute;left:16px;top:52px;width:44px;height:44px;border-radius:50%%;background:linear-gradient(180deg,var(--gtop),var(--gbot));box-shadow:inset 0 0 0 .75px var(--grim);display:flex;align-items:center;justify-content:center;padding-right:1px;box-sizing:border-box}
.nav .back svg path{stroke:var(--label)}
.nav .ttl{position:absolute;left:72px;right:72px;top:44px;height:60px;line-height:60px;text-align:center;font-size:17px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.big{font-size:34px;font-weight:700;padding:104px 20px 10px;letter-spacing:-.34px;line-height:1.2}
.body{flex:1;padding:8px 16px 40px}
.big+.body{padding-top:0}
.hdr{font-size:15px;font-weight:500;color:var(--sec);padding:26px 16px 8px}
.ftr{font-size:13px;color:var(--sec);padding:8px 16px 0;line-height:1.32}
.group{border-radius:26px;overflow:hidden;background:linear-gradient(180deg,var(--gtop),var(--gbot));box-shadow:inset 0 0 0 .75px var(--grim)}
.group+.group{margin-top:34px}
.row{min-height:52px;box-sizing:border-box;padding:8px 16px;display:flex;align-items:center;position:relative}
.row+.row:before,.btnrow+.row:before,.row+.btnrow:before{content:"";position:absolute;left:16px;right:16px;top:0;height:.5px;background:var(--sep)}
.row.hasico+.row:before,.row.hasico:before{left:60px}
.ico{width:30px;height:30px;border-radius:11px;flex:none;margin-right:14px;display:flex;align-items:center;justify-content:center}
.ico svg{display:block}
.dotc{width:22px;height:22px;border-radius:50%%;flex:none;margin-right:14px}
.row.dot:before{left:52px}
.row.col{flex-direction:column;align-items:stretch;padding:12px 16px 6px;min-height:0}
.row .top{display:flex;align-items:center}
.row .l{flex:1;font-size:17px;line-height:1.25}
.row .d{font-size:17px;color:var(--sec);padding:0 10px 0 8px}
.row .gap{width:10px}
.row .v{font-size:17px;padding-left:12px}
.row.link .chev path{stroke:var(--chev)}
.chk path{stroke:var(--acc)}
.row.text{font-size:15px;line-height:1.36;display:block;padding:12px 16px}
.row.tall{min-height:90px;color:var(--sec)}
.tog{width:64px;height:28px;border-radius:14px;position:relative;flex:none;margin-left:auto}
.row.tgr{padding-right:12px}

.tog.on{background:var(--on)}.tog.off{background:var(--off)}
.tog:after{content:"";position:absolute;top:2px;left:2px;width:37px;height:24px;border-radius:0;clip-path:path('%(knob)s');background:#fff;box-shadow:0 1px 1.5px rgba(0,0,0,.2)}
.tog.on:after{left:25px}
.sheader{display:flex;justify-content:space-between;padding:26px 16px 8px;font-size:15px;color:var(--sec);font-weight:500}
.scard{margin:0;height:52px;box-sizing:border-box;border-radius:999px;position:relative;background:linear-gradient(180deg,var(--gtop),var(--gbot));box-shadow:inset 0 0 0 .75px var(--grim);display:flex;align-items:center}
.srow{flex:1;padding:0;box-sizing:border-box}
.seg{padding:4px;box-sizing:border-box}
.seg .cell{flex:1;height:100%%;display:flex;align-items:center;justify-content:center;font-size:16px;color:var(--label);position:relative}
.seg .cell.sel{color:var(--acc);font-weight:500;background:linear-gradient(180deg,var(--seltop),var(--selbot));box-shadow:inset 0 0 6px 2px var(--tvig)}
.seg .adot{width:24px;height:24px;border-radius:50%%;display:block}
.srow .sico{flex:none;display:block}
.srow .slider{margin:0 34px}
.slider{height:6px;border-radius:3px;background:var(--track);position:relative}
.slider .fill{position:absolute;left:0;top:0;height:6px;background:var(--acc)}
.slider .thumb{position:absolute;top:-11px;width:44px;height:28px;box-sizing:border-box;margin-left:0;background:#8a8a8a}
.btnrow{min-height:52px;box-sizing:border-box;padding:0 16px;display:flex;align-items:center;font-size:17px;color:var(--acc);position:relative}
.btnrow.red{color:var(--red)}
.btnrow.off{color:var(--sec)}
.row.pad{padding:8px}
.board{border-radius:18px;padding:8px 6px;background:var(--board);width:100%%;box-sizing:border-box}
.krow{display:flex}
.tile{height:40px;line-height:40px;text-align:center;font-size:14px;margin:3px 2px;border-radius:10px;background:var(--tile);box-sizing:border-box;min-width:0}
.tile.blank{background:transparent}
.tile.slot{line-height:36px}
.row.soon .l{color:var(--sec)}
.row.soon .d{font-size:13px;padding-right:0}
"""
if DARK:
    pal = dict(page='#000000', group='#1C1C1E', label='#FFFFFF', sec='#8E8E93', sep='#38383A', chev='#48484A', off='#5A595E',
               track='#48484A', backbg='#1C1C1E', backrim='rgba(255,255,255,.15)', board='#2C2C2E', tile='#48484A', red='#FF453A', backshadow='', gtop='rgba(255,255,255,.18)', gbot='rgba(255,255,255,.12)', grim='rgba(255,255,255,.15)', thumbtop='rgba(255,255,255,.22)', thumbbot='rgba(255,255,255,.12)', thumbrim='rgba(255,255,255,.22)', tvig='rgba(0,0,0,.55)', wtop='rgba(255,255,255,.18)', wbot='rgba(255,255,255,.12)', vtop='rgba(255,255,255,.102)', vbot='rgba(255,255,255,.063)', vrim='rgba(255,255,255,.149)', gloss='rgba(255,255,255,.2)', spec='rgba(255,255,255,.8)', vig='inset 0 0 7px 1px rgba(255,255,255,.14)')
else:
    pal = dict(page='#F2F2F7', group='#FFFFFF', label='#000000', sec='#6C6C70', sep='#C6C6C8', chev='#C4C4C7', off='#E9E9EA',
               track='#E5E5EA', backbg='#FFFFFF', backrim='rgba(0,0,0,.08)', board='#E5E5EA', tile='#FFFFFF', red='#FF3B30',
               backshadow='', gtop='rgba(255,255,255,.55)', gbot='rgba(255,255,255,.38)', grim='rgba(255,255,255,.6)', thumbtop='rgba(255,255,255,.30)', thumbbot='rgba(255,255,255,.18)', thumbrim='rgba(0,0,0,.20)', tvig='rgba(0,0,0,.20)', wtop='rgba(255,255,255,.55)', wbot='rgba(255,255,255,.38)', vig='inset 0 0 7px 1px rgba(0,0,0,.16)', vtop='rgba(255,255,255,.22)', vbot='rgba(255,255,255,.125)', vrim='rgba(255,255,255,.6)', gloss='rgba(255,255,255,.333)', spec='rgba(255,255,255,1)')
# the chosen part of a capsule selector: the slider handle's glass in dark mode; in light mode the glass is tinted with the accent
if DARK:
    pal.update(seltop=pal['thumbtop'], selbot=pal['thumbbot'], selrim=pal['thumbrim'])
else:
    _r, _g, _b = (ACCENTS[0] >> 16) & 255, (ACCENTS[0] >> 8) & 255, ACCENTS[0] & 255
    pal.update(seltop='rgba(%d,%d,%d,.30)' % (_r, _g, _b), selbot='rgba(%d,%d,%d,.22)' % (_r, _g, _b), selrim='rgba(%d,%d,%d,.45)' % (_r, _g, _b))
parts = dict(f400=os.path.abspath(os.path.join(FONT_DIR, 'SFPRODISPLAYREGULAR.OTF')),
             f500=os.path.abspath(os.path.join(FONT_DIR, 'SFPRODISPLAYMEDIUM.OTF')),
             f700=os.path.abspath(os.path.join(FONT_DIR, 'SFPRODISPLAYBOLD.OTF')), acc=ACC, on=GREEN, **pal)
parts['knob'] = g2d_py(0, 0, 37, 24, 12, 2)   # the toggle knob: capsule (round ends)
css = css % parts

pages = [phone(p) for p in ORDER]
doc = '<!doctype html><html><head><meta charset="utf-8"><style>%s</style></head><body>%s</body></html>' % (css, ''.join(pages))
# G2 continuous-curvature corners, the same path as KeyboardService.g2Rect / g2Corner (power 4): every card, icon tile and
# the back button is clipped to it and gets a matching rim, so the preview corners are G2, not circular.
G2_SCRIPT = '''<script>
function g2d(l,t,r,b,rad,n){
  rad=Math.max(0,Math.min(rad,Math.min(r-l,b-t)/2));
  const e=2/Math.max(2.01,n), P=[];
  const corner=(cx,cy,a0,a1)=>{for(let i=1;i<=20;i++){const a=a0+(a1-a0)*i/20,c=Math.cos(a),s=Math.sin(a);
    P.push([cx+rad*Math.sign(c)*Math.pow(Math.abs(c),e), cy+rad*Math.sign(s)*Math.pow(Math.abs(s),e)]);}};
  P.push([l+rad,t],[r-rad,t]); corner(r-rad,t+rad,-Math.PI/2,0);
  P.push([r,b-rad]); corner(r-rad,b-rad,0,Math.PI/2);
  P.push([l+rad,b]); corner(l+rad,b-rad,Math.PI/2,Math.PI);
  P.push([l,t+rad]); corner(l+rad,t+rad,Math.PI,Math.PI*1.5);
  return 'M'+P.map(p=>p[0].toFixed(2)+' '+p[1].toFixed(2)).join(' L ')+' Z';
}
// shape table: selector, corner radius (from the element's size), whether it has a rim, G2 exponent
const SHAPES=[['.group',(w,h,el)=>el.classList.contains('cap')?h/2:47.86,true,4],['.ico',(w,h)=>47.86,true,4],['.nav .back',(w,h)=>22,true,2],
  ['.board',(w,h)=>47.86,false,4],['.tile',(w,h)=>10,false,4],['.tile.slot',(w,h)=>10,true,4],['.tog',(w,h)=>h/2,false,2],['.scard',(w,h)=>h/2,true,2],['.slider .fill',(w,h)=>h/2,false,2],['.slider .thumb',(w,h)=>h/2,true,2],['.seg .cell.sel',(w,h)=>h/2,true,2]];
let TOID=0;
// The handle's layers above the lens image, in the order glassThumb() stacks them: veil, outer rim, four dark rings that
// fade inwards, specular rim (top-left and bottom-right), gloss.
function thumbOverlay(el,svg,w,h){
  const NS='http://www.w3.org/2000/svg', cs=getComputedStyle(el), v=n=>cs.getPropertyValue(n).trim(), id=++TOID, R=h/2;
  while(svg.firstChild) svg.removeChild(svg.firstChild);
  const mk=(tag,at)=>{const n=document.createElementNS(NS,tag); for(const k in at) n.setAttribute(k,at[k]); return n;};
  const grad=(gid,x1,y1,x2,y2,stops,user)=>{const g=mk('linearGradient',{id:gid,x1:x1,y1:y1,x2:x2,y2:y2});
    if(user) g.setAttribute('gradientUnits','userSpaceOnUse');
    stops.forEach(([o,c])=>{const s=mk('stop',{offset:o}); s.style.stopColor=c; g.appendChild(s);}); return g;};
  const defs=mk('defs'), clear='rgba(255,255,255,0)';
  defs.appendChild(grad('v'+id,0,0,0,1,[[0,v('--vtop')],[1,v('--vbot')]]));
  defs.appendChild(grad('g'+id,0,0,0,1,[[0,v('--gloss')],[1,clear]]));
  defs.appendChild(grad('s'+id,0,0,w,h,[[0,v('--spec')],[.32,clear],[.68,clear],[1,v('--spec')]],true));
  svg.appendChild(defs);
  const cap=i=>g2d(i,i,w-i,h-i,Math.max(0,R-i),2);
  const fill=(d,f)=>svg.appendChild(mk('path',{d:d,fill:f}));
  const line=(d,c,wd)=>{const p=mk('path',{d:d,fill:'none','stroke-width':wd}); p.style.stroke=c; svg.appendChild(p);};
  fill(cap(0),'url(#v'+id+')');
  line(cap(.375),v('--vrim'),.75);
  [0x5C,0x4A,0x3A,0x2C,0x20,0x16,0x0E,0x08].forEach((a,k)=>line(cap(.8*(k+1)+.5),'rgba(0,0,0,'+(a/255)+')',1.0));
  line(cap(1.4+.8),'url(#s'+id+')',1.6);
  fill(cap(0),'url(#g'+id+')');
}
function applyG2(){
  document.querySelectorAll('.g2-rim').forEach(n=>n.remove());
  const NS='http://www.w3.org/2000/svg';
  SHAPES.forEach(([sel,radOf,hasRim,nn])=>document.querySelectorAll(sel).forEach(el=>{
    const w=el.offsetWidth,h=el.offsetHeight; if(!w||!h) return;
    const rad=radOf(w,h,el), n2=el.classList.contains('cap')?2:nn;
    el.style.clipPath='path("'+g2d(0,0,w,h,rad,n2)+'")';
    el.style.borderRadius='0px';   // the CSS circular corner would still cut the G2 shape: remove it
    if(!hasRim) return;
    const cs=getComputedStyle(el);
    if(!el.classList.contains('scard')) el.style.boxShadow='none';
    if(getComputedStyle(el).position==='static') el.style.position='relative';
    const h2=(el.classList.contains('slot')?1:0.375), svg=document.createElementNS(NS,'svg');
    svg.setAttribute('class','g2-rim'); svg.setAttribute('width',w); svg.setAttribute('height',h);
    svg.style.cssText='position:absolute;left:0;top:0;pointer-events:none;z-index:0';
    const p=document.createElementNS(NS,'path');
    p.setAttribute('d',g2d(h2,h2,w-h2,h-h2,rad-h2,n2)); p.setAttribute('fill','none');
    const slot=el.classList.contains('slot'), thumb=el.classList.contains('thumb');
    p.style.stroke=(slot?cs.getPropertyValue('--acc'):el.classList.contains('sel')?cs.getPropertyValue('--selrim'):thumb?cs.getPropertyValue('--thumbrim'):cs.getPropertyValue('--grim')).trim()||'rgba(255,255,255,.15)'; p.setAttribute('stroke-width', slot?'2':'0.75');
    svg.appendChild(p); el.appendChild(svg);
    if(thumb) thumbOverlay(el,svg,w,h);
  }));
}
document.fonts.ready.then(applyG2);
window.addEventListener('load',applyG2);
</script>'''
doc = doc.replace('</body>', G2_SCRIPT + '</body>')
pagefile = os.path.join(os.path.dirname(os.path.abspath(OUT)), 'settings_pages_%s.html' % MODE)
open(pagefile, 'w', encoding='utf-8').write(doc)

shots = []
with sync_playwright() as p:
    b = p.chromium.launch(args=['--force-color-profile=srgb'])
    pg = b.new_page(viewport={'width': 390, 'height': 844}, device_scale_factor=2)
    pg.goto('file://' + pagefile)
    pg.evaluate('document.fonts.ready')
    pg.wait_for_timeout(300)
    # Slider handles: photograph the scene under each handle with the handle hidden, bend it through the same lens as the
    # app (MainActivity.lensRefract) and use the result as the handle's background.
    DSF, MARGIN = 2, 14
    hide = pg.add_style_tag(content='.slider .thumb{visibility:hidden !important}')
    boxes = pg.evaluate("() => [...document.querySelectorAll('.slider .thumb')].map(e => {const r = e.getBoundingClientRect(); return [r.left + scrollX, r.top + scrollY, r.width, r.height]})")
    urls = []
    for (bx, by, bw, bh) in boxes:
        shot = pg.screenshot(clip={'x': bx - MARGIN, 'y': by - MARGIN, 'width': bw + 2 * MARGIN, 'height': bh + 2 * MARGIN}, full_page=True)
        scene = np.asarray(Image.open(io.BytesIO(shot)).convert('RGB'))
        w_px, h_px, m_px = int(round(bw * DSF)), int(round(bh * DSF)), MARGIN * DSF
        scene = scene[:h_px + 2 * m_px, :w_px + 2 * m_px]
        buf = io.BytesIO()
        Image.fromarray(lens_refract(scene, w_px, h_px, m_px), 'RGBA').save(buf, 'PNG')
        urls.append('data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode())
    hide.evaluate('e => e.remove()')
    pg.evaluate("urls => document.querySelectorAll('.slider .thumb').forEach((e, i) => { e.style.backgroundImage = 'url(' + urls[i] + ')'; e.style.backgroundSize = '100% 100%'; })", urls)
    pg.wait_for_timeout(200)
    els = pg.locator('.phone')
    for i in range(els.count()):
        path = os.path.join(os.path.dirname(os.path.abspath(OUT)), '_phone_%s_%d.png' % (MODE, i))
        els.nth(i).screenshot(path=path)
        shots.append(path)
    b.close()

# one image: the phones in a grid, 4 per row; each row as tall as its tallest phone
ims = [Image.open(s).convert('RGB') for s in shots]
cols = 4
gap = 60
rows = [ims[i:i + cols] for i in range(0, len(ims), cols)]
row_h = [max(im.height for im in r) for r in rows]
cell_w = max(im.width for im in ims)
sheet = Image.new('RGB', (cols * cell_w + (cols + 1) * gap, sum(row_h) + (len(rows) + 1) * gap), ((28, 28, 32) if DARK else (224, 228, 237)))
y = gap
for r, rh in zip(rows, row_h):
    for c, im in enumerate(r):
        sheet.paste(im, (gap + c * (cell_w + gap), y))
    y += rh + gap
sheet.save(OUT)
for s in shots:
    os.remove(s)
print('wrote', OUT, 'pages:', len(ims))
