// Canvas port of KeyboardService.java drawing code. Density 2.0 (1 dp = 2 px), exactly like Android's dp(): Math.round(v*density).
// Every number that exists as a constant in the Java source comes from K (parsed out of the file by extract_from_java.py).
const D = 2;
const dp = v => Math.round(v * D);
const ACCENT = K.accent >>> 0;                   // Prefs.ACCENTS[0]
const FONT = 'SFPD';                              // the app's own font: SF Pro Display (assets/fonts)
const EMOJI_FONT = '"AppleEmojiPreview"';   // v3.103: Apple Color Emoji, the app's default

const css = (c, f = 1) => {
  const a = ((c >>> 24) & 255) / 255 * f;
  return `rgba(${(c >> 16) & 255},${(c >> 8) & 255},${c & 255},${a.toFixed(4)})`;
};
const scaleAlpha = (c, f) => { const a = Math.min(255, Math.max(0, Math.round(((c >>> 24) & 255) * f))); return ((a << 24) | (c & 0xFFFFFF)) >>> 0; };
const darken = c => ((0xFF << 24) | (Math.floor(((c >> 16) & 255) * .8) << 16) | (Math.floor(((c >> 8) & 255) * .8) << 8) | Math.floor((c & 255) * .8)) >>> 0;

function mkColors(dark) {
  const c = Object.assign({}, K.colors[dark ? 'dark' : 'light']);
  c.dark = dark; c.accent = ACCENT;
  c.keyShadow = 0;
  return c;
}
function panelColor(dark, blurOk) {            // panelColor(frosted = true, blurOk)
  const p = blurOk ? K.panel.blur : K.panel.noblur;
  return parseInt(p[dark ? 0 : 1], 16) >>> 0;
}

// ------------------------------------------------------------------ text metrics
const _mc = document.createElement('canvas').getContext('2d');
function setFont(ctx, px, weight) { ctx.font = `${weight || 400} ${px}px ${FONT}`; }
function bounds(px, weight, str) {              // Paint.getTextBounds: top = -ascent, bottom = descent
  _mc.font = `${weight || 400} ${px}px ${FONT}`;
  const m = _mc.measureText(str);
  return { top: -m.actualBoundingBoxAscent, bottom: m.actualBoundingBoxDescent };
}
function fontBox(px, weight) {
  _mc.font = `${weight || 400} ${px}px ${FONT}`;
  const m = _mc.measureText('Hg');
  return { asc: m.fontBoundingBoxAscent, desc: m.fontBoundingBoxDescent };
}
function textW(px, weight, s, fam) { _mc.font = `${weight || 400} ${px}px ${fam || FONT}`; return _mc.measureText(s).width; }

// ------------------------------------------------------------------ G2 shapes (g2Corner / g2Rect / g2Callout, same maths)
function g2Corner(p, cx, cy, r, a0, a1, n) {
  const seg = 20, e = 2.0 / Math.max(2.01, n);
  for (let i = 1; i <= seg; i++) {
    const a = a0 + (a1 - a0) * i / seg, c = Math.cos(a), s = Math.sin(a);
    p.lineTo(cx + r * Math.sign(c) * Math.pow(Math.abs(c), e), cy + r * Math.sign(s) * Math.pow(Math.abs(s), e));
  }
}
function g2Rect(l, t, r, b, radius, n) {
  const p = new Path2D();
  const rad = Math.max(0, Math.min(radius, Math.min(r - l, b - t) / 2));
  if (rad < .5) { p.rect(l, t, r - l, b - t); return p; }
  p.moveTo(l + rad, t); p.lineTo(r - rad, t);
  g2Corner(p, r - rad, t + rad, rad, -Math.PI / 2, 0, n); p.lineTo(r, b - rad);
  g2Corner(p, r - rad, b - rad, rad, 0, Math.PI / 2, n); p.lineTo(l + rad, b);
  g2Corner(p, l + rad, b - rad, rad, Math.PI / 2, Math.PI, n); p.lineTo(l, t + rad);
  g2Corner(p, l + rad, t + rad, rad, Math.PI, Math.PI * 1.5, n); p.closePath();
  return p;
}
function g2Callout(kl, kr, kb, hl, hr, ht, yS, yE, rh, rk) {   // port of g2Callout (round corners, smooth shoulder with vertical handles)
  const p = new Path2D(), n = 2.01, m = (yE - yS) * .302;
  p.moveTo(hl + rh, ht); p.lineTo(hr - rh, ht);
  g2Corner(p, hr - rh, ht + rh, rh, -Math.PI / 2, 0, n); p.lineTo(hr, yS);
  p.bezierCurveTo(hr, yS + m, kr, yE - m, kr, yE); p.lineTo(kr, kb - rk);
  g2Corner(p, kr - rk, kb - rk, rk, 0, Math.PI / 2, n); p.lineTo(kl + rk, kb);
  g2Corner(p, kl + rk, kb - rk, rk, Math.PI / 2, Math.PI, n); p.lineTo(kl, yE);
  p.bezierCurveTo(kl, yE - m, hl, yS + m, hl, yS); p.lineTo(hl, ht + rh);
  g2Corner(p, hl + rh, ht + rh, rh, Math.PI, Math.PI * 1.5, n); p.closePath();
  return p;
}

// glassRect / solidRect = G2Drawable
function glassRect(ctx, l, t, r, b, fill, colors) {   // same glass as the Search Emoji capsule: gradient + rim
  const rimPx = Math.max(1, dp(.75)), half = rimPx / 2, d = !!colors.dark, pressed = fill === colors.keyPressed;
  const path = g2Rect(l + half, t + half, r - half, b - half, dp(K.KEY_RADIUS_DP), K.G2_POWER);
  const top = pressed ? (d ? 0x66FFFFFF : 0xE6C9CED8) : (d ? 0x2EFFFFFF : 0x8CFFFFFF);
  const bot = pressed ? (d ? 0x52FFFFFF : 0xD6BEC3CC) : (d ? 0x1FFFFFFF : 0x61FFFFFF);
  const g = ctx.createLinearGradient(0, t, 0, b); g.addColorStop(0, css(top)); g.addColorStop(1, css(bot));
  ctx.fillStyle = g; ctx.fill(path);
  ctx.lineWidth = rimPx; ctx.strokeStyle = css(d ? 0x26FFFFFF : 0x99FFFFFF); ctx.stroke(path);
}
function accentGlassRect(ctx, l, t, r, b, fill, c) {   // the blue action key, also glass (grey in dark mode)
  // light mode: accent tint (as a held clipboard tile); dark mode: grey glass, since blue reads navy there
  const a = fill & 0x00FFFFFF, d = !!c.dark, held = fill !== c.accent, g = ctx.createLinearGradient(0, t, 0, b);
  if (d) { g.addColorStop(0, css(held ? 0x66FFFFFF : 0x4DFFFFFF)); g.addColorStop(1, css(held ? 0x59FFFFFF : 0x40FFFFFF)); }
  else { g.addColorStop(0, css((a | 0x4D000000) >>> 0)); g.addColorStop(1, css((a | 0x3D000000) >>> 0)); }
  const rimPx = Math.max(1, dp(.75)), half = rimPx / 2, path = g2Rect(l + half, t + half, r - half, b - half, dp(K.KEY_RADIUS_DP), K.G2_POWER);
  ctx.fillStyle = g; ctx.fill(path); ctx.lineWidth = rimPx; ctx.strokeStyle = 'rgba(255,255,255,.4)'; ctx.stroke(path);
}
function solidRect(ctx, l, t, r, b, fill) {            // roundRect(color)
  ctx.fillStyle = css(fill); ctx.fill(g2Rect(l, t, r, b, dp(K.KEY_RADIUS_DP), K.G2_POWER));
}

// ------------------------------------------------------------------ glyphs (drawGlyph, 24x24 grid)
const G = { BACK: 4, SEARCH: 5, EMOJI: 6, MIC: 7, CLIP: 8, CLIP_LINE: 34, GLOBE: 30, MIC_LINE: 31, EMOJI_LINE: 32, GLOBE_SOLID: 33,
            SHIFT: 20, SHIFT_ON: 21, CAPS: 22, DELETE: 23, RETURN: 24 };
function globeLines(c, ring) {   // strokes of the globe on the 24 grid (ring, meridian ellipse, centre line, equator, two parallels)
  if (ring !== false) { c.beginPath(); c.arc(12, 12, 10, 0, Math.PI * 2); c.stroke(); }
  c.beginPath(); c.ellipse(12, 12, 3.8, 10, 0, 0, Math.PI * 2); c.stroke();
  c.beginPath(); c.moveTo(12, 2); c.lineTo(12, 22); c.moveTo(2, 12); c.lineTo(22, 12); c.stroke();
  c.beginPath(); c.moveTo(4.08, 5.9); c.quadraticCurveTo(12, 8.1, 19.92, 5.9); c.stroke();
  c.beginPath(); c.moveTo(4.08, 18.1); c.quadraticCurveTo(12, 15.9, 19.92, 18.1); c.stroke();
}
function drawGlyph(ctx, g, cx, cy, size, color) {
  const sc = size / 24, col = css(color);
  let w = dp(g === G.BACK ? 2.2 : 1.7) / sc;
  const iconW = dp(1.9) / sc;   // outline weight shared by globe, smiley, microphone
  ctx.save();
  ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = w;
  ctx.translate(cx - size / 2, cy - size / 2); ctx.scale(sc, sc);
  const P = () => new Path2D();
  const stroke = p => ctx.stroke(p);
  const rr = (l, t, r, b, rad) => { const p = P(); p.roundRect(l, t, r - l, b - t, rad); return p; };
  const arc = (p, l, t, r, b, st, sw) => p.ellipse((l + r) / 2, (t + b) / 2, (r - l) / 2, (b - t) / 2, 0, st * Math.PI / 180, (st + sw) * Math.PI / 180, sw < 0);
  const line = (x1, y1, x2, y2) => { const p = P(); p.moveTo(x1, y1); p.lineTo(x2, y2); ctx.stroke(p); };
  const circ = (x, y, r, fill) => { const p = P(); p.arc(x, y, r, 0, Math.PI * 2); fill ? ctx.fill(p) : ctx.stroke(p); };
  switch (g) {
    case G.BACK: { const p = P(); p.moveTo(15.6, 4.6); p.lineTo(8.4, 12); p.lineTo(15.6, 19.4); stroke(p); break; }
    case G.EMOJI: {   // SOLID smiley (frosted glass off)
      const p = P(); p.arc(12, 12, 11, 0, Math.PI * 2);
      p.moveTo(9.9, 9.3); p.ellipse(8.7, 9.3, 1.2, 1.5, 0, 0, Math.PI * 2);
      p.moveTo(16.5, 9.3); p.ellipse(15.3, 9.3, 1.2, 1.5, 0, 0, Math.PI * 2);
      p.moveTo(5.0, 12.7); p.lineTo(19.0, 12.7); p.bezierCurveTo(18.5, 17.8, 15.5, 19.3, 12, 19.3); p.bezierCurveTo(8.5, 19.3, 5.5, 17.8, 5.0, 12.7); p.closePath();
      p.roundRect(6.2, 13.5, 11.6, 2.1, .8); ctx.fill(p, 'evenodd'); break; }
    case G.EMOJI_LINE: {   // OUTLINE smiley: ring, dot eyes, open mouth with a curved smile line and curved teeth band
      ctx.lineWidth = iconW; circ(12, 12, 10.1);
      const e = P(); e.ellipse(8.77, 9.58, 1.2, 1.5, 0, 0, Math.PI * 2); e.moveTo(16.43, 9.58); e.ellipse(15.23, 9.58, 1.2, 1.5, 0, 0, Math.PI * 2); ctx.fill(e);
      const p = P(); p.moveTo(5.0, 13.0); p.quadraticCurveTo(12, 14.4, 19.0, 13.0); p.bezierCurveTo(18.6, 17.9, 15.5, 19.2, 12, 19.2); p.bezierCurveTo(8.5, 19.2, 5.4, 17.9, 5.0, 13.0); p.closePath();
      p.moveTo(6.4, 14.0); p.quadraticCurveTo(12, 15.4, 17.6, 14.0); p.lineTo(17.3, 14.9); p.quadraticCurveTo(12, 17.3, 6.7, 14.9); p.closePath();
      ctx.fill(p, 'evenodd'); break; }
    case G.MIC: {   // SOLID microphone (frosted glass off)
      ctx.fill(rr(8.54, 1.45, 15.46, 15.29, 3.46));
      ctx.lineWidth = 1.32;
      const p = P(); p.moveTo(5.74, 9.72); p.lineTo(5.74, 11.31); arc(p, 5.74, 5.05, 18.26, 17.57, 180, -180); p.lineTo(18.26, 9.72); stroke(p);
      line(12, 17.57, 12, 21.89); line(7.47, 21.89, 16.53, 21.89); break; }
    case G.SHIFT: case G.SHIFT_ON: {
      const p = P(); p.moveTo(12, 3.6); p.lineTo(2, 13); p.lineTo(7.3, 13); p.lineTo(7.3, 20.4); p.lineTo(16.7, 20.4); p.lineTo(16.7, 13); p.lineTo(22, 13); p.closePath();
      if (g === G.SHIFT_ON) { ctx.lineWidth = dp(1.8) / sc; ctx.fill(p); stroke(p); }   // shift on: solid arrow
      else { ctx.lineWidth = dp(1.7) / sc; stroke(p); }                                  // shift off: outline arrow only
      break; }
    case G.CAPS: {
      ctx.lineWidth = dp(1.8) / sc;
      const p = P(); p.moveTo(12, 2.8); p.lineTo(2, 11.8); p.lineTo(7.3, 11.8); p.lineTo(7.3, 16.2); p.lineTo(16.7, 16.2); p.lineTo(16.7, 11.8); p.lineTo(22, 11.8); p.closePath();
      ctx.fill(p); stroke(p); const b = rr(7.3, 18.9, 16.7, 21.3, 1.2); ctx.fill(b); stroke(b); break; }
    case G.DELETE: {
      ctx.lineWidth = dp(1.5) / sc;
      const p = P(); p.moveTo(7.6, 3.5); p.lineTo(20.3, 3.5); p.quadraticCurveTo(22.7, 3.5, 22.7, 5.9); p.lineTo(22.7, 18.1); p.quadraticCurveTo(22.7, 20.5, 20.3, 20.5);
      p.lineTo(7.6, 20.5); p.lineTo(1.7, 12.9); p.quadraticCurveTo(1.1, 12, 1.7, 11.1); p.closePath(); stroke(p);
      ctx.lineWidth = dp(1.7) / sc; line(11.9, 8.9, 18.1, 15.1); line(18.1, 8.9, 11.9, 15.1); break; }
    case G.RETURN: {
      ctx.lineWidth = dp(1.5) / sc;
      const p = P(); p.moveTo(12.7, 3.8); p.lineTo(19.5, 3.8); p.quadraticCurveTo(21.9, 3.8, 21.9, 6.2); p.lineTo(21.9, 12.2); p.quadraticCurveTo(21.9, 14.6, 19.5, 14.6);
      p.lineTo(2.1, 14.6); p.moveTo(7.5, 9); p.lineTo(2.1, 14.6); p.lineTo(7.5, 20.2); stroke(p); break; }
    case G.CLIP_LINE: {   // OUTLINE clipboard: rounded board, clip tab (board top open under it), three text lines
      ctx.lineWidth = iconW;
      const L = 3.5, R = 20.5, T = 4, B = 22.5, rb = 3.5, cl = 8, cr = 16, ct = 1.5, rc = 2.2, PI = Math.PI;
      const p = P();
      p.moveTo(cl, T); p.lineTo(L + rb, T); p.arc(L + rb, T + rb, rb, -PI / 2, -PI, true);
      p.lineTo(L, B - rb); p.arc(L + rb, B - rb, rb, PI, PI / 2, true);
      p.lineTo(R - rb, B); p.arc(R - rb, B - rb, rb, PI / 2, 0, true);
      p.lineTo(R, T + rb); p.arc(R - rb, T + rb, rb, 0, -PI / 2, true); p.lineTo(cr, T);
      p.moveTo(cl, T); p.lineTo(cl, ct + rc); p.arc(cl + rc, ct + rc, rc, PI, 1.5 * PI, false);
      p.lineTo(cr - rc, ct); p.arc(cr - rc, ct + rc, rc, -PI / 2, 0, false); p.lineTo(cr, T);
      stroke(p);
      line(7.5, 10.5, 16.5, 10.5); line(7.5, 14.5, 16.5, 14.5); line(7.5, 18.5, 13.5, 18.5);
      break; }
    case G.CLIP: {
      const p = P(); p.roundRect(4, 3.2, 16, 19.4, 3.2); p.roundRect(7.2, 1.9, 9.6, 5.7, 2.2);
      p.roundRect(7.8, 10.6, 8.4, 1.6, .8); p.roundRect(7.8, 14.2, 8.4, 1.6, .8); p.roundRect(7.8, 17.8, 8.4, 1.6, .8);
      ctx.fill(p, 'evenodd'); ctx.fill(rr(8.4, 1.4, 15.6, 6.4, 1.8)); break; }
    case G.SEARCH: circ(10.5, 10.5, 6.5); line(15.3, 15.3, 20, 20); break;
    case G.GLOBE: {   // OUTLINE globe (frosted glass on)
      ctx.lineWidth = iconW; globeLines(ctx); break; }
    case G.GLOBE_SOLID: {   // SOLID globe (frosted glass off): disc with the globe lines cut out
      const pad = Math.ceil(size * .2), S = Math.ceil(size) + 2 * pad, o = mkCanvas(S, S), g2 = o.getContext('2d');
      g2.translate(pad, pad); g2.scale(sc, sc); g2.fillStyle = col; g2.beginPath(); g2.arc(12, 12, 10.68, 0, Math.PI * 2); g2.fill();
      g2.globalCompositeOperation = 'destination-out'; g2.lineCap = 'round'; g2.lineJoin = 'round'; g2.lineWidth = 1.2; globeLines(g2, false);
      ctx.drawImage(o, -pad / sc, -pad / sc, S / sc, S / sc); break; }
    case G.MIC_LINE: {   // OUTLINE microphone (frosted glass on)
      ctx.lineWidth = iconW; stroke(rr(9.2, 2.11, 14.8, 14.63, 2.8));
      const p = P(); p.moveTo(5.74, 9.72); p.lineTo(5.74, 11.31); arc(p, 5.74, 5.05, 18.26, 17.57, 180, -180); p.lineTo(18.26, 9.72); stroke(p);
      line(12, 17.57, 12, 21.89); line(7.47, 21.89, 16.53, 21.89); break; }
  }
  ctx.restore();
}
// glass disc (CatIconsView.glassDisc): vertical gradient top -> bottom and a 0.75 dp rim, like capsule()
function glassCircle(ctx, cx, cy, r, dark) {
  const top = dark ? 0x2EFFFFFF : 0x8CFFFFFF, bot = dark ? 0x1FFFFFFF : 0x61FFFFFF;
  const g = ctx.createLinearGradient(0, cy - r, 0, cy + r); g.addColorStop(0, css(top)); g.addColorStop(1, css(bot));
  ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fillStyle = g; ctx.fill();
  ctx.lineWidth = Math.max(1, dp(.75)); ctx.strokeStyle = css(dark ? 0x26FFFFFF : 0x99FFFFFF); ctx.stroke();
}
// drawCatIcon: category icons from the CAT_ICONS table of the Java file
function drawCatIcon(ctx, cat, filled, cx, cy, size, color) {
  const f = K.catIcons[cat], sc = size / 24, col = css(color), parts = t => t.split('|').filter(x => x.trim()).map(x => new Path2D(x.trim()));
  const o = mkCanvas(Math.ceil(size * 1.3), Math.ceil(size * 1.3)), g = o.getContext('2d');
  g.translate((o.width - size) / 2, (o.height - size) / 2); g.scale(sc, sc);
  g.strokeStyle = col; g.fillStyle = col; g.lineCap = 'round'; g.lineJoin = 'round'; g.lineWidth = 1.55;
  if (!filled) { if (f[0].trim()) g.stroke(new Path2D(f[0])); parts(f[1]).forEach(p => g.fill(p, 'evenodd')); }
  else {
    parts(f[2]).forEach(p => g.fill(p, 'evenodd')); if (f[3].trim()) g.stroke(new Path2D(f[3]));
    g.globalCompositeOperation = 'destination-out'; g.lineWidth = 1.2;
    parts(f[4]).forEach(p => g.fill(p)); if (f[5].trim()) g.stroke(new Path2D(f[5]));
    g.globalCompositeOperation = 'source-over'; g.lineWidth = 1.55; parts(f[6]).forEach(p => g.fill(p));
  }
  ctx.drawImage(o, cx - o.width / 2, cy - o.height / 2);
}
// Icons.PIN lives in the shared Icons class (not in the zip) -> approximated push-pin
function drawPin(ctx, cx, cy, size, color) {
  ctx.save(); ctx.strokeStyle = css(color); ctx.lineWidth = Math.max(1.6, size * .085) * 1; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  const s = size, p = new Path2D();
  p.moveTo(cx - s * .18, cy - s * .44); p.lineTo(cx + s * .18, cy - s * .44); p.lineTo(cx + s * .12, cy - s * .06); p.lineTo(cx + s * .30, cy + s * .10);
  p.lineTo(cx - s * .30, cy + s * .10); p.lineTo(cx - s * .12, cy - s * .06); p.closePath(); ctx.stroke(p);
  ctx.beginPath(); ctx.moveTo(cx, cy + s * .10); ctx.lineTo(cx, cy + s * .46); ctx.stroke(); ctx.restore();
}

// ------------------------------------------------------------------ keys and layouts (lettersLayout, bottomRow, ...)
const T = K; // T_* and LAYER_* constants come from the Java file
function key(type, label, text, weight, alt, letter, icon) {
  return { type, label, text, weight, alt: alt || null, letter: !!letter, icon: icon || 0, iconShift: 0, padL: 0, padR: 0, textDp: 0 };
}
const fn = (type, label, w) => key(type, label, null, w);
const ic = (type, icon, w) => key(type, '', null, w, null, false, icon);
const ch = (s, w) => key(T.T_CHAR, s, s, w);
const space = (w, label) => key(T.T_SPACE, label, ' ', w);
function chars(str, alts, letters, w) {
  return [...str].map((c, i) => key(T.T_CHAR, c, c, w, alts ? alts[i] : null, letters, 0));
}
const facingRight = k => { k.padR = T.SIDE_KEY_GAP_EXTRA_DP; return k; };
const facingLeft = k => { k.padL = T.SIDE_KEY_GAP_EXTRA_DP; return k; };
const ICON = -1;  // "has an icon": the glyph is chosen in ownGlyph()

function returnKey(st, w) {
  switch (st.action) {
    case 'go': return key(T.T_ENTER, 'Go', null, w);
    case 'search': return key(T.T_ENTER, '', null, w, null, false, G.SEARCH);
    case 'send': return key(T.T_ENTER, 'Send', null, w);
    case 'done': return key(T.T_ENTER, 'Done', null, w);
    case 'next': return key(T.T_ENTER, 'Next', null, w);
    default: return key(T.T_ENTER, '', null, w, null, false, ICON);
  }
}
const primaryAction = st => ['go', 'search', 'send', 'done'].includes(st.action);

// Keys.accessoryKey (Java): the key for a choice emoji | clip | globe | mic
function accKey(id, w) {
  if (id === 'clip') return ic(T.T_TO_CLIP, G.CLIP, w);
  if (id === 'globe') return ic(T.T_GLOBE, G.GLOBE, w);   // language key: globe icon
  if (id === 'mic') return ic(T.T_MIC, G.MIC, w);
  return ic(T.T_TO_EMOJI, G.EMOJI, w);
}
function bottomRow(st, fromLetters) {
  const tt = fromLetters ? T.T_TO_SYMBOLS1 : T.T_TO_LETTERS, tl = fromLetters ? '123' : 'ABC', k = [];
  if (st.field === 'email') { k.push(fn(tt, tl, 1.6), space(4.2, ''), ch('@', 1), ch('.', 1), returnKey(st, 2.2)); }
  else if (st.field === 'url') { k.push(fn(tt, tl, 1.5), space(3.9, ''), ch('.', 1), ch('/', 1), key(T.T_CHAR, '.com', '.com', 1.3), returnKey(st, 1.3)); }
  else {   // Settings > Keys: optional button between 123 and space (123 split in half), and between space and return (return split in half)
    const mid = st.mid ? accKey(st.mid, 1.25) : null, midR = st.midR ? accKey(st.midR, 1.25) : null;
    if (mid && st.mid === "clip") mid.iconScale = 0.75;   // v3.98: only the middle clipboard key icon is smaller (0.75)
    k.push(fn(tt, tl, mid ? 1.25 : 2.5)); if (mid) k.push(mid);
    k.push(space(5.0, ''));
    if (midR) { k.push(midR); k.push(returnKey(st, 1.25)); } else { k.push(returnKey(st, 2.5)); }
  }
  return k;
}
function layoutRows(st) {
  const dels = () => facingLeft(ic(T.T_DELETE, ICON, 1.5));
  if (st.layer === T.LAYER_SYMBOLS1) return [chars('1234567890', null, false, 1), chars('-/:;()$&@"', null, false, 1),
    [facingRight(fn(T.T_TO_SYMBOLS2, '#+=', 1.5)), ...chars(".,?!'", null, false, 1.4), dels()], bottomRow(st, false)];
  if (st.layer === T.LAYER_SYMBOLS2) return [chars('[]{}#%^*+=', null, false, 1), chars('_\\|~<>\u20AC\u00A3\u00A5\u2022', null, false, 1),
    [facingRight(fn(T.T_TO_SYMBOLS1, '123', 1.5)), ...chars(".,?!'", null, false, 1.4), dels()], bottomRow(st, false)];
  return [chars('qwertyuiop', '1234567890', true, 1),
    [fn(T.T_SPACER, '', .5), ...chars('asdfghjkl', null, true, 1), fn(T.T_SPACER, '', .5)],
    [facingRight(ic(T.T_SHIFT, ICON, 1.5)), ...chars('zxcvbnm', null, true, 1), dels()], bottomRow(st, true)];
}

// KeyRow: children placed by exact pixel edges from their weights
function rowRects(keys, x0, width, y, h) {
  const total = keys.reduce((a, k) => a + k.weight, 0) || 1;
  let acc = 0, left = 0; const out = [];
  keys.forEach(k => { acc += k.weight; const right = Math.round(width * acc / total); out.push({ key: k, x: x0 + left, y, w: right - left, h }); left = right; });
  return out;
}

// ------------------------------------------------------------------ press animation maths (pressFx)
const decel = t => 1 - (1 - t) * (1 - t);
const overshoot = (t, T) => { t -= 1; return t * t * ((T + 1) * t + T) + 1; };
const clamp01 = v => Math.max(0, Math.min(1, v));
function pressAt(timeline, ms) {   // timeline: {upAt: ms the finger lifts}. returns {scale, glow}
  const P = K.press, S = K.PRESS_SCALE;
  const down = t => ({ s: 1 + (S - 1) * decel(clamp01(t / P.downMs)), g: decel(clamp01(t / P.glowDownMs)) });
  if (ms <= timeline.upAt) return down(ms);
  const d = down(timeline.upAt), t = ms - timeline.upAt;
  return { s: d.s + (1 - d.s) * overshoot(clamp01(t / P.upMs), P.overshoot), g: d.g * (1 - decel(clamp01(t / P.glowUpMs))) };
}

// ------------------------------------------------------------------ KeyView.onDraw
function ownGlyph(st, k) {
  if (k.type === T.T_SHIFT) return st.caps ? G.CAPS : (st.shifted ? G.SHIFT_ON : G.SHIFT);
  if (k.type === T.T_DELETE) return G.DELETE;
  if (k.type === T.T_ENTER && k.icon) return k.icon === G.SEARCH ? G.SEARCH : G.RETURN;
  return k.icon;
}
// frosted glass on = outline icons, frosted glass off (solid keyboard) = solid icons (globe, emoji, dictation only)
function styleIcon(st, g) {
  const o = true;   // outline icons only, frosted glass on or off
  if (g === G.EMOJI || g === G.EMOJI_LINE) return o ? G.EMOJI_LINE : G.EMOJI;
  if (g === G.MIC || g === G.MIC_LINE) return o ? G.MIC_LINE : G.MIC;
  if (g === G.GLOBE || g === G.GLOBE_SOLID) return o ? G.GLOBE : G.GLOBE_SOLID;
  if (g === G.CLIP || g === G.CLIP_LINE) return G.CLIP_LINE;
  return g;
}
function drawGlow(ctx, st, k, r, plain, glow) {
  const c = st.colors, base = (k.type === T.T_ENTER && primaryAction(st)) ? 0xFFFFFFFF : c.accent;
  if (plain) {
    const cxp = r.w * (.5 + k.iconShift), rr = dp(26), cy = r.h / 2;
    const g = ctx.createRadialGradient(cxp, cy, 0, cxp, cy, rr);
    g.addColorStop(0, css(scaleAlpha(base, .34 * glow))); g.addColorStop(1, css(scaleAlpha(base, 0)));
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cxp, cy, rr, 0, Math.PI * 2); ctx.fill(); return;
  }
  const l = insetH() + dp(k.padL), t = insetV(), r2 = r.w - insetH() - dp(k.padR), b = r.h - insetV();
  const path = g2Rect(l, t, r2, b, dp(T.KEY_RADIUS_DP), T.G2_POWER);
  const rad = Math.max(r2 - l, b - t) * .7, cx = (l + r2) / 2, cy = (t + b) / 2;
  const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, rad);
  g.addColorStop(0, css(scaleAlpha(base, .30 * glow))); g.addColorStop(1, css(scaleAlpha(base, .05 * glow)));
  ctx.fillStyle = g; ctx.fill(path);
  for (let n = 1; n <= 4; n++) { ctx.lineWidth = dp(1.4 * n); ctx.strokeStyle = css(scaleAlpha(base, .22 * glow / n)); ctx.stroke(path); }
}
const insetH = () => Math.max(1, Math.round(dp(T.KEY_GAP_H_DP) / 2));
const insetV = () => Math.max(1, Math.round(dp(T.KEY_GAP_V_DP) / 2));

// o: {plain, pressed, scale, glow}
function drawKeyView(ctx, st, k, x, y, w, h, o) {
  o = o || {};
  const c = st.colors, plain = !!o.plain, blue = k.type === T.T_ENTER && primaryAction(st);
  ctx.save();
  ctx.translate(x, y);
  if (o.scale && o.scale !== 1) { ctx.translate(w / 2, h / 2); ctx.scale(o.scale, o.scale); ctx.translate(-w / 2, -h / 2); }
  if (plain && o.pressed) ctx.globalAlpha *= .75;
  if (o.alpha !== undefined) ctx.globalAlpha *= o.alpha;
  if (!plain) {
    const l = insetH() + dp(k.padL), t = insetV(), r = w - insetH() - dp(k.padR), b = h - insetV();
    let fill = c.key; if (blue) fill = o.pressed ? darken(c.accent) : c.accent; else if (o.pressed) fill = c.keyPressed;
    if (blue) accentGlassRect(ctx, l, t, r, b, fill, c); else glassRect(ctx, l, t, r, b, fill, c);
  }
  // the shift key tile never changes colour: only the arrow does (solid when on, outline when off)
  // press glow removed (squeeze / bounce stays)
  const cx = w * (.5 + k.iconShift) + dp(k.padL - k.padR) / 2, cy = h / 2;
  const icon = ownGlyph(st, k);
  if (icon) {
    let gs = 22;
    if (icon === G.EMOJI) gs = T.TRAY_ICON_DP * 24 / 22; else if (icon === G.MIC) gs = 26.6 * 24 / 21.05;
    else if (icon === G.CLIP || icon === G.CLIP_LINE) gs = T.GLOBE_ICON_DP * 24 / 20; else if (icon === G.SHIFT || icon === G.SHIFT_ON || icon === G.CAPS) gs = 21.4;
    else if (icon === G.DELETE) gs = 21.2; else if (icon === G.RETURN) gs = 21.2; else if (icon === G.SEARCH && k.type === T.T_ENTER) gs = 23;
    else if (icon === G.GLOBE) gs = T.GLOBE_ICON_DP * 24 / 20; else if (icon === G.MIC_LINE) gs = T.MIC_LINE_ICON_DP * 24 / 21.1;
    let col = c.text;
    if (k.type === T.T_TO_EMOJI || k.type === T.T_MIC || k.type === T.T_GLOBE || k.type === T.T_TO_CLIP) col = c.dark ? 0xFFFFFFFF : 0xFF000000;   // pure black, same as the other icons
    drawGlyph(ctx, styleIcon(st, icon), cx, cy, dp(gs * (k.iconScale || 1)), blue ? 0xFFFFFFFF : col);
    ctx.restore(); return;
  }
  let label = k.label;
  if (k.letter) label = (st.shifted || st.caps) ? label.toUpperCase() : label.toLowerCase();   // lowercase unless Shift / Caps Lock
  if (label) {
    let size;
    if (k.textDp > 0) size = k.textDp;
    else if (k.type === T.T_SPACE) size = 10.5;
    else if (k.type === T.T_CHAR) size = k.label.length === 1 ? T.CHAR_LABEL_DP : 16;
    else if ([T.T_TO_SYMBOLS1, T.T_TO_SYMBOLS2, T.T_TO_LETTERS, T.T_ENTER].includes(k.type)) size = 18; else size = 17;
    const px = dp(size);
    setFont(ctx, px, 400);
    let color = blue ? 0xFFFFFFFF : c.text;
    if (k.type === T.T_CLIP_CLEAR) color = c.accent;
    if (k.type === T.T_SPACE) {
      color = c.dark ? 0x99FFFFFF : 0x99000000; ctx.fillStyle = css(color); ctx.textAlign = 'right'; ctx.textBaseline = 'alphabetic';
      ctx.fillText(label, w - insetH() - dp(10), h - insetV() - dp(7));
    } else {
      // same baseline for every key in the same case: centre the x-height (lowercase) or the cap height (everything else)
      const lower = !!k.letter && !(st.shifted || st.caps);
      const tb = bounds(px, 400, lower ? 'x' : 'H');
      ctx.fillStyle = css(color); ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
      ctx.fillText(label, cx, cy - (tb.top + tb.bottom) / 2);
    }
  }
  ctx.restore();
}

// ------------------------------------------------------------------ key pop-up (showCallout + CalloutView)
// mode 'new' = this update (x-height / cap-height centring), 'old' = v3.5 (font ascent..descent box centring)
function calloutLayout(keyRect, screenW) {
  const kl = keyRect.x + insetH(), kr = keyRect.x + keyRect.w - insetH(), kt = keyRect.y + insetV(), kb = keyRect.y + keyRect.h - insetV();
  const kw = kr - kl, headW = kw * 1.583, kh = kb - kt, cx = (kl + kr) / 2, pad = dp(4);
  const headL = Math.max(pad, Math.min(cx - headW / 2, screenW - pad - headW)), headR = headL + headW;
  const headB = kt + .06 * kh, headT = kt - 1.464 * kh, side = dp(2);
  const ox = Math.min(headL, kl) - side, oy = headT;
  return { kl: kl - ox, kt: kt - oy, kr: kr - ox, kb: kb - oy, hl: headL - ox, hr: headR - ox, ht: 0, hb: headB - oy, ox, oy };
}
function labelBaseline(L, label, mode) {
  const px = dp(34);
  if (mode === 'old') { const fb = fontBox(px, 500); return (L.ht + L.hb) / 2 - (-fb.asc + fb.desc) / 2 - dp(1); }
  const lower = label.length === 1 && label === label.toLowerCase() && label !== label.toUpperCase();
  const tb = bounds(px, 500, lower ? 'x' : 'H');
  return (L.ht + L.hb) / 2 - (tb.top + tb.bottom) / 2;
}
function drawCallout(ctx, st, L, label, mode, opts) {
  label = (st.shifted || st.caps) ? label.toUpperCase() : label.toLowerCase();
  const c = st.colors, kh = L.kb - L.kt, rh = .191 * (L.hr - L.hl), rk = .266 * (L.kr - L.kl), yS = L.kt - .328 * kh, yE = L.kt + .10 * kh, off = dp(1.5);
  ctx.save(); ctx.translate(L.ox, L.oy);
  const body = g2Callout(L.kl, L.kr, L.kb, L.hl, L.hr, L.ht, yS, yE, rh, rk);
  // shadow only outside the head: the glass body is translucent (same as the Java)
  const outside = new Path2D(); outside.rect(-1e5, -1e5, 2e5, 2e5); outside.addPath(body);
  ctx.save(); ctx.clip(outside, 'evenodd');
  ctx.fillStyle = css(c.calloutShadow); ctx.fill(g2Callout(L.kl, L.kr, L.kb + off, L.hl, L.hr, L.ht + off, yS + off, yE + off, rh, rk));
  ctx.restore();
  // frosted glass (same as the Java): the head is a blurred copy of what is under it, the handle is mostly
  // solid and fades out towards the head, then the glass hairline rim
  const d = !!c.dark;
  ctx.save(); ctx.clip(body);
  ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.filter = `blur(${dp(5)}px)`; ctx.drawImage(ctx.canvas, 0, 0); ctx.restore();
  ctx.fillStyle = css(d ? 0x40000000 : 0x59FFFFFF); ctx.fill(body);
  const solid = c.calloutFill, hg = ctx.createLinearGradient(0, yS, 0, yE);
  hg.addColorStop(0, css(solid & 0x00FFFFFF)); hg.addColorStop(1, css((solid & 0x00FFFFFF) | 0xD9000000));
  ctx.fillStyle = hg; ctx.fill(body);
  ctx.restore();
  ctx.lineWidth = Math.max(1, dp(.75)); ctx.strokeStyle = css(d ? 0x26FFFFFF : 0x99FFFFFF); ctx.stroke(body);
  const base = labelBaseline(L, label, mode);
  if (opts && opts.guide) {   // dashed guide through the head centre
    ctx.setLineDash([dp(3), dp(3)]); ctx.strokeStyle = css(c.accent, .9); ctx.lineWidth = Math.max(1, dp(.6));
    const gy = (L.ht + L.hb) / 2; ctx.beginPath(); ctx.moveTo(L.hl - dp(6), gy); ctx.lineTo(L.hr + dp(6), gy); ctx.stroke(); ctx.setLineDash([]);
  }
  setFont(ctx, dp(34), 500); ctx.fillStyle = css(c.calloutText); ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
  ctx.fillText(label, (L.hl + L.hr) / 2, base);
  ctx.restore();
}

// ------------------------------------------------------------------ geometry shared by all scenes
const W = dp(390);                 // 390 dp wide card
const KEY_H = dp(K.defaultHeight); // Prefs.DEFAULT_HEIGHT
const PAD_X = dp(3), PAD_T = dp(2), SUG_H = dp(43), ACC_H = dp(64);
const PANEL_H = PAD_T + SUG_H + 4 * KEY_H + ACC_H;
const APP_H = dp(120);
const CARD_H = APP_H + PANEL_H;
window.__CARD_H = CARD_H; window.__PANEL_H = PANEL_H;
const mkCanvas = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };

// ------------------------------------------------------------------ "Notes" app behind the keyboard (stand-in)
function drawApp(ctx, dark, withText, CARD_H) {
  CARD_H = CARD_H || window.__CARD_H;
  if (withText === undefined) withText = true;
  ctx.fillStyle = dark ? '#0a0b11' : '#f3f5fa'; ctx.fillRect(0, 0, W, CARD_H);
  const blob = (x, y, r, c0) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, c0); g.addColorStop(1, c0.replace(/[\d.]+\)$/, '0)')); ctx.fillStyle = g; ctx.fillRect(0, 0, W, CARD_H); };
  blob(W * .08, APP_H * .75, W * .6, dark ? 'rgba(235,120,70,0.62)' : 'rgba(255,140,100,0.80)');
  blob(W * .95, APP_H * .55, W * .6, dark ? 'rgba(60,105,225,0.62)' : 'rgba(150,185,245,0.85)');
  blob(W * .5, CARD_H * .78, W * .5, dark ? 'rgba(90,60,160,0.22)' : 'rgba(190,175,235,0.30)');
  if (!withText) return;
  ctx.fillStyle = dark ? 'rgba(255,255,255,.55)' : 'rgba(0,0,0,.45)'; setFont(ctx, dp(11), 400); ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
  ctx.fillText('9:41', dp(20), dp(26));
  ctx.fillStyle = dark ? '#fff' : '#000'; setFont(ctx, dp(22), 700); ctx.fillText('Notes', dp(20), dp(54));
  ctx.fillStyle = dark ? 'rgba(255,255,255,.28)' : 'rgba(0,0,0,.18)';
  [[dp(20), dp(70), dp(290)], [dp(20), dp(82), dp(200)]].forEach(([x, y, w]) => { const p = new Path2D(); p.roundRect(x, y, w, dp(4), dp(2)); ctx.fill(p); });
}

// ------------------------------------------------------------------ the keyboard window: blurred backdrop + panel colour (applyWindowStyle)
function drawPanelBackground(ctx, st, bg, y0, PANEL_H) {
  const r = dp(T.PANEL_RADIUS_DP), shape = new Path2D(); shape.roundRect(0, y0, W, PANEL_H, [r, r, 0, 0]);   // GradientDrawable: same circular radius on every layer
  ctx.save(); ctx.clip(shape);
  if (st.frosted) {   // frosted glass ON: the window blur (gaussian, sigma = radius / 2) behind the translucent glass panel colour
    ctx.filter = `blur(${dp(K.windowBlurDp) / 2}px)`; ctx.drawImage(bg, 0, y0, W, PANEL_H, 0, y0, W, PANEL_H); ctx.filter = 'none';
    // v3.94: glass sheen at the top edge (a lighter tint of the glass colour, as Java glassSheen)
    const pc = panelColor(st.dark, true), f = st.dark ? .10 : .45, mix = v => Math.round(v + (255 - v) * f);
    const rr = (pc >> 16) & 255, gg = (pc >> 8) & 255, bb = pc & 255, sh = ((pc >>> 24) << 24 | (mix(rr) << 16) | (mix(gg) << 8) | mix(bb)) >>> 0;
    const gp = ctx.createLinearGradient(0, y0, 0, y0 + PANEL_H); gp.addColorStop(0, css(sh)); gp.addColorStop(1, css(pc)); ctx.fillStyle = gp; ctx.fillRect(0, y0, W, PANEL_H);
  } else { ctx.fillStyle = css(parseInt(K.panel.solid[st.dark ? 0 : 1], 16) >>> 0); ctx.fillRect(0, y0, W, PANEL_H); }   // frosted glass off: solid panel
  ctx.restore();
}

// ------------------------------------------------------------------ progressive edge blur (EdgeBlurLayout + BlurEngine)
const smooth01 = v => v * v * (3 - 2 * v), smoother01 = v => v * v * v * (v * (6 * v - 15) + 10);
function listStrengths(items, padTop, padBot, scrollY, h, zoneTop, zoneBot, legacy) {
  let cum = 0; const tops = items.map(it => { const t = padTop + cum - scrollY; cum += it.h; return t; });
  const vis = items.map((it, i) => tops[i] + it.h >= 0 && tops[i] <= h);
  const first = vis.indexOf(true), last = vis.lastIndexOf(true);
  const ramp = v => legacy ? v : smooth01(v), rd = legacy ? .5 : 1;   // new: eased ramp over the whole zone
  const sTop = first > 0 ? 1 : ramp(clamp01((padTop - tops[0]) / (zoneTop * rd)));
  const lastBottom = tops[last] + items[last].h;
  const sBot = last < items.length - 1 ? 1 : ramp(clamp01((lastBottom - (h - padBot)) / (zoneBot * rd)));
  return { tops, sTop, sBot };
}
function composeEdge(ctx, content, rx, ry, w, h, sTop, sBot, zoneTop, zoneBot, legacy) {
  const E = K.edge, maxBlur = dp(E.maxBlurDp), steps = legacy ? 14 : Math.min(E.steps, 64);
  if (!legacy) { zoneTop = Math.min(zoneTop * K.EDGE_ZONE_SCALE, h * .45); zoneBot = Math.min(zoneBot * K.CLIP_BOTTOM_ZONE_SCALE, h * .45); }   // blur zones reach past the bars; v3.103: bottom zone uses CLIP_BOTTOM_ZONE_SCALE
  if (sTop <= .001 && sBot <= .001) { ctx.drawImage(content, rx, ry); return; }
  ctx.save(); ctx.beginPath();
  const cy0 = sTop > .001 ? zoneTop : 0, cy1 = sBot > .001 ? h - zoneBot : h;
  ctx.rect(rx, ry + cy0, w, cy1 - cy0); ctx.clip(); ctx.drawImage(content, rx, ry); ctx.restore();
  const strip = (y0, y1, inner, s) => {
    y0 = Math.round(y0); y1 = Math.round(y1); if (y1 <= y0) return;   // whole-pixel strip edges, as in the Java
    const d = 1 - inner, depth = legacy ? Math.pow(d, .8) : null;
    const radius = maxBlur * (legacy ? depth : smoother01(d)) * s, alpha = 1 - s * (legacy ? depth : smooth01(d));
    ctx.save(); ctx.beginPath(); ctx.rect(rx, ry + y0, w, y1 - y0); ctx.clip();
    ctx.globalAlpha = alpha; ctx.filter = radius > .5 ? `blur(${radius}px)` : 'none'; ctx.drawImage(content, rx, ry); ctx.restore();
  };
  const shT = zoneTop / steps, shB = zoneBot / steps;
  for (let i = 0; i < steps; i++) {
    const inner = (i + .5) / steps;
    if (sTop > .001) strip(i * shT, (i + 1) * shT, inner, sTop);
    if (sBot > .001) strip(h - (i + 1) * shB, h - i * shB, inner, sBot);
  }
}

// v3.1.43: the universal footer blur, exactly as the approved preview composes it (Java FooterEdge + drawFooterFade): the zone is
// the footer's own height; over the sharp content two blurred copies are laid, a 6 dp blur at 60 % and a 22 dp blur at 100 % of a
// smoothstep ramp (0 at the top of the footer, full at the screen edge); then the themed fade bar (half the footer's height,
// #F6F6F8 in light / #1E1E20 in dark, 92 % at the edge).
function footerBlur(ctx, src, y0, zone, dark) {
  const Wc = src.width, Hc = src.height, sm = t => { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); };
  const snap = mkCanvas(Wc, Hc); snap.getContext('2d').drawImage(src, 0, 0);
  ctx.save(); ctx.beginPath(); ctx.rect(0, y0, Wc, zone); ctx.clip();
  [{ px: 6, k: 0.6 }, { px: 22, k: 1 }].forEach(lv => {
    const L = mkCanvas(Wc, Hc), g = L.getContext('2d');
    g.filter = 'blur(' + dp(lv.px).toFixed(2) + 'px)'; g.drawImage(snap, 0, 0); g.filter = 'none';
    const M = mkCanvas(Wc, Hc), mg = M.getContext('2d'), gr = mg.createLinearGradient(0, y0, 0, y0 + zone);
    for (let i = 0; i <= 16; i++) { const pr = i / 16; gr.addColorStop(pr, 'rgba(0,0,0,' + (lv.k * sm(pr)).toFixed(4) + ')'); }
    mg.fillStyle = gr; mg.fillRect(0, y0, Wc, zone);
    g.globalCompositeOperation = 'destination-in'; g.drawImage(M, 0, 0);
    ctx.drawImage(L, 0, 0);
  });
  const barTop = y0 + zone - zone / 2, F = mkCanvas(Wc, Hc), fg = F.getContext('2d'), rgb = dark ? '30,30,32' : '246,246,248';
  const fade = fg.createLinearGradient(0, barTop, 0, y0 + zone);
  for (let i = 0; i <= 16; i++) { const pr = i / 16; fade.addColorStop(pr, 'rgba(' + rgb + ',' + (0.92 * sm(pr)).toFixed(4) + ')'); }
  fg.fillStyle = fade; fg.fillRect(0, barTop, Wc, y0 + zone - barTop);
  ctx.drawImage(F, 0, 0);
  ctx.restore();
}

// ------------------------------------------------------------------ wrapping for the two-line clipboard preview
function wrapTwoLines(text, px, maxW) {
  const words = text.trim().split(/\s+/); let line1 = '', i = 0;
  for (; i < words.length; i++) { const t = (line1 ? line1 + ' ' : '') + words[i]; if (textW(px, 400, t) <= maxW || !line1) line1 = t; else break; }
  let rest = words.slice(i).join(' ');
  if (!rest) return [line1];
  if (textW(px, 400, rest) <= maxW) return [line1, rest];
  while (rest.length > 1 && textW(px, 400, rest + '\u2026') > maxW) rest = rest.slice(0, -1);
  return [line1, rest.trimEnd() + '\u2026'];
}
// clipboard tile: keys' glass with a 16 dp corner and G2 exponent 2.6; held / selected = accent tint
const CLIP_TILE_RADIUS_DP = 16, CLIP_TILE_POWER = 2.6;
function tileGlass(ctx, l, t, r, b, pressed, colors, tint) {
  // v3.91: a held or selected tile uses the neutral tint (light grey in light mode, white in dark mode), never the accent colour
  const rimPx = Math.max(1, dp(.75)), half = rimPx / 2, d = !!colors.dark;
  const path = g2Rect(l + half, t + half, r - half, b - half, dp(CLIP_TILE_RADIUS_DP), CLIP_TILE_POWER);
  if (pressed) {
    const rgb = (tint !== undefined ? tint : (d ? 0xFFFFFF : 0x8E8E8E)) & 0x00FFFFFF;
    const top = d ? (rgb | 0x59000000) >>> 0 : (rgb | 0x4D000000) >>> 0, bot = d ? (rgb | 0x47000000) >>> 0 : (rgb | 0x3D000000) >>> 0;
    const g = ctx.createLinearGradient(0, t, 0, b); g.addColorStop(0, css(top)); g.addColorStop(1, css(bot));
    ctx.fillStyle = g; ctx.fill(path);
    ctx.lineWidth = rimPx; ctx.strokeStyle = css((rgb | 0x66000000) >>> 0); ctx.stroke(path);
    return;
  }
  const top = d ? 0x2EFFFFFF : 0x8CFFFFFF, bot = d ? 0x1FFFFFFF : 0x61FFFFFF;
  const g = ctx.createLinearGradient(0, t, 0, b); g.addColorStop(0, css(top)); g.addColorStop(1, css(bot));
  ctx.fillStyle = g; ctx.fill(path);
  ctx.lineWidth = rimPx; ctx.strokeStyle = css(d ? 0x26FFFFFF : 0x99FFFFFF); ctx.stroke(path);
}
function clipRows(st, listW, clips, selected, heldTint) {
  const px = dp(15), fb = fontBox(px, 400), lineH = fb.asc + fb.desc;
  return clips.map(it => {
    const cardL = insetH(), cardR = listW - insetH();
    const textMax = (cardR - cardL) - dp(14) - dp(8) - (it.pinned ? dp(30) + dp(8) : 0);
    const lines = wrapTwoLines(it.text, px, textMax);
    const contentH = lines.length * lineH + dp(9) * 2, cardH = Math.max(KEY_H - 2 * insetV(), contentH), h = cardH + 2 * insetV();
    return { h, it, lines, cardH, contentH, lineH, fb,
      draw(c, top) {
        const ct = top + insetV(), cb = ct + cardH, sel = selected === it;
        tileGlass(c, cardL, ct, cardR, cb, sel, st.colors, sel ? heldTint : undefined);
        const ctop = ct + (cardH - contentH) / 2; setFont(c, px, 400); c.fillStyle = css(st.colors.text); c.textAlign = 'left'; c.textBaseline = 'alphabetic';
        lines.forEach((ln, i) => c.fillText(ln, cardL + dp(14), ctop + dp(9) + i * lineH + fb.asc));
        if (it.pinned) drawPin(c, cardR - dp(8) - dp(15), ct + cardH / 2, dp(17), st.colors.accent);
      },
      geom: { cardL, cardR, cardH } };
  });
}

// ------------------------------------------------------------------ emoji data (EmojiData.java, parsed) and the iOS 27 style panel
function emojiGeo() {   // emojiScale / emojiRowPx / emojiTopPx / ... of the Java
  const f = Math.max(.7, Math.min(1, KEY_H / dp(50)));
  return { f, row: dp(Math.min(K.EMOJI_ROW_MAX_DP, KEY_H / D + K.EMOJI_ROW_EXTRA_DP)),
    top: Math.round(dp(K.EMOJI_SEARCH_AREA_DP) * f), cat: Math.round(dp(K.EMOJI_CAT_BAR_DP) * f), foot: 0,
    pillH: Math.round(dp(K.EMOJI_PILL_H_DP) * f), pillTop: dp(K.EMOJI_PILL_TOP_DP), overlap: Math.round(dp(K.EMOJI_BAR_OVERLAP_DP) * f) };
}
function emojiPanelH() { const g = emojiGeo(); return PAD_T + g.top + g.row * K.EMOJI_ROWS + g.cat + g.foot + ACC_H; }   // v3.100: the shared footer row is under the content
function buildGrid(recents) {   // buildEmojiGrid(): column-major, categories back to back
  const R = K.EMOJI_ROWS, cells = [], start = [], cols = []; let col = 0;
  K.emojiLists.forEach((l0, c) => {
    const list = c === 0 ? recents : l0; start[c] = col; let n;
    if (!list.length) { n = c === 0 ? K.EMOJI_COLS : 0; for (let i = 0; i < n * R; i++) cells.push(null); }
    else { n = Math.ceil(list.length / R); for (let i = 0; i < n * R; i++) cells.push(i < list.length ? list[i] : null); }
    cols[c] = n; col += n;
  });
  return { cells, start, cols, total: col };
}
function emojiCellW(w) { return Math.floor((w - dp(K.EMOJI_GRID_INSET_L_DP) - dp(K.EMOJI_GRID_INSET_R_DP)) / K.EMOJI_COLS); }
function drawEmojiGrid(c, st, grid, scrollX, w, hTop, recentsEmpty) {   // EmojiGridView.onDraw, content canvas c, grid starts at y = hTop
  const g = emojiGeo(), cw = emojiCellW(w), il = dp(K.EMOJI_GRID_INSET_L_DP), R = K.EMOJI_ROWS;
  const size = Math.round(Math.min(g.row, cw) * K.EMOJI_SIZE_FACTOR);
  c.font = `${size}px ${EMOJI_FONT}`; c.textAlign = 'center'; c.textBaseline = 'alphabetic'; c.fillStyle = '#000';
  const m = c.measureText('😀'), off = (m.fontBoundingBoxAscent - m.fontBoundingBoxDescent) / 2;   // = -(ascent + descent) / 2 with ascent < 0
  const first = Math.max(0, Math.floor((scrollX - il) / cw)), last = Math.min(grid.total - 1, Math.floor((scrollX + w - il) / cw));
  for (let col = first; col <= last; col++) for (let r = 0; r < R; r++) {
    const e = grid.cells[col * R + r]; if (!e) continue;
    c.fillText(e, il + cw * (col + .5) - scrollX, hTop + g.row * (r + .5) + off);
  }
  if (recentsEmpty) {
    setFont(c, dp(15), 400); c.fillStyle = css(st.dark ? 0x99EBEBF5 : 0x993C3C43); c.textAlign = 'center';
    c.fillText('No Recent Emoji', il + cw * (grid.start[0] + grid.cols[0] / 2) - scrollX, hTop + g.row * R / 2);
  }
}
function selectedCat(grid, scrollX, w) {   // updateEmojiTab()
  const col = Math.floor((scrollX + emojiCellW(w) / 2) / emojiCellW(w)); let sel = 0;
  grid.cols.forEach((n, c) => { if (n > 0 && grid.start[c] <= col) sel = c; });
  return sel;
}
function capsulePath(l, t, r, b) { const p = new Path2D(), half = Math.max(1, dp(.75)) / 2; p.roundRect(l + half, t + half, r - l - 2 * half, b - t - 2 * half, (b - t) / 2); return p; }
function drawCapsule(ctx, st, l, t, r, b) {   // capsule(): glass gradient + rim
  const d = st.dark, top = d ? 0x2EFFFFFF : 0x8CFFFFFF, bot = d ? 0x1FFFFFFF : 0x61FFFFFF, p = capsulePath(l, t, r, b);
  const g = ctx.createLinearGradient(0, t, 0, b); g.addColorStop(0, css(top)); g.addColorStop(1, css(bot)); ctx.fillStyle = g; ctx.fill(p);
  ctx.lineWidth = Math.max(1, dp(.75)); ctx.strokeStyle = css(d ? 0x26FFFFFF : 0x99FFFFFF); ctx.stroke(p);
}
function drawSearchPill(ctx, st, l, t, r, b, value, closable) {   // SearchPill.onDraw
  drawCapsule(ctx, st, l, t, r, b);
  const gray = st.dark ? 0x99EBEBF5 : 0x993C3C43, cy = (t + b) / 2;
  drawGlyph(ctx, G.SEARCH, l + dp(K.PILL_ICON_X_DP), cy, dp(K.PILL_ICON_DP), gray);
  const px = dp(17), fb = fontBox(px, 400); setFont(ctx, px, 400);
  ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic'; ctx.fillStyle = css(value ? st.colors.text : gray);
  let s = value || 'Search Emoji'; const room = (r - l) - dp(K.PILL_TEXT_X_DP) - dp(closable ? K.PILL_CLOSE_ZONE_DP : 14);
  while (value && s.length > 1 && textW(px, 400, s) > room) s = s.slice(1);
  ctx.fillText(s, l + dp(K.PILL_TEXT_X_DP), cy + (fb.asc - fb.desc) / 2);
  if (closable) {
    const cr = dp(K.PILL_CLOSE_DP) / 2, cx = r - dp(K.PILL_CLOSE_ZONE_DP) / 2, k = cr * .38;
    ctx.fillStyle = css(st.dark ? 0x40FFFFFF : 0x33000000); ctx.beginPath(); ctx.arc(cx, cy, cr, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = css(st.dark ? 0xFF1C1C1E : 0xFFFFFFFF); ctx.lineWidth = dp(1.6); ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(cx - k, cy - k); ctx.lineTo(cx + k, cy + k); ctx.moveTo(cx - k, cy + k); ctx.lineTo(cx + k, cy - k); ctx.stroke();
  }
}
// FastEdge: sharp / 5 dp / 15 dp layers cross-faded through gradient masks in the two edge zones
function composeFast(ctx, content, rx, ry, w, h, zt, zb) {
  const sm = t => { t = clamp01(t); return t * t * (3 - 2 * t); };
  const alpha = (k, d) => k === 0 ? 1 - sm(d / .7) : k === 1 ? (d < .5 ? sm(d / .5) : 1 - sm((d - .5) / .5)) : .94 * sm((d - .2) / .8);
  ctx.save(); ctx.beginPath(); ctx.rect(rx, ry + zt, w, h - zb - zt); ctx.clip(); ctx.drawImage(content, rx, ry); ctx.restore();
  const zone = (y0, y1, top) => {
    [[0, 0], [1, dp(5)], [2, dp(15)]].forEach(([k, rad]) => {
      const L = mkCanvas(w, Math.ceil(y1 - y0)), g = L.getContext('2d');
      g.filter = rad ? `blur(${rad}px)` : 'none'; g.drawImage(content, 0, -y0); g.filter = 'none';
      const gr = g.createLinearGradient(0, 0, 0, y1 - y0);
      for (let i = 0; i <= 16; i++) { const p = i / 16; gr.addColorStop(p, `rgba(0,0,0,${alpha(k, top ? 1 - p : p).toFixed(4)})`); }
      g.globalCompositeOperation = 'destination-in'; g.fillStyle = gr; g.fillRect(0, 0, w, y1 - y0);
      ctx.drawImage(L, rx, ry + y0);
    });
  };
  zone(0, zt, true); zone(h - zb, h, false);
}

// ------------------------------------------------------------------ shared pieces: suggestion bar, accessory row, popup menu
function drawSuggestionWords(ctx, st, x0, w, y, words) {
  const c = st.colors, div = Math.max(1, dp(.7)), px = dp(16.5), fb = fontBox(px, 400), any = words.some(Boolean);
  const wts = any ? [1, 1, 1] : [.55, 6.9, .55], tot = wts[0] + wts[1] + wts[2], inner = w - 2 * div;   // nothing to suggest: wide middle cell, dividers 30 dp from the edges
  let ax = x0;
  words.forEach((wd, i) => {
    const cw = inner * wts[i] / tot, cx = ax + cw / 2;
    if (wd) { setFont(ctx, px, 400); ctx.fillStyle = css(c.text); ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic'; ctx.fillText(wd, cx, y + SUG_H / 2 + (fb.asc - fb.desc) / 2); }
    ax += cw;
    if (i < 2) { ctx.fillStyle = css(c.divider); ctx.fillRect(ax, y + (SUG_H - dp(21)) / 2, div, dp(21)); ax += div; }
  });
}
// Java KeyView.drawPressCircle: glass disc (gradient + rim, like glassDisc), alpha = press glow
function pressCircle(ctx, cx, cy, h, dark, glow) {
  const d = Math.min(dp(K.PRESS_CIRCLE_DP), h - dp(2)); if (d <= 0 || glow <= 0) return;
  const top = dark ? 0x59FFFFFF : 0xB3FFFFFF, bot = dark ? 0x3DFFFFFF : 0x80FFFFFF, rim = dark ? 0x40FFFFFF : 0xB3FFFFFF;
  ctx.save(); ctx.globalAlpha = Math.min(1, glow);
  const g = ctx.createLinearGradient(0, cy - d / 2, 0, cy + d / 2); g.addColorStop(0, css(top)); g.addColorStop(1, css(bot));
  ctx.beginPath(); ctx.arc(cx, cy, d / 2, 0, Math.PI * 2); ctx.fillStyle = g; ctx.fill();
  ctx.lineWidth = Math.max(1, dp(.75)); ctx.strokeStyle = css(rim); ctx.stroke();
  ctx.restore();
}
function drawAccessory(ctx, st, x0, w, y, press, micDx) {   // press: { type: 'emoji' | 'clip' | 'mic' | 'globe', glow } (the pressed key's glass circle)
  const slotW = 2.5, left = accKey(st.left || 'emoji', slotW), right = accKey(st.right || 'mic', slotW);
  left.iconShift = (1.051 - slotW / 2) / slotW; right.iconShift = (slotW / 2 - 1.077) / slotW;   // Java: same icon places as before
  const keys = [left, fn(T.T_SPACER, '', 10 - 2 * slotW), right];
  rowRects(keys, x0, w, y, ACC_H).forEach((r, i) => {
    if (i === 2) r.x += micDx || 0;   // v3.120: the right-corner key is pushed sideways by the pop-up's overshoot
    if (r.key.type === T.T_SPACER) return;
    const t = r.key.type === T.T_TO_EMOJI ? 'emoji' : r.key.type === T.T_TO_CLIP ? 'clip' : r.key.type === T.T_MIC ? 'mic' : r.key.type === T.T_GLOBE ? 'globe' : '';
    if (press && press.type === t) pressCircle(ctx, r.x + r.w * (.5 + (r.key.iconShift || 0)), r.y + r.h / 2, r.h, st.dark, press.glow === undefined ? 1 : press.glow);
    drawKeyView(ctx, st, r.key, r.x, r.y, r.w, r.h, { plain: true });
  });
}
// the long-press capsule in the header: a glass capsule split in two by a line, Pin / Unpin | Delete
function drawClipMenuBar(ctx, st, cx, t, b, item, hl) {
  // outer capsule (the shell): fixed 176 dp wide, split exactly in the middle
  const px = dp(16), W = dp(176), labelA = item.pinned ? 'Unpin' : 'Pin', inset = dp(3);
  const l = cx - W / 2, mid = cx, r = cx + W / 2;
  drawCapsule(ctx, st, l, t, r, b);
  // inner capsule (the highlight) on the chosen half, tinted: red Delete, green Pin, blue Unpin
  if (hl) {
    const tint = st.colors.dark ? 0xFFFFFFFF : 0xFF8E8E8E, rgb = tint & 0xFFFFFF;   // v3.91: neutral for every press
    const x0h = hl === 'pin' ? l + inset : mid + inset, x1h = hl === 'pin' ? mid - inset : r - inset;
    const hg = ctx.createLinearGradient(0, t + inset, 0, b - inset);
    hg.addColorStop(0, css((rgb | 0x59000000) >>> 0)); hg.addColorStop(1, css((rgb | 0x47000000) >>> 0));
    const hp = new Path2D(); hp.roundRect(x0h, t + inset, x1h - x0h, b - t - 2 * inset, (b - t) / 2 - inset);
    ctx.fillStyle = hg; ctx.fill(hp);
    ctx.lineWidth = Math.max(1, dp(.75)); ctx.strokeStyle = css((rgb | 0x99000000) >>> 0); ctx.stroke(hp);
  }
  const fb = fontBox(px, 500);
  setFont(ctx, px, 500); ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
  const base = (t + b) / 2 + (fb.asc - fb.desc) / 2;
  ctx.fillStyle = css(st.colors.text); ctx.fillText(labelA, (l + mid) / 2, base);
  // Delete turns over the highlight for contrast: black in light mode, white in dark mode; red otherwise
  ctx.fillStyle = css(0xFFFF3B30); ctx.fillText('Delete', (mid + r) / 2, base);   // v3.93: Delete label is red
  ctx.fillStyle = css(st.colors.divider); ctx.fillRect(mid - dp(.4), t + dp(10), Math.max(1, dp(.75)), b - t - dp(20));
}
function drawClipMenu(ctx, st, cardRect, item, below) {
  const c = st.colors, rowH = dp(46), menuW = dp(168), divH = Math.max(1, dp(.75)), menuH = rowH * 2 + divH;
  const mx = cardRect.x + cardRect.w - menuW - dp(10), my = below ? cardRect.y + cardRect.h + dp(2) : cardRect.y - dp(2) - menuH;
  ctx.save(); ctx.shadowColor = 'rgba(0,0,0,.32)'; ctx.shadowBlur = dp(14); ctx.shadowOffsetY = dp(4);   // elevation 8 dp: shadow approximated
  const p = new Path2D(); p.roundRect(mx, my, menuW, menuH, dp(14)); ctx.fillStyle = css(c.dark ? 0xF22C2E34 : 0xF7FFFFFF); ctx.fill(p); ctx.restore();
  ctx.lineWidth = Math.max(1, dp(.75)); ctx.strokeStyle = css(c.keyStroke); ctx.stroke(p);
  ctx.fillStyle = css(c.divider); ctx.fillRect(mx, my + rowH, menuW, divH);
  setFont(ctx, dp(16), 500); ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
  ctx.fillStyle = css(c.text); ctx.fillText(item.pinned ? 'Unpin' : 'Pin', mx + dp(18), my + rowH / 2);
  ctx.fillStyle = css(0xFFFF3B30); ctx.fillText('Delete', mx + dp(18), my + rowH + divH + rowH / 2);
}

// ------------------------------------------------------------------ one card = one keyboard state
const CLIPS = [
  { text: 'Order #48213, ship to Cebu City', pinned: true },
  { text: 'https://example.com/docs/getting-started?ref=share', pinned: false },
  { text: 'Reminder: submit the draft before Friday noon and attach the data sheet, signed forms and the full reference list', pinned: false },
  { text: 'Wi-Fi password: guest-2026', pinned: false },
  { text: 'Meeting moved to 3 pm, room B2', pinned: false },
  { text: '+63 917 555 0142', pinned: false },
  { text: "Thanks! I'll send the signed forms tonight.", pinned: false },
];
const STATE_BASE = { layer: T.LAYER_LETTERS, shifted: false, caps: false, field: 'normal', action: 'none', frosted: true, left: 'emoji', right: 'mic' };   // frosted glass is on by default (Prefs)

function rowsOf(st, keysYOverride) {   // rects of every key row of the letters / symbols layers
  const x0 = PAD_X, w = W - 2 * PAD_X, keysY = keysYOverride !== undefined ? keysYOverride : APP_H + PAD_T + SUG_H;
  return layoutRows(st).map((keys, r) => rowRects(keys, x0, w, keysY + r * KEY_H, KEY_H));
}

function renderCard(spec) {
  const st = Object.assign({}, STATE_BASE, spec.state || {}); st.dark = !!spec.dark; st.colors = mkColors(st.dark);
  const layer = st.layer, isEmoji = layer === T.LAYER_EMOJI, isSearch = layer === T.LAYER_EMOJI_SEARCH, G_ = emojiGeo();
  const PANEL_H = (isEmoji || isSearch) ? emojiPanelH() : window.__PANEL_H, CARD_H = APP_H + PANEL_H;
  const cv = mkCanvas(W, CARD_H), ctx = cv.getContext('2d');
  const bg = mkCanvas(W, CARD_H); drawApp(bg.getContext('2d'), st.dark, !spec.free, CARD_H);
  ctx.save(); const clipP = new Path2D(); clipP.roundRect(0, 0, W, CARD_H, dp(28)); ctx.clip(clipP);
  ctx.drawImage(bg, 0, 0);
  if (spec.free) { spec.free(ctx, st, bg); ctx.restore(); return cv; }
  drawPanelBackground(ctx, st, bg, APP_H, PANEL_H);

  const x0 = PAD_X, w = W - 2 * PAD_X, oy = APP_H, sugY = oy + PAD_T, keysY = sugY + SUG_H, accY = keysY + 4 * KEY_H;
  const holder = { x: PAD_X, w };

  if (isEmoji) {   // ---- iOS 27 emoji panel
    const R = K.EMOJI_ROWS, gridY = sugY + G_.top, catY = gridY + G_.row * R, footY = catY + G_.cat;
    const recents = spec.recents || [], grid = buildGrid(recents), scrollX = (spec.scrollCat !== undefined ? grid.start[spec.scrollCat] * emojiCellW(w) : 0) + (spec.scrollPx || 0);
    const hh = G_.top + G_.row * R + G_.cat, content = mkCanvas(w, hh), cc = content.getContext('2d');
    drawEmojiGrid(cc, st, grid, scrollX, w, G_.top, !recents.length && scrollX < emojiCellW(w) * K.EMOJI_COLS);
    composeFast(ctx, content, holder.x, sugY, w, hh, G_.top, G_.cat + G_.overlap);
    // top: Search Emoji pill
    const pm = dp(K.EMOJI_PILL_MARGIN_DP);
    drawSearchPill(ctx, st, x0 + pm, sugY + G_.pillTop, x0 + w - pm, sugY + G_.pillTop + G_.pillH, '');
    // category bar: ABC | icons | delete
    const sel = selectedCat(grid, scrollX, w), abc = fn(T.T_TO_LETTERS, 'ABC', 1); abc.textDp = 16.5;
    // same geometry as addEmojiBars(): ABC and delete slots = content + equal side padding, icons in the middle
    const abcW = textW(dp(16.5), 400, 'ABC') / D + 2 * K.EMOJI_BAR_PAD_DP, delW = K.DEL_ICON_W_DP + 2 * K.EMOJI_BAR_PAD_DP, viewW = K.EMOJI_BAR_TOTAL_DP - abcW - delW;
    const bar = rowRects([abc, fn(T.T_SPACER, '', 1), ic(T.T_DELETE, ICON, 1)].map((k, i) => (k.weight = [abcW, viewW, delW][i], k)), x0, w, catY, G_.cat);
    drawKeyView(ctx, st, bar[0].key, bar[0].x, bar[0].y, bar[0].w, bar[0].h, { plain: true });
    drawKeyView(ctx, st, bar[2].key, bar[2].x, bar[2].y, bar[2].w, bar[2].h, { plain: true });
    const iv = bar[1], d = Math.min(dp(K.CAT_SEL_DP), G_.cat - dp(2));
    for (let i = 0; i < K.catIcons.length; i++) {
      const pxPerDp = iv.w / viewW, shift = (delW - abcW) / 2;
      const cx = iv.x + iv.w / 2 + pxPerDp * (shift + K.CAT_PITCH_DP * (i - K.CAT_MID)), cy = catY + G_.cat / 2, on = i === sel;
      if (on) glassCircle(ctx, cx, cy, d / 2, st.dark);   // glass disc: same gradient and rim as the capsules (Java glassDisc)
      drawCatIcon(ctx, i, on, cx, cy, dp(K.CAT_ICON_DP), on ? st.colors.text : scaleAlpha(st.colors.text, .82));
    }
    // v3.100: the footer is the shared accessory row (emoji / mic corners), the same as the keyboard's
    drawAccessory(ctx, st, x0, w, footY, spec.accPress);
    ctx.restore(); return cv;
  }

  const bottom = oy + PANEL_H;
  if (layer === T.LAYER_CLIP) {
    const clips = spec.clips === undefined ? CLIPS : spec.clips;
    // held tile tint: neutral grey (light) / white (dark) for every press (v3.91)
    let heldTint = undefined;
    if (spec.selected !== undefined && spec.menu) {
      const it = clips[spec.selected];
      heldTint = st.colors.dark ? 0xFFFFFFFF : 0xFF8E8E8E;
    }
    const rows = clipRows(st, w, clips, spec.selected !== undefined ? clips[spec.selected] : null, heldTint);
    const items = rows, hy = sugY, hh = SUG_H + 4 * KEY_H + ACC_H, padTop = Math.max(SUG_H, dp(K.EMOJI_PILL_TOP_DP) + emojiGeo().pillH) + dp(K.CLIP_HEADER_GAP_DP), padBot = ACC_H, zoneTop = SUG_H, zoneBot = ACC_H, scrollY = spec.scrollY || 0;
    const empty = items.length === 0;
    if (!empty) {
      const content = mkCanvas(w, hh), cc = content.getContext('2d');
      const S = listStrengths(items, padTop, padBot, scrollY, hh, zoneTop, zoneBot, false);
      items.forEach((it, i) => { const top = S.tops[i]; if (top + it.h >= 0 && top <= hh) it.draw(cc, top); });
      composeEdge(ctx, content, holder.x, hy, w, hh, 1, 0, zoneTop, zoneBot, false);   // v3.120: no bottom blur in the list (noBottom); the header blurs the top
      spec._S = S; spec._rows = rows; spec._padBot = padBot;
    } else {
      const lines = ['Nothing copied yet.', 'Text you copy will show up here.'], px = dp(14), fb = fontBox(px, 400), lh = fb.asc + fb.desc;
      setFont(ctx, px, 400); ctx.fillStyle = css(st.dark ? 0x99FFFFFF : 0x99000000); ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
      const cy = hy + padTop + (hh - padTop - padBot) / 2, top = cy - lines.length * lh / 2;
      lines.forEach((l, i) => ctx.fillText(l, holder.x + w / 2, top + i * lh + fb.asc));
    }
    // header: only the buttons sit in glass (round back button, Clear all capsule); the title is centred on the panel
    const pm = dp(K.EMOJI_PILL_MARGIN_DP), bt = sugY + dp(K.EMOJI_PILL_TOP_DP), bh = emojiGeo().pillH, bl = x0 + pm, cr = x0 + w - pm, cl = cr - dp(K.CLIP_CLEAR_W_DP);
    drawCapsule(ctx, st, bl, bt, bl + bh, bt + bh); drawCapsule(ctx, st, cl, bt, cr, bt + bh);
    drawKeyView(ctx, st, ic(T.T_CLIP_CLOSE, G.BACK, 1), bl, bt, bh, bh, { plain: true });
    const tpx = dp(17), fb = fontBox(tpx, 500);
    if (!(spec.selected !== undefined && spec.menu)) {   // a long-press puts the capsule in the title's place
      setFont(ctx, tpx, 500); ctx.fillStyle = css(st.colors.text); ctx.textAlign = 'center'; ctx.textBaseline = 'alphabetic';
      ctx.fillText('Clipboard', x0 + w / 2, sugY + SUG_H / 2 + (fb.asc - fb.desc) / 2);
    }
    drawKeyView(ctx, st, fn(T.T_CLIP_CLEAR, 'Clear all', 1), cl, bt, cr - cl, bh, { plain: true, alpha: empty ? .35 : 1 });
    if (!empty) footerBlur(ctx, cv, accY, ACC_H, st.dark);   // v3.120: the universal footer blur over what slides under it
    drawAccessory(ctx, st, x0, w, accY);
    if (spec.selected !== undefined && spec.menu) {
      drawClipMenuBar(ctx, st, x0 + w / 2, bt, bt + bh, spec._rows[spec.selected].it, spec.hl);
    }
    ctx.restore(); return cv;
  }

  // ---- letters / symbols / emoji search
  const rowStyle = layer === T.LAYER_EMOJI_SEARCH ? Object.assign({}, st, { layer: T.LAYER_LETTERS }) : st;
  let kY, accY2 = accY;
  if (layer === T.LAYER_EMOJI_SEARCH) {   // pill stays on top, the first emoji row shows the results, the keyboard sits over the rest of the grid
    const pm = dp(K.EMOJI_PILL_MARGIN_DP);
    drawSearchPill(ctx, st, x0 + pm, sugY + G_.pillTop, x0 + w - pm, sugY + G_.pillTop + G_.pillH, spec.query || '', true);
    const resH = Math.max(0, G_.row * K.EMOJI_ROWS + G_.cat - 4 * KEY_H), rowH = Math.min(G_.row, resH), ry = sugY + G_.top;   // v3.120: searchResultsPx
    kY = ry + resH; accY2 = kY + 4 * KEY_H;
    const cw = emojiCellW(w), il = dp(K.EMOJI_GRID_INSET_L_DP), size = Math.round(Math.min(rowH, cw) * K.EMOJI_SIZE_FACTOR);
    ctx.font = `${size}px ${EMOJI_FONT}`; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillStyle = '#000';
    (spec.query ? (K.search_hap || []) : []).forEach((e, i) => ctx.fillText(e, x0 + il + cw * (i + .5), ry + rowH / 2));
    if (!spec.query) { setFont(ctx, dp(15), 400); ctx.fillStyle = css(st.dark ? 0x99EBEBF5 : 0x993C3C43); ctx.textAlign = 'left'; ctx.fillText('Type to find an emoji', x0 + il + dp(10), ry + rowH / 2); }
  } else {
    drawSuggestionWords(ctx, st, x0, w, sugY, spec.words || ['', '', '']);
  }
  const rows = rowsOf(rowStyle, kY);
  let pressed = null;
  rows.forEach((row, r) => row.forEach((rc, i) => {
    if (rc.key.type === T.T_SPACER) return;
    if (spec.press && spec.press.r === r && spec.press.i === i) { pressed = rc; return; }
    drawKeyView(ctx, rowStyle, rc.key, rc.x, rc.y, rc.w, rc.h, {});
  }));
  if (pressed) drawKeyView(ctx, rowStyle, pressed.key, pressed.x, pressed.y, pressed.w, pressed.h,
    { pressed: true, scale: spec.press.scale === undefined ? T.PRESS_SCALE : spec.press.scale, glow: spec.press.glow === undefined ? 1 : spec.press.glow });
  if (spec.cornerPopup) drawCornerGoo(ctx, st, x0, w, accY2, spec.cornerPopup === true ? 1 : spec.cornerPopup);
  const micDx = spec.cornerPopup ? gooMicOffsetPx(spec.cornerPopup === true ? 1 : spec.cornerPopup, x0, w, accY2) : 0;
  drawAccessory(ctx, st, x0, w, accY2, spec.accPress, micDx);
  if (spec.cornerPopup) drawCornerButtons(ctx, st, x0, w, accY2, spec.cornerPopup === true ? 1 : spec.cornerPopup);
  if (spec.trackpad) {   // space held: the keys turn into a blurred glass sheet, opaque over the keys (TrackpadOverlay)
    const F = dp(8), rx = 0, ry = keysY - F, rw = W, rh = 4 * KEY_H + 2 * F;
    const kT = F, kB = F + 4 * KEY_H;
    const snap = mkCanvas(rw, rh), sc = snap.getContext('2d');
    sc.drawImage(cv, rx, ry, rw, rh, 0, 0, rw, rh);
    const lay = mkCanvas(rw, rh), lc = lay.getContext('2d');
    if (st.dark) { lc.filter = `blur(${dp(9)}px)`; lc.drawImage(snap, 0, 0); lc.filter = 'none'; }   // v3.102: light mode draws no blurred keys
    lc.fillStyle = css(st.dark ? 0xDD202022 : 0xFFF7F7F5); lc.fillRect(0, 0, rw, rh);   // solid off-white in light mode
    lc.globalCompositeOperation = 'destination-in';
    const mg = lc.createLinearGradient(0, 0, 0, rh);
    mg.addColorStop(0, 'rgba(0,0,0,0)'); mg.addColorStop(kT / rh, 'rgba(0,0,0,1)');
    mg.addColorStop(kB / rh, 'rgba(0,0,0,1)'); mg.addColorStop(1, 'rgba(0,0,0,0)');
    lc.fillStyle = mg; lc.fillRect(0, 0, rw, rh); lc.globalCompositeOperation = 'source-over';
    ctx.drawImage(lay, rx, ry);
    const msg = 'Move your fingers to control the cursor', tpx = dp(17), lines = wrapTwoLines(msg, tpx, rw - dp(48));
    setFont(ctx, tpx, 500); ctx.fillStyle = css(st.dark ? 0xFFAEAEB2 : 0xFF636366); ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    const lh = dp(22), midY = ry + (kT + kB) / 2 - (lines.length - 1) * lh / 2;
    lines.forEach((ln, i) => ctx.fillText(ln, rx + rw / 2, midY + i * lh));
  }
  if (spec.popup) {
    const rc = rows[spec.popup.r][spec.popup.i], L = calloutLayout(rc, W);
    drawCallout(ctx, st, L, spec.popup.label, 'new');
  }
  ctx.restore(); return cv;
}

// ------------------------------------------------------------------ special cards
function pressFramesCard(dark) {
  return renderCard({ dark, free(ctx, st) {
    const c = st.colors; ctx.fillStyle = css(c.dark ? 0x99000000 : 0x99FFFFFF); const p = new Path2D(); p.roundRect(dp(8), dp(8), W - dp(16), CARD_H - dp(16), dp(20)); ctx.fill(p);
    setFont(ctx, dp(11), 500); ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic'; ctx.fillStyle = css(c.dark ? 0xB3FFFFFF : 0xB3000000);
    ctx.fillText('key scale + glow over time (letter key "g", finger held 140 ms)', dp(20), dp(26));
    const k = chars('g', null, true, 1)[0], kw = Math.round((W - 2 * PAD_X) / 10), frames = [
      ['touch down', 0], ['+35 ms', 35], ['+70 ms', 70], ['lift: +140', 140], ['lift +60 ms', 200], ['lift +120', 260], ['lift +200', 340], ['lift +380', 520]];
    const tl = { upAt: 140 }, colW = Math.floor(W / 4);
    frames.forEach(([name, ms], i) => {
      const col = i % 4, row = Math.floor(i / 4), cx = colW * col + (colW - kw) / 2, cy = dp(38) + row * dp(120);
      const f = pressAt(tl, ms);
      drawKeyView(ctx, st, k, cx, cy, kw, KEY_H, { pressed: ms <= tl.upAt, scale: f.s, glow: f.g });
      setFont(ctx, dp(9.5), 400); ctx.textAlign = 'center'; ctx.fillStyle = css(c.dark ? 0x99FFFFFF : 0x99000000);
      ctx.fillText(name, cx + kw / 2, cy + KEY_H + dp(12));
      setFont(ctx, dp(10.5), 500); ctx.fillStyle = css(c.text); ctx.fillText(f.s.toFixed(3), cx + kw / 2, cy + KEY_H + dp(25));
    });
    // peak of the release overshoot, from the code's own numbers
    let pk = 0, pt = 0; for (let t = 0; t <= 380; t++) { const s = pressAt(tl, 140 + t).s; if (s > pk) { pk = s; pt = t; } }
    const P = K.press; ctx.textAlign = 'left'; setFont(ctx, dp(9.5), 400); ctx.fillStyle = css(c.dark ? 0x99FFFFFF : 0x99000000);
    ['Sink: scale to ' + K.PRESS_SCALE.toFixed(2) + ' in ' + P.downMs + ' ms (DecelerateInterpolator); glow in ' + P.glowDownMs + ' ms.',
     'Release: back to 1.0 over ' + P.upMs + ' ms with OvershootInterpolator(' + P.overshoot + '); glow out over ' + P.glowUpMs + ' ms.',
     'Overshoot peaks at ' + pk.toFixed(3) + ' about ' + pt + ' ms after the finger lifts, then settles on 1.000.'].forEach((l, i) => ctx.fillText(l, dp(20), dp(288) + i * dp(14)));
  } });
}
function popupCompareCard(dark) {
  return renderCard({ dark, free(ctx, st) {
    const c = st.colors; ctx.fillStyle = css(c.dark ? 0x99000000 : 0x99FFFFFF); const p = new Path2D(); p.roundRect(dp(8), dp(8), W - dp(16), CARD_H - dp(16), dp(20)); ctx.fill(p);
    const labels = ['g', 'p', '1', '9', 'A'], kw = Math.round((W - 2 * PAD_X) / 10);
    [['before (v3.5): ascent..descent box centred', 'old', dp(95), dp(32)], ['after (this update): x-height / cap height centred', 'new', dp(235), dp(172)]].forEach(([cap, mode, ky, capY]) => {
      setFont(ctx, dp(11), 500); ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic'; ctx.fillStyle = css(c.dark ? 0xDDFFFFFF : 0xDD000000); ctx.fillText(cap, dp(20), capY);
      labels.forEach((lb, i) => {
        const rect = { x: dp(14) + i * dp(74), y: ky - insetV(), w: kw, h: KEY_H };
        drawCallout(ctx, st, calloutLayout(rect, W), lb, mode, { guide: true });
      });
    });
    setFont(ctx, dp(9.5), 400); ctx.fillStyle = css(c.dark ? 0xAAFFFFFF : 0xAA000000); ctx.textAlign = 'left';
    ctx.fillText('Dashed line = middle of the pop-up head. Letters (small x-height, descenders)', dp(20), CARD_H - dp(38));
    ctx.fillText('and numbers now share one optical height, like the key labels do.', dp(20), CARD_H - dp(24));
  } });
}

// ------------------------------------------------------------------ the sheet
const RECENTS = ['😂', '❤️', '👍', '🙏', '😭', '🔥', '✨', '🥺', '😊', '🎉'];   // stand-in recent emoji
function sceneList(dark) {
  const R = (title, spec, fn) => ({ title, make: () => fn ? fn(dark) : renderCard(Object.assign({ dark }, spec)) });
  const W3 = ['I', 'The', "I'm"], E = { state: { layer: T.LAYER_EMOJI } };
  return [
    R('Emoji panel (iOS 27 layout): Smileys', Object.assign({ scrollCat: 1, recents: RECENTS }, E)),
    R('Emoji panel: Animals & Nature selected (dog icon, filled)', Object.assign({ scrollCat: 2, scrollPx: 0, recents: RECENTS }, E)),
    R('Emoji panel: scrolled between two categories', Object.assign({ scrollCat: 3, scrollPx: -emojiCellW(W - 2 * PAD_X) * 3, recents: RECENTS }, E)),
    R('Emoji panel: Recent (with recent emoji)', Object.assign({ scrollCat: 0, recents: RECENTS }, E)),
    R('Emoji panel: Recent, empty', Object.assign({ scrollCat: 0, recents: [] }, E)),
    R('Emoji panel: Flags', Object.assign({ scrollCat: 8, recents: RECENTS }, E)),
    R('Emoji search (typing "hap"): keyboard over the grid, results in the top row', { state: { layer: T.LAYER_EMOJI_SEARCH }, query: 'hap' }),
    R('Emoji search, empty', { state: { layer: T.LAYER_EMOJI_SEARCH }, query: '' }),
    R('Letters, nothing to suggest (iOS 27 reference state)', { words: ['', '', ''] }),
    R('Space bar held: trackpad mode (blurred keys, prompt, glass)', { words: W3, trackpad: true }),
    R('Hold the lower-left corner: circle on the key, glass capsule in the middle of the footer', { state: { layer: T.LAYER_LETTERS }, cornerPopup: true }),
    R('Opening 17 ms: the press circle stretches into a mini capsule (clock 0.03)', { state: { layer: T.LAYER_LETTERS }, cornerPopup: 0.03 }),
    R('Opening 60 ms: pinching in the middle; the halves separate (clock 0.11)', { state: { layer: T.LAYER_LETTERS }, cornerPopup: 0.11 }),
    R('Opening 83 ms: detached; the left half is back on the key (clock 0.15)', { state: { layer: T.LAYER_LETTERS }, cornerPopup: 0.15 }),
    R('Opening 252 ms: the capsule has widened into the centre of the footer (clock 0.45)', { state: { layer: T.LAYER_LETTERS }, cornerPopup: 0.45 }),
    R('Opening 380 ms: the centred capsule rebounds and touches the mic (clock 0.68)', { state: { layer: T.LAYER_LETTERS }, cornerPopup: 0.68 }),
    R('Opening 540 ms: the mic springs back to its place (clock 0.97)', { state: { layer: T.LAYER_LETTERS }, cornerPopup: 0.97 }),
    R('Letters (sample suggestion words)', { words: W3 }),
    R('Letters, Shift on', { state: { shifted: true }, words: W3 }),
    R('Letters, clipboard in the left corner, mic on the right (Settings > Keys)', { state: { left: 'clip' }, words: W3 }),
    R('Letters, Settings > Keys: globe left, clipboard right', { state: { left: 'globe', right: 'clip' }, words: W3 }),
    R('Letters, emoji between 123 and space (Settings > Keys)', { state: { mid: 'emoji' }, words: W3 }),
    R('Letters, clipboard between 123 and space', { state: { mid: 'clip' }, words: W3 }),
    R('Letters, globe between 123 and space', { state: { mid: 'globe' }, words: W3 }),
    R('Letters, button between space and return (Settings > Keys)', { state: { midR: 'clip' }, words: W3 }),
    R('Letters, Caps Lock', { state: { caps: true }, words: W3 }),
    R('Numbers (123)', { state: { layer: T.LAYER_SYMBOLS1 } }),
    R('Symbols (#+=)', { state: { layer: T.LAYER_SYMBOLS2 } }),
    R('Clipboard panel (header in the glass capsule)', { state: { layer: T.LAYER_CLIP } }),
    R('Clipboard, scrolled: blur under header + footer', { state: { layer: T.LAYER_CLIP }, scrollY: dp(150) }),
    R('Clipboard, long-press tile: highlight glides to Delete', { state: { layer: T.LAYER_CLIP }, selected: 0, menu: true, hl: 'delete' }),
    R('Clipboard, long-press last tile: highlight on Pin', { state: { layer: T.LAYER_CLIP }, selected: 3, menu: true, hl: 'pin' }),
    R('Clipboard, long-press pinned tile: highlight on Unpin (blue)', { state: { layer: T.LAYER_CLIP }, selected: 0, menu: true, hl: 'pin' }),
    R('Clipboard, long-press tile: held tile default (grey, light mode)', { state: { layer: T.LAYER_CLIP }, selected: 1, menu: true }),
    R('Clipboard panel, empty', { state: { layer: T.LAYER_CLIP }, clips: [] }),
    R('Mic key pressed: glass circle behind the icon', { words: W3, accPress: { type: 'mic' } }),
    R('Emoji key pressed: glass circle behind the icon', { words: W3, accPress: { type: 'emoji' } }),
    R('Clipboard key pressed: glass circle behind the icon', { words: W3, state: { left: 'clip' }, accPress: { type: 'clip' } }),
    R('Key pressed: "g" pop-up', { words: W3, press: { r: 1, i: 5 }, popup: { r: 1, i: 5, label: 'g' } }),
    R('Edge key pressed: "p" pop-up', { words: W3, press: { r: 0, i: 9 }, popup: { r: 0, i: 9, label: 'p' } }),
    R('Hold "q": types the number 1', { words: W3, press: { r: 0, i: 0 }, popup: { r: 0, i: 0, label: '1' } }),
    R('Shift pressed (key sunk to ' + Math.round(K.PRESS_SCALE * 100) + ' %)', { words: W3, press: { r: 2, i: 0 } }),
    R('Press animation, frame by frame (from the code)', {}, pressFramesCard),
    R('Email field', { state: { field: 'email' } }),
    R('URL field (Go action)', { state: { field: 'url', action: 'go' } }),
    R('Search field (Search action)', { state: { action: 'search' } }),
    R('Frosted glass ON: letters (outline icons)', { state: { frosted: true }, words: W3 }),
    R('Frosted glass ON: Shift on (solid arrow, tile unchanged)', { state: { frosted: true, shifted: true }, words: W3 }),
    R('Frosted glass ON: emoji panel (outline globe + mic)', Object.assign({ scrollCat: 1, recents: RECENTS }, { state: { layer: T.LAYER_EMOJI, frosted: true } })),
    R('Frosted glass ON: clipboard panel (outline emoji + mic)', { state: { layer: T.LAYER_CLIP, frosted: true } }),
    R('Frosted glass OFF (solid panel): letters', { state: { frosted: false }, words: W3 }),
    R('Frosted glass OFF (solid panel): emoji panel', Object.assign({ scrollCat: 1, recents: RECENTS }, { state: { layer: T.LAYER_EMOJI, frosted: false } })),
  ];
}

// v3.107: the bottom-row editor shows the keyboard's own keys: the letters keyboard cropped to its keys (no app,
// no suggestion bar), with accent outlines on the two corner tiles the user can change.
function editorBoardUrl(dark) {
  const cv = renderCard({ state: { layer: T.LAYER_LETTERS }, dark });
  const top = APP_H + PAD_T + SUG_H, h = PANEL_H - (PAD_T + SUG_H);
  const out = mkCanvas(W, h), oc = out.getContext('2d');
  oc.drawImage(cv, 0, top, W, h, 0, 0, W, h);
  const x0 = PAD_X, w = W - 2 * PAD_X, accY = 4 * KEY_H, slotW = w * 0.25;
  oc.strokeStyle = dark ? '#0A84FF' : '#3478F7'; oc.lineWidth = dp(2);
  [x0 + dp(3), x0 + w - slotW + dp(3)].forEach(x => {
    oc.beginPath(); oc.roundRect(x, accY + dp(3), slotW - dp(6), ACC_H - dp(6), dp(12)); oc.stroke();
  });
  return out.toDataURL('image/png');
}

// v3.1.26: the tool capsule (openCornerPopup / CornerGooView in KeyboardService.java). The clock says where each part is
// heading, and springs carry the parts there, so the motion never stops and jumps between phases. Opening: 560 ms.
const GOO_MS = 1133, GOO_CLOSE_MS = 1133, GOO_NECK_REACH = 1.6, GOO_SPLIT = 1.6, GOO_SWELL = 0.14;   // v3.1.38: one trajectory, close = open backwards; the neck spans the whole split
// v3.1.29: the reference clip, captured frame by frame (same tables as KeyboardService.java)
const GOO_OPEN = { L: [260, 260, 260, 260, 260, 260, 260, 258, 253, 245, 233, 218, 203, 190, 182, 177, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175, 175], N: [556, 556, 556, 556, 556, 556, 556, 556, 557, 557, 558, 559, 561, 562, 562, 563, 563, 563, 563, 562, 561, 560, 559, 558, 557, 557, 557, 557, 557, 557], C: [516.5, 547.5, 563.5, 579.5, 594.5, 606.5, 616.5, 622.5, 621, 623, 623, 622, 621.5, 621, 619.5, 618, 616.5, 614.5, 612.5, 610.5, 608.5, 606.5, 605.5, 606.5, 607, 607.5, 607.5, 608, 608, 608], D: [79, 79, 79, 79, 79, 79, 79, 79, 91, 91, 91, 91, 90, 89, 88, 87, 86, 84, 82, 80, 78, 76, 74, 74, 73, 74, 74, 75, 75, 75] };
const GOO_CLOSE = { L: [175, 175, 175, 175, 175, 175, 177, 182, 190, 203, 218, 233, 245, 254, 258, 260, 260, 260, 260, 260, 260, 260, 260, 260, 260], N: [560, 561, 562, 563, 563, 563, 563, 562, 562, 561, 560, 558, 557, 557, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556], C: [606.5, 608.5, 610, 612.5, 614.5, 616.5, 618, 620, 621, 621.5, 622, 623, 623, 621, 623.5, 616.5, 607.5, 594.5, 579.5, 563.5, 547.5, 535.5, 525.5, 519.5, 516.5], D: [74, 74, 75, 78, 80, 82, 85, 87, 89, 90, 91, 91, 91, 91, 79, 79, 79, 79, 79, 79, 79, 79, 79, 79, 79] };
function gooGeom(u, x0w, w, accY) {   // the layout: the closed state is the capsule attached to the press circle (v3.1.29)
  const R0 = dp(K.PRESS_CIRCLE_DP || 40) / 2, cx = x0w + w * 0.1051, rcx = x0w + w - 0.1077 * w;
  const capW = dp(4 * 50 + 16), capL = x0w + (w - capW) / 2, capR = capL + capW;
  const micContact = rcx - R0 - dp(2), reb = Math.max(dp(6), micContact - capR + dp(6));
  return { R0, cx, rcx, capL, capR, micContact, reb, rr: R0 };
}
function gooSample(ys, x) {   // cubic Hermite through uniform samples, same as sample() in CornerGooView
  const n = ys.length - 1; if (x <= 0) return ys[0]; if (x >= n) return ys[n];
  const i = Math.min(n - 1, Math.floor(x)), t = x - i;
  const sl = k => k === 0 ? ys[1] - ys[0] : k === n ? ys[n] - ys[n - 1] : (ys[k + 1] - ys[k - 1]) / 2;
  const m0 = sl(i), m1 = sl(i + 1), t2 = t * t, t3 = t2 * t;
  return (2 * t3 - 3 * t2 + 1) * ys[i] + (t3 - 2 * t2 + t) * m0 + (-2 * t3 + 3 * t2) * ys[i + 1] + (t3 - t2) * m1;
}
function gooSpring(s, target, k, c, dt) { const n = 4, h = dt / n; for (let i = 0; i < n; i++) { const a = k * (target - s.x) - c * s.v; s.v += a * h; s.x += s.v * h; } }
// The spring state of the tool capsule, one entry per 1/60 s (60 fps), simulated like CornerGooView.onDraw.
// 'open' runs from the key's circle to the capsule (clock 0 -> 1 in GOO_MS), 'close' runs the same targets backwards
// from the open capsule. Each entry carries the shapes, the mic offset and the clock u for that frame.
const GOO_FRAME_N = Math.round(GOO_MS / 1000 * 60), GOO_CLOSE_FRAME_N = Math.round(GOO_CLOSE_MS / 1000 * 60), GOO_FADE_FR = 13;
const GOO_TOTAL_STEPS = 34, GOO_PROG_END = ((608 - 557) + 39.5) / 86.5;
function gooSmooth01(x) { x = Math.max(0, Math.min(1, x)); return x * x * (3 - 2 * x); }
function gooTrajectory(u, L) {   // the same trajectory as computeState() in CornerGooView
  const rr = L.R0, steps = Math.max(0, Math.min(1, u)) * GOO_TOTAL_STEPS, wRest = 3.75 * 2 * rr, wFinal = L.capR - L.capL, neRest = L.cx - rr;
  if (steps < 2) return { x0: neRest, x1: neRest + 2 * rr, rc: rr, bodyAlpha: 0, prog: 0 };
  if (steps < 5) { const g = gooSmooth01((steps - 2) / 3); return { x0: neRest, x1: neRest + 2 * rr + (wRest - 2 * rr) * g, rc: rr, bodyAlpha: g, prog: 0 }; }
  const t = Math.min(steps - 5, GOO_OPEN.L.length - 1);
  const l = gooSample(GOO_OPEN.L, t), n = gooSample(GOO_OPEN.N, t), c = gooSample(GOO_OPEN.C, t), d = gooSample(GOO_OPEN.D, t);
  const prog = ((c - n) + 39.5) / 86.5 / GOO_PROG_END, pFar = Math.max(0, Math.min(1, (260 - l) / 85));
  const x0 = neRest + prog * (L.capL - neRest);
  return { x0, x1: x0 + wRest + pFar * (wFinal - wRest), rc: rr, bodyAlpha: 1, prog: Math.max(0, Math.min(1, prog)) };
}
const GOO_CACHE = {};
function gooSimFrames(kind, x0w, w, accY) {   // the state of every frame; closing runs the same clock backwards
  const key = [kind, x0w, w, accY].join(':');
  if (GOO_CACHE[key]) return GOO_CACHE[key];
  const L = gooGeom(1, x0w, w, accY), rr = L.R0, open = kind !== 'close';
  const N = open ? GOO_FRAME_N : GOO_CLOSE_FRAME_N, out = [];
  for (let f = 0; f <= N + 6; f++) {
    const uu = open ? Math.min(1, f / N) : Math.max(0, 1 - f / N);
    const st = gooTrajectory(uu, L);
    // the highlights (press circle and mic circle) pop in over the first two frames (open) and pop out over the last two (close)
    let cs = 1;
    if (open && f < 2) cs = 0.85 + 0.15 * gooSmooth01(f / 2);
    if (!open && f > N - 2) cs = 1 - 0.15 * gooSmooth01(Math.min(1, (f - (N - 2)) / 2));
    // the press circle swells with the capsule's glide, on the same clock: it grows as the capsule leaves and settles as it arrives
    const glide = Math.sin(Math.PI * st.prog);
    const rc = rr * (1 + GOO_SWELL * glide) * cs;
    const gap = st.x0 - (L.cx + rc), neckReach = GOO_NECK_REACH * rr;
    // the neck (pinch) lasts while the capsule is wider than the circle, and tapers smoothly to nothing as the capsule
    // shrinks into the circle. It is off while the capsule rests in the middle, so nothing bridges to the circle at rest.
    const wRr = (st.x1 - st.x0) / rr;                              // the capsule's width in radii (2 = the circle's width)
    const ramp = gooSmooth01((wRr - 2) / 3.0);                      // 0 once the capsule is no wider than the circle, 1 when clearly wider (taper spans the shrink)
    const arrive = 1 - gooSmooth01((st.prog - 0.8) / 0.12);         // 0 while the capsule rests in the middle
    const gapTaper = gap <= 0 ? 1 : (gap < neckReach ? 0.5 * (1 + Math.cos(Math.PI * gap / neckReach)) : 0);
    const neckH = rr * gapTaper * ramp * arrive;
    // the capsule is hidden on the first frame and shown from the second on (open); closing hides it on its last two frames
    const bodyOn = open ? (f >= 2 ? 1 : 0) : (f <= N - 2 ? 1 : 0);
    const fq = Math.max(0, Math.min(1, (f - N) / GOO_FADE_FR)), fadeOut = 1 - fq * fq * (3 - 2 * fq);
    const fade = open ? 1 : (f <= N ? 1 : fadeOut);
    out.push({ f, t: f / 60, u: uu, x0: st.x0, x1: Math.max(st.x1, st.x0 + 2 * rr), rc, cs, cx: L.cx, bodyHH: rr, off: 0, neckH, micX: 0,
      alpha: fade, bodyAlpha: bodyOn * fade, R0: rr, rcx: L.rcx, capL: L.capL, capR: L.capR });
  }
  GOO_CACHE[key] = out;
  return out;
}
function gooGeomState(u, x0w, w, accY) {   // the state at clock u (opening), from the cached frames
  if (window.GOO_FORCE) return window.GOO_FORCE;   // the frame preview sets one exact frame and renders the card
  const fr = gooSimFrames('open', x0w, w, accY);
  const i = u >= 1 ? fr.length - 1 : Math.min(fr.length - 1, Math.round(Math.max(0, u) * GOO_FRAME_N));
  return fr[i];
}
function gooState(u, x0w, w, accY) { return gooGeomState(u, x0w, w, accY); }
function drawCornerGoo(ctx, st, x0, w, accY, u) {
  // v3.1.32: the circles and the capsule are painted as two layers, so the circles can show while the capsule is hidden
  const g = gooState(u, x0, w, accY), cy = accY + ACC_H / 2;
  const pad = dp(24), ox = x0 - pad, oy = accY - pad, ow = Math.ceil(w + 2 * pad), oh = Math.ceil(ACC_H + 2 * pad);
  const circles = new Path2D();
  circles.arc(g.cx - ox, cy - oy, g.rc, 0, Math.PI * 2);                                                   // the press circle on the key
  const mr = g.R0 * (g.cs === undefined ? 1 : g.cs);
  circles.moveTo(g.rcx + g.micX - ox + mr, cy - oy); circles.arc(g.rcx + g.micX - ox, cy - oy, mr, 0, Math.PI * 2);   // the mic's circle
  const body = new Path2D();
  if (g.x1 - g.x0 > 0.5) body.roundRect(g.x0 - ox, cy - oy - g.bodyHH, g.x1 - g.x0, 2 * g.bodyHH, Math.min(g.bodyHH, (g.x1 - g.x0) / 2));
  if (g.neckH > dp(0.6)) {
    const h = g.neckH, ax = g.cx + Math.sqrt(Math.max(0, g.rc * g.rc - h * h)) - ox;
    const bx = g.x0 + g.R0 - Math.sqrt(Math.max(0, g.R0 * g.R0 - h * h)) - ox, yy = cy - oy;
    if (bx > ax) {
      const mx = (ax + bx) / 2, bow = 0.35 * h, n = new Path2D();
      n.moveTo(ax, yy - h); n.quadraticCurveTo(mx, yy - bow, bx, yy - h); n.lineTo(bx, yy + h);
      n.quadraticCurveTo(mx, yy + bow, ax, yy + h); n.closePath(); body.addPath(n);
    }
  }
  if (g.bodyAlpha >= 0.999) {   // v3.1.37: circles and capsule as one union: one fill, one outline
    paintGooLayer(ctx, st, [circles, body], ox, oy, ow, oh, cy - oy, g.R0, g.alpha);
  } else {
    paintGooLayer(ctx, st, [circles], ox, oy, ow, oh, cy - oy, g.R0, g.alpha);
    if (g.bodyAlpha > 0) paintGooLayer(ctx, st, [body], ox, oy, ow, oh, cy - oy, g.R0, g.bodyAlpha);
  }
}
function paintGooLayer(ctx, st, paths, ox, oy, ow, oh, cyL, R0, alpha) {   // paths: one shape, or several shapes merged into one outline
  const fl = mkCanvas(ow, oh), fc = fl.getContext('2d'), top = cyL - R0, bot = cyL + R0;
  const gr = fc.createLinearGradient(0, top, 0, bot);
  gr.addColorStop(0, css(st.dark ? 0x2EFFFFFF : 0x8CFFFFFF)); gr.addColorStop(1, css(st.dark ? 0x1FFFFFFF : 0x61FFFFFF));
  fc.fillStyle = gr; paths.forEach(p => fc.fill(p, 'nonzero'));
  const rw = Math.max(1, dp(.75)), ring = mkCanvas(ow, oh), rc2 = ring.getContext('2d');
  rc2.lineWidth = 2 * rw; rc2.strokeStyle = css(st.dark ? 0x26FFFFFF : 0x99FFFFFF); paths.forEach(p => rc2.stroke(p));
  rc2.globalCompositeOperation = 'destination-out'; rc2.fillStyle = '#000'; paths.forEach(p => rc2.fill(p, 'nonzero'));
  ctx.save(); ctx.globalAlpha = alpha; ctx.drawImage(fl, ox, oy); ctx.drawImage(ring, ox, oy); ctx.restore();
}
function gooMicOffsetPx(u, x0w, w, accY) { return gooState(u, x0w, w, accY).micX; }
function drawCornerButtons(ctx, st, x0, w, accY, u) {
  // v3.1.36: the four icons follow the capsule: centred on it, scaled with its width, faded with it
  const gg = gooGeom(1, x0, w, accY), R0 = gg.R0, cy = accY + ACC_H / 2, capW = gg.capR - gg.capL;
  const g = gooState(u, x0, w, accY), frac = Math.max(0, Math.min(1, (g.x1 - g.x0) / capW));
  // the icons fade with the open/close clock: in as the capsule opens, out as it closes, fully off at rest
  const alpha = gooSmooth01((u - 0.05) / 0.5), ink = st.dark ? '#FFFFFF' : '#000000';
  if (alpha <= 0) return;
  const groupCx = (g.x0 + g.x1) / 2;
  ['gear', 'resize', 'translate', 'theme'].forEach((k, i) => {
    const off = (dp(8) + i * dp(50) + dp(25)) - capW / 2;
    ctx.save(); ctx.globalAlpha = alpha; drawPopupIcon(ctx, k, groupCx + off * frac, cy, Math.min(dp(50), 2 * R0) * 0.46 * frac, ink); ctx.restore();
  });
}
function drawPopupIcon(ctx, kind, cx, cy, s, ink) {   // the same shapes as Icons.java: every icon fills 0.7 s
  ctx.save(); ctx.strokeStyle = ink; ctx.fillStyle = ink; ctx.lineCap = 'round'; ctx.lineWidth = Math.max(1.6, s * 0.085);
  const line = (x1, y1, x2, y2) => { ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke(); };
  if (kind === 'gear') {
    const r = s * 0.22; ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.arc(cx, cy, r * 0.42, 0, Math.PI * 2); ctx.stroke();
    for (let i = 0; i < 8; i++) { const a = i * Math.PI / 4; line(cx + Math.cos(a) * r * 1.05, cy + Math.sin(a) * r * 1.05, cx + Math.cos(a) * s * 0.35, cy + Math.sin(a) * s * 0.35); }
  } else if (kind === 'resize') {
    const h = s * 0.35, d = s * 0.12;
    line(cx, cy - h, cx, cy + h); line(cx - d, cy - h + d, cx, cy - h); line(cx + d, cy - h + d, cx, cy - h);
    line(cx - d, cy + h - d, cx, cy + h); line(cx + d, cy + h - d, cx, cy + h);
    line(cx - s * 0.35, cy - h, cx - s * 0.20, cy - h); line(cx - s * 0.35, cy + h, cx - s * 0.20, cy + h);
  } else if (kind === 'translate') {
    const l = cx - s * 0.34, r = cx, t = cy - s * 0.33, b = cy + s * 0.08, m = (l + r) / 2;
    line(l, b, m, t); line(m, t, r, b); line(l + (r - l) * 0.25, cy - s * 0.10, r - (r - l) * 0.25, cy - s * 0.10);
    const y = cy + s * 0.27; line(cx - s * 0.10, y, cx + s * 0.34, y); line(cx + s * 0.27, y - s * 0.07, cx + s * 0.34, y); line(cx + s * 0.27, y + s * 0.07, cx + s * 0.34, y);
  } else {
    const r = s * 0.35; ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.arc(cx, cy, r, Math.PI / 2, Math.PI * 1.5); ctx.closePath(); ctx.fill();
  }
  ctx.restore();
}
