"""Frame-by-frame DRAFT of the panel switch: keyboard <-> emoji panel (v3.1.41 draft, no source change yet).

Rule being previewed (the user's description):
  * the keyboard panel is the default active panel;
  * opening the emoji panel: the emoji panel rises from the bottom edge of the panel area while the keyboard
    panel drops out below it; closing it: the emoji panel drops out and the keyboard rises back;
  * the universal footer never moves (the window is anchored to the bottom of the screen);
  * the window grows upward, so the header's top edge rises with it (the header zone height changes).
Every number comes from KeyboardService.java / scenes.js (the same drawing code as the keyboard sheets).
Timing: PANEL_OPEN_MS / PANEL_CLOSE_MS with PANEL_OPEN_EASE / PANEL_CLOSE_EASE, the constants the panel
raise and sink already use in the source.

Usage: python3 build_panel_switch_preview.py ../../app/src/main/java/com/custom/keyboard/KeyboardService.java out.html
"""
import base64, json, os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from extract_from_java import extract, search

JAVA, OUT = sys.argv[1], sys.argv[2]
VERSION = os.environ.get('AYOS_VERSION', '3.1.41')
K = extract(JAVA)
K['search_hap'] = search(K['emojiKeywords'], 'hap')
src = open(JAVA, encoding='utf-8').read()

def bezier_args(name):
    m = re.search(name + r'\s*=\s*new android\.view\.animation\.PathInterpolator\(([^)]*)\)', src)
    return [float(x.strip().rstrip('f')) for x in m.group(1).split(',')]
K['openEase'] = bezier_args('PANEL_OPEN_EASE')
K['closeEase'] = bezier_args('PANEL_CLOSE_EASE')

js = open(os.path.join(HERE, 'scenes.js'), encoding='utf-8').read()
FONTS = os.path.join(os.path.dirname(os.path.abspath(JAVA)), '..', '..', '..', '..', 'assets', 'fonts')
faces = ''
for wt, fn in [(400, 'SFPRODISPLAYREGULAR.OTF'), (500, 'SFPRODISPLAYMEDIUM.OTF'), (700, 'SFPRODISPLAYBOLD.OTF')]:
    data = base64.b64encode(open(os.path.join(FONTS, fn), 'rb').read()).decode()
    faces += "@font-face{font-family:SFPD;font-weight:%d;src:url(data:font/otf;base64,%s) format('opentype')}\n" % (wt, data)

PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Keyboard / emoji panel: zoom and blur switch (footer blur proposal, v%(ver)s)</title>
<style>
%(faces)s
:root{color-scheme:light dark}
body{margin:0;padding:16px;font:14px/1.4 -apple-system,system-ui,"Segoe UI",Roboto,sans-serif;background:#e4e6eb;color:#1c1c1e}
.card{max-width:560px;margin:0 auto;background:#f7f7f9;border-radius:18px;padding:16px}
h1{font-size:17px;margin:0 0 4px}
.sub{color:#6c6c70;font-size:12.5px;margin-bottom:12px}
.stage{background:#dfe2e8;border-radius:14px;padding:10px}
canvas.main{display:block;width:100%%;height:auto;border-radius:12px}
.row{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;align-items:center}
button{font:inherit;border:0;border-radius:10px;padding:9px 14px;background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.12);cursor:pointer}
button.primary{background:#0a7aff;color:#fff}
button:disabled{opacity:.45;cursor:default}
input[type=range]{flex:1;min-width:160px}
.readout{font-variant-numeric:tabular-nums;font-size:13px;background:#fff;border-radius:10px;padding:8px 10px;margin-top:10px}
.phase{font-weight:600}
h2{font-size:14px;margin:18px 0 8px}
.strip{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}
.cell{background:#fff;border-radius:10px;padding:4px;font-size:10.5px;font-variant-numeric:tabular-nums;cursor:pointer}
.cell canvas{width:100%%;height:auto;display:block;border-radius:6px}
.cell.now{outline:2px solid #0a7aff}
.note{color:#6c6c70;font-size:12px;margin-top:12px}
</style></head><body>
<div class="card">
  <h1>Keyboard and emoji panel: switch, frame by frame</h1>
  <div class="sub">DRAFT, TypeFlow v%(ver)s, footer blur proposal (no source change). The panels run under the footer. Footer: now = one flat
  blur band with a hard top edge. Footer: progressive = the clipboard's own bottom blur (sharp, mid and far layers with the same fade)
  applied to the footer's height, live over whatever is underneath. The footer buttons stay sharp.</div>
  <div class="stage"><canvas class="main" id="main"></canvas></div>
  <div class="row">
    <button class="primary" id="btnOpen">Open emoji</button>
    <button id="btnClose">Close emoji</button>
    <button id="btnPause" disabled>Pause</button>
    <button id="btnPrev" disabled>&#9664; frame</button>
    <button id="btnNext" disabled>frame &#9654;</button>
    <button id="btnDark">Dark</button>
    <button id="btnFooterNow">Footer: now (band)</button>
    <button id="btnFooterProg" class="primary">Footer: progressive</button>
  </div>
  <div class="row"><input type="range" id="seek" min="0" max="0" value="0" step="1" disabled></div>
  <div class="readout" id="readout">The keyboard panel is the default. Press Open emoji.</div>
  <h2>Open emoji: every frame</h2>
  <div class="strip" id="stripOpen"></div>
  <h2>Close emoji: every frame</h2>
  <div class="strip" id="stripClose"></div>
  <div class="note">Frames are rendered on demand and cached. The window and the header are drawn from the same clock as the panels.</div>
</div>
<script>const K = %(K)s;
%(js)s
</script>
<script>
// ---- the controller: every frame is drawn from the same helpers as renderCard (scenes.js)
const GEO = emojiGeo();
const SUG_Y = APP_H + PAD_T;                                  // top of the header zone at rest
const KB_TOP = SUG_Y + SUG_H, KB_BOT = KB_TOP + 4 * KEY_H;    // keyboard body: top and bottom (its footer top)
const EM_TOP = SUG_Y + GEO.top;                               // emoji body top at rest (header zone is taller)
const EM_BOT = EM_TOP + GEO.row * K.EMOJI_ROWS + GEO.cat;     // emoji body bottom = the footer top
const FOOT_Y = EM_BOT;                                        // the universal footer: fixed in every frame
const OVERLAP = 0;                                           // 0 = the panels stay exactly where they were (no shift under the footer)
const BODY_BOT = FOOT_Y + OVERLAP;
const COL_BOT = FOOT_Y + ACC_H;                             // the window's bottom: content may run all the way under the footer's blur                           // where the panels' content ends (under the footer's blur)                                  // panel content runs this far under the footer (the footer blurs it)
const D_KB = FOOT_Y - KB_BOT;                                 // the keyboard window starts this much lower
const CARD_H_ALL = Math.round(FOOT_Y + ACC_H);                // the card is the emoji window's full height
const OPEN_MS = K.PANEL_OPEN_MS, CLOSE_MS = K.PANEL_CLOSE_MS;
const openEase = cubicBezier(...K.openEase), closeEase = cubicBezier(...K.closeEase);
const SAMPLE_WORDS = ['I', 'The', 'To'];
const lerp = (a, b, t) => a + (b - a) * t;

function cubicBezier(x1, y1, x2, y2) {   // CSS / PathInterpolator cubic-bezier: solve x(s) = t, return y(s)
  const bz = (s, a, b) => 3 * (1 - s) * (1 - s) * s * a + 3 * (1 - s) * s * s * b + s * s * s;
  return t => {
    t = Math.max(0, Math.min(1, t));
    let lo = 0, hi = 1, s = t;
    for (let i = 0; i < 40; i++) {
      const x = bz(s, x1, x2);
      if (Math.abs(x - t) < 1e-7) break;
      if (x < t) lo = s; else hi = s;
      s = (lo + hi) / 2;
    }
    return bz(s, y1, y2);
  };
}

// The bottom zone of the emoji list only (it melts into the category bar); the header has no top zone.
function composeBottom(ctx, content, rx, ry, w, h, zb) {
  const sm = t => { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); };
  const alpha = (k, d) => k === 0 ? 1 - sm(d / .7) : k === 1 ? (d < .5 ? sm(d / .5) : 1 - sm((d - .5) / .5)) : .94 * sm((d - .2) / .8);
  ctx.save(); ctx.beginPath(); ctx.rect(rx, ry, w, h - zb); ctx.clip(); ctx.drawImage(content, rx, ry); ctx.restore();
  const y0 = h - zb, y1 = h, hz = Math.ceil(y1 - y0);
  [[0, 0], [1, dp(5)], [2, dp(15)]].forEach(([k, rad]) => {
    const L = mkCanvas(w, hz), g = L.getContext('2d');
    g.filter = rad ? `blur(${rad}px)` : 'none'; g.drawImage(content, 0, -y0); g.filter = 'none';
    const gr = g.createLinearGradient(0, 0, 0, hz);
    for (let i = 0; i <= 16; i++) { const p = i / 16; gr.addColorStop(p, `rgba(0,0,0,${alpha(k, p).toFixed(4)})`); }
    g.globalCompositeOperation = 'destination-in'; g.fillStyle = gr; g.fillRect(0, 0, w, hz);
    ctx.drawImage(L, rx, ry + y0);
  });
}

// ---- the frame model (v3.1.41 draft 2). Two groups, fixed layering: the EMOJI group is always on top, the
// KEYBOARD group (keyboard panel + suggestion bar) is always underneath.
//   yE : emoji group offset (0 = at rest, 1 = fully below the footer top)
//   z  : keyboard group zoom and blur progress (0 = at rest, 1 = zoomed out and blurred)
//   e  : window height progress; the window grows and shrinks with the emoji group, so e = 1 - yE
function frameModel(kind, u) {
  // strictly one after the other: the first half moves one group, the second half the other
  if (kind === 'open') {
    const z = closeEase(Math.min(1, u / 0.5));                  // keyboard group zooms out and blurs first
    const yE = 1 - openEase(Math.max(0, (u - 0.5) / 0.5));       // then the emoji group rises
    return { yE, e: 1 - yE, z };
  }
  const yE = closeEase(Math.min(1, u / 0.5));                    // close: the emoji group drops first
  const z = 1 - openEase(Math.max(0, (u - 0.5) / 0.5));          // then the keyboard group zooms back in
  return { yE, e: 1 - yE, z };
}

// Window geometry for progress m. The footer top (FOOT_Y) is fixed. The keyboard group follows the window's body;
// the emoji group's top is the body top when at rest and moves down to the footer top when it leaves.
function windowState(m) {
  const bodyTop = lerp(KB_TOP + D_KB, EM_TOP, m.e);            // the window grows upward, the body top rises
  const zoneH = lerp(SUG_H, GEO.top, m.e);                     // header zone height
  const zoneTop = bodyTop - zoneH;                             // header zone top (the suggestion bar sits here)
  const colTop = zoneTop - PAD_T;                              // top of the keyboard window
  // the emoji group's own top edge is the search capsule's top: at rest it is above the body top by the capsule gap,
  // and it leaves through the footer top, so the capsule, grid and category bar all leave together
  const gap = GEO.top - GEO.pillTop;                           // capsule top to grid top
  const groupTop = lerp(bodyTop - gap, COL_BOT, m.yE);
  const emTop = groupTop + gap;                                // grid top
  return { m, bodyTop, zoneH, zoneTop, colTop, emTop, groupTop, kbTop: bodyTop, footY: FOOT_Y };
}

// KEYBOARD GROUP: the suggestion bar and the keyboard panel, zoomed out and blurred together.
function drawKeyboardGroup(ctx, st, S, x0, w) {
  // the keyboard group never moves with the header: it is always at its rest place (the keyboard window at rest)
  const z = S.m.z, scale = 1 - 0.12 * z;
  const zoneTop = SUG_Y + D_KB, keysTop = KB_TOP + D_KB + OVERLAP;
  const pivotX = W / 2, pivotY = (zoneTop + keysTop + 4 * KEY_H) / 2;   // one pivot for the whole group
  ctx.save();
  ctx.beginPath(); ctx.rect(0, zoneTop - PAD_T, W, Math.max(0, COL_BOT - (zoneTop - PAD_T))); ctx.clip();
  if (z > 0.001) {
    ctx.translate(pivotX, pivotY); ctx.scale(scale, scale); ctx.translate(-pivotX, -pivotY);
    ctx.filter = 'blur(' + (z * 12).toFixed(2) + 'px)';
  }
  drawSuggestionWords(ctx, st, x0, w, zoneTop, SAMPLE_WORDS);
  rowsOf(st, keysTop).forEach(row => row.forEach(rc => {
    if (rc.key.type === T.T_SPACER) return;
    drawKeyView(ctx, st, rc.key, rc.x, rc.y, rc.w, rc.h, {});
  }));
  ctx.filter = 'none';
  ctx.restore();
}

// EMOJI GROUP: the search capsule, the emoji grid and the category bar, always on top; the group moves as one.
function drawEmojiGroup(ctx, st, S, x0, w, grid) {
  const top = S.emTop + OVERLAP, hh = GEO.top + GEO.row * K.EMOJI_ROWS + GEO.cat;
  ctx.save();
  ctx.beginPath(); ctx.rect(0, S.colTop, W, Math.max(0, COL_BOT - S.colTop)); ctx.clip();
  // the search capsule belongs to the emoji group: it sits at the same offset from the grid top at every frame
  const pm = dp(K.EMOJI_PILL_MARGIN_DP), pillY = S.groupTop;
  drawSearchPill(ctx, st, x0 + pm, pillY, x0 + w - pm, pillY + GEO.pillH, '');
  // grid rows, with the bottom blur under the category bar; never drawn below the footer top
  const content = mkCanvas(w, hh), cc = content.getContext('2d');
  drawEmojiGrid(cc, st, grid, 0, w, GEO.top, false);
  const gridEnd = top + GEO.row * K.EMOJI_ROWS;
  ctx.save();
  ctx.beginPath(); ctx.rect(0, S.colTop, W, Math.max(0, Math.min(gridEnd, COL_BOT) - S.colTop)); ctx.clip();
  composeBottom(ctx, content, x0, top - GEO.top, w, hh, GEO.cat + GEO.overlap);
  ctx.restore();
  // category bar: directly under the grid, part of the group
  const catY = gridEnd;
  const sel = selectedCat(grid, 0, w), abc = fn(T.T_TO_LETTERS, 'ABC', 1); abc.textDp = 16.5;
  const abcW = textW(dp(16.5), 400, 'ABC') / D + 2 * K.EMOJI_BAR_PAD_DP, delW = K.DEL_ICON_W_DP + 2 * K.EMOJI_BAR_PAD_DP, viewW = K.EMOJI_BAR_TOTAL_DP - abcW - delW;
  const bar = rowRects([abc, fn(T.T_SPACER, '', 1), ic(T.T_DELETE, ICON, 1)].map((k, i) => (k.weight = [abcW, viewW, delW][i], k)), x0, w, catY, GEO.cat);
  drawKeyView(ctx, st, bar[0].key, bar[0].x, bar[0].y, bar[0].w, bar[0].h, { plain: true });
  drawKeyView(ctx, st, bar[2].key, bar[2].x, bar[2].y, bar[2].w, bar[2].h, { plain: true });
  const iv = bar[1], d = Math.min(dp(K.CAT_SEL_DP), GEO.cat - dp(2));
  for (let i = 0; i < K.catIcons.length; i++) {
    const pxPerDp = iv.w / viewW, shift = (delW - abcW) / 2;
    const cx = iv.x + iv.w / 2 + pxPerDp * (shift + K.CAT_PITCH_DP * (i - K.CAT_MID)), cy = catY + GEO.cat / 2, on = i === sel;
    if (on) glassCircle(ctx, cx, cy, d / 2, st.dark);
    drawCatIcon(ctx, i, on, cx, cy, dp(K.CAT_ICON_DP), on ? st.colors.text : scaleAlpha(st.colors.text, .82));
  }
  ctx.restore();
}

// FOOTER BLUR (preview of the proposal). 'now' = the current v3.1.41 footer: the blur zone is only the footer's own
// height, so it reads as a band. 'progressive' = the proposal: the zone is FADE_SCALE x the footer height, strongest at
// the screen edge and fading to sharp at the top of the fade, so the content flows under the footer.
let footerMode = 'progressive', fadeScale = 2.6, footerBlurPx = 22;
function footerFade01(t) { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); }
function applyFooterBlur(ctx, S, isDark) {
  // The footer blur, fully strong at the screen edge and fading to sharp at the top of the footer.
  // pr = 0 at the footer's top edge (sharp), pr = 1 at the screen edge (strongest). Each blur layer is composited
  // over the live frame, so content sliding under the footer is blurred as it passes.
  const colBottom = FOOT_Y + ACC_H;
  const zoneTop = colBottom - ACC_H;                   // the blur is exactly the footer's height
  const sm = t => { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); };
  const src = ctx.canvas;                              // what is drawn underneath, this frame
  // [blur radius, strength at pr]: the far layer carries the strength at the bottom; the mid layer adds body
  const levels = footerMode === 'now'
    ? [{ px: footerBlurPx, at: () => 1, flat: true }]  // now: one flat band with a hard top edge
    : [{ px: 6, at: pr => 0.6 * sm(pr) }, { px: footerBlurPx, at: pr => sm(pr) }];
  ctx.save();
  ctx.beginPath(); ctx.rect(0, zoneTop, W, ACC_H); ctx.clip();
  levels.forEach(lv => {
    const L = mkCanvas(W, CARD_H_ALL), g = L.getContext('2d');
    g.filter = 'blur(' + dp(lv.px).toFixed(2) + 'px)';
    g.drawImage(src, 0, 0); g.filter = 'none';
    const M = mkCanvas(W, CARD_H_ALL), mg = M.getContext('2d');
    const gr = mg.createLinearGradient(0, zoneTop, 0, colBottom);
    for (let i = 0; i <= 16; i++) {
      const pr = i / 16;
      const al = lv.flat ? 1 : lv.at(pr);
      gr.addColorStop(pr, 'rgba(0,0,0,' + Math.min(1, al).toFixed(4) + ')');
    }
    mg.fillStyle = gr; mg.fillRect(0, zoneTop, W, ACC_H);
    g.globalCompositeOperation = 'destination-in';
    g.drawImage(M, 0, 0);
    ctx.drawImage(L, 0, 0);
  });
  // the themed fade: a bar half the footer's height, light in light mode and dark in dark mode,
  // strongest at the screen edge and fading out upward
  if (footerMode !== 'now') {
    const barTop = colBottom - ACC_H / 2;
    const F = mkCanvas(W, CARD_H_ALL), fg = F.getContext('2d');
    const rgb = isDark ? '30,30,32' : '246,246,248';
    const fade = fg.createLinearGradient(0, barTop, 0, colBottom);
    for (let i = 0; i <= 16; i++) {
      const pr = i / 16;
      fade.addColorStop(pr, 'rgba(' + rgb + ',' + (0.92 * sm(pr)).toFixed(4) + ')');
    }
    fg.fillStyle = fade; fg.fillRect(0, barTop, W, colBottom - barTop);
    ctx.drawImage(F, 0, 0);
  }
  ctx.restore();
}

function switchFrame(m, isDark) {
  const st = Object.assign({}, STATE_BASE, { layer: T.LAYER_LETTERS });
  st.dark = isDark; st.colors = mkColors(isDark);
  const S = windowState(m), x0 = PAD_X, w = W - 2 * PAD_X;
  const cv = mkCanvas(W, CARD_H_ALL), ctx = cv.getContext('2d');
  const bg = mkCanvas(W, CARD_H_ALL);
  drawApp(bg.getContext('2d'), isDark, true, CARD_H_ALL);
  ctx.save();
  const clipP = new Path2D(); clipP.roundRect(0, 0, W, CARD_H_ALL, dp(28)); ctx.clip(clipP);
  ctx.drawImage(bg, 0, 0);
  const panelBottom = FOOT_Y + ACC_H + dp(80);      // the panel runs past the window bottom: no rounded card corners at the footer
  drawPanelBackground(ctx, st, bg, S.colTop, panelBottom - S.colTop);
  const grid = buildGrid(RECENTS);
  drawKeyboardGroup(ctx, st, S, x0, w);     // bottom layer, always
  drawEmojiGroup(ctx, st, S, x0, w, grid);  // top layer, always
  applyFooterBlur(ctx, S, isDark);          // the footer's blur and themed fade, over whatever is underneath
  drawAccessory(ctx, st, x0, w, S.footY);   // the universal footer: fixed, sharp
  ctx.restore();
  return { cv, S };
}

// ---- timeline: one clock per direction, sampled at PREVIEW_FPS (90 fps)
const PREVIEW_FPS = 90;
function timeline(kind) {
  const ms = kind === 'open' ? OPEN_MS : CLOSE_MS, n = Math.ceil(ms * PREVIEW_FPS / 1000), out = [];
  for (let i = 0; i <= n; i++) {
    const t = Math.min(ms, i * 1000 / PREVIEW_FPS), u = t / ms;
    out.push({ i, t, u, m: frameModel(kind, u) });
  }
  return out;
}
const TL = { open: timeline('open'), close: timeline('close') };

const mainEl = document.getElementById('main');
const mctx = mainEl.getContext('2d');
const seek = document.getElementById('seek');
const readout = document.getElementById('readout');
let dark = false, runKind = null, runN = 0, idx = 0, playing = false, rafId = 0;
const cache = {};

function frameCanvas(kind, i) {
  const key = kind + ':' + i + ':' + (dark ? 'd' : 'l') + ':' + footerMode;
  if (cache[key]) return cache[key];
  const c = switchFrame(TL[kind][i].m, dark).cv;
  cache[key] = c;
  return c;
}

function phaseName(kind, fr) {
  if (kind === 'open') {
    if (fr.u < 0.5) return 'Opening, step 1: the keyboard group stays in place and zooms out and blurs; the emoji panel waits';
    if (fr.u < 1) return 'Opening, step 2: the emoji group rises from the bottom over the blurred keyboard; the header grows';
    return 'Opening: emoji panel at rest on top; keyboard group zoomed out and blurred underneath';
  }
  if (fr.u < 0.5) return 'Closing, step 1: the emoji group drops to the bottom; the keyboard group waits, zoomed out';
  if (fr.u < 1) return 'Closing, step 2: the keyboard group zooms back in, in place, and loses its blur';
  return 'Closing: keyboard panel and suggestion bar back at rest';
}

function showFrame(i) {
  if (!runKind) return;
  idx = Math.max(0, Math.min(runN - 1, i));
  const img = frameCanvas(runKind, idx);
  mainEl.width = img.width; mainEl.height = img.height;
  mctx.drawImage(img, 0, 0);
  seek.value = idx;
  document.querySelectorAll('.cell.now').forEach(c => c.classList.remove('now'));
  const cell = document.querySelector('[data-run="' + runKind + '"][data-f="' + idx + '"]');
  if (cell) cell.classList.add('now');
  const fr = TL[runKind][idx], S = windowState(fr.m);
  const dp1 = v => ((v - APP_H) / D).toFixed(1);
  readout.innerHTML = '<span class="phase">' + phaseName(runKind, fr) + '</span><br>' +
    'Frame ' + idx + ' / ' + (runN - 1) + ' (' + PREVIEW_FPS + ' fps) &middot; t = ' + Math.round(fr.t) + ' ms' +
    '<br>window top ' + dp1(S.colTop) + ' dp &middot; header zone ' + (S.zoneH / D).toFixed(1) + ' dp &middot; footer fixed at ' + dp1(S.footY) + ' dp' +
    '<br>keyboard group zoom ' + Math.round(fr.m.z * 12) + '%% &middot; blur ' + (fr.m.z * 12).toFixed(1) + ' px &middot; emoji top ' + dp1(S.emTop) + ' dp';
  document.getElementById('btnPrev').disabled = idx === 0;
  document.getElementById('btnNext').disabled = idx === runN - 1;
}
function stop() { playing = false; cancelAnimationFrame(rafId); document.getElementById('btnPause').textContent = 'Pause'; }
function play() {
  playing = true; document.getElementById('btnPause').textContent = 'Pause';
  const start = performance.now() - (idx / PREVIEW_FPS) * 1000;
  const tick = now => {
    if (!playing) return;
    const f = Math.floor((now - start) / (1000 / PREVIEW_FPS));
    if (f >= runN - 1) { showFrame(runN - 1); stop(); return; }
    showFrame(f); rafId = requestAnimationFrame(tick);
  };
  rafId = requestAnimationFrame(tick);
}
function setRun(kind) {
  runKind = kind; runN = TL[kind].length;
  seek.min = 0; seek.max = runN - 1; seek.disabled = false;
  document.getElementById('btnPause').disabled = false;
  stop(); showFrame(0);
}
function buildStrip(kind, elId) {
  const el = document.getElementById(elId); el.innerHTML = '';
  TL[kind].forEach((fr, i) => {
    const cell = document.createElement('div');
    cell.className = 'cell'; cell.dataset.run = kind; cell.dataset.f = i;
    const img = frameCanvas(kind, i);
    const c = mkCanvas(img.width, img.height); c.getContext('2d').drawImage(img, 0, 0);
    cell.appendChild(c);
    cell.insertAdjacentText('beforeend', i + '  ' + Math.round(fr.t) + ' ms');
    cell.onclick = () => { setRun(kind); stop(); showFrame(i); };
    el.appendChild(cell);
  });
}
document.getElementById('btnOpen').onclick = () => { setRun('open'); play(); };
document.getElementById('btnClose').onclick = () => { setRun('close'); play(); };
document.getElementById('btnPause').onclick = () => { if (playing) stop(); else if (runKind) play(); };
document.getElementById('btnPrev').onclick = () => { stop(); showFrame(idx - 1); };
document.getElementById('btnNext').onclick = () => { stop(); showFrame(idx + 1); };
seek.oninput = () => { stop(); showFrame(+seek.value); };
function setFooter(mode) {
  footerMode = mode;
  document.getElementById('btnFooterNow').className = mode === 'now' ? 'primary' : '';
  document.getElementById('btnFooterProg').className = mode === 'progressive' ? 'primary' : '';
  for (const k of Object.keys(cache)) delete cache[k];
  buildStrip('open', 'stripOpen'); buildStrip('close', 'stripClose');
  if (runKind) showFrame(idx);
}
document.getElementById('btnFooterNow').onclick = () => setFooter('now');
document.getElementById('btnFooterProg').onclick = () => setFooter('progressive');
document.getElementById('btnDark').onclick = () => {
  dark = !dark; for (const k of Object.keys(cache)) delete cache[k];
  document.getElementById('btnDark').textContent = dark ? 'Light' : 'Dark';
  buildStrip('open', 'stripOpen'); buildStrip('close', 'stripClose');
  if (runKind) showFrame(idx);
};
// first paint: the keyboard panel at rest (the default)
{
  const first = switchFrame({ e: 0, yE: 1, z: 0 }, false).cv;   // keyboard at rest, footer as selected
  mainEl.width = first.width; mainEl.height = first.height; mctx.drawImage(first, 0, 0);
}
buildStrip('open', 'stripOpen'); buildStrip('close', 'stripClose');
</script>
</body></html>
"""

html = PAGE % {'ver': VERSION, 'faces': faces, 'K': json.dumps(K, ensure_ascii=False), 'js': js}
open(OUT, 'w', encoding='utf-8').write(html)
print('wrote', OUT, len(html), 'bytes')
