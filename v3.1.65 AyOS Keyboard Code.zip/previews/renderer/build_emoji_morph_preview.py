"""Builds the frame-by-frame preview of the emoji panel's open and close (v3.1.41).

The keyboard, the emoji panel and the universal header / footer are drawn by the same Canvas code as the keyboard
sheets (scenes.js, a port of KeyboardService.java's drawing). Every number comes from KeyboardService.java
(extract_from_java.py), including the morph timing (EMOJI_MORPH_OPEN_MS / EMOJI_MORPH_CLOSE_MS) and the easing
(PANEL_OPEN_EASE / PANEL_CLOSE_EASE). Usage:
    python3 build_emoji_morph_preview.py ../../app/src/main/java/com/custom/keyboard/KeyboardService.java out.html
"""
import base64, json, os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from extract_from_java import extract, search

JAVA, OUT = sys.argv[1], sys.argv[2]
VERSION = os.environ.get('AYOS_VERSION', '3.1.41')
K = extract(JAVA)
K['search_hap'] = search(K['emojiKeywords'], 'hap')

src = open(JAVA, encoding='utf-8').read()
def bezier_args(name):
    m = re.search(name + r'\s*=\s*new android\.view\.animation\.PathInterpolator\(([^)]*)\)', src)
    return [float(x.strip().rstrip('f')) for x in m.group(1).split(',')]
K['openEase'] = bezier_args('PANEL_OPEN_EASE')
K['closeEase'] = bezier_args('PANEL_CLOSE_EASE')

js = open(os.path.join(HERE, 'scenes.js'), encoding='utf-8').read()
FONTS = os.path.join(os.path.dirname(os.path.abspath(JAVA)), '..', '..', '..', '..', 'assets', 'fonts')
faces = ''
for wt, fn in [(400, 'SFPRODISPLAYREGULAR.OTF'), (500, 'SFPRODISPLAYMEDIUM.OTF'), (700, 'SFPRODISPLAYBOLD.OTF')]:
    data = base64.b64encode(open(os.path.join(FONTS, fn), 'rb').read()).decode()
    faces += "@font-face{font-family:SFPD;font-weight:%d;src:url(data:font/otf;base64,%s) format('opentype')}\n" % (wt, data)

PAGE = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Emoji panel: open and close, frame by frame (v%(ver)s)</title>
<style>
%(faces)s
:root{color-scheme:light dark}
body{margin:0;padding:16px;font:14px/1.4 -apple-system,system-ui,"Segoe UI",Roboto,sans-serif;background:#e4e6eb;color:#1c1c1e}
.card{max-width:560px;margin:0 auto;background:#f7f7f9;border-radius:18px;padding:16px}
h1{font-size:17px;margin:0 0 4px}
.sub{color:#6c6c70;font-size:12.5px;margin-bottom:12px}
.stage{background:#dfe2e8;border-radius:14px;padding:10px}
canvas.main{display:block;width:100%%;height:auto;border-radius:12px}
.row{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;align-items:center}
button{font:inherit;border:0;border-radius:10px;padding:9px 14px;background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.12);cursor:pointer}
button.primary{background:#0a7aff;color:#fff}
button:disabled{opacity:.45;cursor:default}
input[type=range]{flex:1;min-width:160px}
.readout{font-variant-numeric:tabular-nums;font-size:13px;background:#fff;border-radius:10px;padding:8px 10px;margin-top:10px}
.phase{font-weight:600}
h2{font-size:14px;margin:18px 0 8px}
.strip{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}
.cell{background:#fff;border-radius:10px;padding:4px;font-size:10.5px;font-variant-numeric:tabular-nums;cursor:pointer}
.cell canvas{width:100%%;height:auto;display:block;border-radius:6px}
.cell.now{outline:2px solid #0a7aff}
.note{color:#6c6c70;font-size:12px;margin-top:12px}
</style></head><body>
<div class="card">
  <h1>Emoji panel: open and close, frame by frame</h1>
  <div class="sub">TypeFlow v%(ver)s. Drawn by the keyboard's own drawing code: the numbers come from KeyboardService.java and
  the morph timing and easing are the ones the code defines (EMOJI_MORPH_OPEN_MS / CLOSE, PANEL_OPEN_EASE / CLOSE). The header
  (suggestion bar or Search Emoji pill) and the content panel move together; the footer stays under the content. Scale: the 390 dp card.</div>
  <div class="stage"><canvas class="main" id="main"></canvas></div>
  <div class="row">
    <button class="primary" id="btnOpen">Open</button>
    <button id="btnClose">Close</button>
    <button id="btnPause" disabled>Pause</button>
    <button id="btnPrev" disabled>&#9664; frame</button>
    <button id="btnNext" disabled>frame &#9654;</button>
    <button id="btnDark">Dark</button>
  </div>
  <div class="row"><input type="range" id="seek" min="0" max="0" value="0" step="1" disabled></div>
  <div class="readout" id="readout">Press Open or Close. Frames run at 60 fps.</div>
  <h2>Open: every frame</h2>
  <div class="strip" id="stripOpen"></div>
  <h2>Close: every frame</h2>
  <div class="strip" id="stripClose"></div>
  <div class="note">Frames are rendered on demand and cached. Opening grows from the keyboard height to the emoji height; closing runs the same geometry backwards.</div>
</div>
<script>const K = %(K)s;
%(js)s
</script>
<script>
// ---- the controller: every frame is drawn by morphFrame(), built from the same helpers as renderCard
const GEO = emojiGeo();
const SUG_Y = APP_H + PAD_T;                                  // top of the header zone
const KB_TOP = SUG_Y + SUG_H, KB_BOT = KB_TOP + 4 * KEY_H;    // keyboard: keys top and footer top
const EM_TOP = SUG_Y + GEO.top;                               // emoji: grid top (header zone is taller)
const EM_BOT = EM_TOP + GEO.row * K.EMOJI_ROWS + GEO.cat;     // emoji: category bar bottom = footer top
const CARD_H_ALL = Math.round(EM_BOT + ACC_H);                // the emoji panel is the tallest state
const OPEN_MS = K.EMOJI_MORPH_OPEN_MS, CLOSE_MS = K.EMOJI_MORPH_CLOSE_MS;
const openEase = cubicBezier(...K.openEase), closeEase = cubicBezier(...K.closeEase);
const SAMPLE_WORDS = ['I', 'The', 'To'];

function cubicBezier(x1, y1, x2, y2) {   // CSS / PathInterpolator cubic-bezier: solve x(s) = t, return y(s)
  const bz = (s, a, b) => 3 * (1 - s) * (1 - s) * s * a + 3 * (1 - s) * s * s * b + s * s * s;
  return t => {
    t = Math.max(0, Math.min(1, t));
    let lo = 0, hi = 1, s = t;
    for (let i = 0; i < 40; i++) {
      const x = bz(s, x1, x2);
      if (Math.abs(x - t) < 1e-7) break;
      if (x < t) lo = s; else hi = s;
      s = (lo + hi) / 2;
    }
    return bz(s, y1, y2);
  };
}
const lerp = (a, b, t) => a + (b - a) * t;

const mainEl = document.getElementById('main');
const mctx = mainEl.getContext('2d');
const seek = document.getElementById('seek');
const readout = document.getElementById('readout');
let dark = false, runKind = null, runN = 0, idx = 0, playing = false, rafId = 0;
const cache = {};

// The state at morph progress e (0 = keyboard, 1 = emoji). The keyboard window is anchored to the bottom of the
// screen (as an input method is), so the footer never moves: it stays at EM_BOT. The window grows upward, so the
// header's top edge rises, the header zone grows from SUG_H to the emoji top area, and the content panel's top
// edge moves up with it. The keys and the category bar sit on the footer, bottom-aligned.
function morphState(e) {
  const d = EM_BOT - KB_BOT;                       // how much higher the emoji window starts than the keyboard one
  const cTop = lerp(KB_TOP + d, EM_TOP, e);        // content (keys or grid) top: top-anchored inside the content box
  const cBot = EM_BOT;                             // content bottom = footer top, fixed
  const zoneH = lerp(SUG_H, GEO.top, e);           // header zone height
  const zoneTop = cTop - zoneH;                    // header zone top
  const colTop = zoneTop - PAD_T;                  // top of the keyboard window
  return { e, cTop, cBot, kbA: 1 - e, emA: e, zoneTop, zoneH, colTop, panelBottom: EM_BOT + ACC_H };
}

// The bottom zone of composeFast only: the emoji list melts into the category bar. The header has no top zone
// (v3.1.41: no progressive blur under the header in the emoji panel), so there is nothing to compose above the list.
function composeBottom(ctx, content, rx, ry, w, h, zb) {
  const sm = t => { t = Math.max(0, Math.min(1, t)); return t * t * (3 - 2 * t); };
  const alpha = (k, d) => k === 0 ? 1 - sm(d / .7) : k === 1 ? (d < .5 ? sm(d / .5) : 1 - sm((d - .5) / .5)) : .94 * sm((d - .2) / .8);
  ctx.save(); ctx.beginPath(); ctx.rect(rx, ry, w, h - zb); ctx.clip(); ctx.drawImage(content, rx, ry); ctx.restore();
  const y0 = h - zb, y1 = h, hz = Math.ceil(y1 - y0);
  [[0, 0], [1, dp(5)], [2, dp(15)]].forEach(([k, rad]) => {
    const L = mkCanvas(w, hz), g = L.getContext('2d');
    g.filter = rad ? `blur(${rad}px)` : 'none'; g.drawImage(content, 0, -y0); g.filter = 'none';
    const gr = g.createLinearGradient(0, 0, 0, hz);
    for (let i = 0; i <= 16; i++) { const p = i / 16; gr.addColorStop(p, `rgba(0,0,0,${alpha(k, p).toFixed(4)})`); }
    g.globalCompositeOperation = 'destination-in'; g.fillStyle = gr; g.fillRect(0, 0, w, hz);
    ctx.drawImage(L, rx, ry + y0);
  });
}
function morphFrame(e, isDark) {
  const st = Object.assign({}, STATE_BASE, { layer: T.LAYER_LETTERS });
  st.dark = isDark; st.colors = mkColors(isDark);
  const S = morphState(e), x0 = PAD_X, w = W - 2 * PAD_X;
  const cv = mkCanvas(W, CARD_H_ALL), ctx = cv.getContext('2d');
  const bg = mkCanvas(W, CARD_H_ALL);
  drawApp(bg.getContext('2d'), isDark, true, CARD_H_ALL);
  ctx.save();
  const clipP = new Path2D(); clipP.roundRect(0, 0, W, CARD_H_ALL, dp(28)); ctx.clip(clipP);
  ctx.drawImage(bg, 0, 0);
  drawPanelBackground(ctx, st, bg, S.colTop, S.panelBottom - S.colTop);

  // header zone: the suggestion words fade out as the Search Emoji pill fades in (no progressive blur here)
  if (S.kbA > 0.001) {
    ctx.save(); ctx.globalAlpha = S.kbA;
    drawSuggestionWords(ctx, st, x0, w, S.zoneTop, SAMPLE_WORDS);
    ctx.restore();
  }
  if (S.emA > 0.001) {
    const pm = dp(K.EMOJI_PILL_MARGIN_DP);
    ctx.save(); ctx.globalAlpha = S.emA;
    drawSearchPill(ctx, st, x0 + pm, S.zoneTop + GEO.pillTop, x0 + w - pm, S.zoneTop + GEO.pillTop + GEO.pillH, '');
    ctx.restore();
  }

  // keyboard keys: top-anchored, clipped by the bottom edge of the content panel
  if (S.kbA > 0.001) {
    ctx.save();
    ctx.beginPath(); ctx.rect(0, S.cTop, W, Math.max(0, S.cBot - S.cTop)); ctx.clip();
    ctx.globalAlpha = S.kbA;
    rowsOf(st, S.cTop).forEach(row => row.forEach(rc => {
      if (rc.key.type === T.T_SPACER) return;
      drawKeyView(ctx, st, rc.key, rc.x, rc.y, rc.w, rc.h, {});
    }));
    ctx.restore();
  }

  // emoji grid: top-anchored, revealed from the top as the panel grows; bottom blur under the category bar
  if (S.emA > 0.001) {
    const grid = buildGrid(RECENTS), hh = GEO.top + GEO.row * K.EMOJI_ROWS + GEO.cat;
    const content = mkCanvas(w, hh), cc = content.getContext('2d');
    drawEmojiGrid(cc, st, grid, 0, w, GEO.top, false);
    ctx.save();
    ctx.beginPath(); ctx.rect(0, S.cTop, W, Math.max(0, S.cBot - GEO.cat - S.cTop)); ctx.clip();
    ctx.globalAlpha = S.emA;
    composeBottom(ctx, content, x0, S.cTop - GEO.top, w, hh, GEO.cat + GEO.overlap);
    ctx.restore();

    // category bar: bottom-anchored (it sinks with the panel's bottom edge)
    const catY = S.cBot - GEO.cat;
    ctx.save(); ctx.globalAlpha = S.emA;
    const sel = selectedCat(grid, 0, w), abc = fn(T.T_TO_LETTERS, 'ABC', 1); abc.textDp = 16.5;
    const abcW = textW(dp(16.5), 400, 'ABC') / D + 2 * K.EMOJI_BAR_PAD_DP, delW = K.DEL_ICON_W_DP + 2 * K.EMOJI_BAR_PAD_DP, viewW = K.EMOJI_BAR_TOTAL_DP - abcW - delW;
    const bar = rowRects([abc, fn(T.T_SPACER, '', 1), ic(T.T_DELETE, ICON, 1)].map((k, i) => (k.weight = [abcW, viewW, delW][i], k)), x0, w, catY, GEO.cat);
    drawKeyView(ctx, st, bar[0].key, bar[0].x, bar[0].y, bar[0].w, bar[0].h, { plain: true });
    drawKeyView(ctx, st, bar[2].key, bar[2].x, bar[2].y, bar[2].w, bar[2].h, { plain: true });
    const iv = bar[1], d = Math.min(dp(K.CAT_SEL_DP), GEO.cat - dp(2));
    for (let i = 0; i < K.catIcons.length; i++) {
      const pxPerDp = iv.w / viewW, shift = (delW - abcW) / 2;
      const cx = iv.x + iv.w / 2 + pxPerDp * (shift + K.CAT_PITCH_DP * (i - K.CAT_MID)), cy = catY + GEO.cat / 2, on = i === sel;
      if (on) glassCircle(ctx, cx, cy, d / 2, st.dark);
      drawCatIcon(ctx, i, on, cx, cy, dp(K.CAT_ICON_DP), on ? st.colors.text : scaleAlpha(st.colors.text, .82));
    }
    ctx.restore();
  }

  // footer: the universal footer, under the content panel's bottom edge
  drawAccessory(ctx, st, x0, w, S.cBot);
  ctx.restore();
  return cv;
}

// ---- timeline: one spring-free clock per direction, sampled at 60 fps
function timeline(kind) {
  const ms = kind === 'open' ? OPEN_MS : CLOSE_MS, n = Math.ceil(ms * 60 / 1000), out = [];
  for (let i = 0; i <= n; i++) {
    const t = Math.min(ms, i * 1000 / 60), u = t / ms;
    const e = kind === 'open' ? openEase(u) : 1 - closeEase(u);
    out.push({ i, t, u, e });
  }
  return out;
}
const TL = { open: timeline('open'), close: timeline('close') };

function frameCanvas(kind, i) {
  const key = kind + ':' + i + ':' + (dark ? 'd' : 'l');
  if (cache[key]) return cache[key];
  const fr = TL[kind][i];
  const c = morphFrame(fr.e, dark);
  cache[key] = c;
  return c;
}

function phaseName(kind, fr) {
  if (kind === 'open') {
    if (fr.u < 0.2) return 'Opening: the window grows upward; the header starts to rise, the footer stays fixed, the keys begin to fade';
    if (fr.u < 0.6) return 'Opening: the header keeps rising; the emoji grid is revealed from the top; the category bar sits on the footer';
    if (fr.u < 1) return 'Opening: the last rows settle into place';
    return 'Opening: at the emoji height';
  }
  if (fr.e > 0.8) return 'Closing: the header starts to drop; the grid is covered from the top; the category bar stays on the footer';
  if (fr.e > 0.3) return 'Closing: the window shrinks back down toward the keyboard height; the footer stays fixed';
  if (fr.e > 0.02) return 'Closing: the keys fade back in';
  return 'Closing: back at the keyboard height';
}

function showFrame(i) {
  if (!runKind) return;
  idx = Math.max(0, Math.min(runN - 1, i));
  const img = frameCanvas(runKind, idx);
  mainEl.width = img.width; mainEl.height = img.height;
  mctx.drawImage(img, 0, 0);
  seek.value = idx;
  document.querySelectorAll('.cell.now').forEach(c => c.classList.remove('now'));
  const cell = document.querySelector('[data-run="' + runKind + '"][data-f="' + idx + '"]');
  if (cell) cell.classList.add('now');
  const fr = TL[runKind][idx], S = morphState(fr.e);
  readout.innerHTML = '<span class="phase">' + phaseName(runKind, fr) + '</span><br>' +
    'Frame ' + idx + ' / ' + (runN - 1) + ' &middot; t = ' + Math.round(fr.t) + ' ms &middot; progress ' + fr.e.toFixed(3) +
    '<br>window top ' + ((S.colTop - APP_H) / D).toFixed(1) + ' dp &middot; header zone ' + (S.zoneH / D).toFixed(1) +
    ' dp &middot; content top ' + ((S.cTop - APP_H) / D).toFixed(1) + ' dp &middot; footer fixed at ' + ((S.cBot - APP_H) / D).toFixed(1) + ' dp';
  document.getElementById('btnPrev').disabled = idx === 0;
  document.getElementById('btnNext').disabled = idx === runN - 1;
}
function stop() { playing = false; cancelAnimationFrame(rafId); document.getElementById('btnPause').textContent = 'Pause'; }
function play() {
  playing = true; document.getElementById('btnPause').textContent = 'Pause';
  const start = performance.now() - (idx / 60) * 1000;
  const tick = now => {
    if (!playing) return;
    const f = Math.floor((now - start) / (1000 / 60));
    if (f >= runN - 1) { showFrame(runN - 1); stop(); return; }
    showFrame(f); rafId = requestAnimationFrame(tick);
  };
  rafId = requestAnimationFrame(tick);
}
function setRun(kind) {
  runKind = kind; runN = TL[kind].length;
  seek.min = 0; seek.max = runN - 1; seek.disabled = false;
  document.getElementById('btnPause').disabled = false;
  stop(); showFrame(0);
}
function buildStrip(kind, elId) {
  const el = document.getElementById(elId); el.innerHTML = '';
  TL[kind].forEach((fr, i) => {
    const cell = document.createElement('div');
    cell.className = 'cell'; cell.dataset.run = kind; cell.dataset.f = i;
    const img = frameCanvas(kind, i);
    const c = mkCanvas(img.width, img.height); c.getContext('2d').drawImage(img, 0, 0);
    cell.appendChild(c);
    cell.insertAdjacentText('beforeend', i + '  ' + Math.round(fr.t) + ' ms');
    cell.onclick = () => { setRun(kind); stop(); showFrame(i); };
    el.appendChild(cell);
  });
}
document.getElementById('btnOpen').onclick = () => { setRun('open'); play(); };
document.getElementById('btnClose').onclick = () => { setRun('close'); play(); };
document.getElementById('btnPause').onclick = () => { if (playing) stop(); else if (runKind) play(); };
document.getElementById('btnPrev').onclick = () => { stop(); showFrame(idx - 1); };
document.getElementById('btnNext').onclick = () => { stop(); showFrame(idx + 1); };
seek.oninput = () => { stop(); showFrame(+seek.value); };
document.getElementById('btnDark').onclick = () => {
  dark = !dark; for (const k of Object.keys(cache)) delete cache[k];
  document.getElementById('btnDark').textContent = dark ? 'Light' : 'Dark';
  buildStrip('open', 'stripOpen'); buildStrip('close', 'stripClose');
  if (runKind) showFrame(idx);
};
setRun('open'); stop(); showFrame(0); runKind = null;   // first paint: the keyboard at rest
readout.textContent = 'Press Open or Close. Frames run at 60 fps.';
buildStrip('open', 'stripOpen'); buildStrip('close', 'stripClose');
</script>
</body></html>
"""

html = PAGE % {'ver': VERSION, 'faces': faces, 'K': json.dumps(K, ensure_ascii=False), 'js': js}
open(OUT, 'w', encoding='utf-8').write(html)
print('wrote', OUT, len(html), 'bytes')
